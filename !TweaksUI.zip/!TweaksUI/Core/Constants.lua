-- TweaksUI Constants
-- Core constants and configuration values

local ADDON_NAME, TweaksUI = ...

-- Version info
TweaksUI.VERSION = "0.14.49"
TweaksUI.ADDON_NAME = ADDON_NAME

-- Build info
TweaksUI.BUILD_VERSION = select(4, GetBuildInfo())
TweaksUI.IS_MIDNIGHT = TweaksUI.BUILD_VERSION >= 120000

-- Module identifiers
TweaksUI.MODULE_IDS = {
    COOLDOWNS = "cooldowns",
    CHAT = "chat",
    ACTION_BARS = "actionBars",
    UNIT_FRAMES = "unitFrames",
    RESOURCE_BARS = "resourceBars",
    CAST_BARS = "castBars",
    NAMEPLATES = "nameplates",
}

-- Module display names (for UI)
TweaksUI.MODULE_NAMES = {
    [TweaksUI.MODULE_IDS.COOLDOWNS] = "Cooldown Trackers",
    [TweaksUI.MODULE_IDS.CHAT] = "Chat",
    [TweaksUI.MODULE_IDS.ACTION_BARS] = "Action Bars",
    [TweaksUI.MODULE_IDS.UNIT_FRAMES] = "Unit Frames",
    [TweaksUI.MODULE_IDS.RESOURCE_BARS] = "Resource Bars",
    [TweaksUI.MODULE_IDS.CAST_BARS] = "Cast Bars",
    [TweaksUI.MODULE_IDS.NAMEPLATES] = "Nameplates",
}

-- Module load order (dependencies should load first)
TweaksUI.MODULE_LOAD_ORDER = {
    TweaksUI.MODULE_IDS.COOLDOWNS,
    TweaksUI.MODULE_IDS.CHAT,
    TweaksUI.MODULE_IDS.CAST_BARS,
    TweaksUI.MODULE_IDS.RESOURCE_BARS,
    TweaksUI.MODULE_IDS.ACTION_BARS,
    TweaksUI.MODULE_IDS.UNIT_FRAMES,
    TweaksUI.MODULE_IDS.NAMEPLATES,
}

-- Events
TweaksUI.EVENTS = {
    MODULE_ENABLED = "TweaksUI_ModuleEnabled",
    MODULE_DISABLED = "TweaksUI_ModuleDisabled",
    SETTINGS_CHANGED = "TweaksUI_SettingsChanged",
    PROFILE_CHANGED = "TweaksUI_ProfileChanged",
}

-- Default colors
TweaksUI.COLORS = {
    PRIMARY = { r = 0, g = 1, b = 0 },       -- Green (TweaksUI brand)
    SECONDARY = { r = 0.5, g = 0.5, b = 0.5 },
    WARNING = { r = 1, g = 0.8, b = 0 },
    ERROR = { r = 1, g = 0.2, b = 0.2 },
    SUCCESS = { r = 0, g = 1, b = 0 },
}

-- Chat prefix for messages
TweaksUI.CHAT_PREFIX = "|cff00ff00TweaksUI:|r "

-- Slash commands
TweaksUI.SLASH_COMMANDS = {
    "/tweaksui",
    "/tui",
}
