-- TweaksUI Edit Mode Manager
-- Centralized handling of all Edit Mode interactions
-- Prevents conflicts from multiple modules hooking EditModeManagerFrame independently

local ADDON_NAME, TweaksUI = ...

-- ============================================================================
-- EDIT MODE MANAGER
-- ============================================================================

TweaksUI.EditMode = {
    -- State
    initialized = false,
    ready = false,
    active = false,
    
    -- Registered callbacks
    callbacks = {
        enter = {},
        exit = {},
        layout = {},
    },
    
    -- Registered frames for Edit Mode dragging
    frames = {},
    
    -- Pending registrations (before ready)
    pendingFrames = {},
    
    -- Current layout name
    activeLayoutName = nil,
    
    -- LibEditMode reference
    libEditMode = nil,
}

local EM = TweaksUI.EditMode

-- ============================================================================
-- CALLBACK MANAGEMENT
-- ============================================================================

-- Register a callback for Edit Mode events
-- event: "enter", "exit", or "layout"
-- callback: function to call when event fires
-- Returns: id that can be used to unregister
function EM:RegisterCallback(event, callback)
    if not self.callbacks[event] then
        TweaksUI:PrintError("EditMode: Unknown event '" .. tostring(event) .. "'")
        return nil
    end
    
    if type(callback) ~= "function" then
        TweaksUI:PrintError("EditMode: Callback must be a function")
        return nil
    end
    
    local id = #self.callbacks[event] + 1
    self.callbacks[event][id] = callback
    
    TweaksUI:PrintDebug("EditMode: Registered callback for '" .. event .. "' (id=" .. id .. ")")
    
    return id
end

-- Unregister a callback
function EM:UnregisterCallback(event, id)
    if self.callbacks[event] and self.callbacks[event][id] then
        self.callbacks[event][id] = nil
        TweaksUI:PrintDebug("EditMode: Unregistered callback for '" .. event .. "' (id=" .. id .. ")")
    end
end

-- Fire callbacks for an event
local function FireCallbacks(event, ...)
    for _, callback in pairs(EM.callbacks[event]) do
        local success, err = pcall(callback, ...)
        if not success then
            TweaksUI:PrintError("EditMode: Callback error for '" .. event .. "': " .. tostring(err))
        end
    end
end

-- ============================================================================
-- FRAME REGISTRATION (for Edit Mode dragging)
-- ============================================================================

-- Register a frame to be draggable in Edit Mode
-- frame: the frame to register
-- options: {
--     name = "Display Name",
--     onPositionChanged = function(frame, point, x, y) ... end,
--     default = { point = "CENTER", x = 0, y = 0 },
--     settings = { ... },  -- Optional LibEditMode settings
-- }
function EM:RegisterFrame(frame, options)
    if not frame then
        TweaksUI:PrintError("EditMode: Cannot register nil frame")
        return false
    end
    
    options = options or {}
    
    local frameInfo = {
        frame = frame,
        name = options.name or frame:GetName() or "Unknown Frame",
        onPositionChanged = options.onPositionChanged,
        default = options.default or { point = "CENTER", x = 0, y = 0 },
        settings = options.settings,
        registered = false,
    }
    
    self.frames[frame] = frameInfo
    
    -- If Edit Mode is already ready, register immediately
    if self.ready and self.libEditMode then
        self:SetupFrameForEditMode(frame)
    else
        -- Queue for later
        table.insert(self.pendingFrames, frame)
        TweaksUI:PrintDebug("EditMode: Frame queued for registration: " .. frameInfo.name)
    end
    
    return true
end

-- Unregister a frame
function EM:UnregisterFrame(frame)
    if self.frames[frame] then
        TweaksUI:PrintDebug("EditMode: Unregistered frame: " .. self.frames[frame].name)
        self.frames[frame] = nil
    end
    
    -- Remove from pending if present
    for i, f in ipairs(self.pendingFrames) do
        if f == frame then
            table.remove(self.pendingFrames, i)
            break
        end
    end
end

-- Setup a single frame for Edit Mode (called when ready)
function EM:SetupFrameForEditMode(frame)
    local info = self.frames[frame]
    if not info or info.registered then return end
    
    if not self.libEditMode then
        TweaksUI:PrintDebug("EditMode: LibEditMode not available")
        return
    end
    
    -- Set display name for Edit Mode
    frame.editModeName = info.name
    
    -- Create position callback wrapper
    local function OnPositionChanged(movedFrame, layoutName, point, x, y)
        if info.onPositionChanged then
            info.onPositionChanged(movedFrame, point, x, y)
        end
    end
    
    -- Register with LibEditMode
    local success, err = pcall(function()
        self.libEditMode:AddFrame(frame, OnPositionChanged, info.default)
        
        -- Add settings if provided
        if info.settings then
            self.libEditMode:AddFrameSettings(frame, info.settings)
        end
    end)
    
    if success then
        info.registered = true
        TweaksUI:PrintDebug("EditMode: Frame registered with LibEditMode: " .. info.name)
    else
        TweaksUI:PrintError("EditMode: Failed to register frame '" .. info.name .. "': " .. tostring(err))
    end
end

-- ============================================================================
-- STATE QUERIES
-- ============================================================================

-- Is Edit Mode currently active?
function EM:IsActive()
    return self.active
end

-- Is Edit Mode system ready? (safe to register frames)
function EM:IsReady()
    return self.ready
end

-- Get active layout name
function EM:GetActiveLayoutName()
    return self.activeLayoutName
end

-- Get LibEditMode reference
function EM:GetLib()
    return self.libEditMode
end

-- ============================================================================
-- INTERNAL: HOOK HANDLERS
-- ============================================================================

local function OnEditModeEnter()
    EM.active = true
    TweaksUI:PrintDebug("EditMode: Entered")
    FireCallbacks("enter")
end

local function OnEditModeExit()
    EM.active = false
    TweaksUI:PrintDebug("EditMode: Exited")
    FireCallbacks("exit")
end

local function OnLayoutChanged(layoutName)
    EM.activeLayoutName = layoutName
    TweaksUI:PrintDebug("EditMode: Layout changed to " .. tostring(layoutName))
    FireCallbacks("layout", layoutName)
end

-- ============================================================================
-- INITIALIZATION
-- ============================================================================

function EM:Initialize()
    if self.initialized then return end
    self.initialized = true
    
    TweaksUI:PrintDebug("EditMode: Initializing...")
    
    -- Verify EditModeManagerFrame exists
    if not EditModeManagerFrame then
        TweaksUI:PrintDebug("EditMode: EditModeManagerFrame not found, retrying in 1s...")
        self.initialized = false
        C_Timer.After(1, function() self:Initialize() end)
        return
    end
    
    -- Load LibEditMode
    self.libEditMode = LibStub and LibStub("LibEditMode", true)
    if not self.libEditMode then
        TweaksUI:PrintDebug("EditMode: LibEditMode not available")
    end
    
    -- Set up hooks (ONCE, centralized - this is the key fix)
    TweaksUI:PrintDebug("EditMode: Setting up hooks...")
    
    -- Hook Edit Mode enter
    if EditModeManagerFrame.EnterEditMode then
        hooksecurefunc(EditModeManagerFrame, "EnterEditMode", OnEditModeEnter)
    end
    hooksecurefunc(EditModeManagerFrame, "Show", function()
        if not EM.active then
            OnEditModeEnter()
        end
    end)
    
    -- Hook Edit Mode exit
    if EditModeManagerFrame.ExitEditMode then
        hooksecurefunc(EditModeManagerFrame, "ExitEditMode", OnEditModeExit)
    end
    hooksecurefunc(EditModeManagerFrame, "Hide", function()
        if EM.active then
            OnEditModeExit()
        end
    end)
    
    -- Hook layout changes
    if EventRegistry then
        EventRegistry:RegisterFrameEventAndCallback("EDIT_MODE_LAYOUTS_UPDATED", function(_, layoutInfo)
            if layoutInfo and layoutInfo.activeLayout then
                local layoutName = layoutInfo.activeLayout <= 2 
                    and (layoutInfo.activeLayout == 1 and "Modern" or "Classic")
                    or "Custom"
                OnLayoutChanged(layoutName)
            end
        end)
    end
    
    self.ready = true
    TweaksUI:PrintDebug("EditMode: Ready" .. (self.libEditMode and " (with LibEditMode)" or " (callbacks only)"))
    
    -- Register any frames that were queued before we were ready
    for _, frame in ipairs(self.pendingFrames) do
        self:SetupFrameForEditMode(frame)
    end
    self.pendingFrames = {}
end

-- ============================================================================
-- EVENT REGISTRATION
-- ============================================================================

-- Initialize after PLAYER_ENTERING_WORLD with a safety delay
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
initFrame:SetScript("OnEvent", function(self, event, isInitialLogin, isReloadingUi)
    if isInitialLogin or isReloadingUi then
        -- Delay initialization to ensure all Blizzard frames are ready
        C_Timer.After(2, function()
            EM:Initialize()
        end)
    end
end)
