-- TweaksUI Main
-- Core addon initialization and slash commands

local ADDON_NAME, TweaksUI = ...

-- Make TweaksUI accessible globally
_G.TweaksUI = TweaksUI

-- Print helper
function TweaksUI:Print(message)
    print(TweaksUI.CHAT_PREFIX .. message)
end

function TweaksUI:PrintError(message)
    print(TweaksUI.CHAT_PREFIX .. "|cffff0000" .. message .. "|r")
end

function TweaksUI:PrintDebug(message)
    if self.debugMode then
        print(TweaksUI.CHAT_PREFIX .. "|cff888888[DEBUG]|r " .. message)
    end
end

-- Debug mode
TweaksUI.debugMode = false

function TweaksUI:SetDebugMode(enabled)
    self.debugMode = enabled
    self:Print("Debug mode " .. (enabled and "enabled" or "disabled"))
end

-- Initialization
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("ADDON_LOADED")
initFrame:RegisterEvent("PLAYER_LOGIN")

local addonLoaded = false
local playerLoggedIn = false

local function Initialize()
    if not addonLoaded or not playerLoggedIn then
        return
    end
    
    TweaksUI:Print("Initializing v" .. TweaksUI.VERSION)
    
    -- Initialize database
    TweaksUI.Database:Initialize()
    
    -- Initialize media
    TweaksUI.Media:Initialize()
    
    -- Initialize all modules
    TweaksUI.ModuleManager:InitializeAll()
    
    -- Enable modules that should be enabled
    TweaksUI.ModuleManager:EnableAll()
    
    -- Check if this is a new version
    local lastSeen = TweaksUI.Database:GetGlobal("lastSeenVersion")
    if lastSeen ~= TweaksUI.VERSION then
        TweaksUI.Database:SetGlobal("lastSeenVersion", TweaksUI.VERSION)
        if lastSeen then
            TweaksUI:Print("Updated to v" .. TweaksUI.VERSION .. "! Type /tui to open settings.")
        else
            TweaksUI:Print("Welcome! Type /tui to open settings.")
        end
    end
    
    TweaksUI:Print("Loaded successfully")
end

initFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        addonLoaded = true
        Initialize()
    elseif event == "PLAYER_LOGIN" then
        playerLoggedIn = true
        Initialize()
    end
end)

-- Spec change handling for profile switching
local specFrame = CreateFrame("Frame")
specFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
specFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
specFrame:SetScript("OnEvent", function(self, event, unit)
    -- Only handle player spec changes
    if event == "PLAYER_SPECIALIZATION_CHANGED" and unit ~= "player" then
        return
    end
    
    -- Wait for database to be initialized (db is set during Initialize())
    if TweaksUI.Database and TweaksUI.Database.db and TweaksUI.Database.OnSpecChanged then
        TweaksUI.Database:OnSpecChanged()
    end
end)

-- Slash commands
local function HandleSlashCommand(msg)
    msg = msg:lower():trim()
    local args = {}
    for word in msg:gmatch("%S+") do
        table.insert(args, word)
    end
    local cmd = args[1] or ""
    
    if cmd == "" or cmd == "config" or cmd == "settings" then
        -- Open settings
        TweaksUI.Settings:Toggle()
        
    
    elseif cmd == "help" then
        TweaksUI:Print("Commands:")
        print("  /tui - Open settings panel")
        print("  /tui modules - List all modules")
        print("  /tui enable <module> - Enable a module")
        print("  /tui disable <module> - Disable a module")
        print("  /tui profile <name> - Switch profile")
        print("  /tui profiles - List profiles")
        print("  /tui import - Open import dialog ")
        print("  /tui export - Export current profile settings")
        print("  /tui debug - Toggle debug mode")
        print("  /tui version - Show version")
        
    elseif cmd == "modules" then
        TweaksUI:Print("Modules:")
        for moduleId, moduleName in pairs(TweaksUI.MODULE_NAMES) do
            local module = TweaksUI.ModuleManager:GetModule(moduleId)
            local status = ""
            if module then
                if module.enabled then
                    status = "|cff00ff00[Enabled]|r"
                elseif module.loaded then
                    status = "|cffff0000[Disabled]|r"
                else
                    status = "|cff888888[Not Loaded]|r"
                end
            else
                status = "|cff888888[Not Registered]|r"
            end
            print("  " .. moduleId .. " - " .. moduleName .. " " .. status)
        end
        
    elseif cmd == "enable" then
        local moduleId = args[2]
        if moduleId then
            TweaksUI.ModuleManager:EnableModule(moduleId)
        else
            TweaksUI:Print("Usage: /tui enable <module>")
        end
        
    elseif cmd == "disable" then
        local moduleId = args[2]
        if moduleId then
            TweaksUI.ModuleManager:DisableModule(moduleId)
        else
            TweaksUI:Print("Usage: /tui disable <module>")
        end
        
    elseif cmd == "profile" then
        local profileName = args[2]
        if profileName then
            TweaksUI.Database:SetProfile(profileName)
        else
            TweaksUI:Print("Current profile: " .. TweaksUI.Database:GetProfileName())
        end
        
    elseif cmd == "profiles" then
        TweaksUI:Print("Profiles:")
        local current = TweaksUI.Database:GetProfileName()
        for _, name in ipairs(TweaksUI.Database:GetProfileList()) do
            if name == current then
                print("  |cff00ff00" .. name .. " (active)|r")
            else
                print("  " .. name)
            end
        end
        
    elseif cmd == "debug" then
        TweaksUI:SetDebugMode(not TweaksUI.debugMode)
        
    elseif cmd == "import" then
        if TweaksUI.Import then
            TweaksUI.Import:ShowImportDialog()
        else
            TweaksUI:PrintError("Import system not available")
        end
        
    elseif cmd == "export" then
        if TweaksUI.Import then
            TweaksUI.Import:ShowExportDialog()
        else
            TweaksUI:PrintError("Export system not available")
        end
        
    elseif cmd == "version" then
        TweaksUI:Print("Version " .. TweaksUI.VERSION)
        TweaksUI:Print("Build: " .. TweaksUI.BUILD_VERSION)
        TweaksUI:Print("Midnight compatible: " .. (TweaksUI.IS_MIDNIGHT and "Yes" or "No"))
        
    elseif cmd == "npdebug" then
        -- Toggle nameplate debug mode
        if TweaksUI.Nameplates and TweaksUI.Nameplates.ToggleDebug then
            TweaksUI.Nameplates:ToggleDebug()
        else
            TweaksUI:PrintError("Nameplates module not loaded")
        end
        
    else
        TweaksUI:Print("Unknown command: " .. cmd)
        TweaksUI:Print("Type /tui help for commands")
    end
end

-- Register slash commands
for _, cmd in ipairs(TweaksUI.SLASH_COMMANDS) do
    local cmdName = cmd:upper():gsub("/", "")
    _G["SLASH_" .. cmdName .. "1"] = cmd
    SlashCmdList[cmdName] = HandleSlashCommand
end
