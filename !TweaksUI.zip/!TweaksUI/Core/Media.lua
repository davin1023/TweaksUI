-- TweaksUI Media
-- Shared textures, fonts, and media management

local ADDON_NAME, TweaksUI = ...

TweaksUI.Media = {}
local Media = TweaksUI.Media

-- Paths
local MEDIA_PATH = "Interface\\AddOns\\TweaksUI\\Media\\"
local TEXTURE_PATH = MEDIA_PATH .. "Textures\\"
local FONT_PATH = MEDIA_PATH .. "Fonts\\"

-- Default media
Media.Textures = {
    -- Status bar textures
    Flat = "Interface\\Buttons\\WHITE8x8",
    Smooth = TEXTURE_PATH .. "smooth",
    Blizzard = "Interface\\TargetingFrame\\UI-StatusBar",
    
    -- Borders
    Border = "Interface\\Buttons\\WHITE8x8",
    
    -- Icons
    Logo = MEDIA_PATH .. "icon",
}

Media.Fonts = {
    Default = "Fonts\\FRIZQT__.TTF",
    Number = "Fonts\\ARIALN.TTF",
}

-- LibSharedMedia integration (optional)
local LSM = nil

function Media:Initialize()
    -- Try to get LibSharedMedia
    if LibStub then
        LSM = LibStub("LibSharedMedia-3.0", true)
    end
    
    if LSM then
        -- Register our textures with LSM
        LSM:Register("statusbar", "TweaksUI Flat", Media.Textures.Flat)
        LSM:Register("statusbar", "TweaksUI Smooth", Media.Textures.Smooth)
        
        TweaksUI:Print("LibSharedMedia integration enabled")
    end
end

-- Get a status bar texture
function Media:GetStatusBarTexture(name)
    -- If LSM is available and has this texture, use it
    if LSM and LSM:IsValid("statusbar", name) then
        return LSM:Fetch("statusbar", name)
    end
    
    -- Check our built-in textures
    if Media.Textures[name] then
        return Media.Textures[name]
    end
    
    -- Default
    return Media.Textures.Flat
end

-- Get a font
function Media:GetFont(name)
    -- If LSM is available and has this font, use it
    if LSM and LSM:IsValid("font", name) then
        return LSM:Fetch("font", name)
    end
    
    -- Check our built-in fonts
    if Media.Fonts[name] then
        return Media.Fonts[name]
    end
    
    -- Default
    return Media.Fonts.Default
end

-- Get status bar texture list (for dropdowns)
function Media:GetStatusBarList()
    local list = {}
    
    -- Add our textures
    for name, _ in pairs(Media.Textures) do
        if name ~= "Border" and name ~= "Logo" then
            list[name] = name
        end
    end
    
    -- Add LSM textures if available
    if LSM then
        for _, name in ipairs(LSM:List("statusbar")) do
            list[name] = name
        end
    end
    
    return list
end

-- Get font list (for dropdowns)
function Media:GetFontList()
    local list = {}
    
    -- Add our fonts
    for name, _ in pairs(Media.Fonts) do
        list[name] = name
    end
    
    -- Add LSM fonts if available
    if LSM then
        for _, name in ipairs(LSM:List("font")) do
            list[name] = name
        end
    end
    
    return list
end

-- Check if LSM is available
function Media:HasSharedMedia()
    return LSM ~= nil
end
