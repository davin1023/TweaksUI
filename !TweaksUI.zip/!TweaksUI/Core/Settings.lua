-- TweaksUI Settings
-- Main settings hub UI - dockable panels for module configuration

local ADDON_NAME, TweaksUI = ...

TweaksUI.Settings = {}
local Settings = TweaksUI.Settings

-- ============================================================
-- CONSTANTS
-- ============================================================
local HUB_WIDTH = 240
local HUB_HEIGHT = 350
local BUTTON_WIDTH = 200
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 6
local SECTION_SPACING = 16

local PANEL_WIDTH = 480
local PANEL_HEIGHT = 600

-- ============================================================
-- DARK BACKDROP TEMPLATE
-- ============================================================
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- Panel references
local hubPanel = nil
local allPanels = {}
local moduleSettingsPanels = {}

-- Static popup for reload prompt
StaticPopupDialogs["TWEAKSUI_RELOAD_PROMPT"] = {
    text = "Settings changed. Reload UI to apply?",
    button1 = "Reload Now",
    button2 = "Later",
    OnAccept = function()
        ReloadUI()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

-- ============================================================
-- HELPER: Create a dockable panel
-- ============================================================
local function CreateDockedPanel(name, width, height, headerText)
    local p = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    p:SetSize(width, height)
    p:SetBackdrop(darkBackdrop)
    p:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    p:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    p:SetFrameStrata("HIGH")
    p:Hide()
    
    local header = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header:SetPoint("TOP", 0, -12)
    header:SetText(headerText)
    header:SetTextColor(1, 0.82, 0)  -- Gold color
    p.header = header
    
    local closeBtn = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() p:Hide() end)
    
    table.insert(allPanels, p)
    return p
end

-- ============================================================
-- HELPER: Position panel next to hub
-- ============================================================
local function PositionPanelNextToHub(targetPanel)
    if not hubPanel then return end
    targetPanel:ClearAllPoints()
    targetPanel:SetPoint("TOPLEFT", hubPanel, "TOPRIGHT", 0, 0)
end

-- ============================================================
-- HELPER: Hide all docked panels
-- ============================================================
local function HideAllPanels()
    for _, p in ipairs(allPanels) do
        p:Hide()
    end
end

-- ============================================================
-- HELPER: Open a panel (hide others, dock to hub)
-- ============================================================
local function OpenPanel(targetPanel)
    HideAllPanels()
    PositionPanelNextToHub(targetPanel)
    targetPanel:Show()
end

-- ============================================================
-- Create a module row (checkbox + settings button)
-- ============================================================
local function CreateModuleRow(parent, moduleId, moduleName, yOffset, onSettingsClick)
    local row = CreateFrame("Frame", nil, parent)
    row:SetPoint("TOPLEFT", 20, yOffset)
    row:SetPoint("TOPRIGHT", -20, yOffset)
    row:SetHeight(BUTTON_HEIGHT)
    
    -- Checkbox to enable/disable module (make it smaller and contained)
    local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
    cb:SetPoint("LEFT", 0, 0)
    cb:SetSize(24, 24)
    cb:SetChecked(TweaksUI.Database:IsModuleEnabled(moduleId))
    cb:SetHitRectInsets(0, 0, 0, 0)  -- Keep hit rect exactly on the checkbox
    row.checkbox = cb
    
    -- Settings button - opens the module's settings panel
    local btn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    btn:SetPoint("LEFT", cb, "RIGHT", 8, 0)
    btn:SetPoint("RIGHT", -5, 0)
    btn:SetHeight(BUTTON_HEIGHT)
    btn:SetText(moduleName)
    row.button = btn
    
    -- Function to update button state based on module enabled status
    local function UpdateButtonState()
        local enabled = TweaksUI.Database:IsModuleEnabled(moduleId)
        btn:SetEnabled(enabled)
        if enabled then
            btn:SetAlpha(1)
        else
            btn:SetAlpha(0.5)
        end
    end
    
    -- Checkbox toggles module enable/disable
    cb:SetScript("OnClick", function(self)
        if self:GetChecked() then
            TweaksUI.ModuleManager:EnableModule(moduleId)
        else
            TweaksUI.ModuleManager:DisableModule(moduleId)
        end
        UpdateButtonState()
    end)
    
    -- Button opens settings (only if module is enabled)
    btn:SetScript("OnClick", function(self)
        if TweaksUI.Database:IsModuleEnabled(moduleId) and onSettingsClick then
            onSettingsClick()
        end
    end)
    
    UpdateButtonState()
    
    row.UpdateButtonState = UpdateButtonState
    return row
end

-- ============================================================
-- CREATE THE HUB PANEL
-- ============================================================
function Settings:CreatePanel()
    if hubPanel then return hubPanel end
    
    -- Main hub panel
    hubPanel = CreateFrame("Frame", "TweaksUI_HubPanel", UIParent, "BackdropTemplate")
    hubPanel:SetSize(HUB_WIDTH, HUB_HEIGHT)
    
    -- Restore saved position or use default
    if TweaksUI_DB and TweaksUI_DB.hubPosition then
        hubPanel:SetPoint(
            TweaksUI_DB.hubPosition.point, 
            UIParent, 
            TweaksUI_DB.hubPosition.relPoint, 
            TweaksUI_DB.hubPosition.x, 
            TweaksUI_DB.hubPosition.y
        )
    else
        hubPanel:SetPoint("CENTER", -400, 0)
    end
    
    hubPanel:SetBackdrop(darkBackdrop)
    hubPanel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hubPanel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hubPanel:SetMovable(true)
    hubPanel:EnableMouse(true)
    hubPanel:RegisterForDrag("LeftButton")
    hubPanel:SetScript("OnDragStart", function(self) self:StartMoving() end)
    hubPanel:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        TweaksUI_DB = TweaksUI_DB or {}
        TweaksUI_DB.hubPosition = { point = point, relPoint = relPoint, x = x, y = y }
    end)
    hubPanel:Hide()
    hubPanel:SetFrameStrata("HIGH")
    
    tinsert(UISpecialFrames, "TweaksUI_HubPanel")
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, hubPanel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        HideAllPanels()
        hubPanel:Hide()
    end)
    
    -- Title
    local title = hubPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("TweaksUI")
    title:SetTextColor(0, 1, 0.5)  -- Teal/green for TweaksUI branding
    
    local ver = hubPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ver:SetPoint("TOP", title, "BOTTOM", 0, -2)
    ver:SetText("v" .. (TweaksUI.VERSION or "0.0.1"))
    ver:SetTextColor(0.6, 0.6, 0.6)
    
    -- Section: Modules
    local modulesHeader = hubPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    modulesHeader:SetPoint("TOPLEFT", 15, -50)
    modulesHeader:SetText("Modules")
    modulesHeader:SetTextColor(1, 0.82, 0)
    
    -- Divider line
    local divider = hubPanel:CreateTexture(nil, "ARTWORK")
    divider:SetHeight(1)
    divider:SetPoint("TOPLEFT", modulesHeader, "BOTTOMLEFT", 0, -4)
    divider:SetPoint("TOPRIGHT", hubPanel, "TOPRIGHT", -15, 0)
    divider:SetColorTexture(0.4, 0.4, 0.4, 0.8)
    
    -- Create module rows
    local yOffset = -75
    local moduleRows = {}
    
    for _, moduleId in ipairs(TweaksUI.MODULE_LOAD_ORDER) do
        local moduleName = TweaksUI.MODULE_NAMES[moduleId]
        if moduleName then
            local row = CreateModuleRow(hubPanel, moduleId, moduleName, yOffset, function()
                self:OpenModuleSettings(moduleId)
            end)
            moduleRows[moduleId] = row
            yOffset = yOffset - (BUTTON_HEIGHT + BUTTON_SPACING)
        end
    end
    
    hubPanel.moduleRows = moduleRows
    
    -- Section: General
    local generalHeader = hubPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    generalHeader:SetPoint("TOPLEFT", 15, yOffset - SECTION_SPACING)
    generalHeader:SetText("General")
    generalHeader:SetTextColor(1, 0.82, 0)
    
    local divider2 = hubPanel:CreateTexture(nil, "ARTWORK")
    divider2:SetHeight(1)
    divider2:SetPoint("TOPLEFT", generalHeader, "BOTTOMLEFT", 0, -4)
    divider2:SetPoint("TOPRIGHT", hubPanel, "TOPRIGHT", -15, 0)
    divider2:SetColorTexture(0.4, 0.4, 0.4, 0.8)
    
    yOffset = yOffset - SECTION_SPACING - 30
    
    -- Profiles button (actual profile management)
    local profilesBtn = CreateFrame("Button", nil, hubPanel, "UIPanelButtonTemplate")
    profilesBtn:SetPoint("TOPLEFT", 20, yOffset)
    profilesBtn:SetPoint("TOPRIGHT", -20, yOffset)
    profilesBtn:SetHeight(BUTTON_HEIGHT)
    profilesBtn:SetText("Profiles")
    profilesBtn:SetScript("OnClick", function()
        self:OpenProfilesPanel()
    end)
    
    yOffset = yOffset - (BUTTON_HEIGHT + BUTTON_SPACING)
    
    -- Import/Export button
    local importExportBtn = CreateFrame("Button", nil, hubPanel, "UIPanelButtonTemplate")
    importExportBtn:SetPoint("TOPLEFT", 20, yOffset)
    importExportBtn:SetPoint("TOPRIGHT", -20, yOffset)
    importExportBtn:SetHeight(BUTTON_HEIGHT)
    importExportBtn:SetText("Import/Export")
    importExportBtn:SetScript("OnClick", function()
        self:OpenImportExportPanel()
    end)
    
    yOffset = yOffset - (BUTTON_HEIGHT + BUTTON_SPACING)
    
    -- About button
    local aboutBtn = CreateFrame("Button", nil, hubPanel, "UIPanelButtonTemplate")
    aboutBtn:SetPoint("TOPLEFT", 20, yOffset)
    aboutBtn:SetPoint("TOPRIGHT", -20, yOffset)
    aboutBtn:SetHeight(BUTTON_HEIGHT)
    aboutBtn:SetText("About")
    aboutBtn:SetScript("OnClick", function()
        self:OpenAboutPanel()
    end)
    
    -- Adjust hub height based on content
    local totalHeight = math.abs(yOffset) + 50
    hubPanel:SetHeight(math.max(HUB_HEIGHT, totalHeight))
    
    return hubPanel
end

-- ============================================================
-- OPEN MODULE SETTINGS
-- ============================================================
function Settings:OpenModuleSettings(moduleId)
    -- First, close ALL module hubs and panels
    self:CloseAllModules()
    
    -- Now open the requested module
    if moduleId == TweaksUI.MODULE_IDS.COOLDOWNS then
        local cooldownsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.COOLDOWNS)
        if cooldownsModule and cooldownsModule.ShowHub then
            cooldownsModule:ShowHub(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.CHAT then
        local chatModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CHAT)
        if chatModule and chatModule.OpenChatHubDocked then
            chatModule:OpenChatHubDocked(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.UNIT_FRAMES then
        local unitFramesModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.UNIT_FRAMES)
        if unitFramesModule and unitFramesModule.OpenUnitFramesHubDocked then
            unitFramesModule:OpenUnitFramesHubDocked(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.CAST_BARS then
        local castBarsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CAST_BARS)
        if castBarsModule and castBarsModule.ShowHub then
            castBarsModule:ShowHub(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.NAMEPLATES then
        local nameplatesModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.NAMEPLATES)
        if nameplatesModule and nameplatesModule.ShowHub then
            nameplatesModule:ShowHub(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.RESOURCE_BARS then
        local resourceBarsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.RESOURCE_BARS)
        if resourceBarsModule and resourceBarsModule.ShowHub then
            resourceBarsModule:ShowHub(hubPanel)
        end
    elseif moduleId == TweaksUI.MODULE_IDS.ACTION_BARS then
        local actionBarsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.ACTION_BARS)
        if actionBarsModule and actionBarsModule.ShowHub then
            actionBarsModule:ShowHub(hubPanel)
        end
    else
        self:OpenComingSoonPanel(moduleId)
    end
end

-- Close all modules' hubs and panels
function Settings:CloseAllModules()
    -- Close any docked panels from Settings
    HideAllPanels()
    
    -- List of all modules that have hubs/panels
    local moduleHubNames = {
        "TweaksUI_ChatHub",
        "TweaksUI_Cooldowns_Hub",
        "TweaksUI_UnitFramesHub",
        "TweaksUI_CastBars_Hub",
        "TweaksUI_Nameplates_Hub",
        "TweaksUI_ResourceBars_Hub",
        "TweaksUI_ActionBars_Hub",
        -- Unit Frames settings containers
        "TweaksUI_UF_player_Container",
        "TweaksUI_UF_target_Container",
        "TweaksUI_UF_focus_Container",
        "TweaksUI_UF_targettarget_Container",
        "TweaksUI_UF_pet_Container",
        "TweaksUI_UF_party_Container",
        "TweaksUI_UF_raid_small_Container",
        "TweaksUI_UF_raid_large_Container",
        "TweaksUI_UF_tanks_Container",
        "TweaksUI_UF_boss_Container",
    }
    
    -- Hide all hub frames
    for _, hubName in ipairs(moduleHubNames) do
        local hub = _G[hubName]
        if hub then
            hub:Hide()
        end
    end
    
    -- Call HideAllPanels on each module
    local moduleIds = {
        TweaksUI.MODULE_IDS.CHAT,
        TweaksUI.MODULE_IDS.COOLDOWNS,
        TweaksUI.MODULE_IDS.UNIT_FRAMES,
        TweaksUI.MODULE_IDS.CAST_BARS,
        TweaksUI.MODULE_IDS.NAMEPLATES,
        TweaksUI.MODULE_IDS.RESOURCE_BARS,
        TweaksUI.MODULE_IDS.ACTION_BARS,
    }
    
    for _, modId in ipairs(moduleIds) do
        local mod = TweaksUI.ModuleManager:GetModule(modId)
        if mod and mod.HideAllPanels then
            mod:HideAllPanels()
        end
    end
end

-- ============================================================
-- CREATE CHAT SETTINGS PANEL
-- ============================================================
function Settings:OpenChatPanel()
    if not moduleSettingsPanels.chat then
        local panel = CreateDockedPanel("TweaksUI_ChatPanel", PANEL_WIDTH, 500, "Chat Settings")
        
        local content = CreateFrame("Frame", nil, panel)
        content:SetPoint("TOPLEFT", 15, -40)
        content:SetPoint("BOTTOMRIGHT", -15, 15)
        
        -- Get the Chat module and let it create the settings content
        local chatModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CHAT)
        if chatModule and chatModule.CreateSettingsContent then
            chatModule:CreateSettingsContent(content)
        else
            -- Fallback if module not loaded
            local desc = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            desc:SetPoint("TOPLEFT", 0, 0)
            desc:SetWidth(PANEL_WIDTH - 50)
            desc:SetText("Chat module settings.\n\nEnable the Chat module to configure settings.")
            desc:SetTextColor(0.8, 0.8, 0.8)
            desc:SetJustifyH("LEFT")
        end
        
        moduleSettingsPanels.chat = panel
    end
    
    OpenPanel(moduleSettingsPanels.chat)
end

-- ============================================================
-- CREATE PROFILES PANEL
-- ============================================================
function Settings:OpenImportExportPanel()
    if not moduleSettingsPanels.importExport then
        local panel = CreateDockedPanel("TweaksUI_ImportExportPanel", PANEL_WIDTH, 550, "Import/Export")
        
        local content = CreateFrame("Frame", nil, panel)
        content:SetPoint("TOPLEFT", 15, -40)
        content:SetPoint("BOTTOMRIGHT", -15, 15)
        
        local desc = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        desc:SetPoint("TOPLEFT", 0, 0)
        desc:SetWidth(PANEL_WIDTH - 50)
        desc:SetText("Import and export settings for each module.\nClick a module button to open its import/export window.")
        desc:SetTextColor(0.8, 0.8, 0.8)
        desc:SetJustifyH("LEFT")
        
        local yOffset = -50
        local btnWidth = (PANEL_WIDTH - 70) / 2
        local btnHeight = 32
        local btnSpacing = 8
        
        -- Helper to create a module row with export/import buttons
        local function CreateModuleExportRow(moduleName, moduleId, y, exportFunc, importFunc, enabled)
            local label = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            label:SetPoint("TOPLEFT", 0, y)
            label:SetText(moduleName)
            if not enabled then
                label:SetTextColor(0.5, 0.5, 0.5)
            end
            
            local exportBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
            exportBtn:SetSize(70, 24)
            exportBtn:SetPoint("TOPLEFT", 0, y - 18)
            exportBtn:SetText("Export")
            if enabled then
                exportBtn:SetScript("OnClick", exportFunc)
            else
                exportBtn:Disable()
            end
            
            local importBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
            importBtn:SetSize(70, 24)
            importBtn:SetPoint("LEFT", exportBtn, "RIGHT", 8, 0)
            importBtn:SetText("Import")
            if enabled then
                importBtn:SetScript("OnClick", importFunc)
            else
                importBtn:Disable()
            end
            
            return y - 50
        end
        
        -- Unit Frames
        local ufModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.UNIT_FRAMES)
        local ufEnabled = ufModule ~= nil
        yOffset = CreateModuleExportRow("Unit Frames", TweaksUI.MODULE_IDS.UNIT_FRAMES, yOffset,
            function()
                if ufModule and ufModule.ShowExportWindow then
                    ufModule:ShowExportWindow()
                end
            end,
            function()
                if ufModule and ufModule.ShowImportWindow then
                    ufModule:ShowImportWindow()
                end
            end,
            ufEnabled
        )
        
        -- Chat
        local chatModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CHAT)
        local chatEnabled = chatModule ~= nil
        yOffset = CreateModuleExportRow("Chat", TweaksUI.MODULE_IDS.CHAT, yOffset,
            function()
                if chatModule and chatModule.ShowExportWindow then
                    chatModule:ShowExportWindow()
                end
            end,
            function()
                if chatModule and chatModule.ShowImportWindow then
                    chatModule:ShowImportWindow()
                end
            end,
            chatEnabled
        )
        
        -- Cast Bars
        local castBarsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CAST_BARS)
        local castBarsEnabled = castBarsModule ~= nil
        yOffset = CreateModuleExportRow("Cast Bars", TweaksUI.MODULE_IDS.CAST_BARS, yOffset,
            function()
                if castBarsModule and castBarsModule.ShowExportDialog then
                    castBarsModule:ShowExportDialog()
                end
            end,
            function()
                if castBarsModule and castBarsModule.ShowImportDialog then
                    castBarsModule:ShowImportDialog()
                end
            end,
            castBarsEnabled
        )
        
        -- Nameplates
        local nameplatesModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.NAMEPLATES)
        local nameplatesEnabled = nameplatesModule ~= nil
        yOffset = CreateModuleExportRow("Nameplates", TweaksUI.MODULE_IDS.NAMEPLATES, yOffset,
            function()
                if nameplatesModule and nameplatesModule.ShowExportDialog then
                    nameplatesModule:ShowExportDialog()
                end
            end,
            function()
                if nameplatesModule and nameplatesModule.ShowImportDialog then
                    nameplatesModule:ShowImportDialog()
                end
            end,
            nameplatesEnabled
        )
        
        -- Cooldown Trackers
        local cooldownsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.COOLDOWNS)
        local cooldownsEnabled = cooldownsModule ~= nil
        yOffset = CreateModuleExportRow("Cooldown Trackers", TweaksUI.MODULE_IDS.COOLDOWNS, yOffset,
            function()
                if cooldownsModule and cooldownsModule.ShowExportDialog then
                    cooldownsModule:ShowExportDialog()
                end
            end,
            function()
                if cooldownsModule and cooldownsModule.ShowImportDialog then
                    cooldownsModule:ShowImportDialog()
                end
            end,
            cooldownsEnabled
        )
        
        -- Resource Bars
        local resourceBarsModule = TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.RESOURCE_BARS)
        local resourceBarsEnabled = resourceBarsModule ~= nil
        yOffset = CreateModuleExportRow("Resource Bars", TweaksUI.MODULE_IDS.RESOURCE_BARS, yOffset,
            function()
                if resourceBarsModule and resourceBarsModule.ShowExportDialog then
                    resourceBarsModule:ShowExportDialog()
                end
            end,
            function()
                if resourceBarsModule and resourceBarsModule.ShowImportDialog then
                    resourceBarsModule:ShowImportDialog()
                end
            end,
            resourceBarsEnabled
        )
        
        -- Placeholder modules (coming soon)
        local placeholders = {
            { name = "Action Bars", id = TweaksUI.MODULE_IDS.ACTION_BARS },
        }
        
        for _, mod in ipairs(placeholders) do
            yOffset = CreateModuleExportRow(mod.name .. " |cff888888(coming soon)|r", mod.id, yOffset,
                function() end, function() end, false)
        end
        
        -- Separator
        yOffset = yOffset - 10
        local sep = content:CreateTexture(nil, "ARTWORK")
        sep:SetPoint("TOPLEFT", 0, yOffset)
        sep:SetSize(PANEL_WIDTH - 50, 1)
        sep:SetColorTexture(0.4, 0.4, 0.4, 0.8)
        yOffset = yOffset - 20
        
        -- Export All section
        local allLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        allLabel:SetPoint("TOPLEFT", 0, yOffset)
        allLabel:SetText("Export/Import All Modules")
        allLabel:SetTextColor(1, 0.82, 0)
        yOffset = yOffset - 20
        
        local allDesc = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        allDesc:SetPoint("TOPLEFT", 0, yOffset)
        allDesc:SetWidth(PANEL_WIDTH - 50)
        allDesc:SetText("Export or import all module settings as a single string.\nIncludes: Cooldowns, Chat, Unit Frames, Resource Bars, Cast Bars, Nameplates")
        allDesc:SetJustifyH("LEFT")
        yOffset = yOffset - 35
        
        -- Export All button
        local exportAllBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        exportAllBtn:SetSize(120, 26)
        exportAllBtn:SetPoint("TOPLEFT", 0, yOffset)
        exportAllBtn:SetText("Export All")
        exportAllBtn:SetScript("OnClick", function()
            TweaksUI.Import:ShowExportAllDialog()
        end)
        
        -- Import All button
        local importAllBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        importAllBtn:SetSize(120, 26)
        importAllBtn:SetPoint("LEFT", exportAllBtn, "RIGHT", 10, 0)
        importAllBtn:SetText("Import All")
        importAllBtn:SetScript("OnClick", function()
            TweaksUI.Import:ShowImportAllDialog()
        end)
        
        moduleSettingsPanels.importExport = panel
    end
    
    OpenPanel(moduleSettingsPanels.importExport)
end

-- ============================================================
-- CREATE PROFILES PANEL (Profile Management)
-- ============================================================
function Settings:OpenProfilesPanel()
    if not moduleSettingsPanels.profiles then
        local panel = CreateDockedPanel("TweaksUI_ProfilesPanel", PANEL_WIDTH, 600, "Profiles")
        
        local content = CreateFrame("Frame", nil, panel)
        content:SetPoint("TOPLEFT", 15, -40)
        content:SetPoint("BOTTOMRIGHT", -15, 15)
        
        local yOffset = 0
        
        -- Current Profile Section
        local currentLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        currentLabel:SetPoint("TOPLEFT", 0, yOffset)
        currentLabel:SetText("Current Profile")
        currentLabel:SetTextColor(1, 0.82, 0)
        yOffset = yOffset - 25
        
        -- Profile dropdown
        local profileDropdown = CreateFrame("Frame", "TweaksUI_ProfileDropdown", content, "UIDropDownMenuTemplate")
        profileDropdown:SetPoint("TOPLEFT", -15, yOffset)
        UIDropDownMenu_SetWidth(profileDropdown, 180)
        
        local function UpdateProfileDropdown()
            UIDropDownMenu_SetText(profileDropdown, TweaksUI.Database:GetProfileName())
        end
        
        UIDropDownMenu_Initialize(profileDropdown, function(self, level)
            local profiles = TweaksUI.Database:GetProfileList()
            for _, name in ipairs(profiles) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = name
                info.checked = (name == TweaksUI.Database:GetProfileName())
                info.func = function()
                    TweaksUI.Database:SetProfile(name)
                    UpdateProfileDropdown()
                    -- Suggest reload
                    StaticPopup_Show("TWEAKSUI_RELOAD_PROMPT")
                end
                UIDropDownMenu_AddButton(info, level)
            end
        end)
        UpdateProfileDropdown()
        
        yOffset = yOffset - 35
        
        -- Profile action buttons
        local btnWidth = 85
        local btnHeight = 24
        local btnSpacing = 5
        
        -- New Profile button
        local newBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        newBtn:SetSize(btnWidth, btnHeight)
        newBtn:SetPoint("TOPLEFT", 0, yOffset)
        newBtn:SetText("New")
        newBtn:SetScript("OnClick", function()
            StaticPopupDialogs["TWEAKSUI_NEW_PROFILE"] = {
                text = "Enter name for new profile:",
                button1 = "Create",
                button2 = "Cancel",
                hasEditBox = true,
                OnAccept = function(self)
                    local name = self.EditBox:GetText()
                    if name and name ~= "" then
                        if TweaksUI.Database:CreateProfile(name) then
                            UpdateProfileDropdown()
                        end
                    end
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("TWEAKSUI_NEW_PROFILE")
        end)
        
        -- Copy Profile button
        local copyBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        copyBtn:SetSize(btnWidth, btnHeight)
        copyBtn:SetPoint("LEFT", newBtn, "RIGHT", btnSpacing, 0)
        copyBtn:SetText("Copy")
        copyBtn:SetScript("OnClick", function()
            StaticPopupDialogs["TWEAKSUI_COPY_PROFILE"] = {
                text = "Enter name for copy of '" .. TweaksUI.Database:GetProfileName() .. "':",
                button1 = "Copy",
                button2 = "Cancel",
                hasEditBox = true,
                OnAccept = function(self)
                    local name = self.EditBox:GetText()
                    if name and name ~= "" then
                        if TweaksUI.Database:CopyProfile(TweaksUI.Database:GetProfileName(), name) then
                            UpdateProfileDropdown()
                        end
                    end
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("TWEAKSUI_COPY_PROFILE")
        end)
        
        -- Rename Profile button
        local renameBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        renameBtn:SetSize(btnWidth, btnHeight)
        renameBtn:SetPoint("LEFT", copyBtn, "RIGHT", btnSpacing, 0)
        renameBtn:SetText("Rename")
        renameBtn:SetScript("OnClick", function()
            local currentProfile = TweaksUI.Database:GetProfileName()
            if currentProfile == "Default" then
                TweaksUI:PrintError("Cannot rename the Default profile")
                return
            end
            StaticPopupDialogs["TWEAKSUI_RENAME_PROFILE"] = {
                text = "Enter new name for profile '" .. currentProfile .. "':",
                button1 = "Rename",
                button2 = "Cancel",
                hasEditBox = true,
                OnAccept = function(self)
                    local name = self.EditBox:GetText()
                    if name and name ~= "" then
                        if TweaksUI.Database:RenameProfile(currentProfile, name) then
                            UpdateProfileDropdown()
                        end
                    end
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("TWEAKSUI_RENAME_PROFILE")
        end)
        
        yOffset = yOffset - 35
        
        -- Delete Profile button
        local deleteBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        deleteBtn:SetSize(btnWidth, btnHeight)
        deleteBtn:SetPoint("TOPLEFT", 0, yOffset)
        deleteBtn:SetText("Delete")
        deleteBtn:SetScript("OnClick", function()
            local currentProfile = TweaksUI.Database:GetProfileName()
            if currentProfile == "Default" then
                TweaksUI:PrintError("Cannot delete the Default profile")
                return
            end
            StaticPopupDialogs["TWEAKSUI_DELETE_PROFILE"] = {
                text = "Are you sure you want to delete profile '" .. currentProfile .. "'?\n\nThis cannot be undone!",
                button1 = "Delete",
                button2 = "Cancel",
                OnAccept = function()
                    TweaksUI.Database:DeleteProfile(currentProfile)
                    UpdateProfileDropdown()
                    StaticPopup_Show("TWEAKSUI_RELOAD_PROMPT")
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("TWEAKSUI_DELETE_PROFILE")
        end)
        
        -- Save to Profile button
        local saveBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        saveBtn:SetSize(btnWidth + 30, btnHeight)
        saveBtn:SetPoint("LEFT", deleteBtn, "RIGHT", btnSpacing, 0)
        saveBtn:SetText("Save Current")
        saveBtn:SetScript("OnClick", function()
            local currentProfile = TweaksUI.Database:GetProfileName()
            StaticPopupDialogs["TWEAKSUI_SAVE_PROFILE"] = {
                text = "Save all current settings to profile '" .. currentProfile .. "'?",
                button1 = "Save",
                button2 = "Cancel",
                OnAccept = function()
                    -- Save settings from each module to the database
                    local modules = {
                        { id = TweaksUI.MODULE_IDS.COOLDOWNS, name = "Cooldowns" },
                        { id = TweaksUI.MODULE_IDS.CHAT, name = "Chat" },
                        { id = TweaksUI.MODULE_IDS.UNIT_FRAMES, name = "Unit Frames" },
                        { id = TweaksUI.MODULE_IDS.RESOURCE_BARS, name = "Resource Bars" },
                        { id = TweaksUI.MODULE_IDS.CAST_BARS, name = "Cast Bars" },
                        { id = TweaksUI.MODULE_IDS.NAMEPLATES, name = "Nameplates" },
                    }
                    
                    local savedCount = 0
                    for _, mod in ipairs(modules) do
                        local moduleObj = TweaksUI.ModuleManager:GetModule(mod.id)
                        if moduleObj and moduleObj.GetSettings then
                            local settings = moduleObj:GetSettings()
                            if settings then
                                TweaksUI.Database:SetModuleSettings(mod.id, settings)
                                savedCount = savedCount + 1
                            end
                        end
                    end
                    
                    TweaksUI:Print("Saved settings to profile '" .. currentProfile .. "' (" .. savedCount .. " modules)")
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("TWEAKSUI_SAVE_PROFILE")
        end)
        
        yOffset = yOffset - 50
        
        -- Separator
        local sep1 = content:CreateTexture(nil, "ARTWORK")
        sep1:SetPoint("TOPLEFT", 0, yOffset)
        sep1:SetSize(PANEL_WIDTH - 50, 1)
        sep1:SetColorTexture(0.4, 0.4, 0.4, 0.8)
        yOffset = yOffset - 20
        
        -- Spec Profiles Section
        local specLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        specLabel:SetPoint("TOPLEFT", 0, yOffset)
        specLabel:SetText("Specialization Profiles")
        specLabel:SetTextColor(1, 0.82, 0)
        yOffset = yOffset - 20
        
        local specDesc = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        specDesc:SetPoint("TOPLEFT", 0, yOffset)
        specDesc:SetWidth(PANEL_WIDTH - 50)
        specDesc:SetText("Automatically switch profiles when you change specs.\nLeave blank to use the default character profile.")
        specDesc:SetJustifyH("LEFT")
        specDesc:SetTextColor(0.7, 0.7, 0.7)
        yOffset = yOffset - 35
        
        -- Create spec profile dropdowns
        local specDropdowns = {}
        local numSpecs = GetNumSpecializations()
        
        for i = 1, numSpecs do
            local _, specName, _, specIcon = GetSpecializationInfo(i)
            if specName then
                -- Spec label with icon
                local specRow = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                specRow:SetPoint("TOPLEFT", 0, yOffset)
                specRow:SetText("|T" .. specIcon .. ":16|t " .. specName)
                
                -- Dropdown for spec profile
                local specDrop = CreateFrame("Frame", "TweaksUI_SpecProfile" .. i, content, "UIDropDownMenuTemplate")
                specDrop:SetPoint("TOPLEFT", 130, yOffset + 5)
                UIDropDownMenu_SetWidth(specDrop, 140)
                
                local function UpdateSpecDropdown()
                    local specProfile = TweaksUI.Database:GetSpecProfile(nil, i)
                    UIDropDownMenu_SetText(specDrop, specProfile or "(Use Default)")
                end
                
                UIDropDownMenu_Initialize(specDrop, function(self, level)
                    -- None option
                    local info = UIDropDownMenu_CreateInfo()
                    info.text = "(Use Default)"
                    info.checked = (TweaksUI.Database:GetSpecProfile(nil, i) == nil)
                    info.func = function()
                        TweaksUI.Database:SetSpecProfile(nil, i, nil)
                        UpdateSpecDropdown()
                    end
                    UIDropDownMenu_AddButton(info, level)
                    
                    -- Profile options
                    local profiles = TweaksUI.Database:GetProfileList()
                    for _, name in ipairs(profiles) do
                        info = UIDropDownMenu_CreateInfo()
                        info.text = name
                        info.checked = (TweaksUI.Database:GetSpecProfile(nil, i) == name)
                        info.func = function()
                            TweaksUI.Database:SetSpecProfile(nil, i, name)
                            UpdateSpecDropdown()
                        end
                        UIDropDownMenu_AddButton(info, level)
                    end
                end)
                UpdateSpecDropdown()
                
                specDropdowns[i] = { dropdown = specDrop, update = UpdateSpecDropdown }
                yOffset = yOffset - 30
            end
        end
        
        yOffset = yOffset - 20
        
        -- Separator
        local sep2 = content:CreateTexture(nil, "ARTWORK")
        sep2:SetPoint("TOPLEFT", 0, yOffset)
        sep2:SetSize(PANEL_WIDTH - 50, 1)
        sep2:SetColorTexture(0.4, 0.4, 0.4, 0.8)
        yOffset = yOffset - 20
        
        -- Character info
        local charLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        charLabel:SetPoint("TOPLEFT", 0, yOffset)
        charLabel:SetText("Character Info")
        charLabel:SetTextColor(1, 0.82, 0)
        yOffset = yOffset - 25
        
        local charKey = TweaksUI.Database:GetCharacterKey()
        local charInfo = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        charInfo:SetPoint("TOPLEFT", 0, yOffset)
        charInfo:SetWidth(PANEL_WIDTH - 50)
        charInfo:SetJustifyH("LEFT")
        charInfo:SetText("Current character: |cff00ff00" .. charKey .. "|r")
        charInfo:SetTextColor(0.8, 0.8, 0.8)
        
        moduleSettingsPanels.profiles = panel
    end
    
    OpenPanel(moduleSettingsPanels.profiles)
end

-- ============================================================
-- CREATE ABOUT PANEL
-- ============================================================
function Settings:OpenAboutPanel()
    if not moduleSettingsPanels.about then
        local panel = CreateDockedPanel("TweaksUI_AboutPanel", PANEL_WIDTH, 400, "About TweaksUI")
        
        local content = CreateFrame("Frame", nil, panel)
        content:SetPoint("TOPLEFT", 15, -40)
        content:SetPoint("BOTTOMRIGHT", -15, 15)
        
        local info = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        info:SetPoint("TOPLEFT", 0, 0)
        info:SetWidth(PANEL_WIDTH - 50)
        info:SetJustifyH("LEFT")
        info:SetText(
            "|cff00ff80TweaksUI|r v" .. (TweaksUI.VERSION or "0.3.0") .. "\n\n" ..
            "A modular UI enhancement suite for World of Warcraft.\n\n" ..
            "|cffffffffModules:|r\n" ..
            "• |cff00ff00Cooldown Trackers|r - Custom layouts for Blizzard's cooldown trackers\n" ..
            "• |cff00ff00Chat|r - Custom chat frame with filtering, tabs, and more\n" ..
            "• |cff00ff00Unit Frames|r - Class colors, scaling, textures for unit frames\n" ..
            "• |cff00ff00Cast Bars|r - Standalone cast bars for player, target, and focus\n" ..
            "• |cff00ff00Nameplates|r - Fully customizable enemy and friendly nameplates\n" ..
            "• |cff00ff00Resource Bars|r - Power bars and class resources with Edit Mode positioning\n" ..
            "• |cff00ff00Action Bars|r - Layout and visibility controls for action bars\n\n" ..
            "|cffffffffAuthor:|r Meltheran\n" ..
            "|cffffffffWebsite:|r curseforge.com/wow/addons/tweaksui"
        )
        info:SetTextColor(0.8, 0.8, 0.8)
        
        moduleSettingsPanels.about = panel
    end
    
    OpenPanel(moduleSettingsPanels.about)
end

-- ============================================================
-- CREATE COMING SOON PANEL
-- ============================================================
function Settings:OpenComingSoonPanel(moduleId)
    local moduleName = TweaksUI.MODULE_NAMES[moduleId] or moduleId
    local panelKey = "comingsoon_" .. moduleId
    
    if not moduleSettingsPanels[panelKey] then
        local panel = CreateDockedPanel("TweaksUI_" .. moduleId .. "Panel", PANEL_WIDTH, 300, moduleName)
        
        local content = CreateFrame("Frame", nil, panel)
        content:SetPoint("TOPLEFT", 15, -40)
        content:SetPoint("BOTTOMRIGHT", -15, 15)
        
        local msg = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        msg:SetPoint("CENTER")
        msg:SetText("|cff888888Coming Soon|r\n\n|cff666666This module is planned for a future update.|r")
        
        moduleSettingsPanels[panelKey] = panel
    end
    
    OpenPanel(moduleSettingsPanels[panelKey])
end

-- ============================================================
-- TOGGLE / SHOW / HIDE
-- ============================================================
function Settings:Toggle()
    if not hubPanel then
        self:CreatePanel()
    end
    
    if hubPanel:IsShown() then
        HideAllPanels()
        hubPanel:Hide()
    else
        hubPanel:Show()
    end
end

function Settings:Show()
    if not hubPanel then
        self:CreatePanel()
    end
    hubPanel:Show()
end

function Settings:Hide()
    if hubPanel then
        HideAllPanels()
        hubPanel:Hide()
    end
end
