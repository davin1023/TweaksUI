Soul Fragment Textures
======================

Place your custom soul fragment display textures here.

Required Files:
- SoulFragments_flame.tga (or .blp)
- SoulFragments_fel.tga (or .blp)  
- SoulFragments_void.tga (or .blp)

Image Requirements:
- Size: 256x256 pixels recommended (power of 2)
- Format: TGA (32-bit with alpha channel) or BLP
- Transparency: Use alpha channel for transparent areas

The count number will be displayed centered on the image.
You can adjust the position offset in the settings panel.
