-- ============================================================================
-- TweaksUI: Action Bars Module
-- Enhances Blizzard's action bars with layout and visibility options
-- ============================================================================

local ADDON_NAME, TweaksUI = ...

-- Create the module
local ActionBars = TweaksUI.ModuleManager:NewModule(
    TweaksUI.MODULE_IDS.ACTION_BARS,
    "Action Bars",
    "Customize action bar layouts and visibility"
)

-- ============================================================================
-- LOCAL VARIABLES
-- ============================================================================

local settings = nil
local actionBarsHub = nil
local settingsPanels = {}
local currentOpenPanel = nil
local eventFrame = nil
local pendingUpdates = {}
local originalButtonPositions = {}
local hookedBars = {}
local highlightFrames = {}  -- For highlighting selected bar in settings

-- Panel dimensions
local HUB_WIDTH = 180
local HUB_HEIGHT = 400
local PANEL_WIDTH = 360
local PANEL_HEIGHT = 520
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 4

-- Dark backdrop for panels
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- ============================================================================
-- BAR CONFIGURATION
-- ============================================================================

local BAR_INFO = {
    ActionBar1 = {
        displayName = "Action Bar 1",
        buttonPrefix = "ActionButton",
        buttonCount = 12,
        frame = "MainActionBarButtonContainer1",
        selectionFrame = "MainActionBar",  -- Edit Mode selection is on this frame
        visibilityFrame = "MainActionBar",  -- Frame to fade for visibility
        visibilitySetting = nil,  -- Always visible
        order = 1,
    },
    ActionBar2 = {
        displayName = "Action Bar 2",
        buttonPrefix = "MultiBarBottomLeftButton",
        buttonCount = 12,
        frame = "MultiBarBottomLeft",
        selectionFrame = "MultiBarBottomLeft",
        visibilitySetting = "MultiBarBottomLeftVisibility",
        order = 2,
    },
    ActionBar3 = {
        displayName = "Action Bar 3",
        buttonPrefix = "MultiBarBottomRightButton",
        buttonCount = 12,
        frame = "MultiBarBottomRight",
        selectionFrame = "MultiBarBottomRight",
        visibilitySetting = "MultiBarBottomRightVisibility",
        order = 3,
    },
    ActionBar4 = {
        displayName = "Action Bar 4",
        buttonPrefix = "MultiBarRightButton",
        buttonCount = 12,
        frame = "MultiBarRight",
        selectionFrame = "MultiBarRight",
        visibilitySetting = "MultiBarRightVisibility",
        order = 4,
    },
    ActionBar5 = {
        displayName = "Action Bar 5",
        buttonPrefix = "MultiBarLeftButton",
        buttonCount = 12,
        frame = "MultiBarLeft",
        selectionFrame = "MultiBarLeft",
        visibilitySetting = "MultiBarLeftVisibility",
        order = 5,
    },
    ActionBar6 = {
        displayName = "Action Bar 6",
        buttonPrefix = "MultiBar5Button",
        buttonCount = 12,
        frame = "MultiBar5",
        selectionFrame = "MultiBar5",
        visibilitySetting = "MultiBar5Visibility",
        order = 6,
    },
    ActionBar7 = {
        displayName = "Action Bar 7",
        buttonPrefix = "MultiBar6Button",
        buttonCount = 12,
        frame = "MultiBar6",
        selectionFrame = "MultiBar6",
        visibilitySetting = "MultiBar6Visibility",
        order = 7,
    },
    ActionBar8 = {
        displayName = "Action Bar 8",
        buttonPrefix = "MultiBar7Button",
        buttonCount = 12,
        frame = "MultiBar7",
        selectionFrame = "MultiBar7",
        visibilitySetting = "MultiBar7Visibility",
        order = 8,
    },
}

local BAR_ORDER = {
    "ActionBar1",
    "ActionBar2",
    "ActionBar3",
    "ActionBar4",
    "ActionBar5",
    "ActionBar6",
    "ActionBar7",
    "ActionBar8",
}

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

local function GetDefaultBarSettings()
    return {
        enabled = false,
        -- Layout
        buttonsShown = 12,    -- How many buttons to show (1-12)
        columns = 12,         -- Buttons per row (horizontal) or per column (vertical)
        orientation = "horizontal",  -- "horizontal" or "vertical"
        buttonSize = 45,
        horizontalSpacing = 6,
        verticalSpacing = 6,
        -- Visibility
        visibilityEnabled = false,
        showOnMouseover = false,
        showInCombat = true,
        showOutOfCombat = true,
        showWithTarget = true,
        showSolo = true,
        showInParty = true,
        showInRaid = true,
        showInInstance = true,
        showMounted = true,
        showInVehicle = true,
        showDragonriding = true,
        barAlpha = 1.0,         -- Overall action bar opacity
        buttonFrameAlpha = 1.0, -- Button frame/border opacity (0-1)
        -- Text/Overlay settings
        keybindAlpha = 1.0,     -- Keybind text opacity
        countAlpha = 1.0,       -- Stack count text opacity
        macroNameAlpha = 1.0,   -- Macro name text opacity
        pageArrowsAlpha = 1.0,  -- Page up/down arrows opacity (Bar 1 only)
    }
end

local DEFAULT_SETTINGS = {
    enabled = false,
    bars = {},
}

for barId, _ in pairs(BAR_INFO) do
    DEFAULT_SETTINGS.bars[barId] = GetDefaultBarSettings()
end

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

local function DeepCopy(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for k, v in pairs(orig) do
            copy[k] = DeepCopy(v)
        end
    else
        copy = orig
    end
    return copy
end

local function EnsureDefaults(tbl, defaults)
    if type(defaults) ~= "table" then return end
    if type(tbl) ~= "table" then return end
    for k, v in pairs(defaults) do
        if tbl[k] == nil then
            tbl[k] = DeepCopy(v)
        elseif type(v) == "table" and type(tbl[k]) == "table" then
            EnsureDefaults(tbl[k], v)
        end
    end
end

local function DebugPrint(...)
    if TweaksUI and TweaksUI.PrintDebug then
        TweaksUI:PrintDebug("[ActionBars]", ...)
    end
end

-- ============================================================================
-- COMBAT LOCKDOWN HANDLING
-- ============================================================================

local function IsInCombat()
    return InCombatLockdown()
end

local function QueueUpdate(barId)
    pendingUpdates[barId] = true
    if eventFrame then
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    end
end

local function ProcessPendingUpdates()
    if IsInCombat() then return end
    for barId, _ in pairs(pendingUpdates) do
        ActionBars:ApplyBarLayout(barId)
    end
    pendingUpdates = {}
end

-- ============================================================================
-- BUTTON POSITION STORAGE
-- ============================================================================

local function StoreOriginalPositions(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    if originalButtonPositions[barId] then return end
    
    originalButtonPositions[barId] = {}
    
    for i = 1, info.buttonCount do
        local button = _G[info.buttonPrefix .. i]
        if button and button:GetNumPoints() > 0 then
            local point, relativeTo, relativePoint, x, y = button:GetPoint(1)
            local scale = button:GetScale()
            
            -- Get the true intrinsic size at scale 1
            local origScale = button:GetScale()
            button:SetScale(1)
            local baseWidth = button:GetWidth()
            local baseHeight = button:GetHeight()
            button:SetScale(origScale)
            
            -- Store icon anchor info
            local iconPoint, iconRelativeTo, iconRelativePoint, iconX, iconY
            local icon = button.icon or button.Icon
            if icon and icon:GetNumPoints() > 0 then
                iconPoint, iconRelativeTo, iconRelativePoint, iconX, iconY = icon:GetPoint(1)
            end
            
            originalButtonPositions[barId][i] = {
                point = point,
                relativeTo = relativeTo,
                relativePoint = relativePoint,
                x = x,
                y = y,
                scale = scale,
                baseWidth = baseWidth,
                baseHeight = baseHeight,
                iconPoint = iconPoint,
                iconRelativeTo = iconRelativeTo,
                iconRelativePoint = iconRelativePoint,
                iconX = iconX,
                iconY = iconY,
            }
        end
    end
    DebugPrint("Stored original positions for", barId)
end

local function RestoreOriginalPositions(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    
    local positions = originalButtonPositions[barId]
    if not positions then return end
    
    if IsInCombat() then
        QueueUpdate(barId)
        return
    end
    
    for i = 1, info.buttonCount do
        local button = _G[info.buttonPrefix .. i]
        local pos = positions[i]
        if button and pos and pos.relativeTo then
            -- Reset scale, restore position, restore original scale
            button:SetScale(1)
            button:ClearAllPoints()
            button:SetPoint(pos.point or "CENTER", pos.relativeTo, pos.relativePoint or "CENTER", pos.x or 0, pos.y or 0)
            button:SetScale(pos.scale or 1)
            
            -- Restore icon anchor
            local icon = button.icon or button.Icon
            if icon and pos.iconPoint then
                icon:ClearAllPoints()
                icon:SetPoint(pos.iconPoint, pos.iconRelativeTo or button, pos.iconRelativePoint or pos.iconPoint, pos.iconX or 0, pos.iconY or 0)
            end
            
            -- Restore button frame alpha
            local normalTex = button.NormalTexture or button:GetNormalTexture()
            if normalTex then
                normalTex:SetAlpha(1)
            end
            if button.FloatingBG then
                button.FloatingBG:SetAlpha(1)
            end
            if button.Border then
                button.Border:SetAlpha(1)
            end
            if button.SlotArt then
                button.SlotArt:SetAlpha(1)
            end
            if button.SlotBackground then
                button.SlotBackground:SetAlpha(1)
            end
            
            button:SetAlpha(1)
        end
    end
    DebugPrint("Restored original positions for", barId)
end

-- ============================================================================
-- BLIZZARD LAYOUT HOOK
-- ============================================================================

local function HookBarLayoutUpdate(barId)
    if hookedBars[barId] then return end
    
    local info = BAR_INFO[barId]
    if not info then return end
    
    local bar = _G[info.frame]
    if not bar then return end
    
    if bar.UpdateGridLayout then
        hooksecurefunc(bar, "UpdateGridLayout", function()
            if settings and settings.bars and settings.bars[barId] and settings.bars[barId].enabled then
                C_Timer.After(0.05, function()
                    if not IsInCombat() then
                        ActionBars:ApplyBarLayout(barId)
                    end
                end)
            end
        end)
    end
    
    hookedBars[barId] = true
end

-- ============================================================================
-- LAYOUT SYSTEM
-- ============================================================================

function ActionBars:ApplyBarLayout(barId)
    if IsInCombat() then
        QueueUpdate(barId)
        DebugPrint("Layout queued for", barId, "(in combat)")
        return
    end
    
    local barSettings = settings and settings.bars and settings.bars[barId]
    local info = BAR_INFO[barId]
    
    if not barSettings or not info then
        DebugPrint("No settings or info for", barId)
        return
    end
    
    if not barSettings.enabled then
        RestoreOriginalPositions(barId)
        return
    end
    
    local bar = _G[info.frame]
    if not bar then
        DebugPrint("Bar frame not found:", info.frame)
        return
    end
    
    -- Store original positions before modifying
    StoreOriginalPositions(barId)
    
    -- Hook layout updates
    HookBarLayoutUpdate(barId)
    
    local buttonsShown = barSettings.buttonsShown or 12
    local cols = barSettings.columns or 12
    local size = barSettings.buttonSize or 45
    local hSpacing = barSettings.horizontalSpacing or 6
    local vSpacing = barSettings.verticalSpacing or 6
    local orientation = barSettings.orientation or "horizontal"
    
    -- Calculate rows from buttons and columns
    local rows = math.ceil(buttonsShown / cols)
    
    -- Ensure bar itself has scale 1 so our offsets work correctly
    bar:SetScale(1)
    
    -- Base size is always 45 for WoW action buttons
    local baseSize = 45
    
    -- Calculate the scale factor
    local scale = size / baseSize
    
    -- Get button frame alpha setting (controls the border/slot texture, not the icon)
    local buttonFrameAlpha = barSettings.buttonFrameAlpha or 1.0
    
    DebugPrint("Applying layout to", barId, "- size:", size, "baseSize:", baseSize, "scale:", scale, "hSpacing:", hSpacing)
    
    -- Position each button
    -- Key insight: SetPoint offsets are in the CHILD's scaled coordinate space
    -- So we need to divide offsets by scale to get correct screen-space positions
    for i = 1, info.buttonCount do
        local button = _G[info.buttonPrefix .. i]
        if button then
            local row, col
            if orientation == "vertical" then
                col = math.floor((i - 1) / rows)
                row = (rows - 1) - ((i - 1) % rows)  -- Button 1 at top
            else
                row = math.floor((i - 1) / cols)
                col = (i - 1) % cols
            end
            
            -- Calculate desired screen-space position
            local xOffset = col * (size + hSpacing)
            local yOffset = row * (size + vSpacing)
            
            -- Reset scale and position
            button:SetScale(1)
            button:ClearAllPoints()
            
            -- Set scale FIRST
            button:SetScale(scale)
            
            -- Now set position - divide by scale since offsets are in scaled space
            button:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", xOffset / scale, yOffset / scale)
            
            -- Ensure icon fills the button frame
            local icon = button.icon or button.Icon
            if icon then
                icon:ClearAllPoints()
                icon:SetAllPoints(button)
            end
            
            -- Apply button frame alpha to the border/slot textures (not the icon)
            local normalTex = button.NormalTexture or button:GetNormalTexture()
            if normalTex then
                normalTex:SetAlpha(buttonFrameAlpha)
            end
            
            -- Also apply to other frame elements
            if button.FloatingBG then
                button.FloatingBG:SetAlpha(buttonFrameAlpha)
            end
            if button.Border then
                button.Border:SetAlpha(buttonFrameAlpha)
            end
            if button.SlotArt then
                button.SlotArt:SetAlpha(buttonFrameAlpha)
            end
            if button.SlotBackground then
                button.SlotBackground:SetAlpha(buttonFrameAlpha)
            end
            
            -- Show/hide based on buttonsShown
            if i <= buttonsShown then
                button:SetAlpha(1)
            else
                button:SetAlpha(0)
            end
        end
    end
    
    -- Resize bar container to fit the buttons
    local actualCols = math.min(cols, buttonsShown)
    
    -- Width is always based on columns, height on rows
    -- Orientation only changes how buttons are laid out, not the frame dimensions
    local totalWidth = actualCols * size + (actualCols - 1) * hSpacing
    local totalHeight = rows * size + (rows - 1) * vSpacing
    
    pcall(function()
        bar:SetSize(totalWidth, totalHeight)
    end)
    
    -- Store custom size for Edit Mode updates
    bar.tweaksCustomWidth = totalWidth
    bar.tweaksCustomHeight = totalHeight
    
    -- Update Edit Mode selection frame to match new size
    self:UpdateEditModeFrame(barId, totalWidth, totalHeight)
    
    DebugPrint("Layout complete for", barId)
end

-- Update Edit Mode selection frame for a specific bar
function ActionBars:UpdateEditModeFrame(barId, width, height)
    local info = BAR_INFO[barId]
    if not info then return end
    
    -- Get the frame that has the Selection child (may be different from button container)
    local selectionParentName = info.selectionFrame or info.frame
    local selectionParent = _G[selectionParentName]
    if not selectionParent then return end
    
    DebugPrint("UpdateEditModeFrame", barId, "parent:", selectionParentName, "size:", width, "x", height)
    
    -- Resize the selection parent frame
    -- The Selection frame should be anchored to fill its parent, so this should work
    pcall(function()
        selectionParent:SetSize(width, height)
    end)
    
    -- If Selection exists and uses SetAllPoints, resizing parent should be enough
    -- Don't modify Selection's anchors as that breaks Blizzard's snapping code
end

-- Debug function to find Edit Mode frame structure
function ActionBars:DebugEditModeFrames(barId)
    local info = BAR_INFO[barId or "ActionBar1"]
    if not info then 
        print("No bar info found")
        return 
    end
    
    local bar = _G[info.frame]
    if not bar then 
        print("Bar frame not found:", info.frame)
        return 
    end
    
    local barSettings = settings and settings.bars and settings.bars[barId]
    
    print("=== Edit Mode Debug for", barId or "ActionBar1", "===")
    
    -- Show our settings
    print("--- Our Settings ---")
    if barSettings then
        print("  enabled:", barSettings.enabled and "yes" or "no")
        print("  buttonsShown:", barSettings.buttonsShown or "nil")
        print("  columns:", barSettings.columns or "nil")
        print("  buttonSize:", barSettings.buttonSize or "nil")
        print("  hSpacing:", barSettings.horizontalSpacing or "nil")
        print("  vSpacing:", barSettings.verticalSpacing or "nil")
        print("  orientation:", barSettings.orientation or "nil")
        
        -- Calculate what size SHOULD be
        local buttonsShown = barSettings.buttonsShown or 12
        local cols = barSettings.columns or 12
        local size = barSettings.buttonSize or 45
        local hSpacing = barSettings.horizontalSpacing or 6
        local vSpacing = barSettings.verticalSpacing or 6
        local orientation = barSettings.orientation or "horizontal"
        local rows = math.ceil(buttonsShown / cols)
        local actualCols = math.min(cols, buttonsShown)
        
        -- Width is always based on columns, height on rows
        -- Orientation only changes how buttons are laid out, not the frame dimensions
        local calcWidth = actualCols * size + (actualCols - 1) * hSpacing
        local calcHeight = rows * size + (rows - 1) * vSpacing
        print("  Calculated size should be:", calcWidth, "x", calcHeight)
    else
        print("  No settings found!")
    end
    
    print("--- Frame Info ---")
    print("Button container:", info.frame)
    print("  Size:", string.format("%.1f x %.1f", bar:GetWidth(), bar:GetHeight()))
    print("  tweaksCustomWidth:", bar.tweaksCustomWidth or "nil")
    print("  tweaksCustomHeight:", bar.tweaksCustomHeight or "nil")
    
    -- Check the selection parent frame
    local selectionParentName = info.selectionFrame or info.frame
    print("Selection parent:", selectionParentName)
    
    local selectionParent = _G[selectionParentName]
    if selectionParent then
        print("  Size:", string.format("%.1f x %.1f", selectionParent:GetWidth(), selectionParent:GetHeight()))
        
        if selectionParent.Selection then
            local sel = selectionParent.Selection
            print("  Selection exists, size:", string.format("%.1f x %.1f", sel:GetWidth(), sel:GetHeight()))
            print("  Selection shown:", sel:IsShown() and "yes" or "no")
            
            -- Check anchoring
            local numPoints = sel:GetNumPoints()
            print("  Selection anchors:", numPoints)
            for i = 1, numPoints do
                local point, relativeTo, relativePoint, x, y = sel:GetPoint(i)
                local relName = relativeTo and (relativeTo:GetName() or "unnamed") or "nil"
                print(string.format("    %d: %s -> %s:%s (%.1f, %.1f)", i, point, relName, relativePoint or "?", x or 0, y or 0))
            end
        else
            print("  Selection: nil")
        end
    else
        print("  Selection parent not found!")
    end
    
    print("Edit Mode active:", EditModeManagerFrame and EditModeManagerFrame.editModeActive and "yes" or "no")
    print("=== End Debug ===")
end

-- Update all Edit Mode frames
function ActionBars:UpdateAllEditModeFrames()
    for _, barId in ipairs(BAR_ORDER) do
        local barSettings = settings and settings.bars and settings.bars[barId]
        if barSettings and barSettings.enabled then
            local info = BAR_INFO[barId]
            if info then
                local bar = _G[info.frame]
                if bar then
                    local width, height
                    
                    -- Use stored custom size if available
                    if bar.tweaksCustomWidth and bar.tweaksCustomHeight then
                        width = bar.tweaksCustomWidth
                        height = bar.tweaksCustomHeight
                    else
                        -- Calculate from settings
                        local buttonsShown = barSettings.buttonsShown or 12
                        local cols = barSettings.columns or 12
                        local size = barSettings.buttonSize or 45
                        local hSpacing = barSettings.horizontalSpacing or 6
                        local vSpacing = barSettings.verticalSpacing or 6
                        local orientation = barSettings.orientation or "horizontal"
                        
                        local rows = math.ceil(buttonsShown / cols)
                        local actualCols = math.min(cols, buttonsShown)
                        
                        -- Width is always based on columns, height on rows
                        width = actualCols * size + (actualCols - 1) * hSpacing
                        height = rows * size + (rows - 1) * vSpacing
                        
                        -- Store for future use
                        bar.tweaksCustomWidth = width
                        bar.tweaksCustomHeight = height
                    end
                    
                    self:UpdateEditModeFrame(barId, width, height)
                end
            end
        end
    end
end

function ActionBars:ApplyAllLayouts()
    for _, barId in ipairs(BAR_ORDER) do
        self:ApplyBarLayout(barId)
    end
end

function ActionBars:RestoreAllLayouts()
    for _, barId in ipairs(BAR_ORDER) do
        RestoreOriginalPositions(barId)
    end
end

-- ============================================================================
-- VISIBILITY SYSTEM (OR logic - show if ANY condition is met)
-- ============================================================================

local visibilityFrames = {}  -- Track visibility state per bar

local function UpdateBarVisibility(barId)
    local barSettings = settings and settings.bars and settings.bars[barId]
    local info = BAR_INFO[barId]
    
    if not barSettings or not info then return end
    
    -- Use visibilityFrame if specified, otherwise use main frame
    local visibilityFrameName = info.visibilityFrame or info.frame
    local bar = _G[visibilityFrameName]
    if not bar then return end
    
    -- Store original alpha if needed
    if not bar.tweaksOriginalAlpha then
        local currentAlpha = bar:GetAlpha()
        bar.tweaksOriginalAlpha = (currentAlpha > 0) and currentAlpha or 1
    end
    
    local barAlpha = barSettings.barAlpha or 1.0
    
    -- If tweaks not enabled, restore original alpha
    if not barSettings.enabled then
        bar:SetAlpha(bar.tweaksOriginalAlpha or 1)
        return
    end
    
    -- If visibility rules not enabled, just apply bar alpha
    if not barSettings.visibilityEnabled then
        bar:SetAlpha(barAlpha)
        return
    end
    
    -- Check all conditions (OR logic)
    local shouldShow = false
    
    -- Mouseover check
    if barSettings.showOnMouseover and bar.tweaksIsMouseOver then
        shouldShow = true
    end
    
    -- Combat check
    if barSettings.showInCombat and UnitAffectingCombat("player") then
        shouldShow = true
    end
    
    -- Out of combat check
    if barSettings.showOutOfCombat and not UnitAffectingCombat("player") then
        shouldShow = true
    end
    
    -- Target check
    if barSettings.showWithTarget and UnitExists("target") then
        shouldShow = true
    end
    
    -- Group checks
    if barSettings.showSolo and not IsInGroup() then
        shouldShow = true
    end
    if barSettings.showInParty and IsInGroup() and not IsInRaid() then
        shouldShow = true
    end
    if barSettings.showInRaid and IsInRaid() then
        shouldShow = true
    end
    
    -- Instance check
    if barSettings.showInInstance then
        local inInstance, instanceType = IsInInstance()
        if inInstance and (instanceType == "party" or instanceType == "raid") then
            shouldShow = true
        end
    end
    
    -- Mounted check
    if barSettings.showMounted and IsMounted() then
        shouldShow = true
    end
    
    -- Dragonriding/Skyriding check
    if barSettings.showDragonriding then
        local isDragonriding = false
        
        -- When dragonriding/skyriding, player is mounted and has the override bar active
        if IsMounted() then
            -- Check if we have the dragonriding action bar active
            -- HasBonusActionBar or HasOverrideActionBar indicates special mount bar
            if HasBonusActionBar and HasBonusActionBar() then
                isDragonriding = true
            elseif HasOverrideActionBar and HasOverrideActionBar() then
                isDragonriding = true
            end
            
            -- Alternative: check for Vigor power (power type 26 in some versions)
            if not isDragonriding then
                -- Check alternate power while mounted
                local maxVigor = UnitPowerMax("player", Enum.PowerType.Alternate or 10)
                if maxVigor and maxVigor > 0 then
                    isDragonriding = true
                end
            end
        end
        
        if isDragonriding then
            shouldShow = true
        end
    end
    
    -- Vehicle check
    if barSettings.showInVehicle and UnitInVehicle("player") then
        shouldShow = true
    end
    
    -- Apply visibility - use bar alpha when visible, 0 when hidden
    local targetAlpha = shouldShow and barAlpha or 0
    
    -- Smooth fade
    if bar.tweaksTargetAlpha ~= targetAlpha then
        bar.tweaksTargetAlpha = targetAlpha
        bar.tweaksFading = true
    end
end

local function SetupVisibilityUpdater(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    
    -- Use visibilityFrame if specified, otherwise use main frame
    local visibilityFrameName = info.visibilityFrame or info.frame
    local bar = _G[visibilityFrameName]
    if not bar then return end
    
    -- Don't setup twice
    if bar.tweaksVisibilityUpdater then return end
    
    local detector = CreateFrame("Frame", nil, bar)
    detector:SetAllPoints(bar)
    detector:EnableMouse(false)
    detector:SetMouseClickEnabled(false)
    
    detector.throttle = 0
    detector:SetScript("OnUpdate", function(self, elapsed)
        self.throttle = self.throttle + elapsed
        
        -- Check mouseover every frame for responsiveness
        local mouseOver = bar:IsMouseOver()
        if mouseOver ~= bar.tweaksIsMouseOver then
            bar.tweaksIsMouseOver = mouseOver
            UpdateBarVisibility(barId)
        end
        
        -- Check other conditions less frequently
        if self.throttle >= 0.1 then
            self.throttle = 0
            UpdateBarVisibility(barId)
        end
        
        -- Handle fading
        if bar.tweaksFading then
            local current = bar:GetAlpha()
            local target = bar.tweaksTargetAlpha or 1
            local step = elapsed * 5  -- Fade speed
            
            if current < target then
                bar:SetAlpha(math.min(current + step, target))
            elseif current > target then
                bar:SetAlpha(math.max(current - step, target))
            end
            
            if math.abs(current - target) < 0.01 then
                bar:SetAlpha(target)
                bar.tweaksFading = false
            end
        end
    end)
    
    bar.tweaksVisibilityUpdater = detector
    visibilityFrames[barId] = detector
end

local function TeardownVisibilityUpdater(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    
    -- Use visibilityFrame if specified, otherwise use main frame
    local visibilityFrameName = info.visibilityFrame or info.frame
    local bar = _G[visibilityFrameName]
    if not bar then return end
    
    if bar.tweaksVisibilityUpdater then
        bar.tweaksVisibilityUpdater:SetScript("OnUpdate", nil)
        bar.tweaksVisibilityUpdater:Hide()
        bar.tweaksVisibilityUpdater = nil
    end
    
    -- Reset state
    bar.tweaksIsMouseOver = nil
    bar.tweaksFading = nil
    bar.tweaksTargetAlpha = nil
    
    -- Restore alpha
    if bar.tweaksOriginalAlpha then
        bar:SetAlpha(bar.tweaksOriginalAlpha)
    else
        bar:SetAlpha(1)
    end
    
    visibilityFrames[barId] = nil
end

function ActionBars:ApplyVisibility(barId)
    local barSettings = settings and settings.bars and settings.bars[barId]
    
    if not barSettings then return end
    
    if barSettings.enabled and barSettings.visibilityEnabled then
        SetupVisibilityUpdater(barId)
        UpdateBarVisibility(barId)
    else
        TeardownVisibilityUpdater(barId)
        -- Still apply alpha even when visibility rules are off
        UpdateBarVisibility(barId)
    end
end

function ActionBars:ApplyAllVisibility()
    for _, barId in ipairs(BAR_ORDER) do
        self:ApplyVisibility(barId)
    end
end

-- ============================================================================
-- TEXT OVERLAY SETTINGS
-- ============================================================================

function ActionBars:ApplyTextSettings(barId)
    local barSettings = settings and settings.bars and settings.bars[barId]
    local info = BAR_INFO[barId]
    
    if not barSettings or not info then return end
    if not barSettings.enabled then return end
    
    local keybindAlpha = barSettings.keybindAlpha or 1
    local countAlpha = barSettings.countAlpha or 1
    local macroNameAlpha = barSettings.macroNameAlpha or 1
    
    -- Apply to each button
    for i = 1, info.buttonCount do
        local button = _G[info.buttonPrefix .. i]
        if button then
            -- Keybind/Hotkey text
            local hotKey = button.HotKey or _G[button:GetName() .. "HotKey"]
            if hotKey then
                hotKey:SetAlpha(keybindAlpha)
            end
            
            -- Stack count text
            local count = button.Count or _G[button:GetName() .. "Count"]
            if count then
                count:SetAlpha(countAlpha)
            end
            
            -- Macro name text
            local name = button.Name or _G[button:GetName() .. "Name"]
            if name then
                name:SetAlpha(macroNameAlpha)
            end
        end
    end
    
    -- Page arrows for Action Bar 1 only
    if barId == "ActionBar1" then
        local pageArrowsAlpha = barSettings.pageArrowsAlpha or 1
        
        -- The page number container and its children
        if MainActionBar and MainActionBar.ActionBarPageNumber then
            local pageNumber = MainActionBar.ActionBarPageNumber
            
            -- Set alpha on the whole container
            pageNumber:SetAlpha(pageArrowsAlpha)
            
            -- Also explicitly set on children in case they have separate alpha
            if pageNumber.UpButton then
                pageNumber.UpButton:SetAlpha(pageArrowsAlpha)
            end
            if pageNumber.DownButton then
                pageNumber.DownButton:SetAlpha(pageArrowsAlpha)
            end
            if pageNumber.Text then
                pageNumber.Text:SetAlpha(pageArrowsAlpha)
            end
        end
    end
    
    DebugPrint("Applied text settings for", barId)
end

function ActionBars:ApplyAllTextSettings()
    for _, barId in ipairs(BAR_ORDER) do
        self:ApplyTextSettings(barId)
    end
end

-- ============================================================================
-- EVENT HANDLING
-- ============================================================================

local function OnEvent(self, event, ...)
    if event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(1.0, function()
            ActionBars:ApplyAllLayouts()
            ActionBars:ApplyAllVisibility()
            ActionBars:ApplyAllTextSettings()
        end)
        -- Update Edit Mode frames after layouts are applied
        C_Timer.After(1.5, function()
            ActionBars:UpdateAllEditModeFrames()
        end)
    elseif event == "PLAYER_REGEN_ENABLED" then
        ProcessPendingUpdates()
        -- Don't unregister - we need it for visibility updates
    elseif event == "ACTIONBAR_PAGE_CHANGED" or event == "UPDATE_BONUS_ACTIONBAR" then
        if not IsInCombat() then
            C_Timer.After(0.1, function()
                ActionBars:ApplyBarLayout("ActionBar1")
            end)
        end
    elseif event == "EDIT_MODE_LAYOUTS_UPDATED" then
        -- Re-apply our layouts after Edit Mode updates
        C_Timer.After(0.1, function()
            ActionBars:ApplyAllLayouts()
        end)
        C_Timer.After(0.3, function()
            ActionBars:UpdateAllEditModeFrames()
        end)
    end
end

local function SetupEvents()
    if not eventFrame then
        eventFrame = CreateFrame("Frame")
    end
    eventFrame:SetScript("OnEvent", OnEvent)
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
    eventFrame:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
    eventFrame:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
end

local function TeardownEvents()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
    end
end

-- ============================================================================
-- SETTINGS UI - HELPERS
-- ============================================================================

local function CreateSlider(parent, x, y, label, minVal, maxVal, step, getValue, setValue, formatStr)
    local sliderFrame = CreateFrame("Frame", nil, parent)
    sliderFrame:SetSize(PANEL_WIDTH - 50, 50)
    sliderFrame:SetPoint("TOPLEFT", x, y)
    
    local labelText = sliderFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    labelText:SetPoint("TOPLEFT", 0, 0)
    labelText:SetText(label)
    
    local slider = CreateFrame("Slider", nil, sliderFrame, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", 0, -18)
    slider:SetSize(PANEL_WIDTH - 100, 17)
    slider:SetMinMaxValues(minVal, maxVal)
    slider:SetValueStep(step)
    slider:SetObeyStepOnDrag(true)
    slider:SetValue(getValue())
    
    local function FormatValue(val)
        if formatStr then
            return string.format(formatStr, val)
        else
            return tostring(val)
        end
    end
    
    slider.Low:SetText(FormatValue(minVal))
    slider.High:SetText(FormatValue(maxVal))
    slider.Text:SetText(FormatValue(getValue()))
    
    slider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value / step + 0.5) * step
        self.Text:SetText(FormatValue(value))
        setValue(value)
    end)
    
    return y - 55
end

local function CreateCheckbox(parent, x, y, label, getValue, setValue)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    cb:SetSize(24, 24)
    cb:SetChecked(getValue())
    cb.text:SetText(label)
    cb.text:SetFontObject("GameFontNormal")
    
    cb:SetScript("OnClick", function(self)
        setValue(self:GetChecked())
    end)
    
    return y - 28
end

local function CreateHeader(parent, x, y, text)
    local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header:SetPoint("TOPLEFT", x, y)
    header:SetText(text)
    header:SetTextColor(1, 0.82, 0)
    return y - 22
end

local function CreateSeparator(parent, y)
    local sep = parent:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT", 10, y)
    sep:SetSize(PANEL_WIDTH - 70, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    return y - 10
end

-- ============================================================================
-- SETTINGS UI - BAR SETTINGS PANEL
-- ============================================================================

function ActionBars:CreateBarSettingsPanel(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    
    local panelName = "TweaksUI_ActionBars_" .. barId .. "_Panel"
    
    local panel = CreateFrame("Frame", panelName, UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:SetClampedToScreen(true)
    panel:Hide()
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText(info.displayName)
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
        ActionBars:HideBarHighlight(barId)
        currentOpenPanel = nil
    end)
    
    -- Hide highlight when panel is hidden (escape key, etc)
    panel:SetScript("OnHide", function()
        ActionBars:HideBarHighlight(barId)
        currentOpenPanel = nil
    end)
    
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    
    -- Enable checkbox at top
    local function getBarSettings()
        return settings and settings.bars and settings.bars[barId] or GetDefaultBarSettings()
    end
    
    local function setBarSetting(key, value)
        if settings and settings.bars and settings.bars[barId] then
            settings.bars[barId][key] = value
            
            if key == "enabled" and value == true then
                C_Timer.After(0.1, function()
                    ActionBars:ApplyBarLayout(barId)
                    ActionBars:ApplyVisibility(barId)
                    ActionBars:ApplyTextSettings(barId)
                end)
            elseif key == "enabled" then
                ActionBars:ApplyBarLayout(barId)
                ActionBars:ApplyVisibility(barId)
                ActionBars:ApplyTextSettings(barId)
            elseif key == "buttonsShown" or key == "columns" or key == "orientation" or
                   key == "buttonSize" or key == "horizontalSpacing" or key == "verticalSpacing" or
                   key == "buttonFrameAlpha" then
                ActionBars:ApplyBarLayout(barId)
            elseif key:match("^show") or key == "visibilityEnabled" or key == "barAlpha" then
                ActionBars:ApplyVisibility(barId)
            elseif key == "keybindAlpha" or key == "countAlpha" or key == "macroNameAlpha" or key == "pageArrowsAlpha" then
                ActionBars:ApplyTextSettings(barId)
            end
        end
    end
    
    local enableCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    enableCb:SetPoint("TOPLEFT", 15, -35)
    enableCb:SetSize(24, 24)
    enableCb:SetChecked(getBarSettings().enabled)
    enableCb.text:SetText("Enable " .. info.displayName .. " Tweaks")
    enableCb.text:SetFontObject("GameFontNormal")
    enableCb:SetScript("OnClick", function(self)
        setBarSetting("enabled", self:GetChecked())
    end)
    
    -- Warning frame for hidden bars
    local warningFrame = CreateFrame("Frame", nil, panel, "BackdropTemplate")
    warningFrame:SetPoint("TOPLEFT", 10, -58)
    warningFrame:SetPoint("TOPRIGHT", -10, -58)
    warningFrame:SetHeight(40)
    warningFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    warningFrame:SetBackdropColor(0.3, 0.1, 0.1, 0.9)
    warningFrame:SetBackdropBorderColor(0.8, 0.2, 0.2, 1)
    warningFrame:Hide()
    
    local warningIcon = warningFrame:CreateTexture(nil, "ARTWORK")
    warningIcon:SetPoint("LEFT", 8, 0)
    warningIcon:SetSize(18, 18)
    warningIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
    
    local warningText = warningFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    warningText:SetPoint("TOPLEFT", warningIcon, "TOPRIGHT", 6, 2)
    warningText:SetPoint("RIGHT", -70, 0)
    warningText:SetJustifyH("LEFT")
    warningText:SetText("|cffff8888This bar is hidden.|r Enable it in Game Menu > Options > Action Bars.")
    warningText:SetWordWrap(true)
    
    local openOptionsBtn = CreateFrame("Button", nil, warningFrame, "UIPanelButtonTemplate")
    openOptionsBtn:SetPoint("RIGHT", -5, 0)
    openOptionsBtn:SetSize(60, 22)
    openOptionsBtn:SetText("Open")
    openOptionsBtn:SetScript("OnClick", function()
        -- Close our panels first so user can see Options
        ActionBars:HideAllPanels()
        
        -- Just show the settings panel - user can navigate to Action Bars
        if SettingsPanel then
            SettingsPanel:Show()
        else
            ToggleGameMenu()
        end
    end)
    
    panel.warningFrame = warningFrame
    
    -- Function to check if bar is visible
    local function IsBarVisible()
        local bar = _G[info.frame]
        if not bar then return false end
        
        -- Check if the bar or its parent is shown
        if bar:IsShown() then return true end
        
        -- For bars with parent containers, check parent too
        local parent = bar:GetParent()
        if parent and not parent:IsShown() then return false end
        
        return bar:IsShown()
    end
    
    -- Function to update warning visibility
    local function UpdateWarningVisibility()
        if barId == "ActionBar1" then
            -- Action Bar 1 is always visible
            warningFrame:Hide()
            return
        end
        
        if IsBarVisible() then
            warningFrame:Hide()
        else
            warningFrame:Show()
        end
    end
    
    -- Check on show
    panel:HookScript("OnShow", function()
        UpdateWarningVisibility()
    end)
    
    -- Periodically check while panel is shown (in case user enables bar in Edit Mode)
    local updateTimer = 0
    panel:HookScript("OnUpdate", function(self, elapsed)
        updateTimer = updateTimer + elapsed
        if updateTimer >= 1.0 then
            updateTimer = 0
            UpdateWarningVisibility()
        end
    end)
    
    -- Store the update function for external calls
    panel.UpdateWarningVisibility = UpdateWarningVisibility
    
    -- Tab buttons (positioned below warning area)
    local TAB_HEIGHT = 24
    local tabContainer = CreateFrame("Frame", nil, panel)
    tabContainer:SetPoint("TOPLEFT", 10, -103)
    tabContainer:SetPoint("TOPRIGHT", -10, -103)
    tabContainer:SetHeight(TAB_HEIGHT)
    
    -- Content frames for each tab
    local layoutContent = CreateFrame("Frame", nil, panel)
    layoutContent:SetPoint("TOPLEFT", 10, -133)
    layoutContent:SetPoint("BOTTOMRIGHT", -30, 10)
    
    local visibilityContent = CreateFrame("Frame", nil, panel)
    visibilityContent:SetPoint("TOPLEFT", 10, -133)
    visibilityContent:SetPoint("BOTTOMRIGHT", -30, 10)
    visibilityContent:Hide()
    
    local textContent = CreateFrame("Frame", nil, panel)
    textContent:SetPoint("TOPLEFT", 10, -133)
    textContent:SetPoint("BOTTOMRIGHT", -30, 10)
    textContent:Hide()
    
    local function SelectTab(tabName)
        if tabName == "layout" then
            layoutContent:Show()
            visibilityContent:Hide()
            textContent:Hide()
            panel.layoutTab:SetNormalFontObject("GameFontHighlight")
            panel.visibilityTab:SetNormalFontObject("GameFontNormal")
            panel.textTab:SetNormalFontObject("GameFontNormal")
        elseif tabName == "visibility" then
            layoutContent:Hide()
            visibilityContent:Show()
            textContent:Hide()
            panel.layoutTab:SetNormalFontObject("GameFontNormal")
            panel.visibilityTab:SetNormalFontObject("GameFontHighlight")
            panel.textTab:SetNormalFontObject("GameFontNormal")
        else
            layoutContent:Hide()
            visibilityContent:Hide()
            textContent:Show()
            panel.layoutTab:SetNormalFontObject("GameFontNormal")
            panel.visibilityTab:SetNormalFontObject("GameFontNormal")
            panel.textTab:SetNormalFontObject("GameFontHighlight")
        end
    end
    
    local TAB_WIDTH = (PANEL_WIDTH - 38) / 3
    
    local layoutTab = CreateFrame("Button", nil, tabContainer)
    layoutTab:SetSize(TAB_WIDTH, TAB_HEIGHT)
    layoutTab:SetPoint("TOPLEFT", 0, 0)
    layoutTab:SetNormalFontObject("GameFontHighlight")
    layoutTab:SetText("Layout")
    layoutTab:GetFontString():SetPoint("CENTER")
    layoutTab:SetScript("OnClick", function() SelectTab("layout") end)
    
    local layoutTabBg = layoutTab:CreateTexture(nil, "BACKGROUND")
    layoutTabBg:SetAllPoints()
    layoutTabBg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
    
    panel.layoutTab = layoutTab
    
    local visibilityTab = CreateFrame("Button", nil, tabContainer)
    visibilityTab:SetSize(TAB_WIDTH, TAB_HEIGHT)
    visibilityTab:SetPoint("TOPLEFT", layoutTab, "TOPRIGHT", 4, 0)
    visibilityTab:SetNormalFontObject("GameFontNormal")
    visibilityTab:SetText("Visibility")
    visibilityTab:GetFontString():SetPoint("CENTER")
    visibilityTab:SetScript("OnClick", function() SelectTab("visibility") end)
    
    local visibilityTabBg = visibilityTab:CreateTexture(nil, "BACKGROUND")
    visibilityTabBg:SetAllPoints()
    visibilityTabBg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
    
    panel.visibilityTab = visibilityTab
    
    local textTab = CreateFrame("Button", nil, tabContainer)
    textTab:SetSize(TAB_WIDTH, TAB_HEIGHT)
    textTab:SetPoint("TOPLEFT", visibilityTab, "TOPRIGHT", 4, 0)
    textTab:SetNormalFontObject("GameFontNormal")
    textTab:SetText("Text")
    textTab:GetFontString():SetPoint("CENTER")
    textTab:SetScript("OnClick", function() SelectTab("text") end)
    
    local textTabBg = textTab:CreateTexture(nil, "BACKGROUND")
    textTabBg:SetAllPoints()
    textTabBg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
    
    panel.textTab = textTab
    
    -- ========== LAYOUT TAB CONTENT ==========
    local layoutScroll = CreateFrame("ScrollFrame", nil, layoutContent, "UIPanelScrollFrameTemplate")
    layoutScroll:SetAllPoints()
    
    local layoutScrollChild = CreateFrame("Frame", nil, layoutScroll)
    layoutScrollChild:SetSize(PANEL_WIDTH - 60, 400)
    layoutScroll:SetScrollChild(layoutScrollChild)
    
    local y = -5
    
    y = CreateSlider(layoutScrollChild, 5, y, "Buttons Shown", 1, 12, 1,
        function() return getBarSettings().buttonsShown end,
        function(v) setBarSetting("buttonsShown", v) end)
    
    y = CreateCheckbox(layoutScrollChild, 5, y, "Vertical Orientation",
        function() return getBarSettings().orientation == "vertical" end,
        function(v) setBarSetting("orientation", v and "vertical" or "horizontal") end)
    
    y = CreateSlider(layoutScrollChild, 5, y, "Columns", 1, 12, 1,
        function() return getBarSettings().columns end,
        function(v) setBarSetting("columns", v) end)
    
    y = CreateSlider(layoutScrollChild, 5, y, "Button Size", 24, 72, 1,
        function() return getBarSettings().buttonSize end,
        function(v) setBarSetting("buttonSize", v) end)
    
    y = CreateSlider(layoutScrollChild, 5, y, "Horizontal Spacing", -20, 16, 1,
        function() return getBarSettings().horizontalSpacing end,
        function(v) setBarSetting("horizontalSpacing", v) end)
    
    y = CreateSlider(layoutScrollChild, 5, y, "Vertical Spacing", -20, 16, 1,
        function() return getBarSettings().verticalSpacing end,
        function(v) setBarSetting("verticalSpacing", v) end)
    
    -- ========== VISIBILITY TAB CONTENT ==========
    local visibilityScroll = CreateFrame("ScrollFrame", nil, visibilityContent, "UIPanelScrollFrameTemplate")
    visibilityScroll:SetAllPoints()
    
    local visibilityScrollChild = CreateFrame("Frame", nil, visibilityScroll)
    visibilityScrollChild:SetSize(PANEL_WIDTH - 60, 600)
    visibilityScroll:SetScrollChild(visibilityScrollChild)
    
    y = -5
    
    -- Helper function to create alpha slider
    local function CreateAlphaSlider(parent, x, yPos, label, getSetting, setSetting, minVal)
        minVal = minVal or 0.1
        local container = CreateFrame("Frame", nil, parent)
        container:SetPoint("TOPLEFT", x, yPos)
        container:SetSize(PANEL_WIDTH - 60, 45)
        
        local sliderLabel = container:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sliderLabel:SetPoint("TOPLEFT", 0, 0)
        sliderLabel:SetText(label)
        
        local sliderValue = container:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        sliderValue:SetPoint("TOPRIGHT", 0, 0)
        
        local slider = CreateFrame("Slider", nil, container, "OptionsSliderTemplate")
        slider:SetPoint("TOPLEFT", 0, -18)
        slider:SetPoint("TOPRIGHT", 0, -18)
        slider:SetMinMaxValues(minVal, 1.0)
        slider:SetValueStep(0.05)
        slider:SetObeyStepOnDrag(true)
        slider.Low:SetText(string.format("%d%%", minVal * 100))
        slider.High:SetText("100%")
        
        local function UpdateDisplay()
            local val = getSetting() or 1.0
            sliderValue:SetText(string.format("%d%%", val * 100))
            slider:SetValue(val)
        end
        
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.floor(value * 20 + 0.5) / 20
            sliderValue:SetText(string.format("%d%%", value * 100))
            setSetting(value)
        end)
        
        slider:HookScript("OnShow", UpdateDisplay)
        UpdateDisplay()
        
        return yPos - 50
    end
    
    -- Opacity section header
    local opacityLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    opacityLabel:SetPoint("TOPLEFT", 5, y - 5)
    opacityLabel:SetText("|cffaaaaaa— Opacity —|r")
    y = y - 20
    
    -- Action Bar Opacity slider
    y = CreateAlphaSlider(visibilityScrollChild, 5, y, "Action Bar Opacity",
        function() return getBarSettings().barAlpha end,
        function(v) setBarSetting("barAlpha", v) end,
        0.1)
    
    -- Button Frame Opacity slider (can go to 0)
    y = CreateAlphaSlider(visibilityScrollChild, 5, y, "Button Frame Opacity",
        function() return getBarSettings().buttonFrameAlpha end,
        function(v) setBarSetting("buttonFrameAlpha", v) end,
        0)
    
    y = CreateSeparator(visibilityScrollChild, y - 5)
    
    -- Visibility Rules section
    local visRulesLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    visRulesLabel:SetPoint("TOPLEFT", 5, y - 5)
    visRulesLabel:SetText("|cffaaaaaa— Visibility Rules —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 5, y, "Enable Visibility Rules",
        function() return getBarSettings().visibilityEnabled end,
        function(v) setBarSetting("visibilityEnabled", v) end)
    
    local infoText = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    infoText:SetPoint("TOPLEFT", 25, y - 5)
    infoText:SetText("|cff888888Bar shows if ANY checked condition is true|r")
    y = y - 20
    
    local mouseoverLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mouseoverLabel:SetPoint("TOPLEFT", 5, y - 5)
    mouseoverLabel:SetText("|cffaaaaaa— Mouseover —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show On Mouseover",
        function() return getBarSettings().showOnMouseover end,
        function(v) setBarSetting("showOnMouseover", v) end)
    
    local combatLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    combatLabel:SetPoint("TOPLEFT", 5, y - 5)
    combatLabel:SetText("|cffaaaaaa— Combat —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show In Combat",
        function() return getBarSettings().showInCombat end,
        function(v) setBarSetting("showInCombat", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show Out of Combat",
        function() return getBarSettings().showOutOfCombat end,
        function(v) setBarSetting("showOutOfCombat", v) end)
    
    local targetLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    targetLabel:SetPoint("TOPLEFT", 5, y - 5)
    targetLabel:SetText("|cffaaaaaa— Target —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show With Target",
        function() return getBarSettings().showWithTarget end,
        function(v) setBarSetting("showWithTarget", v) end)
    
    local groupLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    groupLabel:SetPoint("TOPLEFT", 5, y - 5)
    groupLabel:SetText("|cffaaaaaa— Group —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show Solo",
        function() return getBarSettings().showSolo end,
        function(v) setBarSetting("showSolo", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show In Party",
        function() return getBarSettings().showInParty end,
        function(v) setBarSetting("showInParty", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show In Raid",
        function() return getBarSettings().showInRaid end,
        function(v) setBarSetting("showInRaid", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show In Instance",
        function() return getBarSettings().showInInstance end,
        function(v) setBarSetting("showInInstance", v) end)
    
    local specialLabel = visibilityScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    specialLabel:SetPoint("TOPLEFT", 5, y - 5)
    specialLabel:SetText("|cffaaaaaa— Special —|r")
    y = y - 20
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show When Mounted",
        function() return getBarSettings().showMounted end,
        function(v) setBarSetting("showMounted", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show In Vehicle",
        function() return getBarSettings().showInVehicle end,
        function(v) setBarSetting("showInVehicle", v) end)
    
    y = CreateCheckbox(visibilityScrollChild, 20, y, "Show When Dragonriding",
        function() return getBarSettings().showDragonriding end,
        function(v) setBarSetting("showDragonriding", v) end)
    
    -- ========== TEXT TAB CONTENT ==========
    local textScroll = CreateFrame("ScrollFrame", nil, textContent, "UIPanelScrollFrameTemplate")
    textScroll:SetAllPoints()
    
    local textScrollChild = CreateFrame("Frame", nil, textScroll)
    textScrollChild:SetSize(PANEL_WIDTH - 60, 300)
    textScroll:SetScrollChild(textScrollChild)
    
    y = -5
    
    local textLabel = textScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    textLabel:SetPoint("TOPLEFT", 5, y)
    textLabel:SetText("|cffaaaaaa— Text Overlay Alpha —|r")
    y = y - 20
    
    y = CreateSlider(textScrollChild, 5, y, "Keybind Text", 0, 100, 1,
        function() return (getBarSettings().keybindAlpha or 1) * 100 end,
        function(v) setBarSetting("keybindAlpha", v / 100) end,
        "%d%%")
    
    y = CreateSlider(textScrollChild, 5, y, "Stack Count", 0, 100, 1,
        function() return (getBarSettings().countAlpha or 1) * 100 end,
        function(v) setBarSetting("countAlpha", v / 100) end,
        "%d%%")
    
    y = CreateSlider(textScrollChild, 5, y, "Macro Name", 0, 100, 1,
        function() return (getBarSettings().macroNameAlpha or 1) * 100 end,
        function(v) setBarSetting("macroNameAlpha", v / 100) end,
        "%d%%")
    
    -- Page arrows only for Action Bar 1
    if barId == "ActionBar1" then
        local arrowsLabel = textScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        arrowsLabel:SetPoint("TOPLEFT", 5, y - 10)
        arrowsLabel:SetText("|cffaaaaaa— Action Bar 1 Special —|r")
        y = y - 30
        
        y = CreateSlider(textScrollChild, 5, y, "Page Arrows", 0, 100, 1,
            function() return (getBarSettings().pageArrowsAlpha or 1) * 100 end,
            function(v) setBarSetting("pageArrowsAlpha", v / 100) end,
            "%d%%")
    end
    
    settingsPanels[barId] = panel
    return panel
end

-- ============================================================================
-- SETTINGS UI - HUB PANEL
-- ============================================================================

function ActionBars:ShowHub(parentPanel)
    if actionBarsHub then
        actionBarsHub:ClearAllPoints()
        actionBarsHub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
        actionBarsHub:Show()
        return
    end
    
    local hub = CreateFrame("Frame", "TweaksUI_ActionBars_Hub", UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, HUB_HEIGHT)
    hub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    hub:SetMovable(true)
    hub:EnableMouse(true)
    hub:SetClampedToScreen(true)
    
    actionBarsHub = hub
    
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Action Bars")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function()
        self:HideAllPanels()
    end)
    
    hub:RegisterForDrag("LeftButton")
    hub:SetScript("OnDragStart", hub.StartMoving)
    hub:SetScript("OnDragStop", hub.StopMovingOrSizing)
    hub:SetScript("OnHide", function()
        self:HideAllHighlights()
    end)
    
    local yOffset = -42
    local buttonWidth = HUB_WIDTH - 20
    
    local sectionLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sectionLabel:SetPoint("TOP", 0, yOffset)
    sectionLabel:SetText("|cff888888Action Bar Settings|r")
    yOffset = yOffset - 18
    
    for _, barId in ipairs(BAR_ORDER) do
        local info = BAR_INFO[barId]
        if info then
            local btn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
            btn:SetSize(buttonWidth, BUTTON_HEIGHT)
            btn:SetPoint("TOP", 0, yOffset)
            btn:SetText(info.displayName)
            btn:SetScript("OnClick", function()
                self:ToggleBarPanel(barId)
            end)
            yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
        end
    end
    
    yOffset = yOffset - 8
    local sep = hub:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOP", 0, yOffset)
    sep:SetSize(buttonWidth, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 12
    
    local quickLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    quickLabel:SetPoint("TOP", 0, yOffset)
    quickLabel:SetText("|cff888888Quick Actions|r")
    yOffset = yOffset - 20
    
    local applyBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    applyBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    applyBtn:SetPoint("TOP", 0, yOffset)
    applyBtn:SetText("Apply All Changes")
    applyBtn:SetScript("OnClick", function()
        self:ApplyAllLayouts()
        self:ApplyAllVisibility()
        TweaksUI:Print("Action Bars: All changes applied")
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    local resetBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    resetBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    resetBtn:SetPoint("TOP", 0, yOffset)
    resetBtn:SetText("Reset to Default")
    resetBtn:SetScript("OnClick", function()
        StaticPopup_Show("TWEAKSUI_ACTIONBARS_RESET")
    end)
    
    StaticPopupDialogs["TWEAKSUI_ACTIONBARS_RESET"] = {
        text = "Reset all Action Bar settings to default?",
        button1 = "Reset",
        button2 = "Cancel",
        OnAccept = function()
            settings.bars = DeepCopy(DEFAULT_SETTINGS.bars)
            ActionBars:RestoreAllLayouts()
            TweaksUI:Print("Action Bars: Reset to default")
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
    
    hub:Show()
end

function ActionBars:ToggleBarPanel(barId)
    -- Hide all other panels and their highlights
    for name, panel in pairs(settingsPanels) do
        if panel and name ~= barId then
            panel:Hide()
            self:HideBarHighlight(name)
        end
    end
    
    if settingsPanels[barId] then
        if settingsPanels[barId]:IsShown() then
            settingsPanels[barId]:Hide()
            self:HideBarHighlight(barId)
            currentOpenPanel = nil
        else
            settingsPanels[barId]:ClearAllPoints()
            settingsPanels[barId]:SetPoint("TOPLEFT", actionBarsHub, "TOPRIGHT", 0, 0)
            settingsPanels[barId]:Show()
            self:ShowBarHighlight(barId)
            currentOpenPanel = barId
        end
    else
        self:CreateBarSettingsPanel(barId)
        if settingsPanels[barId] then
            settingsPanels[barId]:ClearAllPoints()
            settingsPanels[barId]:SetPoint("TOPLEFT", actionBarsHub, "TOPRIGHT", 0, 0)
            settingsPanels[barId]:Show()
            self:ShowBarHighlight(barId)
            currentOpenPanel = barId
        end
    end
end

-- Create and show highlight around the selected action bar
function ActionBars:ShowBarHighlight(barId)
    local info = BAR_INFO[barId]
    if not info then return end
    
    local bar = _G[info.frame]
    if not bar then return end
    
    -- Create highlight frame if it doesn't exist
    if not highlightFrames[barId] then
        local highlight = CreateFrame("Frame", nil, bar, "BackdropTemplate")
        highlight:SetFrameStrata("HIGH")
        
        -- Inner glow
        local innerGlow = highlight:CreateTexture(nil, "BACKGROUND")
        innerGlow:SetTexture("Interface\\Buttons\\WHITE8x8")
        innerGlow:SetAllPoints()
        innerGlow:SetVertexColor(0, 0.8, 1, 0.3)
        highlight.innerGlow = innerGlow
        
        -- Create multiple border layers for thickness
        for i = 1, 3 do
            local border = highlight:CreateTexture(nil, "BORDER")
            border:SetTexture("Interface\\Buttons\\WHITE8x8")
            border:SetVertexColor(0, 0.8, 1, 1)
            highlight["border" .. i] = border
        end
        
        -- Top border
        highlight.border1:SetPoint("TOPLEFT", highlight, "TOPLEFT", 0, 0)
        highlight.border1:SetPoint("TOPRIGHT", highlight, "TOPRIGHT", 0, 0)
        highlight.border1:SetHeight(3)
        
        -- Bottom border
        highlight.border2:SetPoint("BOTTOMLEFT", highlight, "BOTTOMLEFT", 0, 0)
        highlight.border2:SetPoint("BOTTOMRIGHT", highlight, "BOTTOMRIGHT", 0, 0)
        highlight.border2:SetHeight(3)
        
        -- Left border
        highlight.border3:SetPoint("TOPLEFT", highlight, "TOPLEFT", 0, 0)
        highlight.border3:SetPoint("BOTTOMLEFT", highlight, "BOTTOMLEFT", 0, 0)
        highlight.border3:SetWidth(3)
        
        -- Right border (need a 4th)
        local border4 = highlight:CreateTexture(nil, "BORDER")
        border4:SetTexture("Interface\\Buttons\\WHITE8x8")
        border4:SetVertexColor(0, 0.8, 1, 1)
        border4:SetPoint("TOPRIGHT", highlight, "TOPRIGHT", 0, 0)
        border4:SetPoint("BOTTOMRIGHT", highlight, "BOTTOMRIGHT", 0, 0)
        border4:SetWidth(3)
        highlight.border4 = border4
        
        -- Outer glow effect using a larger frame behind
        local outerGlow = CreateFrame("Frame", nil, highlight)
        outerGlow:SetPoint("TOPLEFT", -6, 6)
        outerGlow:SetPoint("BOTTOMRIGHT", 6, -6)
        outerGlow:SetFrameLevel(highlight:GetFrameLevel() - 1)
        
        local outerGlowTex = outerGlow:CreateTexture(nil, "BACKGROUND")
        outerGlowTex:SetTexture("Interface\\Buttons\\WHITE8x8")
        outerGlowTex:SetAllPoints()
        outerGlowTex:SetVertexColor(0, 0.6, 1, 0.4)
        highlight.outerGlow = outerGlow
        highlight.outerGlowTex = outerGlowTex
        
        -- Pulsing animation - faster and more dramatic
        local ag = highlight:CreateAnimationGroup()
        ag:SetLooping("REPEAT")
        
        local fadeOut = ag:CreateAnimation("Alpha")
        fadeOut:SetFromAlpha(1)
        fadeOut:SetToAlpha(0.3)
        fadeOut:SetDuration(0.4)
        fadeOut:SetOrder(1)
        
        local fadeIn = ag:CreateAnimation("Alpha")
        fadeIn:SetFromAlpha(0.3)
        fadeIn:SetToAlpha(1)
        fadeIn:SetDuration(0.4)
        fadeIn:SetOrder(2)
        
        highlight.pulseAnim = ag
        highlightFrames[barId] = highlight
    end
    
    local highlight = highlightFrames[barId]
    highlight:SetParent(bar)
    highlight:ClearAllPoints()
    highlight:SetPoint("TOPLEFT", bar, "TOPLEFT", -6, 6)
    highlight:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 6, -6)
    highlight:Show()
    highlight.outerGlow:Show()
    highlight.pulseAnim:Play()
end

-- Hide highlight for a bar
function ActionBars:HideBarHighlight(barId)
    if highlightFrames[barId] then
        highlightFrames[barId].pulseAnim:Stop()
        highlightFrames[barId]:Hide()
        if highlightFrames[barId].outerGlow then
            highlightFrames[barId].outerGlow:Hide()
        end
    end
end

-- Hide all highlights
function ActionBars:HideAllHighlights()
    for barId, _ in pairs(highlightFrames) do
        self:HideBarHighlight(barId)
    end
end

function ActionBars:HideAllPanels()
    if actionBarsHub then
        actionBarsHub:Hide()
    end
    for _, panel in pairs(settingsPanels) do
        if panel and panel.Hide then
            panel:Hide()
        end
    end
    self:HideAllHighlights()
    currentOpenPanel = nil
end

-- ============================================================================
-- PUBLIC API
-- ============================================================================

function ActionBars:GetSettings()
    return settings
end

function ActionBars:SaveSettings()
    if settings then
        TweaksUI.Database:SetModuleSettings(self.id, settings)
    end
end

function ActionBars:Refresh()
    self:ApplyAllLayouts()
    self:ApplyAllVisibility()
end

-- ============================================================================
-- MODULE LIFECYCLE
-- ============================================================================

function ActionBars:OnInitialize()
    DebugPrint("OnInitialize")
    
    local db = TweaksUI.Database:GetModuleSettings(self.id)
    if not db or not db.bars then
        db = DeepCopy(DEFAULT_SETTINGS)
        TweaksUI.Database:SetModuleSettings(self.id, db)
    end
    
    EnsureDefaults(db, DEFAULT_SETTINGS)
    settings = db
    
    DebugPrint("Settings loaded")
end

function ActionBars:OnEnable()
    DebugPrint("OnEnable")
    
    if not settings then return end
    
    -- Clear stored positions to get fresh measurements from Blizzard's defaults
    originalButtonPositions = {}
    
    settings.enabled = true
    SetupEvents()
    
    C_Timer.After(0.5, function()
        self:ApplyAllLayouts()
        self:ApplyAllVisibility()
        self:ApplyAllTextSettings()
    end)
    
    -- Update Edit Mode frames after a delay to ensure they're loaded
    C_Timer.After(1.0, function()
        self:UpdateAllEditModeFrames()
    end)
    
    -- Another pass to catch any late-loading frames
    C_Timer.After(3.0, function()
        self:UpdateAllEditModeFrames()
    end)
    
    -- Hook Edit Mode to update selection frames when entering
    if EditModeManagerFrame and not self.editModeHooked then
        hooksecurefunc(EditModeManagerFrame, "EnterEditMode", function()
            -- Multiple updates to catch any timing issues
            C_Timer.After(0.1, function()
                ActionBars:UpdateAllEditModeFrames()
            end)
            C_Timer.After(0.5, function()
                ActionBars:UpdateAllEditModeFrames()
            end)
            
            -- Start a ticker to keep enforcing our sizes while in Edit Mode
            if not ActionBars.editModeTicker then
                ActionBars.editModeTicker = C_Timer.NewTicker(0.5, function()
                    if EditModeManagerFrame and EditModeManagerFrame.editModeActive then
                        ActionBars:UpdateAllEditModeFrames()
                    else
                        -- Exit Edit Mode - stop ticker
                        if ActionBars.editModeTicker then
                            ActionBars.editModeTicker:Cancel()
                            ActionBars.editModeTicker = nil
                        end
                    end
                end)
            end
        end)
        
        -- Also hook ExitEditMode to clean up
        hooksecurefunc(EditModeManagerFrame, "ExitEditMode", function()
            if ActionBars.editModeTicker then
                ActionBars.editModeTicker:Cancel()
                ActionBars.editModeTicker = nil
            end
        end)
        
        self.editModeHooked = true
    end
    
    TweaksUI:Print("Action Bars |cff00ff00enabled|r")
end

function ActionBars:OnDisable()
    DebugPrint("OnDisable")
    
    if not settings then return end
    
    settings.enabled = false
    TeardownEvents()
    self:RestoreAllLayouts()
    
    -- Disable visibility for all bars
    for _, barId in ipairs(BAR_ORDER) do
        TeardownVisibilityUpdater(barId)
    end
    
    TweaksUI:Print("Action Bars |cffff0000disabled|r")
end

function ActionBars:OnProfileChanged(profileName)
    DebugPrint("OnProfileChanged:", profileName)
    
    local db = TweaksUI.Database:GetModuleSettings(self.id)
    if not db or not db.bars then
        db = DeepCopy(DEFAULT_SETTINGS)
    end
    EnsureDefaults(db, DEFAULT_SETTINGS)
    settings = db
    
    if self.enabled then
        self:Refresh()
    end
end

TweaksUI.ActionBars = ActionBars
