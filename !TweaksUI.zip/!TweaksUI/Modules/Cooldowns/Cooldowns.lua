-- ============================================================================
-- TweaksUI Cooldowns Module
-- Hooks Blizzard's Cooldown Manager viewers and applies custom layouts
-- ============================================================================

local ADDON_NAME, TweaksUI = ...

-- Ensure module IDs exist
if not TweaksUI.MODULE_IDS then return end
if not TweaksUI.MODULE_IDS.COOLDOWNS then
    TweaksUI.MODULE_IDS.COOLDOWNS = "cooldowns"
    TweaksUI.MODULE_NAMES[TweaksUI.MODULE_IDS.COOLDOWNS] = "Cooldown Trackers"
    table.insert(TweaksUI.MODULE_LOAD_ORDER, 1, TweaksUI.MODULE_IDS.COOLDOWNS)
end

-- Create the module
local Cooldowns = TweaksUI.ModuleManager:NewModule(TweaksUI.MODULE_IDS.COOLDOWNS)

-- ============================================================================
-- BLIZZARD VIEWER DEFINITIONS
-- ============================================================================

-- These are the frames Blizzard creates for the Cooldown Manager system
local TRACKERS = {
    { 
        name = "EssentialCooldownViewer", 
        displayName = "Essential Cooldowns", 
        key = "essential",
        isBarType = false 
    },
    { 
        name = "UtilityCooldownViewer", 
        displayName = "Utility Cooldowns", 
        key = "utility",
        isBarType = false 
    },
    { 
        name = "BuffIconCooldownViewer", 
        displayName = "Buff Tracker", 
        key = "buffs",
        isBarType = false 
    },
}

-- ============================================================================
-- CONSTANTS
-- ============================================================================

local HUB_WIDTH = 220
local HUB_HEIGHT = 480
local PANEL_WIDTH = 420
local PANEL_HEIGHT = 600
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 6

-- Dark backdrop
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

-- Aspect ratio presets
local ASPECT_PRESETS = {
    { label = "1:1 (Square)", value = "1:1" },
    { label = "4:3", value = "4:3" },
    { label = "3:4", value = "3:4" },
    { label = "16:9 (Wide)", value = "16:9" },
    { label = "9:16 (Tall)", value = "9:16" },
    { label = "2:1", value = "2:1" },
    { label = "1:2", value = "1:2" },
    { label = "Custom", value = "custom" },
}

-- Shared tracker defaults (used by all trackers)
local TRACKER_DEFAULTS = {
    enabled = true,
    -- Icon size
    iconSize = 36,              -- Base size (used with aspect ratio)
    iconWidth = nil,            -- Custom width (nil = use iconSize + aspect)
    iconHeight = nil,           -- Custom height (nil = use iconSize + aspect)
    aspectRatio = "1:1",        -- Preset or "custom"
    -- Layout
    columns = 8,
    rows = 0,                   -- 0 = unlimited
    customLayout = "",          -- Custom pattern like "4,4,2" (empty = use columns)
    spacingH = 2,               -- Horizontal spacing between icons
    spacingV = 2,               -- Vertical spacing between rows
    growDirection = "RIGHT",    -- PRIMARY: LEFT, RIGHT, UP, or DOWN
    growSecondary = "DOWN",     -- SECONDARY: LEFT, RIGHT, UP, or DOWN
    alignment = "LEFT",         -- LEFT, CENTER, or RIGHT
    reverseOrder = false,
    -- Appearance
    zoom = 0.08,                -- Texture inset (0 = full, higher = more zoom)
    borderAlpha = 1.0,
    iconOpacity = 1.0,
    -- Text
    cooldownTextScale = 1.0,    -- Scale of countdown numbers
    countTextScale = 1.0,       -- Scale of stack counts
    -- Visibility
    visibilityEnabled = false,  -- Master toggle for visibility conditions
    showInCombat = true,
    showOutOfCombat = true,
    showSolo = true,
    showInParty = true,
    showInRaid = true,
    showInInstance = true,
    showInArena = true,
    showInBattleground = true,
    showHasTarget = true,       -- Has a target selected
    showNoTarget = true,        -- No target selected
    -- Fade
    fadeEnabled = false,
    fadeDelay = 3.0,            -- Seconds before fading
    fadeAlpha = 0.3,            -- Alpha when faded
    fadeDuration = 0.3,         -- Fade animation duration
    -- Persistent icon order (saved by texture fileID)
    savedIconOrder = {},        -- Array of texture fileIDs in desired order
}

-- Copy defaults for each tracker
local function CreateTrackerDefaults()
    local t = {}
    for k, v in pairs(TRACKER_DEFAULTS) do
        t[k] = v
    end
    return t
end

local DEFAULTS = {
    -- Per-tracker settings (copy shared defaults)
    essential = CreateTrackerDefaults(),
    utility = CreateTrackerDefaults(),
    buffs = CreateTrackerDefaults(),
    -- Global settings
    global = {
        debugMode = false,
    },
}

-- Add buff-specific settings
DEFAULTS.buffs.greyscaleInactive = true
DEFAULTS.buffs.inactiveAlpha = 0.5

-- ============================================================================
-- LOCAL VARIABLES
-- ============================================================================

local settings = nil
local cooldownHub = nil
local settingsPanels = {}
local currentOpenPanel = nil

-- Tracker state
local hookedViewers = {}  -- [viewerFrame] = trackerKey
local baselineOrders = {} -- [viewerFrame] = { icon1, icon2, ... }

-- Update flags (combat-safe pattern)
local needsLayoutUpdate = {}  -- [trackerKey] = true

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

local function DeepCopy(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for k, v in pairs(orig) do
            copy[k] = DeepCopy(v)
        end
    else
        copy = orig
    end
    return copy
end

local function dprint(...)
    if settings and settings.global and settings.global.debugMode then
        print("|cff00ff00[TweaksUI CD]|r", ...)
    end
end

local function GetSetting(trackerKey, settingName)
    if not settings or not settings[trackerKey] then return nil end
    return settings[trackerKey][settingName]
end

local function SetSetting(trackerKey, settingName, value)
    if not settings then return end
    settings[trackerKey] = settings[trackerKey] or {}
    settings[trackerKey][settingName] = value
    
    -- Also immediately persist to database
    if TweaksUI and TweaksUI.Database and TweaksUI.Database.SetModuleSettings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
end

-- Public function to get all settings (used by Export All)
function Cooldowns:GetSettings()
    -- Ensure settings are initialized with proper merge logic
    if not settings then
        -- Start with defaults
        settings = DeepCopy(DEFAULTS)
        
        -- Merge any saved settings from database
        local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
        if dbSettings then
            for key, trackerSettings in pairs(dbSettings) do
                if settings[key] and type(trackerSettings) == "table" then
                    for k, v in pairs(trackerSettings) do
                        settings[key][k] = v
                    end
                elseif key == "global" and type(trackerSettings) == "table" then
                    for k, v in pairs(trackerSettings) do
                        settings.global[k] = v
                    end
                end
            end
        end
    end
    
    -- Save to database to ensure it's up to date with full settings
    if TweaksUI and TweaksUI.Database and TweaksUI.Database.SetModuleSettings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
    return settings
end

local function GetTrackerInfo(key)
    for _, t in ipairs(TRACKERS) do
        if t.key == key then return t end
    end
    return nil
end

local function GetTrackerByName(name)
    for _, t in ipairs(TRACKERS) do
        if t.name == name then return t end
    end
    return nil
end

-- ============================================================================
-- ICON COLLECTION
-- ============================================================================

-- Check if a frame is an icon (has Icon texture and typical icon properties)
local function IsIcon(frame)
    if not frame then return false end
    if not frame.GetWidth then return false end
    
    local w, h = frame:GetWidth(), frame:GetHeight()
    if not w or not h or w < 10 or h < 10 then return false end
    
    -- Check for Icon texture (Blizzard's cooldown icons have this)
    if frame.Icon then return true end
    if frame.icon then return true end
    
    -- Check for cooldown element
    if frame.Cooldown then return true end
    if frame.cooldown then return true end
    
    return false
end

-- Collect all icon children from a viewer frame
local function CollectIcons(viewer)
    local icons = {}
    if not viewer or not viewer.GetNumChildren then return icons end
    
    local numChildren = viewer:GetNumChildren() or 0
    
    for i = 1, numChildren do
        local child = select(i, viewer:GetChildren())
        if child and IsIcon(child) then
            icons[#icons + 1] = child
        elseif child and child.GetNumChildren then
            -- Check nested children (some viewers have container frames)
            local numNested = child:GetNumChildren() or 0
            for j = 1, numNested do
                local nested = select(j, child:GetChildren())
                if nested and IsIcon(nested) then
                    icons[#icons + 1] = nested
                end
            end
        end
    end
    
    return icons
end


-- Get texture fileID from an icon (stable identifier across sessions)
-- Uses pcall to safely handle "secret values" during combat/targeting
local function GetIconTextureID(icon)
    if not icon then return 0 end
    local textureObj = icon.Icon or icon.icon
    if textureObj then
        if textureObj.GetTextureFileID then
            local ok, fileID = pcall(function()
                local id = textureObj:GetTextureFileID()
                if id and id > 0 then return id end
                return nil
            end)
            if ok and fileID then return fileID end
        end
        if textureObj.GetTexture then
            local ok, tex = pcall(function()
                local t = textureObj:GetTexture()
                if type(t) == "number" and t > 0 then return t end
                return nil
            end)
            if ok and tex then return tex end
        end
    end
    return 0
end

-- Session cache for stable icon ordering per tracker
-- Once we establish an order, we keep it stable to prevent icons jumping around
local iconOrderCache = {}  -- [trackerKey] = { icon1, icon2, ... }


-- Sort icons by visual position (reading order: top-to-bottom, left-to-right)
local function SortVisual(a, b)
    local at, bt = a:GetTop() or 0, b:GetTop() or 0
    local al, bl = a:GetLeft() or 0, b:GetLeft() or 0
    
    -- Sort top-to-bottom first (higher Y = higher on screen)
    if math.abs(at - bt) > 5 then return at > bt end
    
    -- Then left-to-right for icons in same row
    return al < bl
end

-- Get icons in stable order
-- Uses session cache for all trackers + persistent savedIconOrder for buffs
local function GetOrderedIcons(viewer, trackerKey)
    local all = CollectIcons(viewer)
    local shown = {}
    local shownSet = {}  -- For quick lookup
    
    -- Filter to only shown icons and create lookup set
    for _, icon in ipairs(all) do
        if icon:IsShown() then
            shown[#shown + 1] = icon
            shownSet[icon] = true
        end
    end
    
    if #shown == 0 then
        dprint(string.format("GetOrderedIcons [%s]: 0 shown", trackerKey))
        return shown
    end
    
    dprint(string.format("GetOrderedIcons [%s]: %d total, %d shown", trackerKey, #all, #shown))
    
    -- If no session cache exists, create initial order
    if not iconOrderCache[trackerKey] then
        -- BUFFS: Try to restore from persistent savedIconOrder first
        if trackerKey == "buffs" then
            local savedOrder = GetSetting(trackerKey, "savedIconOrder")
            if savedOrder and #savedOrder > 0 then
                -- Build lookup: fileID -> desired position
                local orderLookup = {}
                for i, fileID in ipairs(savedOrder) do
                    orderLookup[fileID] = i
                end
                
                -- Sort by saved position, unknowns go to end sorted by fileID
                table.sort(shown, function(a, b)
                    local idA = GetIconTextureID(a)
                    local idB = GetIconTextureID(b)
                    local posA = orderLookup[idA]
                    local posB = orderLookup[idB]
                    
                    if posA and posB then return posA < posB end
                    if posA then return true end
                    if posB then return false end
                    return idA < idB
                end)
                
                dprint(string.format("GetOrderedIcons [%s]: Restored from saved order", trackerKey))
            else
                -- No saved order - sort by fileID for consistency
                table.sort(shown, function(a, b)
                    return GetIconTextureID(a) < GetIconTextureID(b)
                end)
                dprint(string.format("GetOrderedIcons [%s]: No saved order, sorted by fileID", trackerKey))
            end
        else
            -- ESSENTIALS/UTILITY: Sort by visual position
            table.sort(shown, SortVisual)
            dprint(string.format("GetOrderedIcons [%s]: Sorted by visual position", trackerKey))
        end
        
        -- Store in session cache
        iconOrderCache[trackerKey] = {}
        for i, icon in ipairs(shown) do
            iconOrderCache[trackerKey][i] = icon
        end
        
        return shown
    end
    
    -- Session cache exists - use cached order, filter to currently shown icons
    local cached = iconOrderCache[trackerKey]
    local result = {}
    local usedIcons = {}
    
    -- First, add icons from cache that are still shown (preserves order)
    for _, cachedIcon in ipairs(cached) do
        if shownSet[cachedIcon] then
            result[#result + 1] = cachedIcon
            usedIcons[cachedIcon] = true
        end
    end
    
    -- Then add any new icons that weren't in cache (at the end)
    for _, icon in ipairs(shown) do
        if not usedIcons[icon] then
            result[#result + 1] = icon
        end
    end
    
    -- Update session cache with current set
    iconOrderCache[trackerKey] = {}
    for i, icon in ipairs(result) do
        iconOrderCache[trackerKey][i] = icon
    end
    
    return result
end

-- Clear icon order cache (session cache and optionally persistent for buffs)
local function ClearIconOrderCache(trackerKey)
    if trackerKey then
        iconOrderCache[trackerKey] = nil
        if trackerKey == "buffs" then
            SetSetting(trackerKey, "savedIconOrder", {})
        end
        dprint(string.format("Cleared icon order cache for [%s]", trackerKey))
    else
        iconOrderCache = {}
        SetSetting("buffs", "savedIconOrder", {})
        dprint("Cleared all icon order caches")
    end
end

-- ============================================================================
-- LAYOUT SYSTEM
-- ============================================================================

-- Apply border alpha to an icon
local function ApplyBorderAlpha(icon, alpha)
    if not icon then return end
    alpha = alpha or 1.0
    
    pcall(function()
        -- Try common border texture names
        if icon.Border then icon.Border:SetAlpha(alpha) end
        if icon.border then icon.border:SetAlpha(alpha) end
        if icon.IconBorder then icon.IconBorder:SetAlpha(alpha) end
        if icon.iconBorder then icon.iconBorder:SetAlpha(alpha) end
        
        -- Some icons use NormalTexture for the border
        if icon.GetNormalTexture then
            local normalTexture = icon:GetNormalTexture()
            if normalTexture then normalTexture:SetAlpha(alpha) end
        end
        
        -- Search through regions for border textures
        if icon.GetRegions then
            local iconTexture = icon.Icon or icon.icon
            for _, region in ipairs({icon:GetRegions()}) do
                if region and region:GetObjectType() == "Texture" and region ~= iconTexture then
                    local texturePath = region:GetTexture()
                    if texturePath then
                        if type(texturePath) == "string" then
                            -- String path - check for border keywords
                            if texturePath:find("Border") or texturePath:find("border") or 
                               texturePath:find("Highlight") or texturePath:find("Normal") or
                               texturePath:find("Edge") or texturePath:find("Frame") then
                                region:SetAlpha(alpha)
                            end
                        elseif type(texturePath) == "number" then
                            -- Numeric file ID - assume non-icon textures are borders
                            region:SetAlpha(alpha)
                        end
                    end
                end
            end
        end
        
        -- Check children frames for borders
        if icon.GetChildren then
            for _, child in ipairs({icon:GetChildren()}) do
                if child and child:GetObjectType() == "Frame" then
                    local name = child:GetName()
                    if name and (name:find("Border") or name:find("border")) then
                        child:SetAlpha(alpha)
                    end
                end
            end
        end
    end)
end

-- Apply cooldown text scale to an icon
local function ApplyCooldownTextScale(icon, scale)
    if not icon then return end
    scale = scale or 1.0
    
    local cd = icon.Cooldown or icon.cooldown
    if not cd then return end
    
    pcall(function()
        -- Method 1: Direct cooldown.text (OmniCC style)
        if cd.text then
            if not cd.text._TUI_origFontSize then
                local font, size, flags = cd.text:GetFont()
                if font and size then
                    cd.text._TUI_origFontSize = size
                    cd.text._TUI_origFont = font
                    cd.text._TUI_origFlags = flags or ""
                end
            end
            if cd.text._TUI_origFontSize then
                cd.text:SetFont(cd.text._TUI_origFont, cd.text._TUI_origFontSize * scale, cd.text._TUI_origFlags)
            end
        end
        
        -- Method 2: Check for Text fontstring in cooldown frame
        if cd.Text then
            if not cd.Text._TUI_origFontSize then
                local font, size, flags = cd.Text:GetFont()
                if font and size then
                    cd.Text._TUI_origFontSize = size
                    cd.Text._TUI_origFont = font
                    cd.Text._TUI_origFlags = flags or ""
                end
            end
            if cd.Text._TUI_origFontSize then
                cd.Text:SetFont(cd.Text._TUI_origFont, cd.Text._TUI_origFontSize * scale, cd.Text._TUI_origFlags)
            end
        end
        
        -- Method 3: Search cooldown frame regions for fontstrings
        if cd.GetRegions then
            for _, region in ipairs({cd:GetRegions()}) do
                if region and region:GetObjectType() == "FontString" then
                    if not region._TUI_origFontSize then
                        local font, size, flags = region:GetFont()
                        if font and size then
                            region._TUI_origFontSize = size
                            region._TUI_origFont = font
                            region._TUI_origFlags = flags or ""
                        end
                    end
                    if region._TUI_origFontSize then
                        region:SetFont(region._TUI_origFont, region._TUI_origFontSize * scale, region._TUI_origFlags)
                    end
                end
            end
        end
    end)
end

-- Apply count/charge text scale to an icon
local function ApplyCountTextScale(icon, scale)
    if not icon then return end
    scale = scale or 1.0
    
    -- Helper to apply scale to a fontstring
    local function ScaleFontString(fs)
        if not fs or not fs.GetFont then return end
        if not fs._TUI_origFontSize then
            local font, size, flags = fs:GetFont()
            if font and size then
                fs._TUI_origFontSize = size
                fs._TUI_origFont = font
                fs._TUI_origFlags = flags or ""
            end
        end
        if fs._TUI_origFontSize then
            fs:SetFont(fs._TUI_origFont, fs._TUI_origFontSize * scale, fs._TUI_origFlags)
        end
    end
    
    -- Helper to recursively search a frame for FontStrings
    local function SearchFrame(frame, depth)
        if not frame or depth > 5 then return end  -- Limit recursion depth
        
        -- Search regions (direct children textures/fontstrings)
        if frame.GetRegions then
            for _, region in ipairs({frame:GetRegions()}) do
                if region and region:GetObjectType() == "FontString" then
                    -- Check if this looks like a count (small text, usually at corner)
                    local text = region:GetText()
                    local name = region:GetName() or ""
                    -- Scale any fontstring that:
                    -- 1. Has a name containing count/charge/stack
                    -- 2. Or displays a number
                    -- 3. Or is positioned at bottom-right (typical count position)
                    if name:lower():find("count") or name:lower():find("charge") or name:lower():find("stack") then
                        ScaleFontString(region)
                    elseif text and text:match("^%d+$") then
                        -- Pure number text - likely a count
                        ScaleFontString(region)
                    end
                end
            end
        end
        
        -- Search child frames recursively
        if frame.GetChildren then
            for _, child in ipairs({frame:GetChildren()}) do
                if child then
                    local childName = child:GetName() or ""
                    local childType = child:GetObjectType()
                    
                    -- Check child frame name for count-related keywords
                    if childName:lower():find("count") or childName:lower():find("charge") or childName:lower():find("stack") then
                        -- This frame is likely count-related, scale all its fontstrings
                        if child.GetRegions then
                            for _, region in ipairs({child:GetRegions()}) do
                                if region and region:GetObjectType() == "FontString" then
                                    ScaleFontString(region)
                                end
                            end
                        end
                    end
                    
                    -- Recurse into child frames
                    SearchFrame(child, depth + 1)
                end
            end
        end
    end
    
    pcall(function()
        -- Method 1: Direct common count text fields
        local countText = icon.Count or icon.count or icon.CountText or icon.countText
        if countText then
            ScaleFontString(countText)
        end
        
        -- Method 2: Check cooldown frame for charge display
        local cooldown = icon.Cooldown or icon.cooldown
        if cooldown then
            -- Some cooldown frames have a charges fontstring
            if cooldown.Count then ScaleFontString(cooldown.Count) end
            if cooldown.count then ScaleFontString(cooldown.count) end
            if cooldown.Charges then ScaleFontString(cooldown.Charges) end
            if cooldown.charges then ScaleFontString(cooldown.charges) end
            
            -- Search cooldown's children too
            SearchFrame(cooldown, 0)
        end
        
        -- Method 3: Recursive search of icon frame
        SearchFrame(icon, 0)
    end)
end

-- Debug helper to dump icon structure
local function DumpIconStructure(icon, trackerKey)
    if not icon then return end
    
    local info = {
        name = icon:GetName() or "unnamed",
        objectType = icon:GetObjectType(),
        fields = {},
        regions = {},
        children = {},
    }
    
    -- Check common fields
    local fieldsToCheck = {"Icon", "icon", "Cooldown", "cooldown", "Count", "count", 
                          "Border", "border", "IconBorder", "NormalTexture"}
    for _, field in ipairs(fieldsToCheck) do
        if icon[field] then
            info.fields[field] = type(icon[field])
        end
    end
    
    -- Get regions
    if icon.GetRegions then
        for i, region in ipairs({icon:GetRegions()}) do
            local regionInfo = {
                type = region:GetObjectType(),
                name = region:GetName(),
            }
            if region:GetObjectType() == "Texture" then
                local tex = region:GetTexture()
                regionInfo.texture = type(tex) == "string" and tex or ("fileID:" .. tostring(tex))
            end
            info.regions[i] = regionInfo
        end
    end
    
    -- Get children
    if icon.GetChildren then
        for i, child in ipairs({icon:GetChildren()}) do
            info.children[i] = {
                type = child:GetObjectType(),
                name = child:GetName(),
            }
        end
    end
    
    dprint(string.format("[%s] Icon structure: %s", trackerKey, info.name))
    dprint(string.format("  Fields: %s", table.concat((function()
        local t = {}
        for k, v in pairs(info.fields) do t[#t+1] = k .. "=" .. v end
        return t
    end)(), ", ")))
    dprint(string.format("  Regions: %d", #info.regions))
    for i, r in ipairs(info.regions) do
        dprint(string.format("    [%d] %s: %s %s", i, r.type, r.name or "nil", r.texture or ""))
    end
    dprint(string.format("  Children: %d", #info.children))
    for i, c in ipairs(info.children) do
        dprint(string.format("    [%d] %s: %s", i, c.type, c.name or "nil"))
    end
end

local function ApplyGridLayout(viewer, trackerKey)
    if not viewer or not viewer:IsShown() then return false end
    
    -- Prevent concurrent layout
    if viewer._TUI_applying then return false end
    viewer._TUI_applying = true
    
    -- Get icons
    local icons = GetOrderedIcons(viewer, trackerKey)
    if #icons == 0 then
        viewer._TUI_applying = false
        return false
    end
    
    -- Get settings
    local iconSize = GetSetting(trackerKey, "iconSize") or 36
    local customWidth = GetSetting(trackerKey, "iconWidth")
    local customHeight = GetSetting(trackerKey, "iconHeight")
    local aspectRatio = GetSetting(trackerKey, "aspectRatio") or "1:1"
    
    local columns = GetSetting(trackerKey, "columns") or 8
    local maxRows = GetSetting(trackerKey, "rows") or 0  -- 0 = unlimited
    local customLayout = GetSetting(trackerKey, "customLayout") or ""
    local spacingH = GetSetting(trackerKey, "spacingH") or 2
    local spacingV = GetSetting(trackerKey, "spacingV") or 2
    
    local growDir = GetSetting(trackerKey, "growDirection") or "RIGHT"
    local growSec = GetSetting(trackerKey, "growSecondary") or "DOWN"
    local alignment = GetSetting(trackerKey, "alignment") or "LEFT"
    local reverseOrder = GetSetting(trackerKey, "reverseOrder") or false
    
    local zoom = GetSetting(trackerKey, "zoom") or 0.08
    local iconOpacity = GetSetting(trackerKey, "iconOpacity") or 1.0
    local borderAlpha = GetSetting(trackerKey, "borderAlpha") or 1.0
    
    local cooldownTextScale = GetSetting(trackerKey, "cooldownTextScale") or 1.0
    local countTextScale = GetSetting(trackerKey, "countTextScale") or 1.0
    
    -- Reverse order if needed
    if reverseOrder then
        local reversed = {}
        for i = #icons, 1, -1 do
            reversed[#reversed + 1] = icons[i]
        end
        icons = reversed
    end
    
    -- Calculate icon dimensions
    local iconWidth, iconHeight
    
    if customWidth and customHeight and customWidth > 0 and customHeight > 0 then
        -- Custom pixel dimensions override everything
        iconWidth = customWidth
        iconHeight = customHeight
    elseif aspectRatio == "custom" and customWidth and customHeight then
        -- Custom mode but values set
        iconWidth = customWidth > 0 and customWidth or iconSize
        iconHeight = customHeight > 0 and customHeight or iconSize
    elseif aspectRatio and aspectRatio ~= "1:1" and aspectRatio ~= "custom" then
        -- Aspect ratio preset
        local w, h = aspectRatio:match("(%d+):(%d+)")
        w, h = tonumber(w), tonumber(h)
        if w and h and w > 0 and h > 0 then
            -- Base size is the larger dimension
            if w >= h then
                iconWidth = iconSize
                iconHeight = iconSize * h / w
            else
                iconHeight = iconSize
                iconWidth = iconSize * w / h
            end
        else
            iconWidth, iconHeight = iconSize, iconSize
        end
    else
        -- 1:1 square
        iconWidth, iconHeight = iconSize, iconSize
    end
    
    -- Parse custom layout pattern (e.g., "4,4,2" = 4 icons in row 1, 4 in row 2, 2 in row 3)
    local customRowSizes = {}
    local useCustomLayout = false
    if customLayout and customLayout ~= "" then
        for num in customLayout:gmatch("(%d+)") do
            local n = tonumber(num)
            if n and n > 0 then
                table.insert(customRowSizes, n)
                useCustomLayout = true
            end
        end
    end
    
    -- Build cumulative index to row/col mapping for custom layout
    local customMapping = {}  -- [iconIndex] = { row = n, col = n }
    if useCustomLayout then
        local iconIdx = 1
        for row, rowSize in ipairs(customRowSizes) do
            for col = 1, rowSize do
                customMapping[iconIdx] = { row = row - 1, col = col - 1 }
                iconIdx = iconIdx + 1
            end
        end
    end
    
    dprint(string.format("ApplyGridLayout [%s]: %d icons, size=%.0fx%.0f, cols=%d, spacingH=%d, spacingV=%d, grow=%s/%s%s", 
        trackerKey, #icons, iconWidth, iconHeight, columns, spacingH, spacingV, growDir, growSec,
        useCustomLayout and string.format(", custom=%s", customLayout) or ""))
    
    -- Determine if primary direction is horizontal or vertical
    local primaryIsHorizontal = (growDir == "LEFT" or growDir == "RIGHT")
    
    -- For vertical primary, we need to know how many rows to use
    local numRows = maxRows
    if not primaryIsHorizontal and numRows == 0 then
        -- Calculate rows needed based on columns and icon count
        numRows = math.ceil(#icons / columns)
    end
    
    -- Position each icon in grid
    local iconCount = 0
    for i, icon in ipairs(icons) do
        local col, row
        
        if useCustomLayout and customMapping[i] then
            -- Use custom layout mapping
            col = customMapping[i].col
            row = customMapping[i].row
        else
            -- Standard grid layout
            local idx = i - 1
            
            if primaryIsHorizontal then
                -- Horizontal primary (LEFT/RIGHT): fill rows first, then wrap to next row
                -- Row 1: 1,2,3 | Row 2: 4,5,6 | Row 3: 7,8,9
                col = idx % columns
                row = math.floor(idx / columns)
            else
                -- Vertical primary (UP/DOWN): fill columns first, then wrap to next column
                -- Col 1: 1,4,7 | Col 2: 2,5,8 | Col 3: 3,6,9
                local effectiveRows = numRows > 0 and numRows or math.ceil(#icons / columns)
                row = idx % effectiveRows
                col = math.floor(idx / effectiveRows)
            end
        end
        
        -- Check row limit (0 = unlimited)
        if maxRows > 0 and row >= maxRows then
            -- Hide icons beyond row limit
            icon:Hide()
        else
            iconCount = iconCount + 1
            icon:Show()
            
            -- Calculate offset based on grow direction
            local xOffset, yOffset
            
            -- Primary direction determines the "fast" axis
            -- Secondary direction determines the "slow" axis (wrap direction)
            if growDir == "RIGHT" then
                xOffset = col * (iconWidth + spacingH)
            elseif growDir == "LEFT" then
                xOffset = -col * (iconWidth + spacingH)
            elseif growDir == "DOWN" then
                -- Vertical primary: col determines horizontal offset
                if growSec == "RIGHT" then
                    xOffset = col * (iconWidth + spacingH)
                else  -- LEFT
                    xOffset = -col * (iconWidth + spacingH)
                end
            elseif growDir == "UP" then
                -- Vertical primary: col determines horizontal offset
                if growSec == "RIGHT" then
                    xOffset = col * (iconWidth + spacingH)
                else  -- LEFT
                    xOffset = -col * (iconWidth + spacingH)
                end
            else
                xOffset = col * (iconWidth + spacingH)
            end
            
            if growDir == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growDir == "UP" then
                yOffset = row * (iconHeight + spacingV)
            elseif growSec == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growSec == "UP" then
                yOffset = row * (iconHeight + spacingV)
            else
                yOffset = -row * (iconHeight + spacingV)
            end
            
            -- Calculate alignment offset
            local alignOffset = 0
            if alignment == "CENTER" then
                -- For center, we need to know the total row width
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[row + 1] then
                    iconsInThisRow = customRowSizes[row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                local viewerWidth = viewer:GetWidth() or rowWidth
                alignOffset = (viewerWidth - rowWidth) / 2
            elseif alignment == "RIGHT" then
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[row + 1] then
                    iconsInThisRow = customRowSizes[row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                local viewerWidth = viewer:GetWidth() or rowWidth
                alignOffset = viewerWidth - rowWidth
            end
            
            -- Apply position relative to viewer with alignment
            icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT", viewer, "TOPLEFT", xOffset + alignOffset, yOffset)
            
            -- Apply size
            icon:SetSize(iconWidth, iconHeight)
            
            -- Apply opacity (but don't override buff state tracking)
            if trackerKey ~= "buffs" or not GetSetting("buffs", "greyscaleInactive") then
                icon:SetAlpha(iconOpacity)
            end
            
            -- Apply border alpha using helper function
            ApplyBorderAlpha(icon, borderAlpha)
            
            -- Apply zoom and aspect ratio cropping to icon texture
            -- Aspect ratio cropping: crop the texture to match the icon's aspect ratio
            -- Zoom: additional uniform inset (0 = no zoom, 0.1 = 10% inset)
            pcall(function()
                local textureObj = icon.Icon or icon.icon
                if textureObj and textureObj.SetTexCoord then
                    -- Start with zoom inset
                    local left = zoom
                    local right = 1 - zoom
                    local top = zoom
                    local bottom = 1 - zoom
                    
                    -- Calculate aspect ratio cropping
                    -- Textures are assumed square, so we crop to match icon dimensions
                    if iconWidth > iconHeight then
                        -- Wide icon: crop top and bottom
                        local cropAmount = (1 - iconHeight / iconWidth) / 2
                        top = top + cropAmount * (1 - 2 * zoom)
                        bottom = bottom - cropAmount * (1 - 2 * zoom)
                    elseif iconHeight > iconWidth then
                        -- Tall icon: crop left and right
                        local cropAmount = (1 - iconWidth / iconHeight) / 2
                        left = left + cropAmount * (1 - 2 * zoom)
                        right = right - cropAmount * (1 - 2 * zoom)
                    end
                    
                    textureObj:SetTexCoord(left, right, top, bottom)
                end
            end)
            
            -- Apply cooldown text scale using helper function
            ApplyCooldownTextScale(icon, cooldownTextScale)
            
            -- Apply count text scale using helper function
            ApplyCountTextScale(icon, countTextScale)
            
            -- Debug: dump first icon structure when debug mode enabled
            if iconCount == 1 and GetSetting("global", "debugMode") then
                DumpIconStructure(icon, trackerKey)
            end
        end
    end
    
    viewer._TUI_applying = false
    dprint(string.format("ApplyGridLayout [%s]: Complete (%d visible)", trackerKey, iconCount))
    return true
end

-- ============================================================================
-- BUFF STATE TRACKING (Buffs tracker only)
-- ============================================================================
-- Detects active vs inactive buffs and applies visual styling
-- Inactive buffs are desaturated and faded for better awareness
--
-- CRITICAL INSIGHT from CMT:
-- The icon's auraInstanceID tells us if the buff is active!
-- - auraInstanceID ~= nil means buff is ACTIVE
-- - auraInstanceID == nil means buff is INACTIVE
-- No need to query C_UnitAuras at all!

local buffStateCache = {}  -- [icon] = lastActiveState (boolean)
local buffUpdateTicker = nil
local BUFF_UPDATE_INTERVAL = 0.1  -- Check buff states 10 times per second

-- Check if a buff icon is currently active
-- Simple check: if icon has auraInstanceID, buff is active
local function IsIconBuffActive(icon)
    if not icon then return true end  -- Default to active if we can't check
    
    -- The magic: auraInstanceID is set when buff is active, nil when inactive
    return (icon.auraInstanceID ~= nil)
end

-- Apply visual state to a buff icon based on active/inactive
-- Now supports comprehensive per-icon overrides including size, offset, aspect ratio
local function ApplyBuffVisualState(icon, isActive, trackerKey)
    if not icon then return end
    trackerKey = trackerKey or "buffs"
    
    -- Get settings
    local greyscaleInactive = GetSetting(trackerKey, "greyscaleInactive")
    local inactiveAlpha = GetSetting(trackerKey, "inactiveAlpha") or 0.5
    local baseOpacity = GetSetting(trackerKey, "iconOpacity") or 1.0
    
    -- Skip if greyscale feature is disabled
    if not greyscaleInactive then
        pcall(function()
            local textureObj = icon.Icon or icon.icon
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(false)
            end
            icon:SetAlpha(baseOpacity)
        end)
        return
    end
    
    -- Check if state changed (avoid unnecessary updates)
    if buffStateCache[icon] == isActive then
        return  -- No change
    end
    
    buffStateCache[icon] = isActive
    dprint(string.format("Buff state: %s (auraInstanceID: %s)", 
        isActive and "ACTIVE" or "INACTIVE",
        tostring(icon.auraInstanceID)))
    
    -- Apply visual changes
    pcall(function()
        local textureObj = icon.Icon or icon.icon
        if isActive then
            -- Active buff - normal appearance
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(false)
            end
            icon:SetAlpha(baseOpacity)
        else
            -- Inactive buff - desaturate and fade
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(true)
            end
            icon:SetAlpha(inactiveAlpha)
        end
    end)
end

-- Update all buff icons' visual states
local function UpdateBuffVisualStates()
    local viewer = _G["BuffIconCooldownViewer"]
    if not viewer or not viewer:IsShown() then return end
    
    -- Get all icons
    local icons = CollectIcons(viewer)
    
    local activeCount, inactiveCount = 0, 0
    for _, icon in ipairs(icons) do
        if icon:IsShown() then
            local isActive = IsIconBuffActive(icon)
            if isActive then
                activeCount = activeCount + 1
            else
                inactiveCount = inactiveCount + 1
            end
            ApplyBuffVisualState(icon, isActive)
        end
    end
    
    dprint(string.format("Buff icons: %d active, %d inactive", activeCount, inactiveCount))
end

-- Start the buff state update ticker
local function StartBuffStateTracking()
    if buffUpdateTicker then return end  -- Already running
    
    buffUpdateTicker = C_Timer.NewTicker(BUFF_UPDATE_INTERVAL, function()
        -- Only run if greyscale feature is enabled
        if GetSetting("buffs", "greyscaleInactive") then
            pcall(UpdateBuffVisualStates)
        end
    end)
    
    dprint("Buff state tracking started")
end

-- Stop the buff state update ticker
local function StopBuffStateTracking()
    if buffUpdateTicker then
        buffUpdateTicker:Cancel()
        buffUpdateTicker = nil
        dprint("Buff state tracking stopped")
    end
end

-- ============================================================================
-- VISIBILITY SYSTEM
-- ============================================================================
-- Handles show/hide based on combat, group, instance conditions
-- Also handles fade in/out animations

local visibilityState = {}  -- [trackerKey] = { visible = bool, faded = bool, lastActivity = time }
local fadeTimers = {}       -- [trackerKey] = ticker

-- Get current player state for visibility checks
local function GetPlayerState()
    local state = {
        inCombat = InCombatLockdown() or UnitAffectingCombat("player"),
        inGroup = IsInGroup(),
        inRaid = IsInRaid(),
        inInstance = false,
        inArena = false,
        inBattleground = false,
        isSolo = not IsInGroup(),
        hasTarget = UnitExists("target"),
    }
    
    -- Check instance type
    local _, instanceType = IsInInstance()
    if instanceType == "party" or instanceType == "raid" then
        state.inInstance = true
    elseif instanceType == "arena" then
        state.inArena = true
    elseif instanceType == "pvp" then
        state.inBattleground = true
    end
    
    return state
end

-- Check if viewer should be visible based on conditions
local function ShouldBeVisible(trackerKey)
    local enabled = GetSetting(trackerKey, "visibilityEnabled")
    if not enabled then
        return true  -- Visibility system disabled = always show
    end
    
    local state = GetPlayerState()
    
    -- OR logic: if ANY checked condition is true, show the tracker
    if state.inCombat and GetSetting(trackerKey, "showInCombat") then return true end
    if not state.inCombat and GetSetting(trackerKey, "showOutOfCombat") then return true end
    if state.isSolo and GetSetting(trackerKey, "showSolo") then return true end
    if state.inGroup and not state.inRaid and GetSetting(trackerKey, "showInParty") then return true end
    if state.inRaid and GetSetting(trackerKey, "showInRaid") then return true end
    if state.inInstance and GetSetting(trackerKey, "showInInstance") then return true end
    if state.inArena and GetSetting(trackerKey, "showInArena") then return true end
    if state.inBattleground and GetSetting(trackerKey, "showInBattleground") then return true end
    if state.hasTarget and GetSetting(trackerKey, "showHasTarget") then return true end
    if not state.hasTarget and GetSetting(trackerKey, "showNoTarget") then return true end
    
    -- No conditions matched
    return false
end

-- Apply fade to a viewer
local function ApplyFade(viewer, trackerKey, targetAlpha, duration)
    if not viewer then return end
    
    local currentAlpha = viewer:GetAlpha()
    if math.abs(currentAlpha - targetAlpha) < 0.01 then return end
    
    -- Use UIFrameFadeOut/In for smooth animation
    if targetAlpha < currentAlpha then
        UIFrameFadeOut(viewer, duration or 0.3, currentAlpha, targetAlpha)
    else
        UIFrameFadeIn(viewer, duration or 0.3, currentAlpha, targetAlpha)
    end
end

-- Update visibility for a single tracker
local function UpdateTrackerVisibility(trackerKey)
    local trackerInfo = GetTrackerInfo(trackerKey)
    if not trackerInfo then return end
    
    local viewer = _G[trackerInfo.name]
    if not viewer then return end
    
    local shouldShow = ShouldBeVisible(trackerKey)
    local fadeEnabled = GetSetting(trackerKey, "fadeEnabled")
    local fadeDelay = GetSetting(trackerKey, "fadeDelay") or 3.0
    local fadeAlpha = GetSetting(trackerKey, "fadeAlpha") or 0.3
    local fadeDuration = GetSetting(trackerKey, "fadeDuration") or 0.3
    
    -- Initialize state if needed
    if not visibilityState[trackerKey] then
        visibilityState[trackerKey] = { visible = true, faded = false, lastActivity = GetTime() }
    end
    
    local state = visibilityState[trackerKey]
    
    if shouldShow then
        -- Should be visible
        if not state.visible then
            viewer:Show()
            state.visible = true
            -- Immediately apply layout to prevent flash of default layout
            ApplyGridLayout(viewer, trackerKey)
            dprint(string.format("[%s] Showing (visibility condition met)", trackerKey))
        end
        
        -- Handle fading
        if fadeEnabled then
            -- Check if we should be faded (no recent activity)
            local timeSinceActivity = GetTime() - state.lastActivity
            if timeSinceActivity >= fadeDelay and not state.faded then
                ApplyFade(viewer, trackerKey, fadeAlpha, fadeDuration)
                state.faded = true
                dprint(string.format("[%s] Fading out (inactive for %.1fs)", trackerKey, timeSinceActivity))
            end
        else
            -- Fade disabled - ensure full opacity
            if viewer:GetAlpha() < 1.0 then
                ApplyFade(viewer, trackerKey, 1.0, 0.2)
                state.faded = false
            end
        end
    else
        -- Should be hidden
        if state.visible then
            viewer:Hide()
            state.visible = false
            dprint(string.format("[%s] Hiding (no visibility conditions met)", trackerKey))
        end
    end
end

-- Mark activity on a tracker (resets fade timer)
local function MarkTrackerActivity(trackerKey)
    if not visibilityState[trackerKey] then
        visibilityState[trackerKey] = { visible = true, faded = false, lastActivity = GetTime() }
    end
    
    local state = visibilityState[trackerKey]
    state.lastActivity = GetTime()
    
    -- If currently faded, unfade
    if state.faded then
        local trackerInfo = GetTrackerInfo(trackerKey)
        if trackerInfo then
            local viewer = _G[trackerInfo.name]
            if viewer then
                ApplyFade(viewer, trackerKey, 1.0, 0.2)
                state.faded = false
            end
        end
    end
end

-- Update visibility for all trackers
local function UpdateAllVisibility()
    for _, tracker in ipairs(TRACKERS) do
        UpdateTrackerVisibility(tracker.key)
    end
end

-- Start visibility update ticker (checks fade timers)
local visibilityTicker = nil
local function StartVisibilitySystem()
    if visibilityTicker then return end
    
    visibilityTicker = C_Timer.NewTicker(0.5, function()
        for _, tracker in ipairs(TRACKERS) do
            if GetSetting(tracker.key, "visibilityEnabled") or GetSetting(tracker.key, "fadeEnabled") then
                UpdateTrackerVisibility(tracker.key)
            end
        end
    end)
    
    dprint("Visibility system started")
end

local function StopVisibilitySystem()
    if visibilityTicker then
        visibilityTicker:Cancel()
        visibilityTicker = nil
        dprint("Visibility system stopped")
    end
end

-- ============================================================================
-- VIEWER HOOKING
-- ============================================================================

local function HookViewer(viewer, trackerKey)
    if not viewer or hookedViewers[viewer] then return end
    
    hookedViewers[viewer] = trackerKey
    viewer._TUI_Key = trackerKey
    
    dprint(string.format("Hooking viewer: %s [%s]", viewer:GetName() or "unnamed", trackerKey))
    
    -- Hook Layout function to intercept Blizzard's layout and apply ours
    if viewer.Layout then
        hooksecurefunc(viewer, "Layout", function(self)
            -- Skip if we're currently applying our layout
            if self._TUI_applying then return end
            
            dprint(string.format("Layout hook fired for [%s]", trackerKey))
            
            if self:IsShown() then
                -- BUFFS ONLY: Capture order from Blizzard positions when Cooldown Manager changes
                if trackerKey == "buffs" then
                    local icons = CollectIcons(self)
                    local shown = {}
                    local hasValidPositions = false
                    
                    for _, icon in ipairs(icons) do
                        if icon:IsShown() then
                            shown[#shown + 1] = icon
                            local t, l = icon:GetTop(), icon:GetLeft()
                            if t and l and (t ~= 0 or l ~= 0) then
                                hasValidPositions = true
                            end
                        end
                    end
                    
                    -- Only capture order if icons have valid positions
                    if hasValidPositions and #shown > 0 then
                        -- Sort by visual position (reading order)
                        table.sort(shown, function(a, b)
                            local at, bt = a:GetTop() or 0, b:GetTop() or 0
                            local al, bl = a:GetLeft() or 0, b:GetLeft() or 0
                            if math.abs(at - bt) > 5 then return at > bt end
                            return al < bl
                        end)
                        
                        -- Build new order from texture IDs
                        local newOrder = {}
                        for i, icon in ipairs(shown) do
                            newOrder[i] = GetIconTextureID(icon)
                        end
                        
                        -- Compare to saved order
                        local savedOrder = GetSetting(trackerKey, "savedIconOrder") or {}
                        local orderChanged = #newOrder ~= #savedOrder
                        if not orderChanged then
                            for i, id in ipairs(newOrder) do
                                if savedOrder[i] ~= id then
                                    orderChanged = true
                                    break
                                end
                            end
                        end
                        
                        -- Save new order if it changed (player used Cooldown Manager)
                        if orderChanged then
                            SetSetting(trackerKey, "savedIconOrder", newOrder)
                            dprint(string.format("Layout hook [%s]: Order changed, saved new order: %s", 
                                trackerKey, table.concat(newOrder, ",")))
                        end
                    end
                end
                
                -- Apply our layout
                pcall(ApplyGridLayout, self, trackerKey)
            end
        end)
    end
    
    -- Hook Show to catch when viewer becomes visible
    hooksecurefunc(viewer, "Show", function(self)
        dprint(string.format("Show hook fired for [%s]", trackerKey))
        -- Apply immediately
        if self:IsShown() then
            pcall(ApplyGridLayout, self, trackerKey)
        end
    end)
    
    -- Initial layout if already visible
    if viewer:IsShown() then
        pcall(ApplyGridLayout, viewer, trackerKey)
    end
end

local function HookAllViewers()
    for _, tracker in ipairs(TRACKERS) do
        local viewer = _G[tracker.name]
        if viewer then
            HookViewer(viewer, tracker.key)
        else
            dprint(string.format("Viewer not found: %s", tracker.name))
        end
    end
end

-- ============================================================================
-- EVENT HANDLING
-- ============================================================================

local eventFrame = CreateFrame("Frame")
local updateTimer = 0
local UPDATE_THROTTLE = 0.1
local layoutEnforceTimer = 0
local LAYOUT_ENFORCE_INTERVAL = 0.2  -- Check layout 5x per second (like CMT)

local function OnEvent(self, event, arg1, ...)
    if event == "ADDON_LOADED" then
        -- Try to hook viewers as they become available
        C_Timer.After(0.5, HookAllViewers)
        
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Hook viewers and apply initial layout
        C_Timer.After(0.5, function()
            HookAllViewers()
            -- Apply layout to all visible viewers
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
            -- Update visibility
            UpdateAllVisibility()
        end)
        
        -- DELAYED CACHE RESET: Clear session caches and recapture after positions are stable
        -- This fixes order issues where positions aren't valid at initial capture
        C_Timer.After(2.0, function()
            dprint("Delayed reset - clearing session caches and recapturing with stable positions")
            -- Clear session caches only (not persistent savedIconOrder for buffs)
            iconOrderCache = {}
            -- Re-apply layout to all visible viewers
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
        end)
        
        -- Force Edit Mode to re-apply positions multiple times after load
        -- This fixes position issues after reload
        local function RefreshEditModePositions()
            if EditModeManagerFrame and not InCombatLockdown() then
                pcall(function()
                    -- Trigger layout update on each cooldown viewer
                    for _, tracker in ipairs(TRACKERS) do
                        local viewer = _G[tracker.name]
                        if viewer then
                            -- Try calling SetHasActiveChanges to trigger position refresh
                            if viewer.SetHasActiveChanges then
                                viewer:SetHasActiveChanges(false)
                            end
                            -- Try ApplySystemAnchor if available
                            if viewer.ApplySystemAnchor then
                                viewer:ApplySystemAnchor()
                            end
                        end
                    end
                end)
            end
        end
        
        -- Try at multiple intervals to ensure position is correct
        C_Timer.After(1.0, RefreshEditModePositions)
        C_Timer.After(2.0, RefreshEditModePositions)
        C_Timer.After(4.0, RefreshEditModePositions)
        
    elseif event == "SPELL_UPDATE_COOLDOWN" or event == "ACTIONBAR_UPDATE_COOLDOWN" then
        -- Icons might have changed, schedule layout update
        for key in pairs(needsLayoutUpdate) do
            needsLayoutUpdate[key] = true
        end
        -- Mark activity for fade system
        MarkTrackerActivity("essential")
        MarkTrackerActivity("utility")
        
    elseif event == "PLAYER_REGEN_ENABLED" then
        -- Left combat - safe to do UI updates
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        -- Update visibility (combat state changed)
        UpdateAllVisibility()
        
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- Entered combat - update visibility
        UpdateAllVisibility()
        -- Mark activity on all trackers
        for _, tracker in ipairs(TRACKERS) do
            MarkTrackerActivity(tracker.key)
        end
        
    elseif event == "GROUP_ROSTER_UPDATE" then
        -- Group composition changed - update visibility
        UpdateAllVisibility()
        
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        -- Instance type might have changed - update visibility
        C_Timer.After(0.5, UpdateAllVisibility)
        
    elseif event == "UNIT_AURA" and arg1 == "player" then
        -- Player aura changed - mark activity for buffs tracker
        MarkTrackerActivity("buffs")
        
    elseif event == "PLAYER_TARGET_CHANGED" then
        -- Target changed - update visibility
        UpdateAllVisibility()
        -- Mark activity on all trackers
        for _, tracker in ipairs(TRACKERS) do
            MarkTrackerActivity(tracker.key)
        end
        
    elseif event == "EDIT_MODE_LAYOUTS_UPDATED" then
        -- Edit Mode has applied positions - now apply our grid layouts
        dprint("EDIT_MODE_LAYOUTS_UPDATED fired")
        C_Timer.After(0.1, function()
            HookAllViewers()
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
        end)
    end
end

local function OnUpdate(self, elapsed)
    updateTimer = updateTimer + elapsed
    layoutEnforceTimer = layoutEnforceTimer + elapsed
    
    -- Process pending layout updates (throttled)
    if updateTimer >= UPDATE_THROTTLE then
        updateTimer = 0
        for key, needed in pairs(needsLayoutUpdate) do
            if needed then
                needsLayoutUpdate[key] = false
                local info = GetTrackerInfo(key)
                if info then
                    local viewer = _G[info.name]
                    if viewer and viewer:IsShown() and not viewer._TUI_applying then
                        pcall(ApplyGridLayout, viewer, key)
                    end
                end
            end
        end
    end
    
    -- Aggressive layout enforcement (5x per second like CMT)
    -- This catches Blizzard resetting layouts during combat
    if layoutEnforceTimer >= LAYOUT_ENFORCE_INTERVAL then
        layoutEnforceTimer = 0
        -- Always enforce layout on visible trackers
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() and not viewer._TUI_applying then
                local trackerSettings = settings[tracker.key]
                if trackerSettings and trackerSettings.customLayout then
                    pcall(ApplyGridLayout, viewer, tracker.key)
                end
            end
        end
    end
end

-- ============================================================================
-- EXPORT / IMPORT
-- ============================================================================

local function SerializeCooldownSettings()
    -- Simple serialization for settings
    local serialized = "TweaksUI_Cooldowns:"
    
    -- Recursive function to serialize table
    local function serializeTable(tbl, prefix)
        local result = ""
        for k, v in pairs(tbl) do
            local key = prefix and (prefix .. "." .. k) or k
            if type(v) == "table" then
                result = result .. serializeTable(v, key)
            elseif type(v) == "boolean" then
                result = result .. key .. "=" .. (v and "true" or "false") .. ";"
            elseif type(v) == "number" then
                result = result .. key .. "=" .. tostring(v) .. ";"
            elseif type(v) == "string" then
                result = result .. key .. "=" .. v .. ";"
            end
        end
        return result
    end
    
    serialized = serialized .. serializeTable(settings, nil)
    return serialized
end

local function DeserializeCooldownSettings(str)
    if not str or not str:find("^TweaksUI_Cooldowns:") then
        return nil, "Invalid import string"
    end
    
    str = str:gsub("^TweaksUI_Cooldowns:", "")
    
    local newSettings = DeepCopy(DEFAULTS)
    
    for pair in str:gmatch("([^;]+)") do
        local key, value = pair:match("(.+)=(.+)")
        if key and value then
            -- Parse the key path
            local parts = {}
            for part in key:gmatch("[^%.]+") do
                table.insert(parts, part)
            end
            
            -- Navigate to the setting location
            local current = newSettings
            for i = 1, #parts - 1 do
                if current[parts[i]] then
                    current = current[parts[i]]
                end
            end
            
            -- Set the value
            local finalKey = parts[#parts]
            if value == "true" then
                current[finalKey] = true
            elseif value == "false" then
                current[finalKey] = false
            elseif tonumber(value) then
                current[finalKey] = tonumber(value)
            else
                current[finalKey] = value
            end
        end
    end
    
    return newSettings
end

function Cooldowns:ShowExportDialog()
    local dialog = CreateFrame("Frame", "TweaksUI_Cooldowns_ExportDialog", UIParent, "BackdropTemplate")
    dialog:SetSize(450, 300)
    dialog:SetPoint("CENTER")
    dialog:SetBackdrop(darkBackdrop)
    dialog:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    dialog:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    dialog:SetFrameStrata("FULLSCREEN_DIALOG")
    dialog:EnableMouse(true)
    
    local title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Export Cooldown Tracker Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, dialog, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, dialog, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 15, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 50)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(390)
    editBox:SetAutoFocus(false)
    editBox:SetText(SerializeCooldownSettings())
    editBox:HighlightText()
    scrollFrame:SetScrollChild(editBox)
    
    local copyLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    copyLabel:SetPoint("BOTTOM", 0, 30)
    copyLabel:SetText("Press Ctrl+C to copy")
    copyLabel:SetTextColor(0.8, 0.8, 0.8)
    
    local closeButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    closeButton:SetPoint("BOTTOM", 0, 10)
    closeButton:SetSize(100, 24)
    closeButton:SetText("Close")
    closeButton:SetScript("OnClick", function() dialog:Hide() end)
end

function Cooldowns:ShowImportDialog()
    local dialog = CreateFrame("Frame", "TweaksUI_Cooldowns_ImportDialog", UIParent, "BackdropTemplate")
    dialog:SetSize(450, 300)
    dialog:SetPoint("CENTER")
    dialog:SetBackdrop(darkBackdrop)
    dialog:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    dialog:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    dialog:SetFrameStrata("FULLSCREEN_DIALOG")
    dialog:EnableMouse(true)
    
    local title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Import Cooldown Tracker Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, dialog, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, dialog, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 15, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 80)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(390)
    editBox:SetAutoFocus(true)
    editBox:SetText("")
    scrollFrame:SetScrollChild(editBox)
    
    local pasteLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    pasteLabel:SetPoint("BOTTOM", 0, 58)
    pasteLabel:SetText("Paste import string above (Ctrl+V)")
    pasteLabel:SetTextColor(0.8, 0.8, 0.8)
    
    local module = self
    
    local importButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    importButton:SetPoint("BOTTOMLEFT", 50, 20)
    importButton:SetSize(100, 24)
    importButton:SetText("Import")
    importButton:SetScript("OnClick", function()
        local str = editBox:GetText()
        local newSettings, err = DeserializeCooldownSettings(str)
        if newSettings then
            -- Apply new settings
            for k, v in pairs(newSettings) do
                settings[k] = v
            end
            -- Refresh all layouts
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
            TweaksUI:Print("Cooldown Tracker settings imported successfully!")
            dialog:Hide()
        else
            TweaksUI:Print("|cffff0000Import failed:|r " .. (err or "Unknown error"))
        end
    end)
    
    local cancelButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    cancelButton:SetPoint("BOTTOMRIGHT", -50, 20)
    cancelButton:SetSize(100, 24)
    cancelButton:SetText("Cancel")
    cancelButton:SetScript("OnClick", function() dialog:Hide() end)
end

-- ============================================================================
-- SETTINGS HUB
-- ============================================================================

function Cooldowns:CreateHub(parent)
    if cooldownHub then return cooldownHub end
    
    local hub = CreateFrame("Frame", "TweaksUI_Cooldowns_Hub", parent or UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, HUB_HEIGHT)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    hub:Hide()
    
    -- Title
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Cooldown Trackers")
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        hub:Hide()
        self:HideAllPanels()
    end)
    
    local yOffset = -42
    
    -- Section label
    local sectionLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sectionLabel:SetPoint("TOP", 0, yOffset)
    sectionLabel:SetText("|cff888888Blizzard Trackers|r")
    yOffset = yOffset - 16
    
    -- Create button for each tracker
    for _, tracker in ipairs(TRACKERS) do
        local btn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
        btn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
        btn:SetPoint("TOP", 0, yOffset)
        btn:SetText(tracker.displayName)
        btn:SetScript("OnClick", function()
            self:TogglePanel(tracker.key)
        end)
        yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    end
    
    yOffset = yOffset - 10
    
    -- Debug toggle
    local debugCB = CreateFrame("CheckButton", nil, hub, "UICheckButtonTemplate")
    debugCB:SetPoint("TOPLEFT", 15, yOffset)
    debugCB:SetSize(24, 24)
    debugCB:SetChecked(settings.global.debugMode)
    debugCB:SetScript("OnClick", function(self)
        settings.global.debugMode = self:GetChecked()
    end)
    
    local debugLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    debugLabel:SetPoint("LEFT", debugCB, "RIGHT", 4, 0)
    debugLabel:SetText("Debug Mode")
    debugLabel:SetTextColor(0.8, 0.8, 0.8)
    yOffset = yOffset - 30
    
    -- Separator
    local sep = hub:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOP", 0, yOffset)
    sep:SetSize(HUB_WIDTH - 20, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 12
    
    -- Import/Export section label
    local ieLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ieLabel:SetPoint("TOP", 0, yOffset)
    ieLabel:SetText("|cff888888Import / Export|r")
    yOffset = yOffset - 20
    
    -- Export button
    local exportBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    exportBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    exportBtn:SetPoint("TOP", 0, yOffset)
    exportBtn:SetText("Export All")
    exportBtn:SetScript("OnClick", function()
        self:ShowExportDialog()
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Import button
    local importBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    importBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    importBtn:SetPoint("TOP", 0, yOffset)
    importBtn:SetText("Import")
    importBtn:SetScript("OnClick", function()
        self:ShowImportDialog()
    end)
    
    -- Refresh All button at bottom
    local refreshBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    refreshBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    refreshBtn:SetPoint("BOTTOM", 0, 10)
    refreshBtn:SetText("Refresh All Layouts")
    refreshBtn:SetScript("OnClick", function()
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        TweaksUI:Print("Refreshed all tracker layouts")
    end)
    
    cooldownHub = hub
    return hub
end

function Cooldowns:ShowHub(parent)
    if not cooldownHub then
        self:CreateHub(parent)
    end
    
    if parent then
        cooldownHub:ClearAllPoints()
        cooldownHub:SetPoint("TOPLEFT", parent, "TOPRIGHT", 0, 0)
    end
    
    cooldownHub:Show()
end

function Cooldowns:HideAllPanels()
    for _, panel in pairs(settingsPanels) do
        if panel then panel:Hide() end
    end
    if cooldownHub then cooldownHub:Hide() end
    currentOpenPanel = nil
end

function Cooldowns:TogglePanel(trackerKey)
    -- Hide other panels
    for key, panel in pairs(settingsPanels) do
        if panel and key ~= trackerKey then
            panel:Hide()
        end
    end
    
    if settingsPanels[trackerKey] then
        if settingsPanels[trackerKey]:IsShown() then
            settingsPanels[trackerKey]:Hide()
            currentOpenPanel = nil
        else
            settingsPanels[trackerKey]:Show()
            currentOpenPanel = trackerKey
        end
    else
        self:CreateTrackerPanel(trackerKey)
        if settingsPanels[trackerKey] then
            settingsPanels[trackerKey]:Show()
            currentOpenPanel = trackerKey
        end
    end
end

-- ============================================================================
-- TRACKER SETTINGS PANEL
-- ============================================================================

function Cooldowns:CreateTrackerPanel(trackerKey)
    local trackerInfo = GetTrackerInfo(trackerKey)
    if not trackerInfo then return end
    
    local panel = CreateFrame("Frame", "TweaksUI_Cooldowns_" .. trackerKey .. "_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetPoint("TOPLEFT", cooldownHub, "TOPRIGHT", 0, 0)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    
    settingsPanels[trackerKey] = panel
    
    -- Title
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText(trackerInfo.displayName)
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
    end)
    
    -- Handle panel hide
    panel:SetScript("OnHide", function()
        currentOpenPanel = nil
    end)
    
    -- Tab buttons container
    local tabContainer = CreateFrame("Frame", nil, panel)
    tabContainer:SetPoint("TOPLEFT", 10, -40)
    tabContainer:SetPoint("TOPRIGHT", -10, -40)
    tabContainer:SetHeight(28)
    
    -- Content frames (one per tab)
    local contentFrames = {}
    local tabButtons = {}
    local currentTab = 1
    
    -- Tab definitions
    local tabs = {
        { name = "Layout", key = "layout" },
        { name = "Appearance", key = "appearance" },
        { name = "Text", key = "text" },
        { name = "Visibility", key = "visibility" },
    }
    
    -- Add buff-specific tab
    if trackerKey == "buffs" then
        table.insert(tabs, { name = "Buff Display", key = "buffdisplay" })
    end
    
    -- Helper function to refresh layout
    local function RefreshLayout()
        local viewer = _G[trackerInfo.name]
        if viewer and viewer:IsShown() then
            ApplyGridLayout(viewer, trackerKey)
        end
    end
    
    -- Create tab content frame
    local function CreateTabContent()
        local content = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
        content:SetPoint("TOPLEFT", 10, -72)
        content:SetPoint("BOTTOMRIGHT", -28, 10)
        
        local scrollChild = CreateFrame("Frame", nil, content)
        scrollChild:SetSize(PANEL_WIDTH - 50, 800)
        content:SetScrollChild(scrollChild)
        
        content.scrollChild = scrollChild
        content:Hide()
        return content
    end
    
    -- UI Element Helpers
    local function CreateHeader(parent, yOffset, text)
        yOffset = yOffset - 8
        local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        header:SetPoint("TOPLEFT", 5, yOffset)
        header:SetText(text)
        header:SetTextColor(1, 0.82, 0)
        return yOffset - 20
    end
    
    local function CreateSlider(parent, yOffset, labelText, min, max, step, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        yOffset = yOffset - 16
        
        local slider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
        slider:SetPoint("TOPLEFT", 10, yOffset)
        slider:SetSize(PANEL_WIDTH - 90, 17)
        slider:SetMinMaxValues(min, max)
        slider:SetValueStep(step)
        slider:SetObeyStepOnDrag(true)
        slider:SetValue(getValue())
        
        slider.Low:SetText(min)
        slider.High:SetText(max)
        slider.Text:SetText(string.format(step < 1 and "%.2f" or "%d", getValue()))
        
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.floor(value / step + 0.5) * step
            setValue(value)
            self.Text:SetText(string.format(step < 1 and "%.2f" or "%d", value))
            RefreshLayout()
        end)
        
        return yOffset - 30
    end
    
    local function CreateCheckbox(parent, yOffset, labelText, getValue, setValue)
        local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 5, yOffset)
        cb:SetSize(24, 24)
        cb:SetChecked(getValue())
        cb:SetScript("OnClick", function(self)
            setValue(self:GetChecked())
            RefreshLayout()
        end)
        
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        return yOffset - 26
    end
    
    local function CreateDropdown(parent, yOffset, labelText, options, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        yOffset = yOffset - 18
        
        local dropdown = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate")
        dropdown:SetPoint("TOPLEFT", -5, yOffset)
        UIDropDownMenu_SetWidth(dropdown, PANEL_WIDTH - 110)
        
        local function OnSelect(self, value)
            setValue(value)
            UIDropDownMenu_SetText(dropdown, self:GetText())
            RefreshLayout()
        end
        
        UIDropDownMenu_Initialize(dropdown, function(self, level)
            for _, opt in ipairs(options) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = opt.label
                info.value = opt.value
                info.func = OnSelect
                info.arg1 = opt.value
                info.checked = (getValue() == opt.value)
                UIDropDownMenu_AddButton(info, level)
            end
        end)
        
        local currentVal = getValue()
        for _, opt in ipairs(options) do
            if opt.value == currentVal then
                UIDropDownMenu_SetText(dropdown, opt.label)
                break
            end
        end
        
        return yOffset - 30
    end
    
    local function CreateEditBox(parent, yOffset, labelText, getValue, setValue, width)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        box:SetPoint("LEFT", label, "RIGHT", 8, 0)
        box:SetSize(width or 60, 20)
        box:SetAutoFocus(false)
        box:SetText(getValue() or "")
        box:SetScript("OnEnterPressed", function(self)
            setValue(self:GetText())
            RefreshLayout()
            self:ClearFocus()
        end)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        
        return yOffset - 26, box
    end
    
    local function CreateButton(parent, yOffset, text, width, onClick)
        local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        btn:SetPoint("TOPLEFT", 10, yOffset)
        btn:SetSize(width, 22)
        btn:SetText(text)
        btn:SetScript("OnClick", function()
            onClick()
            RefreshLayout()
        end)
        return yOffset - 28
    end
    
    -- ========================================
    -- TAB 1: Layout
    -- ========================================
    local function BuildLayoutTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Icon Size")
        y = CreateSlider(parent, y, "Base Size", 16, 80, 1,
            function() return GetSetting(trackerKey, "iconSize") or 36 end,
            function(v) SetSetting(trackerKey, "iconSize", v) end)
        
        y = CreateDropdown(parent, y, "Aspect Ratio", ASPECT_PRESETS,
            function() return GetSetting(trackerKey, "aspectRatio") or "1:1" end,
            function(v) 
                SetSetting(trackerKey, "aspectRatio", v)
                if v ~= "custom" then
                    SetSetting(trackerKey, "iconWidth", nil)
                    SetSetting(trackerKey, "iconHeight", nil)
                end
            end)
        
        -- Custom dimensions
        local customLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        customLabel:SetPoint("TOPLEFT", 10, y)
        customLabel:SetText("Custom: Width")
        customLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local widthBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        widthBox:SetPoint("LEFT", customLabel, "RIGHT", 5, 0)
        widthBox:SetSize(40, 20)
        widthBox:SetAutoFocus(false)
        widthBox:SetNumeric(true)
        widthBox:SetNumber(GetSetting(trackerKey, "iconWidth") or 36)
        widthBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconWidth", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        
        local heightLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        heightLabel:SetPoint("LEFT", widthBox, "RIGHT", 10, 0)
        heightLabel:SetText("Height")
        heightLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local heightBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        heightBox:SetPoint("LEFT", heightLabel, "RIGHT", 5, 0)
        heightBox:SetSize(40, 20)
        heightBox:SetAutoFocus(false)
        heightBox:SetNumeric(true)
        heightBox:SetNumber(GetSetting(trackerKey, "iconHeight") or 36)
        heightBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconHeight", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        y = y - 28
        
        y = CreateHeader(parent, y, "Grid Layout")
        y = CreateSlider(parent, y, "Columns", 1, 20, 1,
            function() return GetSetting(trackerKey, "columns") or 8 end,
            function(v) SetSetting(trackerKey, "columns", v) end)
        
        y = CreateSlider(parent, y, "Max Rows (0=unlimited)", 0, 10, 1,
            function() return GetSetting(trackerKey, "rows") or 0 end,
            function(v) SetSetting(trackerKey, "rows", v) end)
        
        -- Custom layout pattern
        y, _ = CreateEditBox(parent, y, "Custom Pattern (e.g. 4,4,2):",
            function() return GetSetting(trackerKey, "customLayout") or "" end,
            function(v) SetSetting(trackerKey, "customLayout", v) end, 100)
        
        y = CreateHeader(parent, y, "Spacing")
        
        -- Horizontal spacing with edit box for custom values
        local hLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hLabel:SetPoint("TOPLEFT", 10, y)
        hLabel:SetText("Horizontal:")
        hLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local hBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        hBox:SetPoint("LEFT", hLabel, "RIGHT", 8, 0)
        hBox:SetSize(60, 20)
        hBox:SetAutoFocus(false)
        hBox:SetNumeric(false)  -- Allow negative too
        hBox:SetText(tostring(GetSetting(trackerKey, "spacingH") or 2))
        hBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingH", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        hBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        -- Vertical spacing with edit box for custom values
        local vLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        vLabel:SetPoint("TOPLEFT", 10, y)
        vLabel:SetText("Vertical:")
        vLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local vBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        vBox:SetPoint("LEFT", vLabel, "RIGHT", 8, 0)
        vBox:SetSize(60, 20)
        vBox:SetAutoFocus(false)
        vBox:SetNumeric(false)
        vBox:SetText(tostring(GetSetting(trackerKey, "spacingV") or 2))
        vBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingV", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        vBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        y = CreateButton(parent, y, "Compress (0 spacing)", 140, function()
            SetSetting(trackerKey, "spacingH", 0)
            SetSetting(trackerKey, "spacingV", 0)
            hBox:SetText("0")
            vBox:SetText("0")
        end)
        
        y = CreateHeader(parent, y, "Direction & Alignment")
        -- Primary direction: which way icons fill first
        -- Horizontal (Left/Right) = row mode: 1,2,3 / 4,5,6
        -- Vertical (Up/Down) = column mode: 1,4,7 / 2,5,8
        local growOpts = {
            { label = "Right (Row Mode)", value = "RIGHT" }, 
            { label = "Left (Row Mode)", value = "LEFT" },
            { label = "Down (Column Mode)", value = "DOWN" },
            { label = "Up (Column Mode)", value = "UP" },
        }
        y = CreateDropdown(parent, y, "Primary", growOpts,
            function() return GetSetting(trackerKey, "growDirection") or "RIGHT" end,
            function(v) SetSetting(trackerKey, "growDirection", v) end)
        
        -- Secondary direction: which way to wrap after filling primary
        local growSecOpts = {
            { label = "Down", value = "DOWN" }, 
            { label = "Up", value = "UP" },
            { label = "Right", value = "RIGHT" },
            { label = "Left", value = "LEFT" },
        }
        y = CreateDropdown(parent, y, "Secondary", growSecOpts,
            function() return GetSetting(trackerKey, "growSecondary") or "DOWN" end,
            function(v) SetSetting(trackerKey, "growSecondary", v) end)
        
        local alignOpts = {{ label = "Left", value = "LEFT" }, { label = "Center", value = "CENTER" }, { label = "Right", value = "RIGHT" }}
        y = CreateDropdown(parent, y, "Alignment", alignOpts,
            function() return GetSetting(trackerKey, "alignment") or "LEFT" end,
            function(v) SetSetting(trackerKey, "alignment", v) end)
        
        y = CreateCheckbox(parent, y, "Reverse Icon Order",
            function() return GetSetting(trackerKey, "reverseOrder") or false end,
            function(v) SetSetting(trackerKey, "reverseOrder", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 2: Appearance
    -- ========================================
    local function BuildAppearanceTab(parent)
        local y = -10
        
        y = CreateSlider(parent, y, "Icon Opacity", 0.1, 1.0, 0.05,
            function() return GetSetting(trackerKey, "iconOpacity") or 1.0 end,
            function(v) SetSetting(trackerKey, "iconOpacity", v) end)
        
        y = CreateSlider(parent, y, "Border Alpha", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "borderAlpha") or 1.0 end,
            function(v) SetSetting(trackerKey, "borderAlpha", v) end)
        
        y = CreateSlider(parent, y, "Zoom (texture crop)", 0, 0.2, 0.01,
            function() return GetSetting(trackerKey, "zoom") or 0.08 end,
            function(v) SetSetting(trackerKey, "zoom", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 3: Text
    -- ========================================
    local function BuildTextTab(parent)
        local y = -10
        
        y = CreateSlider(parent, y, "Cooldown Text Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "cooldownTextScale") or 1.0 end,
            function(v) 
                SetSetting(trackerKey, "cooldownTextScale", v) 
                -- Force immediate layout update
                local viewer = _G[GetTrackerInfo(trackerKey).name]
                if viewer then ApplyGridLayout(viewer, trackerKey) end
            end)
        
        y = CreateSlider(parent, y, "Count/Charge Text Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "countTextScale") or 1.0 end,
            function(v) 
                SetSetting(trackerKey, "countTextScale", v)
                -- Force immediate layout update
                local viewer = _G[GetTrackerInfo(trackerKey).name]
                if viewer then ApplyGridLayout(viewer, trackerKey) end
            end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 4: Visibility
    -- ========================================
    local function BuildVisibilityTab(parent)
        local y = -10
        
        y = CreateCheckbox(parent, y, "Enable Visibility Conditions",
            function() return GetSetting(trackerKey, "visibilityEnabled") or false end,
            function(v) SetSetting(trackerKey, "visibilityEnabled", v) end)
        
        y = CreateHeader(parent, y, "Show When (OR logic)")
        
        y = CreateCheckbox(parent, y, "In Combat",
            function() return GetSetting(trackerKey, "showInCombat") end,
            function(v) SetSetting(trackerKey, "showInCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Out of Combat",
            function() return GetSetting(trackerKey, "showOutOfCombat") end,
            function(v) SetSetting(trackerKey, "showOutOfCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Solo",
            function() return GetSetting(trackerKey, "showSolo") end,
            function(v) SetSetting(trackerKey, "showSolo", v) end)
        
        y = CreateCheckbox(parent, y, "In Party",
            function() return GetSetting(trackerKey, "showInParty") end,
            function(v) SetSetting(trackerKey, "showInParty", v) end)
        
        y = CreateCheckbox(parent, y, "In Raid",
            function() return GetSetting(trackerKey, "showInRaid") end,
            function(v) SetSetting(trackerKey, "showInRaid", v) end)
        
        y = CreateCheckbox(parent, y, "In Instance (Dungeon)",
            function() return GetSetting(trackerKey, "showInInstance") end,
            function(v) SetSetting(trackerKey, "showInInstance", v) end)
        
        y = CreateCheckbox(parent, y, "In Arena",
            function() return GetSetting(trackerKey, "showInArena") end,
            function(v) SetSetting(trackerKey, "showInArena", v) end)
        
        y = CreateCheckbox(parent, y, "In Battleground",
            function() return GetSetting(trackerKey, "showInBattleground") end,
            function(v) SetSetting(trackerKey, "showInBattleground", v) end)
        
        y = CreateCheckbox(parent, y, "Has Target",
            function() return GetSetting(trackerKey, "showHasTarget") end,
            function(v) SetSetting(trackerKey, "showHasTarget", v) end)
        
        y = CreateCheckbox(parent, y, "No Target",
            function() return GetSetting(trackerKey, "showNoTarget") end,
            function(v) SetSetting(trackerKey, "showNoTarget", v) end)
        
        y = CreateHeader(parent, y, "Fade Settings")
        
        y = CreateCheckbox(parent, y, "Enable Fade",
            function() return GetSetting(trackerKey, "fadeEnabled") or false end,
            function(v) SetSetting(trackerKey, "fadeEnabled", v) end)
        
        y = CreateSlider(parent, y, "Fade Delay (seconds)", 0, 10, 0.5,
            function() return GetSetting(trackerKey, "fadeDelay") or 3.0 end,
            function(v) SetSetting(trackerKey, "fadeDelay", v) end)
        
        y = CreateSlider(parent, y, "Fade Alpha", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "fadeAlpha") or 0.3 end,
            function(v) SetSetting(trackerKey, "fadeAlpha", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 5: Buff Display (buffs only)
    -- ========================================
    local function BuildBuffDisplayTab(parent)
        local y = -10
        
        y = CreateCheckbox(parent, y, "Greyscale Inactive Buffs",
            function() return GetSetting(trackerKey, "greyscaleInactive") end,
            function(v) 
                SetSetting(trackerKey, "greyscaleInactive", v)
                if v then
                    pcall(UpdateBuffVisualStates)
                else
                    local viewer = _G["BuffIconCooldownViewer"]
                    if viewer then
                        local icons = CollectIcons(viewer)
                        for _, icon in ipairs(icons) do
                            pcall(function()
                                local textureObj = icon.Icon or icon.icon
                                if textureObj and textureObj.SetDesaturated then
                                    textureObj:SetDesaturated(false)
                                end
                                icon:SetAlpha(GetSetting("buffs", "iconOpacity") or 1.0)
                            end)
                        end
                    end
                    wipe(buffStateCache)
                end
            end)
        
        y = CreateSlider(parent, y, "Inactive Buff Opacity", 0.1, 1.0, 0.05,
            function() return GetSetting(trackerKey, "inactiveAlpha") or 0.5 end,
            function(v) 
                SetSetting(trackerKey, "inactiveAlpha", v)
                -- Force update all buff visuals with new opacity
                wipe(buffStateCache)
                pcall(UpdateBuffVisualStates)
            end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- Build tab content builders
    local tabBuilders = {
        layout = BuildLayoutTab,
        appearance = BuildAppearanceTab,
        text = BuildTextTab,
        visibility = BuildVisibilityTab,
        buffdisplay = BuildBuffDisplayTab,
    }
    
    -- Create content frames and tab buttons
    local tabWidth = (PANEL_WIDTH - 20) / #tabs
    local scrollChildren = {}  -- Store scroll children for refresh
    
    for i, tab in ipairs(tabs) do
        -- Create content frame
        local content = CreateTabContent()
        contentFrames[tab.key] = content
        scrollChildren[tab.key] = content.scrollChild
        
        -- Build content
        if tabBuilders[tab.key] then
            tabBuilders[tab.key](content.scrollChild)
        end
        
        -- Create tab button
        local tabBtn = CreateFrame("Button", nil, tabContainer)
        tabBtn:SetSize(tabWidth - 2, 26)
        tabBtn:SetPoint("LEFT", (i - 1) * tabWidth, 0)
        
        tabBtn.bg = tabBtn:CreateTexture(nil, "BACKGROUND")
        tabBtn.bg:SetAllPoints()
        tabBtn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
        
        tabBtn.text = tabBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        tabBtn.text:SetPoint("CENTER")
        tabBtn.text:SetText(tab.name)
        
        tabBtn:SetScript("OnClick", function()
            -- Hide all content
            for _, cf in pairs(contentFrames) do
                cf:Hide()
            end
            -- Show selected
            contentFrames[tab.key]:Show()
            -- Update button visuals
            for _, btn in ipairs(tabButtons) do
                btn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
                btn.text:SetTextColor(0.7, 0.7, 0.7)
            end
            tabBtn.bg:SetColorTexture(0.3, 0.3, 0.5, 1)
            tabBtn.text:SetTextColor(1, 1, 1)
            currentTab = i
        end)
        
        tabBtn:SetScript("OnEnter", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.25, 0.25, 0.35, 0.9)
            end
        end)
        
        tabBtn:SetScript("OnLeave", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
            end
        end)
        
        tabButtons[i] = tabBtn
    end
    
    -- Show first tab
    contentFrames[tabs[1].key]:Show()
    tabButtons[1].bg:SetColorTexture(0.3, 0.3, 0.5, 1)
    tabButtons[1].text:SetTextColor(1, 1, 1)
    
    panel:Show()
end


-- ============================================================================
-- MODULE LIFECYCLE
-- ============================================================================

function Cooldowns:OnInitialize()
    -- Load settings from database
    local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
    
    -- Start with defaults
    settings = DeepCopy(DEFAULTS)
    
    -- Merge saved settings
    if dbSettings then
        for key, trackerSettings in pairs(dbSettings) do
            if settings[key] and type(trackerSettings) == "table" then
                for k, v in pairs(trackerSettings) do
                    -- Migration: old "spacing" -> "spacingH" and "spacingV"
                    if k == "spacing" then
                        settings[key]["spacingH"] = v
                        settings[key]["spacingV"] = v
                    else
                        settings[key][k] = v
                    end
                end
            elseif key == "global" and type(trackerSettings) == "table" then
                for k, v in pairs(trackerSettings) do
                    settings.global[k] = v
                end
            end
        end
    end
    
    -- Initialize layout update flags
    for _, tracker in ipairs(TRACKERS) do
        needsLayoutUpdate[tracker.key] = false
    end
    
    dprint("Cooldowns module initialized")
    if dbSettings then
        dprint("Loaded saved settings")
    else
        dprint("No saved settings found, using defaults")
    end
end


function Cooldowns:OnEnable()
    -- Register events
    eventFrame:RegisterEvent("ADDON_LOADED")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("SPELL_UPDATE_COOLDOWN")
    eventFrame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")  -- Combat start
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")     -- Party/raid changes
    eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")   -- Instance changes
    eventFrame:RegisterEvent("UNIT_AURA")               -- Buff changes (for activity)
    eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")   -- Target changes
    eventFrame:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")  -- Edit Mode positions applied
    
    eventFrame:SetScript("OnEvent", OnEvent)
    eventFrame:SetScript("OnUpdate", OnUpdate)
    
    -- Hook viewers immediately (they might already exist)
    HookAllViewers()
    
    -- Schedule additional hook attempt
    C_Timer.After(1.0, HookAllViewers)
    C_Timer.After(3.0, HookAllViewers)
    
    -- Start buff state tracking
    StartBuffStateTracking()
    
    -- Start visibility system
    StartVisibilitySystem()
    
    dprint("Cooldowns module enabled")
end

function Cooldowns:OnDisable()
    eventFrame:UnregisterAllEvents()
    eventFrame:SetScript("OnEvent", nil)
    eventFrame:SetScript("OnUpdate", nil)
    
    -- Stop buff state tracking
    StopBuffStateTracking()
    
    -- Stop visibility system
    StopVisibilitySystem()
    
    if cooldownHub then
        cooldownHub:Hide()
    end
    self:HideAllPanels()
    
    dprint("Cooldowns module disabled")
end

-- Save settings on logout
local saveFrame = CreateFrame("Frame")
saveFrame:RegisterEvent("PLAYER_LOGOUT")
saveFrame:SetScript("OnEvent", function()
    if settings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
end)

-- Debug slash command
SLASH_TUICD1 = "/tuicd"
SlashCmdList["TUICD"] = function(msg)
    msg = msg:lower():trim()
    
    if msg == "debug" then
        -- Toggle debug mode
        if settings and settings.global then
            settings.global.debugMode = not settings.global.debugMode
            print("|cff00ff00[TweaksUI CD]|r Debug mode:", settings.global.debugMode and "ON" or "OFF")
        end
        
    elseif msg == "dump" then
        -- Dump icon structure
        print("|cff00ff00[TweaksUI CD]|r Dumping icon structures...")
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                print("  " .. tracker.key .. ":")
                local icons = CollectIcons(viewer)
                for i, icon in ipairs(icons) do
                    if i <= 2 and icon:IsShown() then  -- Only first 2 shown icons
                        local name = icon:GetName() or "unnamed"
                        print("    Icon " .. i .. ": " .. name)
                        -- Check for fields
                        local fields = {}
                        if icon.Border then table.insert(fields, "Border") end
                        if icon.border then table.insert(fields, "border") end
                        if icon.IconBorder then table.insert(fields, "IconBorder") end
                        if icon.Icon then table.insert(fields, "Icon") end
                        if icon.icon then table.insert(fields, "icon") end
                        if icon.Cooldown then table.insert(fields, "Cooldown") end
                        if icon.cooldown then table.insert(fields, "cooldown") end
                        if icon.Count then table.insert(fields, "Count") end
                        if icon.count then table.insert(fields, "count") end
                        if icon.GetNormalTexture and icon:GetNormalTexture() then table.insert(fields, "NormalTexture") end
                        print("      Fields: " .. table.concat(fields, ", "))
                        
                        -- Check regions for FontStrings
                        if icon.GetRegions then
                            local fontStrings = {}
                            for _, region in ipairs({icon:GetRegions()}) do
                                if region:GetObjectType() == "FontString" then
                                    local fsName = region:GetName() or "unnamed"
                                    local fsText = region:GetText() or ""
                                    table.insert(fontStrings, fsName .. "='" .. fsText .. "'")
                                end
                            end
                            if #fontStrings > 0 then
                                print("      FontStrings: " .. table.concat(fontStrings, ", "))
                            end
                        end
                        
                        -- Check children
                        if icon.GetChildren then
                            for _, child in ipairs({icon:GetChildren()}) do
                                local childName = child:GetName() or child:GetObjectType()
                                print("      Child: " .. childName)
                                
                                -- Check child for FontStrings
                                if child.GetRegions then
                                    for _, region in ipairs({child:GetRegions()}) do
                                        if region:GetObjectType() == "FontString" then
                                            local fsName = region:GetName() or "unnamed"
                                            local fsText = region:GetText() or ""
                                            print("        FontString: " .. fsName .. " = '" .. fsText .. "'")
                                        end
                                    end
                                end
                                
                                -- Check grandchildren
                                if child.GetChildren then
                                    for _, grandchild in ipairs({child:GetChildren()}) do
                                        local gcName = grandchild:GetName() or grandchild:GetObjectType()
                                        if grandchild.GetRegions then
                                            for _, region in ipairs({grandchild:GetRegions()}) do
                                                if region:GetObjectType() == "FontString" then
                                                    local fsName = region:GetName() or "unnamed"
                                                    local fsText = region:GetText() or ""
                                                    print("          " .. gcName .. " FontString: " .. fsName .. " = '" .. fsText .. "'")
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        
    elseif msg == "test" then
        -- Test settings persistence
        print("|cff00ff00[TweaksUI CD]|r Testing settings...")
        print("  settings table exists:", settings ~= nil)
        if settings then
            print("  settings.essential:", settings.essential ~= nil)
            if settings.essential then
                print("    iconSize:", settings.essential.iconSize)
                print("    columns:", settings.essential.columns)
            end
        end
        -- Check database
        local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
        print("  DB settings exists:", dbSettings ~= nil)
        if dbSettings and dbSettings.essential then
            print("    DB iconSize:", dbSettings.essential.iconSize)
        end
        
    elseif msg == "reset" then
        -- Clear saved order and recapture all trackers
        print("|cff00ff00[TweaksUI CD]|r Clearing saved icon order and recapturing...")
        ClearIconOrderCache()
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        print("|cff00ff00[TweaksUI CD]|r Reset complete. Icon order saved from current positions.")
    
    elseif msg == "resetbuffs" then
        -- Clear saved order for just buffs tracker
        print("|cff00ff00[TweaksUI CD]|r Clearing buffs icon order and recapturing...")
        ClearIconOrderCache("buffs")
        local viewer = _G["BuffIconCooldownViewer"]
        if viewer and viewer:IsShown() then
            ApplyGridLayout(viewer, "buffs")
            print("|cff00ff00[TweaksUI CD]|r Buffs tracker reset complete.")
        else
            print("|cff00ff00[TweaksUI CD]|r Buffs tracker not visible - show it first.")
        end
    
    elseif msg == "order" then
        -- Show current saved order for all trackers
        print("|cff00ff00[TweaksUI CD]|r Saved icon order:")
        for _, tracker in ipairs(TRACKERS) do
            local savedOrder = GetSetting(tracker.key, "savedIconOrder")
            if savedOrder and #savedOrder > 0 then
                print(string.format("  [%s]: %d icons - %s", tracker.key, #savedOrder, table.concat(savedOrder, ", ")))
            else
                print(string.format("  [%s]: (no saved order)", tracker.key))
            end
        end
        
    else
        print("|cff00ff00[TweaksUI CD]|r Commands:")
        print("  /tuicd debug - Toggle debug mode")
        print("  /tuicd dump - Dump icon structure info")
        print("  /tuicd test - Test settings persistence")
        print("  /tuicd reset - Clear and recapture ALL tracker icon order")
        print("  /tuicd resetbuffs - Clear and recapture buffs tracker order")
        print("  /tuicd order - Show saved icon order (texture fileIDs)")
    end
end
