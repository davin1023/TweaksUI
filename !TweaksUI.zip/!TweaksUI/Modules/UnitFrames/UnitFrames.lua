-- TweaksUI Unit Frames Module
-- Custom unit frame overlays with full control over appearance
-- Works WITH Blizzard's systems for targeting/menus, replaces visuals

local ADDON_NAME, TweaksUI = ...

-- Create the module
local UnitFrames = TweaksUI.ModuleManager:NewModule(
    TweaksUI.MODULE_IDS.UNIT_FRAMES,
    "Unit Frames",
    "Fully customizable unit frames for player, target, and more"
)

-- ============================================================================
-- MIDNIGHT SECRET VALUE HANDLING
-- ============================================================================

-- Safe value function for Midnight secret values
local function SafeValue(value)
    if issecretvalue and issecretvalue(value) then
        return nil
    end
    return value
end

-- ============================================================================
-- CONSTANTS
-- ============================================================================

local HEALTH_TEXT_FORMATS = {
    { id = "none", name = "Hidden" },
    { id = "current", name = "Current (45,230)" },
    { id = "max", name = "Maximum (100,000)" },
    { id = "percent", name = "Percent (45%)" },
    { id = "current_max", name = "Current / Max" },
    { id = "current_percent", name = "Current - Percent" },
    { id = "percent_current", name = "Percent - Current" },
    { id = "deficit", name = "Deficit (-54,770)" },
}

local POWER_TEXT_FORMATS = {
    { id = "none", name = "Hidden" },
    { id = "current", name = "Current" },
    { id = "max", name = "Maximum" },
    { id = "percent", name = "Percent" },
    { id = "current_max", name = "Current / Max" },
}

local HEALTH_COLOR_MODES = {
    { id = "class", name = "Class Color" },
    { id = "reaction", name = "Reaction Color" },
    { id = "custom", name = "Custom Color" },
    { id = "gradient", name = "Health Gradient" },
}

local POWER_COLOR_MODES = {
    { id = "power", name = "Power Type" },
    { id = "custom", name = "Custom Color" },
}

local NAME_COLOR_MODES = {
    { id = "white", name = "White" },
    { id = "class", name = "Class Color" },
    { id = "reaction", name = "Reaction Color" },
    { id = "custom", name = "Custom Color" },
}

local PORTRAIT_MODES = {
    { id = "none", name = "Hidden" },
    { id = "2d", name = "2D Portrait" },
    { id = "3d", name = "3D Model" },
    { id = "class", name = "Class Icon" },
}

local PORTRAIT_POSITIONS = {
    { id = "left", name = "Left" },
    { id = "right", name = "Right" },
}

local FONT_OUTLINES = {
    { id = "", name = "None" },
    { id = "OUTLINE", name = "Thin" },
    { id = "THICKOUTLINE", name = "Thick" },
}

local ANCHOR_POINTS = {
    { id = "TOPLEFT", name = "Top Left" },
    { id = "TOP", name = "Top" },
    { id = "TOPRIGHT", name = "Top Right" },
    { id = "LEFT", name = "Left" },
    { id = "CENTER", name = "Center" },
    { id = "RIGHT", name = "Right" },
    { id = "BOTTOMLEFT", name = "Bottom Left" },
    { id = "BOTTOM", name = "Bottom" },
    { id = "BOTTOMRIGHT", name = "Bottom Right" },
}

local HORIZONTAL_ALIGN = {
    { id = "LEFT", name = "Left" },
    { id = "CENTER", name = "Center" },
    { id = "RIGHT", name = "Right" },
}

local VERTICAL_ALIGN = {
    { id = "TOP", name = "Top" },
    { id = "MIDDLE", name = "Middle" },
    { id = "BOTTOM", name = "Bottom" },
}

-- Role sorting options for party/raid
local ROLE_SORT_OPTIONS = {
    { id = "TANK_HEALER_DPS", name = "Tank / Healer / DPS" },
    { id = "HEALER_TANK_DPS", name = "Healer / Tank / DPS" },
    { id = "DPS_TANK_HEALER", name = "DPS / Tank / Healer" },
    { id = "DPS_HEALER_TANK", name = "DPS / Healer / Tank" },
    { id = "NONE", name = "No Sorting (Group Order)" },
}

-- Growth directions for party/raid containers
local GROWTH_DIRECTIONS = {
    { id = "DOWN", name = "Down" },
    { id = "UP", name = "Up" },
    { id = "RIGHT", name = "Right" },
    { id = "LEFT", name = "Left" },
}

-- Role priority for sorting (lower = higher priority)
local ROLE_PRIORITY = {
    TANK_HEALER_DPS = { TANK = 1, HEALER = 2, DAMAGER = 3, NONE = 4 },
    HEALER_TANK_DPS = { HEALER = 1, TANK = 2, DAMAGER = 3, NONE = 4 },
    DPS_TANK_HEALER = { DAMAGER = 1, TANK = 2, HEALER = 3, NONE = 4 },
    DPS_HEALER_TANK = { DAMAGER = 1, HEALER = 2, TANK = 3, NONE = 4 },
}

-- Power type colors
local POWER_COLORS = {
    [Enum.PowerType.Mana] = { 0.0, 0.0, 1.0 },
    [Enum.PowerType.Rage] = { 1.0, 0.0, 0.0 },
    [Enum.PowerType.Focus] = { 1.0, 0.5, 0.25 },
    [Enum.PowerType.Energy] = { 1.0, 1.0, 0.0 },
    [Enum.PowerType.ComboPoints] = { 1.0, 0.96, 0.41 },
    [Enum.PowerType.Runes] = { 0.5, 0.5, 0.5 },
    [Enum.PowerType.RunicPower] = { 0.0, 0.82, 1.0 },
    [Enum.PowerType.SoulShards] = { 0.58, 0.51, 0.79 },
    [Enum.PowerType.LunarPower] = { 0.3, 0.52, 0.9 },
    [Enum.PowerType.HolyPower] = { 0.95, 0.9, 0.6 },
    [Enum.PowerType.Maelstrom] = { 0.0, 0.5, 1.0 },
    [Enum.PowerType.Chi] = { 0.71, 1.0, 0.92 },
    [Enum.PowerType.Insanity] = { 0.4, 0.0, 0.8 },
    [Enum.PowerType.ArcaneCharges] = { 0.1, 0.1, 0.98 },
    [Enum.PowerType.Fury] = { 0.79, 0.26, 0.99 },
    [Enum.PowerType.Pain] = { 1.0, 0.61, 0.0 },
    [Enum.PowerType.Essence] = { 0.2, 0.58, 0.5 },
}

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

local function GetDefaultFrameSettings(unit)
    local isPlayer = (unit == "player")
    local isTarget = (unit == "target")
    local isFocus = (unit == "focus")
    local isToT = (unit == "targettarget")
    local isPet = (unit == "pet")
    local isParty = unit:match("^party%d$")
    
    -- Default positions based on unit type
    local defaultX, defaultY
    local defaultWidth, defaultHeight = 220, 46
    
    if isPlayer then
        defaultX, defaultY = -300, -150
    elseif isTarget then
        defaultX, defaultY = 300, -150
    elseif isFocus then
        defaultX, defaultY = -300, -220
    elseif isToT then
        defaultX, defaultY = 300, -220
        defaultWidth, defaultHeight = 160, 32  -- Smaller for ToT
    elseif isPet then
        defaultX, defaultY = -300, -290
        defaultWidth, defaultHeight = 160, 32  -- Smaller for Pet
    elseif isParty then
        -- Stack party frames vertically on the left
        local partyNum = tonumber(unit:match("%d")) or 1
        defaultX, defaultY = -450, 100 - ((partyNum - 1) * 55)
        defaultWidth, defaultHeight = 180, 44  -- Medium size for party
    else
        defaultX, defaultY = 0, 0
    end
    
    -- Smaller frames get adjusted defaults
    local isSmallFrame = (isToT or isPet)
    local isMediumFrame = isParty
    
    return {
        enabled = true,
        
        -- Frame dimensions and position
        frame = {
            width = defaultWidth,
            height = defaultHeight,
            autoSize = true,  -- Dynamically calculate size based on elements
            x = defaultX,
            y = defaultY,
            anchor = "CENTER",
            scale = 1.0,
            -- Background appearance
            showBackground = true,
            bgColor = { 0.02, 0.02, 0.02, 0.92 },
            -- Border appearance
            showBorder = true,
            borderColor = { 0, 0, 0, 1 },
            borderSize = 1,
            -- Spacing
            padding = 1,  -- Padding inside frame
            barSpacing = 1,  -- Space between health and power bars
            -- Extra background extension (for text outside bars)
            bgExtendTop = 0,  -- Extend background above frame
            bgExtendBottom = 0,  -- Extend background below frame
        },
        
        -- Health Bar
        healthBar = {
            enabled = true,
            height = isSmallFrame and 20 or 30,
            texture = "Blizzard",
            colorMode = "class",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.12, 0.12, 0.12, 0.85 },
        },
        
        -- Power Bar
        powerBar = {
            enabled = not isSmallFrame,  -- Disabled by default for small frames
            height = isSmallFrame and 6 or 12,
            texture = "Blizzard",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.08, 0.08, 0.08, 0.85 },
        },
        
        -- Cast Bar
        castBar = {
            enabled = false,
            height = isSmallFrame and 8 or 12,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
            attachedTo = "bottom",  -- "bottom" = below frame, "health" = inside health bar
            offsetY = 0,
        },
        
        -- Health Text
        healthText = {
            enabled = true,
            format = isSmallFrame and "percent" or "current_percent",
            abbreviate = true,
            fontSize = isSmallFrame and 9 or 11,
            fontOutline = "OUTLINE",
            anchor = "CENTER",
            offsetX = 0,
            offsetY = isSmallFrame and 0 or 2,
            color = { 1, 1, 1, 1 },
            colorByHealth = false,
            hAlign = "CENTER",  -- LEFT, CENTER, RIGHT
            vAlign = "MIDDLE",  -- TOP, MIDDLE, BOTTOM
        },
        
        -- Power Text
        powerText = {
            enabled = false,
            format = "current",
            abbreviate = true,
            fontSize = 9,
            fontOutline = "OUTLINE",
            anchor = "CENTER",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        
        -- Name Text
        nameText = {
            enabled = not isSmallFrame,  -- Disabled by default for small frames
            fontSize = isSmallFrame and 9 or 11,
            fontOutline = "OUTLINE",
            anchor = "BOTTOM",
            frameAnchor = "TOP",
            anchorToHealthBar = false,  -- If true, anchors inside health bar instead of frame edge
            offsetX = 0,
            offsetY = 2,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        
        -- Level Text
        levelText = {
            enabled = isTarget,  -- Only enabled by default for target
            fontSize = isSmallFrame and 9 or 11,
            fontOutline = "OUTLINE",
            anchor = "BOTTOMRIGHT",
            frameAnchor = "TOPRIGHT",
            offsetX = -2,
            offsetY = 2,
            showClassification = true,
            hideAtMaxLevel = false,
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        
        -- Portrait
        portrait = {
            enabled = false,
            mode = "2d",
            size = isSmallFrame and 28 or 44,
            position = "left",
            outside = false,  -- If true, portrait doesn't affect bar width
            offsetX = 0,
            offsetY = 0,
        },
        
        -- Raid Target Icon
        raidTarget = {
            enabled = true,
            size = isSmallFrame and 18 or (isParty and 18 or 24),
            anchor = "CENTER",
            frameAnchor = isParty and "TOP" or "TOP",
            offsetX = 0,
            offsetY = isParty and -2 or (isSmallFrame and 8 or 12),
        },
        
        -- Role Icon (Tank/Healer/DPS)
        roleIcon = {
            enabled = isParty,  -- On by default for party frames
            size = isSmallFrame and 14 or (isParty and 16 or 18),
            anchor = "CENTER",
            frameAnchor = isParty and "TOPLEFT" or "TOPLEFT",
            offsetX = isParty and 2 or (isSmallFrame and 2 or 4),
            offsetY = isParty and -2 or (isSmallFrame and -2 or -4),
        },
        
        -- Debuff Indicators (for dispellable debuffs)
        debuffIndicators = {
            enabled = isParty,  -- Enabled by default for party frames
            showMagic = true,
            showCurse = true,
            showDisease = true,
            showPoison = true,
            showBleed = false,
            size = isParty and 14 or 12,
            position = "BOTTOMRIGHT",
            offsetX = -2,
            offsetY = 2,
            showBorder = true,
        },
        
        -- Visibility Settings (per-frame)
        visibility = {
            enabled = false,            -- Master toggle for this frame
            combat = false,             -- Show in combat
            mouseover = false,          -- Show on mouseover
            target = false,             -- Show when have target
            group = false,              -- Show in party/raid
            instance = false,           -- Show by instance type
            instanceTypes = {},         -- Which instance types: party, raid, arena, pvp, scenario
            fadeAlpha = 0,              -- Alpha when hidden (0-100)
        },
    }
end

local DEFAULTS = {
    enabled = false,
    player = nil,
    target = nil,
    savedLayouts = {},  -- User's custom saved layouts
}

-- ============================================================================
-- PRESET LAYOUTS
-- ============================================================================

local PRESET_LAYOUTS = {
    simple = {
        name = "Simple",
        description = "Clean minimal look with centered text",
        frame = {
            width = 200,
            height = 40,
            scale = 1.0,
            autoSize = true,
            showBackground = true,
            bgColor = { 0.05, 0.05, 0.05, 0.9 },
            showBorder = true,
            borderColor = { 0, 0, 0, 1 },
            borderSize = 1,
            padding = 2,
            barSpacing = 2,
            bgExtendTop = 0,
            bgExtendBottom = 0,
        },
        healthBar = {
            enabled = true,
            height = 24,
            texture = "Blizzard",
            colorMode = "class",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.8 },
        },
        powerBar = {
            enabled = true,
            height = 8,
            texture = "Blizzard",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.8 },
        },
        healthText = {
            enabled = true,
            format = "percent",
            abbreviate = true,
            fontSize = 11,
            fontOutline = "OUTLINE",
            offsetX = -4,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            colorByHealth = false,
            hAlign = "RIGHT",
            vAlign = "MIDDLE",
        },
        powerText = {
            enabled = false,
            format = "current",
            abbreviate = true,
            fontSize = 9,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        nameText = {
            enabled = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            frameAnchor = "LEFT",
            anchorToHealthBar = true,
            offsetX = 4,
            offsetY = 0,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "LEFT",
            vAlign = "MIDDLE",
        },
        levelText = {
            enabled = false,
            fontSize = 10,
            fontOutline = "OUTLINE",
            frameAnchor = "TOPRIGHT",
            offsetX = 0,
            offsetY = 2,
            showClassification = false,
            hideAtMaxLevel = true,
            hAlign = "RIGHT",
        },
        portrait = {
            enabled = false,
            mode = "none",
            size = 40,
            position = "left",
            outside = false,
            offsetX = 0,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 20,
            anchor = "CENTER",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = 10,
        },
        castBar = {
            enabled = false,
            height = 12,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
            attachedTo = "bottom",
            offsetY = 0,
        },
    },
    
    robust = {
        name = "Robust",
        description = "Full featured with portrait and all elements",
        frame = {
            width = 280,
            height = 50,
            scale = 1.0,
            autoSize = true,
            showBackground = true,
            bgColor = { 0.02, 0.02, 0.02, 0.95 },
            showBorder = true,
            borderColor = { 0.3, 0.3, 0.3, 1 },
            borderSize = 2,
            padding = 0,
            barSpacing = 2,
            bgExtendTop = 18,
            bgExtendBottom = 0,
        },
        healthBar = {
            enabled = true,
            height = 28,
            texture = "Blizzard Raid Bar",
            colorMode = "class",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.15, 0.15, 0.15, 0.9 },
        },
        powerBar = {
            enabled = true,
            height = 14,
            texture = "Blizzard Raid Bar",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.9 },
        },
        healthText = {
            enabled = true,
            format = "current_percent",
            abbreviate = true,
            fontSize = 12,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            colorByHealth = true,
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        powerText = {
            enabled = true,
            format = "current",
            abbreviate = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        nameText = {
            enabled = true,
            fontSize = 12,
            fontOutline = "OUTLINE",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = -14,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "CENTER",
        },
        levelText = {
            enabled = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            frameAnchor = "TOPRIGHT",
            offsetX = -4,
            offsetY = -14,
            showClassification = true,
            hideAtMaxLevel = false,
            hAlign = "RIGHT",
        },
        portrait = {
            enabled = true,
            mode = "2d",
            size = 50,
            position = "left",
            outside = true,
            offsetX = -52,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 24,
            anchor = "CENTER",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = 12,
        },
        castBar = {
            enabled = false,
            height = 12,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
            attachedTo = "bottom",
            offsetY = 0,
        },
    },
    
    fancy = {
        name = "Fancy",
        description = "Stylish with 3D portrait and gradient health",
        frame = {
            width = 250,
            height = 44,
            scale = 1.0,
            autoSize = true,
            showBackground = true,
            bgColor = { 0.03, 0.03, 0.06, 0.92 },
            showBorder = true,
            borderColor = { 0.4, 0.35, 0.2, 1 },
            borderSize = 1,
            padding = 0,
            barSpacing = 1,
            bgExtendTop = 18,
            bgExtendBottom = 0,
        },
        healthBar = {
            enabled = true,
            height = 32,
            texture = "Blizzard Raid Bar",
            colorMode = "gradient",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.08, 0.08, 0.12, 0.85 },
        },
        powerBar = {
            enabled = true,
            height = 10,
            texture = "Blizzard Raid Bar",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.06, 0.06, 0.1, 0.85 },
        },
        healthText = {
            enabled = true,
            format = "current_max",
            abbreviate = true,
            fontSize = 11,
            fontOutline = "OUTLINE",
            offsetX = 2,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            colorByHealth = false,
            hAlign = "LEFT",
            vAlign = "MIDDLE",
        },
        powerText = {
            enabled = false,
            format = "percent",
            abbreviate = true,
            fontSize = 9,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        nameText = {
            enabled = true,
            fontSize = 13,
            fontOutline = "THICKOUTLINE",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = -14,
            colorMode = "class",
            customColor = { 1, 0.85, 0, 1 },
            hAlign = "CENTER",
        },
        levelText = {
            enabled = true,
            fontSize = 11,
            fontOutline = "OUTLINE",
            frameAnchor = "TOPRIGHT",
            offsetX = -4,
            offsetY = -14,
            showClassification = true,
            hideAtMaxLevel = true,
            hAlign = "RIGHT",
        },
        portrait = {
            enabled = true,
            mode = "2d",
            size = 54,
            position = "left",
            outside = true,
            offsetX = -56,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 28,
            anchor = "CENTER",
            frameAnchor = "RIGHT",
            offsetX = 14,
            offsetY = 0,
        },
        castBar = {
            enabled = false,
            height = 12,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
            attachedTo = "bottom",
            offsetY = 0,
        },
    },
    
    minimal = {
        name = "Minimal",
        description = "Ultra-clean floating bars only",
        frame = {
            width = 180,
            height = 24,
            scale = 1.0,
            autoSize = true,
            showBackground = false,
            bgColor = { 0, 0, 0, 0 },
            showBorder = false,
            borderColor = { 0, 0, 0, 0 },
            borderSize = 0,
            padding = 0,
            barSpacing = 1,
            bgExtendTop = 0,
            bgExtendBottom = 0,
        },
        healthBar = {
            enabled = true,
            height = 18,
            texture = "Blizzard",
            colorMode = "class",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.15, 0.15, 0.15, 0.6 },
        },
        powerBar = {
            enabled = true,
            height = 4,
            texture = "Blizzard",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.5 },
        },
        healthText = {
            enabled = true,
            format = "percent",
            abbreviate = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            offsetX = -4,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            colorByHealth = true,
            hAlign = "RIGHT",
            vAlign = "MIDDLE",
        },
        powerText = {
            enabled = false,
            format = "none",
            abbreviate = true,
            fontSize = 8,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        nameText = {
            enabled = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            frameAnchor = "LEFT",
            anchorToHealthBar = true,
            offsetX = 4,
            offsetY = 0,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "LEFT",
            vAlign = "MIDDLE",
        },
        levelText = {
            enabled = false,
            fontSize = 9,
            fontOutline = "OUTLINE",
            frameAnchor = "TOPRIGHT",
            offsetX = 0,
            offsetY = 0,
            showClassification = false,
            hideAtMaxLevel = true,
            hAlign = "RIGHT",
        },
        portrait = {
            enabled = false,
            mode = "none",
            size = 30,
            position = "left",
            outside = false,
            offsetX = 0,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 18,
            anchor = "CENTER",
            frameAnchor = "LEFT",
            offsetX = -10,
            offsetY = 0,
        },
        castBar = {
            enabled = false,
            height = 10,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
            attachedTo = "bottom",
            offsetY = 0,
        },
    },
    
    -- Party Style - Compact, class-colored, health-focused (healer-friendly)
    party = {
        name = "Party Style",
        description = "Compact layout ideal for party/group frames with icons inside",
        frame = {
            width = 170,
            height = 42,
            scale = 1.0,
            autoSize = true,
            showBackground = true,
            bgColor = { 0.02, 0.02, 0.02, 0.92 },
            showBorder = true,
            borderColor = { 0, 0, 0, 1 },
            borderSize = 1,
            padding = 2,
            barSpacing = 1,
            bgExtendTop = 0,
            bgExtendBottom = 0,
        },
        healthBar = {
            enabled = true,
            height = 30,
            texture = "Blizzard",
            colorMode = "class",
            customColor = { 0, 0.8, 0, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.9 },
        },
        powerBar = {
            enabled = true,
            height = 6,
            texture = "Blizzard",
            colorMode = "power",
            customColor = { 0, 0.5, 1, 1 },
            bgColor = { 0.1, 0.1, 0.1, 0.9 },
        },
        healthText = {
            enabled = true,
            format = "percent",
            abbreviate = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            offsetX = -4,
            offsetY = 0,
            colorByHealth = false,
            hAlign = "RIGHT",
            vAlign = "MIDDLE",
        },
        powerText = {
            enabled = false,
            format = "none",
            abbreviate = true,
            fontSize = 8,
            fontOutline = "OUTLINE",
            offsetX = 0,
            offsetY = 0,
            color = { 1, 1, 1, 1 },
            hAlign = "CENTER",
            vAlign = "MIDDLE",
        },
        nameText = {
            enabled = true,
            fontSize = 10,
            fontOutline = "OUTLINE",
            frameAnchor = "LEFT",
            anchorToHealthBar = true,
            offsetX = 4,
            offsetY = 0,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "LEFT",
            vAlign = "MIDDLE",
        },
        levelText = {
            enabled = false,
            fontSize = 9,
            fontOutline = "OUTLINE",
            frameAnchor = "TOPRIGHT",
            offsetX = 0,
            offsetY = 0,
            showClassification = false,
            hideAtMaxLevel = true,
            hAlign = "RIGHT",
        },
        portrait = {
            enabled = false,
            mode = "none",
            size = 28,
            position = "left",
            outside = false,
            offsetX = 0,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 18,
            anchor = "CENTER",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = -2,
        },
        roleIcon = {
            enabled = true,
            size = 16,
            anchor = "CENTER",
            frameAnchor = "TOPLEFT",
            offsetX = 2,
            offsetY = -2,
        },
        debuffIndicators = {
            enabled = true,
            showMagic = true,
            showCurse = true,
            showDisease = true,
            showPoison = true,
            showBleed = false,
            size = 14,
            position = "BOTTOMRIGHT",
            offsetX = -2,
            offsetY = 2,
            showBorder = true,
        },
        castBar = {
            enabled = false,
            height = 8,
            showIcon = true,
            showTimer = true,
            showSpellName = true,
        },
    },
}

-- Shared raid frame visual defaults (used by both small and large)
local RAID_FRAME_VISUAL_DEFAULTS = {
    frame = {
        width = 72,
        height = 36,
        showBackground = true,
        showBorder = true,
        borderSize = 1,
        bgColor = { 0.05, 0.05, 0.05, 0.9 },
        borderColor = { 0, 0, 0, 1 },
    },
    healthBar = {
        height = 24,
        texture = "Interface\\TargetingFrame\\UI-StatusBar",
        colorMode = "class",
        customColor = { 0.2, 0.8, 0.2, 1 },
        showAbsorbBar = false,
    },
    powerBar = {
        enabled = true,
        height = 6,
        texture = "Interface\\TargetingFrame\\UI-StatusBar",
    },
    healthText = {
        enabled = false,
        format = "percent",
        fontSize = 9,
        fontOutline = "OUTLINE",
        position = "CENTER",
        offsetX = 0,
        offsetY = 0,
    },
    powerText = {
        enabled = false,
        format = "none",
        fontSize = 8,
        fontOutline = "OUTLINE",
    },
    nameText = {
        enabled = true,
        fontSize = 10,
        fontOutline = "OUTLINE",
        frameAnchor = "LEFT",
        anchorToHealthBar = true,
        offsetX = 2,
        offsetY = 0,
        colorMode = "class",
        customColor = { 1, 1, 1, 1 },
        hAlign = "LEFT",
        vAlign = "MIDDLE",
        maxLength = 8,
    },
    portrait = {
        enabled = false,
        mode = "none",
        size = 20,
        position = "left",
        outside = false,
        offsetX = 0,
        offsetY = 0,
    },
    raidTarget = {
        enabled = true,
        size = 14,
        anchor = "CENTER",
        frameAnchor = "TOP",
        offsetX = 0,
        offsetY = -2,
    },
    roleIcon = {
        enabled = true,
        size = 12,
        anchor = "CENTER",
        frameAnchor = "TOPLEFT",
        offsetX = 1,
        offsetY = -1,
    },
    debuffIndicators = {
        enabled = true,
        showMagic = true,
        showCurse = true,
        showDisease = true,
        showPoison = true,
        showBleed = false,
        size = 10,
        position = "BOTTOMRIGHT",
        offsetX = -1,
        offsetY = 1,
        showBorder = true,
    },
    castBar = {
        enabled = false,
        height = 6,
        showIcon = true,
        showTimer = true,
        showSpellName = true,
    },
    rangeCheck = {
        enabled = true,
        outOfRangeAlpha = 0.4,
    },
    highlightDispellable = true,
    showOffline = true,
    showDead = true,
}

-- Raid frames master settings
local RAID_DEFAULTS = {
    enabled = false,
    sizeThreshold = 20,  -- Use small layout for <= this many players, large for more
    
    -- Small raid layout (10-20 players)
    small = {
        container = {
            x = -300,
            y = 100,
            anchor = "CENTER",
            scale = 1.0,
        },
        layout = {
            mode = "GRID",  -- GRID, GROUP_ROWS, or GROUP_COLUMNS
            -- GRID mode: arrange all players in a simple grid (ignores group boundaries)
            columns = 5,    -- Number of columns
            spacing = 2,
            growthDirection = "DOWN",  -- How to fill: DOWN, UP, RIGHT, LEFT
            
            -- GROUP modes: arrange by party group
            groupsPerRow = 4,     -- For GROUP_ROWS: groups per row before wrapping down
            groupsPerColumn = 2,  -- For GROUP_COLUMNS: groups per column before wrapping right
            groupSpacing = 8,     -- Space between groups
            
            -- Within each group
            membersPerRow = 5,    -- Members per row within a group (1 = vertical column)
            memberGrowth = "DOWN", -- How members fill within group: DOWN, RIGHT
        },
        -- Visual settings (copied from shared defaults)
        frame = nil,  -- Will be filled from RAID_FRAME_VISUAL_DEFAULTS
        healthBar = nil,
        powerBar = nil,
        healthText = nil,
        powerText = nil,
        nameText = nil,
        portrait = nil,
        raidTarget = nil,
        roleIcon = nil,
        debuffIndicators = nil,
        rangeCheck = nil,
        highlightDispellable = true,
        showOffline = true,
        showDead = true,
    },
    
    -- Large raid layout (21-40 players)
    large = {
        container = {
            x = -300,
            y = -100,
            anchor = "CENTER",
            scale = 0.9,
        },
        layout = {
            mode = "GROUP_ROWS",  -- Default to group rows for large raids
            columns = 8,
            spacing = 1,
            growthDirection = "DOWN",
            
            groupsPerRow = 8,
            groupsPerColumn = 4,
            groupSpacing = 4,
            
            membersPerRow = 5,
            memberGrowth = "DOWN",
        },
        -- Visual settings - slightly smaller for large raids
        frame = {
            width = 60,
            height = 30,
            showBackground = true,
            showBorder = true,
            borderSize = 1,
            bgColor = { 0.05, 0.05, 0.05, 0.9 },
            borderColor = { 0, 0, 0, 1 },
        },
        healthBar = {
            height = 20,
            texture = "Interface\\TargetingFrame\\UI-StatusBar",
            colorMode = "class",
            customColor = { 0.2, 0.8, 0.2, 1 },
            showAbsorbBar = false,
        },
        powerBar = {
            enabled = true,
            height = 4,
            texture = "Interface\\TargetingFrame\\UI-StatusBar",
        },
        healthText = {
            enabled = false,
            format = "percent",
            fontSize = 8,
            fontOutline = "OUTLINE",
            position = "CENTER",
            offsetX = 0,
            offsetY = 0,
        },
        powerText = {
            enabled = false,
            format = "none",
            fontSize = 7,
            fontOutline = "OUTLINE",
        },
        nameText = {
            enabled = true,
            fontSize = 9,
            fontOutline = "OUTLINE",
            frameAnchor = "LEFT",
            anchorToHealthBar = true,
            offsetX = 2,
            offsetY = 0,
            colorMode = "class",
            customColor = { 1, 1, 1, 1 },
            hAlign = "LEFT",
            vAlign = "MIDDLE",
            maxLength = 6,  -- Shorter names for compact display
        },
        portrait = {
            enabled = false,
            mode = "none",
            size = 16,
            position = "left",
            outside = false,
            offsetX = 0,
            offsetY = 0,
        },
        raidTarget = {
            enabled = true,
            size = 12,
            anchor = "CENTER",
            frameAnchor = "TOP",
            offsetX = 0,
            offsetY = -1,
        },
        roleIcon = {
            enabled = true,
            size = 10,
            anchor = "CENTER",
            frameAnchor = "TOPLEFT",
            offsetX = 1,
            offsetY = -1,
        },
        debuffIndicators = {
            enabled = true,
            showMagic = true,
            showCurse = true,
            showDisease = true,
            showPoison = true,
            showBleed = false,
            size = 8,
            position = "BOTTOMRIGHT",
            offsetX = -1,
            offsetY = 1,
            showBorder = true,
        },
        rangeCheck = {
            enabled = true,
            outOfRangeAlpha = 0.4,
        },
        highlightDispellable = true,
        showOffline = true,
        showDead = true,
    },
}

-- Tank frames settings (separate container for tanks only)
local TANK_DEFAULTS = {
    enabled = false,
    showMainTank = true,      -- Show players marked as Main Tank
    showMainAssist = true,    -- Show players marked as Main Assist
    showRoleTanks = true,     -- Show players with Tank role assigned
    maxTanks = 4,             -- Maximum tanks to show
    
    container = {
        x = -400,
        y = 200,
        anchor = "CENTER",
        scale = 1.0,
    },
    layout = {
        direction = "DOWN",   -- DOWN, UP, RIGHT, LEFT
        spacing = 2,
    },
    frame = {
        width = 120,
        height = 40,
        showBackground = true,
        showBorder = true,
        borderSize = 1,
        bgColor = { 0.05, 0.05, 0.05, 0.9 },
        borderColor = { 0.3, 0.3, 0.3, 1 },
    },
    healthBar = {
        height = 28,
        colorMode = "class",  -- "class", "health", "custom"
        customColor = { 0.2, 0.8, 0.2, 1 },
        bgColor = { 0.1, 0.1, 0.1, 0.8 },
    },
    powerBar = {
        enabled = true,
        height = 6,
    },
    nameText = {
        enabled = true,
        fontSize = 11,
        fontOutline = "OUTLINE",
        colorMode = "class",
        maxLength = 12,
    },
    healthText = {
        enabled = true,
        fontSize = 10,
        format = "percent",  -- "percent", "current", "deficit"
    },
    roleIcon = {
        enabled = true,
        size = 14,
        position = "TOPLEFT",
        offsetX = 1,
        offsetY = -1,
    },
    raidTarget = {
        enabled = true,
        size = 16,
        position = "RIGHT",
        offsetX = -2,
        offsetY = 0,
    },
    debuffIndicators = {
        enabled = true,
        size = 8,
        position = "BOTTOMRIGHT",
        offsetX = -1,
        offsetY = 1,
        showMagic = true,
        showCurse = true,
        showDisease = true,
        showPoison = true,
    },
    castBar = {
        enabled = false,
        height = 8,
        showIcon = true,
        showTimer = true,
        showSpellName = true,
    },
    -- Visibility settings (per-frame)
    visibility = {
        enabled = false,
        combat = false,
        mouseover = false,
        target = false,
        group = false,
        instance = false,
        instanceTypes = {},
        fadeAlpha = 0,
    },
}

-- Boss frame defaults
local BOSS_DEFAULTS = {
    enabled = false,
    maxBosses = 5,            -- Maximum boss frames to show (boss1-boss5)
    
    container = {
        x = 400,
        y = 200,
        anchor = "CENTER",
        scale = 1.0,
    },
    layout = {
        direction = "DOWN",   -- DOWN, UP, RIGHT, LEFT
        spacing = 2,
    },
    frame = {
        width = 180,
        height = 50,
        showBackground = true,
        showBorder = true,
        borderSize = 1,
        bgColor = { 0.05, 0.05, 0.05, 0.9 },
        borderColor = { 0.5, 0.1, 0.1, 1 },  -- Reddish border for bosses
    },
    healthBar = {
        height = 36,
        colorMode = "custom",  -- "class", "health", "custom"
        customColor = { 0.8, 0.2, 0.2, 1 },  -- Red for bosses
        bgColor = { 0.1, 0.1, 0.1, 0.8 },
    },
    powerBar = {
        enabled = true,
        height = 8,
    },
    nameText = {
        enabled = true,
        fontSize = 12,
        fontOutline = "OUTLINE",
        colorMode = "custom",
        customColor = { 1, 0.8, 0.2, 1 },  -- Gold color
        maxLength = 20,
    },
    healthText = {
        enabled = true,
        fontSize = 11,
        format = "percent",  -- "percent", "current", "deficit"
    },
    raidTarget = {
        enabled = true,
        size = 20,
        position = "LEFT",
        offsetX = 2,
        offsetY = 0,
    },
    castBar = {
        enabled = true,
        height = 10,
        showIcon = true,
        showTimer = true,
    },
    -- Visibility settings (per-frame)
    visibility = {
        enabled = false,
        combat = false,
        mouseover = false,
        target = false,
        group = false,
        instance = false,
        instanceTypes = {},
        fadeAlpha = 0,
    },
}

-- ============================================================================
-- MODULE STATE
-- ============================================================================

local settings = nil
local unitFramesHub = nil
local settingsPanels = {}
local customFrames = {}
local blizzardFramesMasked = {}
local LibSharedMedia = nil
-- LibEditMode is now managed by TweaksUI.EditMode (Core/EditModeManager.lua)
local LibEditMode = nil  -- Keep for backward compatibility with any remaining references
local eventFrame = nil

-- Helper function for getting spell texture (modern API)
local function GetSpellTextureByID(spellID)
    if not spellID then return nil end
    -- Modern API (Dragonflight+)
    if C_Spell and C_Spell.GetSpellTexture then
        return C_Spell.GetSpellTexture(spellID)
    end
    -- Fallback for older API
    local _, _, texture = GetSpellInfo(spellID)
    return texture
end

-- Party container state
local partyContainer = nil
local partyMemberFrames = {}

-- Raid container state - two sets for small/large raids
local raidSmallContainer = nil
local raidLargeContainer = nil
local raidSmallMemberFrames = {}  -- { [index] = frame } for small raids (1-20)
local raidLargeMemberFrames = {}  -- { [index] = frame } for large raids (1-40)
local activeRaidSize = "small"  -- Which layout is currently active

-- Tank container state
local tankContainer = nil
local tankMemberFrames = {}  -- { [index] = frame } for tanks (1-4)

-- Boss container state
local bossContainer = nil
local bossMemberFrames = {}  -- { [index] = frame } for bosses (1-5)

-- Currently open settings panel (for preview mode)
local currentOpenPanel = nil
local blizzardCastBarHidden = false

-- Legacy compatibility
local raidContainer = nil  -- Points to active container
local raidMemberFrames = {}  -- Points to active frame set

-- Simulation modes - separate for each raid size
local simulationMode = false  -- For individual frames and party
local simulateRaidSmall = false  -- Simulate small raid layout
local simulateRaidLarge = false  -- Simulate large raid layout
local simulateTanks = false  -- Simulate tank frames
local simulateBoss = false  -- Simulate boss frames

-- Individual unit types (non-group frames)
local INDIVIDUAL_UNITS = {"player", "target", "focus", "targettarget", "pet"}

-- Panel constants
local HUB_WIDTH = 220
local PANEL_WIDTH = 420
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 4

-- Dark backdrop template
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- Simple flat backdrop for custom frames
local frameBackdrop = {
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8",
    edgeSize = 1,
    insets = { left = 0, right = 0, top = 0, bottom = 0 }
}

-- ============================================================================
-- BLIZZARD FRAME REFERENCES
-- ============================================================================

local BLIZZARD_FRAMES = {
    player = function() return PlayerFrame end,
    target = function() return TargetFrame end,
    focus = function() return FocusFrame end,
    targettarget = function() return TargetFrameToT end,
    focustarget = function() return FocusFrameToT end,
    pet = function() return PetFrame end,
    party1 = function() return PartyFrame and PartyFrame.MemberFrame1 end,
    party2 = function() return PartyFrame and PartyFrame.MemberFrame2 end,
    party3 = function() return PartyFrame and PartyFrame.MemberFrame3 end,
    party4 = function() return PartyFrame and PartyFrame.MemberFrame4 end,
}

-- Debuff type colors (matching Blizzard's dispel colors)
local DEBUFF_TYPE_COLORS = {
    Magic = { 0.2, 0.6, 1.0, 1 },     -- Blue
    Curse = { 0.6, 0.0, 1.0, 1 },     -- Purple
    Disease = { 0.6, 0.4, 0.0, 1 },   -- Brown
    Poison = { 0.0, 0.6, 0.0, 1 },    -- Green
    Bleed = { 0.8, 0.0, 0.0, 1 },     -- Red (for bleeds)
}

-- Simulated data for unit frames
local SIMULATED_UNITS = {
    player = { name = "Simulated Player", class = "WARRIOR", health = 85000, maxHealth = 100000, power = 80, maxPower = 100, powerType = 1, level = 80, role = "TANK" },
    target = { name = "Target Dummy", class = "MAGE", health = 45000, maxHealth = 100000, power = 12000, maxPower = 20000, powerType = 0, level = 80, role = "DAMAGER" },
    focus = { name = "Focus Target", class = "PRIEST", health = 72000, maxHealth = 90000, power = 45000, maxPower = 60000, powerType = 0, level = 80, role = "HEALER" },
    targettarget = { name = "ToT Unit", class = "ROGUE", health = 30000, maxHealth = 50000, power = 100, maxPower = 100, powerType = 3, level = 79, role = "DAMAGER" },
    pet = { name = "Pet", class = "HUNTER", health = 25000, maxHealth = 40000, power = 100, maxPower = 100, powerType = 2, level = 80, role = "NONE" },
    party1 = { name = "Party Tank", class = "PALADIN", health = 95000, maxHealth = 100000, power = 30000, maxPower = 50000, powerType = 0, level = 80, role = "TANK", debuffType = nil },
    party2 = { name = "Party Healer", class = "DRUID", health = 60000, maxHealth = 85000, power = 70000, maxPower = 80000, powerType = 0, level = 80, role = "HEALER", debuffType = "Magic" },
    party3 = { name = "Party DPS", class = "SHAMAN", health = 40000, maxHealth = 75000, power = 35000, maxPower = 60000, powerType = 0, level = 80, role = "DAMAGER", debuffType = "Poison" },
    party4 = { name = "Party Rogue", class = "ROGUE", health = 88000, maxHealth = 110000, power = 100, maxPower = 100, powerType = 3, level = 80, role = "DAMAGER", debuffType = "Curse" },
}

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

local function AbbreviateNumber(value)
    -- Use Blizzard's AbbreviateLargeNumbers if available (handles secret values)
    if AbbreviateLargeNumbers then
        return AbbreviateLargeNumbers(value) or "0"
    end
    
    -- Fallback with pcall
    local success, result = pcall(function()
        local v = value + 0
        if v >= 1000000000 then
            return string.format("%.1fB", v / 1000000000)
        elseif v >= 1000000 then
            return string.format("%.1fM", v / 1000000)
        elseif v >= 10000 then
            return string.format("%.1fK", v / 1000)
        else
            return tostring(math.floor(v))
        end
    end)
    return success and result or "0"
end

local function FormatNumber(value)
    -- Use Blizzard's BreakUpLargeNumbers if available (handles secret values)
    if BreakUpLargeNumbers then
        return BreakUpLargeNumbers(value) or "0"
    end
    
    -- Fallback with pcall
    local success, result = pcall(function()
        local v = value + 0
        local formatted = tostring(math.floor(v))
        while true do
            formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", "%1,%2")
            if k == 0 then break end
        end
        return formatted
    end)
    return success and result or "0"
end

local function GetClassColor(unit)
    if not UnitExists(unit) then return 0.5, 0.5, 0.5 end
    
    -- For pets, use owner's class color
    if unit == "pet" or unit == "playerpet" then
        local _, playerClass = UnitClass("player")
        if type(playerClass) == "string" and playerClass ~= "" then
            local color = RAID_CLASS_COLORS[playerClass]
            if color then return color.r, color.g, color.b end
        end
    end
    
    local isPlayer = UnitIsPlayer(unit)
    if type(isPlayer) == "boolean" and isPlayer then
        local _, class = UnitClass(unit)
        if type(class) == "string" and class ~= "" then
            local color = RAID_CLASS_COLORS[class]
            if color then return color.r, color.g, color.b end
        end
    end
    
    return 0.5, 0.5, 0.5
end

local function GetReactionColor(unit)
    if not UnitExists(unit) then return 0.5, 0.5, 0.5 end
    
    local isPlayer = UnitIsPlayer(unit)
    if type(isPlayer) == "boolean" and isPlayer then
        return GetClassColor(unit)
    end
    
    local reaction = UnitReaction(unit, "player")
    if type(reaction) ~= "number" then return 0.5, 0.5, 0.5 end
    
    if reaction <= 2 then
        return 1, 0, 0
    elseif reaction == 3 then
        return 1, 0.5, 0
    elseif reaction == 4 then
        return 1, 1, 0
    else
        return 0, 1, 0
    end
end

local function GetHealthGradientColor(percent)
    -- Ensure percent is a valid number
    if type(percent) ~= "number" then percent = 0 end
    
    if percent > 0.5 then
        local factor = (percent - 0.5) * 2
        return 1 - factor, 1, 0
    else
        local factor = percent * 2
        return 1, factor, 0
    end
end

local function GetPowerColor(unit)
    if not UnitExists(unit) then return 0.5, 0.5, 0.5 end
    
    local powerType = UnitPowerType(unit)
    if type(powerType) == "number" and POWER_COLORS[powerType] then
        return unpack(POWER_COLORS[powerType])
    end
    
    return 0, 0.5, 1
end

local function FormatHealthText(current, max, percent, format, abbreviate)
    if format == "none" then return "" end
    
    -- Use pre-calculated percent if provided, otherwise try to calculate
    if type(percent) ~= "number" then percent = 0 end
    
    -- For formats that need raw values, pass them through AbbreviateNumber/FormatNumber
    -- Those functions use pcall internally to handle secret values
    local formatNum = abbreviate and AbbreviateNumber or FormatNumber
    
    if format == "current" then
        return formatNum(current)
    elseif format == "max" then
        return formatNum(max)
    elseif format == "percent" then
        return string.format("%.0f%%", percent)
    elseif format == "current_max" then
        return string.format("%s / %s", formatNum(current), formatNum(max))
    elseif format == "current_percent" then
        return string.format("%s - %.0f%%", formatNum(current), percent)
    elseif format == "percent_current" then
        return string.format("%.0f%% - %s", percent, formatNum(current))
    elseif format == "deficit" then
        -- Deficit requires arithmetic, use pcall
        local success, result = pcall(function()
            local deficit = max - current
            if deficit > 0 then
                return string.format("-%s", formatNum(deficit))
            end
            return ""
        end)
        return success and result or ""
    end
    
    return formatNum(current)
end

local function GetClassificationString(unit)
    if not UnitExists(unit) then return "" end
    
    local classification = UnitClassification(unit)
    if type(classification) ~= "string" then return "" end
    
    if classification == "worldboss" then
        return "|cffFF0000Boss|r "
    elseif classification == "rareelite" then
        return "|cffFF66FFRare+|r "
    elseif classification == "elite" then
        return "|cffFFCC00+|r"
    elseif classification == "rare" then
        return "|cffFF66FFRare|r "
    end
    
    return ""
end

-- ============================================================================
-- BLIZZARD FRAME MASKING
-- ============================================================================

local function MaskBlizzardFrame(unit)
    local frameFunc = BLIZZARD_FRAMES[unit]
    if not frameFunc then return end
    
    local frame = frameFunc()
    if not frame then return end
    if blizzardFramesMasked[unit] then return end
    
    blizzardFramesMasked[unit] = {
        originalAlpha = frame:GetAlpha(),
    }
    
    frame:SetAlpha(0)
    
    -- Also hide Edit Mode selection if it exists
    if frame.Selection then
        frame.Selection:Hide()
    end
    
    -- Hook to maintain alpha and keep Edit Mode selection hidden
    if not frame._tweaksUIAlphaHook then
        hooksecurefunc(frame, "Show", function(self)
            if blizzardFramesMasked[unit] then
                self:SetAlpha(0)
                if self.Selection then
                    self.Selection:Hide()
                end
            end
        end)
        frame._tweaksUIAlphaHook = true
    end
end

local function UnmaskBlizzardFrame(unit)
    local frameFunc = BLIZZARD_FRAMES[unit]
    if not frameFunc then return end
    
    local frame = frameFunc()
    if not frame then return end
    if not blizzardFramesMasked[unit] then return end
    
    local data = blizzardFramesMasked[unit]
    frame:SetAlpha(data.originalAlpha or 1)
    blizzardFramesMasked[unit] = nil
end

-- Hidden frame for reparenting Edit Mode elements
local hiddenFrame = nil
local function GetHiddenFrame()
    if not hiddenFrame then
        hiddenFrame = CreateFrame("Frame")
        hiddenFrame:Hide()
    end
    return hiddenFrame
end

-- Hide Blizzard's cast bars when custom cast bars are enabled
local function HideBlizzardCastBars()
    if blizzardCastBarHidden then return end
    
    -- Player cast bar
    if PlayerCastingBarFrame then
        PlayerCastingBarFrame:SetAlpha(0)
        if not PlayerCastingBarFrame._tweaksUICastHook then
            hooksecurefunc(PlayerCastingBarFrame, "Show", function(self)
                if blizzardCastBarHidden then
                    self:SetAlpha(0)
                end
            end)
            PlayerCastingBarFrame._tweaksUICastHook = true
        end
    end
    
    -- Pet cast bar
    if PetCastingBarFrame then
        PetCastingBarFrame:SetAlpha(0)
        if not PetCastingBarFrame._tweaksUICastHook then
            hooksecurefunc(PetCastingBarFrame, "Show", function(self)
                if blizzardCastBarHidden then
                    self:SetAlpha(0)
                end
            end)
            PetCastingBarFrame._tweaksUICastHook = true
        end
    end
    
    blizzardCastBarHidden = true
end

local function ShowBlizzardCastBars()
    if not blizzardCastBarHidden then return end
    
    if PlayerCastingBarFrame then
        PlayerCastingBarFrame:SetAlpha(1)
    end
    if PetCastingBarFrame then
        PetCastingBarFrame:SetAlpha(1)
    end
    
    blizzardCastBarHidden = false
end

-- Show a preview cast bar on a frame
local function ShowPreviewCastBar(frame, unitSettings)
    if not frame or not frame.castBar then return end
    if not unitSettings or not unitSettings.castBar then return end
    
    local cbs = unitSettings.castBar
    if not cbs.enabled then 
        frame.castBar:Hide()
        return 
    end
    
    -- Show simulated cast bar for preview
    frame.castBar:SetMinMaxValues(0, 3)
    frame.castBar:SetValue(1.5)
    if frame.castText then 
        if cbs.showSpellName then
            frame.castText:SetText("Preview Cast") 
            frame.castText:Show()
        else
            frame.castText:Hide()
        end
    end
    if frame.castTimer then 
        if cbs.showTimer then
            frame.castTimer:SetText("1.5") 
            frame.castTimer:Show()
        else
            frame.castTimer:Hide()
        end
    end
    if frame.castIcon then 
        if cbs.showIcon then
            frame.castIcon:SetTexture("Interface\\Icons\\Spell_Nature_Heal")
            frame.castIcon:Show()
        else
            frame.castIcon:Hide()
        end
    end
    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
    frame.castBar:Show()
end

-- Hide preview cast bar
local function HidePreviewCastBar(frame)
    if not frame or not frame.castBar then return end
    frame.castBar:Hide()
end

-- Check if any custom cast bar is enabled and update Blizzard cast bar visibility
local function UpdateBlizzardCastBarVisibility()
    local anyEnabled = false
    
    -- Check individual frames
    for _, unit in ipairs({"player", "target", "focus", "pet", "targettarget"}) do
        if settings[unit] and settings[unit].enabled and 
           settings[unit].castBar and settings[unit].castBar.enabled then
            anyEnabled = true
            break
        end
    end
    
    if anyEnabled then
        HideBlizzardCastBars()
    else
        ShowBlizzardCastBars()
    end
end

-- Map unit to Blizzard frame names and Edit Mode system enums
local UNIT_FRAME_INFO = {
    player = {
        frameName = "PlayerFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PlayerFrame,
    },
    target = {
        frameName = "TargetFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.TargetFrame,
    },
    focus = {
        frameName = "FocusFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.FocusFrame,
    },
    pet = {
        frameName = "PetFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PetFrame,
    },
    targettarget = {
        frameName = "TargetFrameToT",
        system = nil, -- ToT doesn't have its own system enum
    },
    party1 = {
        frameName = "PartyFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PartyFrame,
    },
    party2 = {
        frameName = "PartyFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PartyFrame,
    },
    party3 = {
        frameName = "PartyFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PartyFrame,
    },
    party4 = {
        frameName = "PartyFrame",
        system = Enum.EditModeSystem and Enum.EditModeSystem.PartyFrame,
    },
}

local editModeHooked = false
local editModeHiddenUnits = {}

local function HideUnitFrameFromEditMode(unit)
    local hidden = GetHiddenFrame()
    local info = UNIT_FRAME_INFO[unit]
    if not info then return end
    
    -- Method 1: Hide the Selection overlay directly on the Blizzard frame
    local blizzFrame = _G[info.frameName]
    if blizzFrame then
        if blizzFrame.Selection and type(blizzFrame.Selection) == "table" then
            blizzFrame.Selection:Hide()
            blizzFrame.Selection:SetParent(hidden)
        end
        -- Also check for HighlightSystem (used in some Edit Mode implementations)
        -- Must verify it's a table/frame, not a function
        if blizzFrame.HighlightSystem and type(blizzFrame.HighlightSystem) == "table" and blizzFrame.HighlightSystem.Hide then
            blizzFrame.HighlightSystem:Hide()
        end
    end
    
    -- Method 2: Search through EditModeManagerFrame's registered systems
    if EditModeManagerFrame and EditModeManagerFrame.registeredSystemFrames then
        for _, frame in ipairs(EditModeManagerFrame.registeredSystemFrames) do
            if frame and type(frame) == "table" then
                local shouldHide = false
                
                -- Check by system enum
                if info.system and frame.system == info.system then
                    shouldHide = true
                end
                
                -- Check by frame name
                if frame.GetName then
                    local name = frame:GetName() or ""
                    if name == info.frameName or name:find(info.frameName) then
                        shouldHide = true
                    end
                end
                
                -- Check if frame matches directly
                if frame == blizzFrame then
                    shouldHide = true
                end
                
                if shouldHide then
                    -- Hide the selection overlay
                    if frame.Selection and type(frame.Selection) == "table" then
                        frame.Selection:Hide()
                        frame.Selection:SetParent(hidden)
                    end
                    -- Hide highlight (verify it's a table/frame first)
                    if frame.HighlightSystem and type(frame.HighlightSystem) == "table" and frame.HighlightSystem.Hide then
                        frame.HighlightSystem:Hide()
                    end
                end
            end
        end
    end
    
    editModeHiddenUnits[unit] = true
end

local function HideAllCustomUnitFramesFromEditMode()
    for unit, _ in pairs(customFrames) do
        if settings[unit] and settings[unit].enabled then
            HideUnitFrameFromEditMode(unit)
        end
    end
end

-- Setup Edit Mode callbacks via centralized EditModeManager
local function SetupEditModeCallbacks()
    if editModeHooked then 
        return 
    end
    
    if not TweaksUI.EditMode then
        TweaksUI:PrintDebug("SetupEditModeCallbacks: EditModeManager not available")
        return
    end
    
    TweaksUI:PrintDebug("SetupEditModeCallbacks: Registering callbacks")
    
    -- Register for Edit Mode enter
    TweaksUI.EditMode:RegisterCallback("enter", function()
        TweaksUI:PrintDebug("UnitFrames: Edit Mode entered (via EditModeManager)")
        HideAllCustomUnitFramesFromEditMode()
        C_Timer.After(0.1, HideAllCustomUnitFramesFromEditMode)
        C_Timer.After(0.3, HideAllCustomUnitFramesFromEditMode)
        
        -- Show party/raid containers for positioning
        UnitFrames:ShowContainersForEditMode()
    end)
    
    -- Register for Edit Mode exit
    TweaksUI.EditMode:RegisterCallback("exit", function()
        TweaksUI:PrintDebug("UnitFrames: Edit Mode exited (via EditModeManager)")
        UnitFrames:HideContainersAfterEditMode()
    end)
    
    -- Hook the individual Blizzard unit frames' SetShown to keep selections hidden
    -- These hooks are UnitFrames-specific and don't go through EditModeManager
    for unit, info in pairs(UNIT_FRAME_INFO) do
        local blizzFrame = _G[info.frameName]
        if blizzFrame and not blizzFrame._tweaksEditModeHook then
            -- Hook the selection's Show method if it exists
            if blizzFrame.Selection then
                hooksecurefunc(blizzFrame.Selection, "Show", function(self)
                    if blizzardFramesMasked[unit] then
                        self:Hide()
                    end
                end)
            end
            blizzFrame._tweaksEditModeHook = true
        end
    end
    
    editModeHooked = true
end

-- Show party/raid containers during Edit Mode for positioning
-- This shows them regardless of enabled state so you can position before enabling
function UnitFrames:ShowContainersForEditMode()
    if InCombatLockdown() then return end
    
    TweaksUI:PrintDebug("ShowContainersForEditMode called")
    
    -- Always enable simulation when showing for Edit Mode
    simulationMode = true
    simulateRaidSmall = true
    simulateRaidLarge = true
    simulateTanks = true
    simulateBoss = true
    
    -- Party container - create and show if party settings exist
    if settings.party then
        TweaksUI:PrintDebug("Party settings exist, partyContainer: " .. tostring(partyContainer))
        if not partyContainer then
            self:CreatePartyContainer()
            TweaksUI:PrintDebug("Created party container: " .. tostring(partyContainer))
        end
        if partyContainer then
            partyContainer:Show()
            TweaksUI:PrintDebug("Party container shown, alpha: " .. partyContainer:GetAlpha())
            self:UpdatePartyFrames()
            self:RegisterContainerWithEditMode("party")
        end
    end
    
    -- Raid containers - create and show BOTH small and large for Edit Mode positioning
    if settings.raid then
        TweaksUI:PrintDebug("Raid settings exist")
        
        -- Small raid container
        if not raidSmallContainer then
            self:CreateRaidContainer("small")
            TweaksUI:PrintDebug("Created small raid container: " .. tostring(raidSmallContainer))
        end
        if raidSmallContainer then
            raidSmallContainer:Show()
            TweaksUI:PrintDebug("Small raid container shown")
            self:RegisterContainerWithEditMode("raid_small")
        end
        
        -- Large raid container
        if not raidLargeContainer then
            self:CreateRaidContainer("large")
            TweaksUI:PrintDebug("Created large raid container: " .. tostring(raidLargeContainer))
        end
        if raidLargeContainer then
            raidLargeContainer:Show()
            TweaksUI:PrintDebug("Large raid container shown")
            self:RegisterContainerWithEditMode("raid_large")
        end
        
        -- Update both layouts
        self:UpdateRaidFrames()
    end
    
    -- Tank container
    if settings.tanks then
        if not tankContainer then
            self:CreateTankContainer()
        end
        if tankContainer then
            tankContainer:Show()
            self:UpdateTankFrames()
            self:RegisterContainerWithEditMode("tanks")
        end
    end
    
    -- Boss container
    if settings.boss then
        if not bossContainer then
            self:CreateBossContainer()
        end
        if bossContainer then
            bossContainer:Show()
            self:UpdateBossFrames()
            self:RegisterContainerWithEditMode("boss")
        end
    end
end

-- Hide containers after Edit Mode if not actually in a group
function UnitFrames:HideContainersAfterEditMode()
    if InCombatLockdown() then return end
    
    -- Turn off all simulation modes
    simulationMode = false
    simulateRaidSmall = false
    simulateRaidLarge = false
    simulateTanks = false
    simulateBoss = false
    
    -- Party container - hide if not in a party
    if partyContainer and not IsInGroup() then
        partyContainer:Hide()
    elseif partyContainer then
        self:UpdatePartyFrames()
    end
    
    -- Raid containers - hide if not in a raid
    if not IsInRaid() then
        if raidSmallContainer then raidSmallContainer:Hide() end
        if raidLargeContainer then raidLargeContainer:Hide() end
    else
        self:UpdateRaidFrames()
    end
    
    -- Tank container - hide if no real tanks
    if tankContainer then
        local hasTanks = false
        if IsInGroup() then
            for i = 1, GetNumGroupMembers() do
                local unit = IsInRaid() and "raid"..i or "party"..i
                if UnitExists(unit) then
                    local role = UnitGroupRolesAssigned(unit)
                    if role == "TANK" then
                        hasTanks = true
                        break
                    end
                end
            end
        end
        if not hasTanks then
            tankContainer:Hide()
        else
            self:UpdateTankFrames()
        end
    end
    
    -- Boss container - hide if no real bosses
    if bossContainer then
        local hasBoss = false
        for i = 1, 5 do
            if UnitExists("boss" .. i) then
                hasBoss = true
                break
            end
        end
        if not hasBoss then
            bossContainer:Hide()
        else
            self:UpdateBossFrames()
        end
    end
    
    -- Update individual frames with real data (deferred to ensure method is available)
    local module = self
    C_Timer.After(0.1, function()
        for _, unit in ipairs(INDIVIDUAL_UNITS) do
            if customFrames[unit] and module.RefreshFrame then
                pcall(function() module:RefreshFrame(unit) end)
            end
        end
    end)
end

-- Register a container with centralized EditModeManager
function UnitFrames:RegisterContainerWithEditMode(containerType)
    TweaksUI:PrintDebug("RegisterContainerWithEditMode: " .. containerType)
    
    -- Use centralized EditModeManager
    if not TweaksUI.EditMode then 
        TweaksUI:PrintDebug("RegisterContainerWithEditMode: EditModeManager not available")
        return 
    end
    
    local container, containerSettings
    if containerType == "party" then
        container = partyContainer
        containerSettings = settings.party and settings.party.container
    elseif containerType == "raid_small" then
        container = raidSmallContainer
        containerSettings = settings.raid and settings.raid.small and settings.raid.small.container
    elseif containerType == "raid_large" then
        container = raidLargeContainer
        containerSettings = settings.raid and settings.raid.large and settings.raid.large.container
    elseif containerType == "tanks" then
        container = tankContainer
        containerSettings = settings.tanks and settings.tanks.container
    elseif containerType == "boss" then
        container = bossContainer
        containerSettings = settings.boss and settings.boss.container
    end
    
    if not container or not containerSettings then 
        TweaksUI:PrintDebug("RegisterContainerWithEditMode: container or settings nil")
        return 
    end
    
    -- Check if already registered
    if container._editModeRegistered then 
        TweaksUI:PrintDebug("RegisterContainerWithEditMode: already registered")
        return 
    end
    
    local function OnPositionChanged(movedFrame, point, x, y)
        containerSettings.anchor = point
        containerSettings.x = x
        containerSettings.y = y
        TweaksUI:PrintDebug("Container " .. containerType .. " moved to " .. x .. ", " .. y)
    end
    
    TweaksUI:PrintDebug("RegisterContainerWithEditMode: Adding frame to EditModeManager")
    TweaksUI.EditMode:RegisterFrame(container, {
        name = "TweaksUI: " .. containerType:gsub("_", " "):gsub("^%l", string.upper) .. " Container",
        onPositionChanged = OnPositionChanged,
        default = {
            point = containerSettings.anchor or "CENTER",
            x = containerSettings.x or 0,
            y = containerSettings.y or 0,
        },
    })
    
    container._editModeRegistered = true
    TweaksUI:PrintDebug("RegisterContainerWithEditMode: " .. containerType .. " registered successfully")
end

-- ============================================================================
-- CUSTOM FRAME CREATION
-- ============================================================================

local function CreateCustomUnitFrame(unit)
    if customFrames[unit] then return customFrames[unit] end
    
    local unitSettings = settings[unit]
    if not unitSettings then return nil end
    
    local frameName = "TweaksUI_UF_" .. unit
    
    -- Main container frame (secure for click-through)
    local frame = CreateFrame("Button", frameName, UIParent, "SecureUnitButtonTemplate,BackdropTemplate")
    frame.unit = unit
    frame:SetAttribute("unit", unit)
    frame:SetAttribute("*type1", "target")
    frame:SetAttribute("*type2", "togglemenu")
    frame:RegisterForClicks("AnyUp")
    
    frame:SetBackdrop(frameBackdrop)
    frame:SetFrameStrata("LOW")
    frame:SetFrameLevel(10)
    
    -- Health Bar
    frame.healthBar = CreateFrame("StatusBar", frameName .. "_Health", frame)
    frame.healthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    frame.healthBar:SetMinMaxValues(0, 1)
    frame.healthBar:SetValue(1)
    frame.healthBar:SetFrameLevel(frame:GetFrameLevel() + 1)
    
    frame.healthBar.bg = frame.healthBar:CreateTexture(nil, "BACKGROUND")
    frame.healthBar.bg:SetAllPoints()
    frame.healthBar.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    
    -- Power Bar
    frame.powerBar = CreateFrame("StatusBar", frameName .. "_Power", frame)
    frame.powerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    frame.powerBar:SetMinMaxValues(0, 1)
    frame.powerBar:SetValue(1)
    frame.powerBar:SetFrameLevel(frame:GetFrameLevel() + 1)
    
    frame.powerBar.bg = frame.powerBar:CreateTexture(nil, "BACKGROUND")
    frame.powerBar.bg:SetAllPoints()
    frame.powerBar.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    
    -- Text overlay frame (ensures all text is above bars and portrait)
    frame.textOverlay = CreateFrame("Frame", frameName .. "_TextOverlay", frame)
    frame.textOverlay:SetAllPoints()
    frame.textOverlay:SetFrameLevel(frame:GetFrameLevel() + 10)
    
    -- Health Text (on overlay, positioned relative to health bar)
    frame.healthText = frame.textOverlay:CreateFontString(nil, "OVERLAY")
    frame.healthText:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    
    -- Power Text (on overlay, positioned relative to power bar)
    frame.powerText = frame.textOverlay:CreateFontString(nil, "OVERLAY")
    frame.powerText:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
    
    -- Name Text (on overlay)
    frame.nameText = frame.textOverlay:CreateFontString(nil, "OVERLAY")
    frame.nameText:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    
    -- Level Text (on overlay)
    frame.levelText = frame.textOverlay:CreateFontString(nil, "OVERLAY")
    frame.levelText:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    
    -- Portrait container
    frame.portraitFrame = CreateFrame("Frame", frameName .. "_Portrait", frame)
    frame.portraitFrame:SetFrameLevel(frame:GetFrameLevel() + 2)
    
    -- 3D Portrait
    frame.portrait3D = CreateFrame("PlayerModel", frameName .. "_Portrait3D", frame.portraitFrame)
    frame.portrait3D:SetAllPoints()
    
    -- 2D Portrait
    frame.portrait2D = frame.portraitFrame:CreateTexture(nil, "ARTWORK")
    frame.portrait2D:SetAllPoints()
    
    -- Class Icon
    frame.classIcon = frame.portraitFrame:CreateTexture(nil, "ARTWORK")
    frame.classIcon:SetAllPoints()
    
    -- Portrait backdrop
    frame.portraitFrame.bg = frame.portraitFrame:CreateTexture(nil, "BACKGROUND")
    frame.portraitFrame.bg:SetAllPoints()
    frame.portraitFrame.bg:SetColorTexture(0, 0, 0, 0.8)
    
    -- Raid Target Icon
    frame.raidTarget = frame:CreateTexture(nil, "OVERLAY")
    frame.raidTarget:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
    
    -- Role Icon (Tank/Healer/DPS)
    frame.roleIcon = frame:CreateTexture(nil, "OVERLAY")
    frame.roleIcon:SetSize(18, 18)
    frame.roleIcon:Hide()
    
    -- Debuff Indicators container
    frame.debuffIndicators = CreateFrame("Frame", frameName .. "_DebuffIndicators", frame)
    frame.debuffIndicators:SetFrameLevel(frame:GetFrameLevel() + 15)
    frame.debuffIndicators:SetSize(60, 14)
    
    -- Create individual debuff type indicators
    frame.debuffIndicators.indicators = {}
    local debuffTypes = { "Magic", "Curse", "Disease", "Poison", "Bleed" }
    for i, debuffType in ipairs(debuffTypes) do
        local indicator = CreateFrame("Frame", nil, frame.debuffIndicators, "BackdropTemplate")
        indicator:SetSize(12, 12)
        indicator:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        indicator.debuffType = debuffType
        indicator.color = DEBUFF_TYPE_COLORS[debuffType]
        indicator:SetBackdropColor(unpack(indicator.color))
        indicator:SetBackdropBorderColor(0, 0, 0, 1)
        indicator:Hide()
        
        -- Icon texture (optional - shows spell icon if we want)
        indicator.icon = indicator:CreateTexture(nil, "ARTWORK")
        indicator.icon:SetAllPoints()
        indicator.icon:SetTexture("Interface\\Buttons\\WHITE8X8")
        indicator.icon:SetVertexColor(unpack(indicator.color))
        
        frame.debuffIndicators.indicators[debuffType] = indicator
    end
    
    -- Cast Bar
    local castBar = CreateFrame("StatusBar", frameName .. "_CastBar", frame)
    castBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
    castBar:SetStatusBarColor(1, 0.7, 0, 1)
    castBar:SetMinMaxValues(0, 1)
    castBar:SetValue(0)
    castBar:SetFrameLevel(frame:GetFrameLevel() + 5)
    castBar:Hide()
    frame.castBar = castBar
    
    local castBg = castBar:CreateTexture(nil, "BACKGROUND")
    castBg:SetAllPoints()
    castBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
    
    local castText = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    castText:SetPoint("LEFT", castBar, "LEFT", 2, 0)
    frame.castText = castText
    
    local castIcon = castBar:CreateTexture(nil, "OVERLAY")
    castIcon:SetSize(12, 12)
    castIcon:SetPoint("LEFT", castBar, "LEFT", 1, 0)
    frame.castIcon = castIcon
    
    local castTimer = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    castTimer:SetPoint("RIGHT", castBar, "RIGHT", -2, 0)
    frame.castTimer = castTimer
    
    -- OnUpdate for smooth cast bar animation
    castBar:SetScript("OnUpdate", function(self, elapsed)
        if not self:IsShown() then return end
        if not frame.unit then return end
        
        local unitSettings = settings[frame.unit]
        if not unitSettings or not unitSettings.castBar or not unitSettings.castBar.enabled then
            self:Hide()
            return
        end
        
        local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(frame.unit)
        local isChannel = false
        if not SafeValue(castName) then
            castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(frame.unit)
            isChannel = true
        end
        
        local safeCastName = SafeValue(castName)
        local safeStartTime = SafeValue(startTime)
        local safeEndTime = SafeValue(endTime)
        
        if safeCastName and safeStartTime and safeEndTime then
            local duration = (safeEndTime - safeStartTime) / 1000
            local elapsedTime = (GetTime() * 1000 - safeStartTime) / 1000
            
            if isChannel then
                -- Channels count down
                self:SetValue(duration - elapsedTime)
            else
                self:SetValue(elapsedTime)
            end
            
            if frame.castTimer and unitSettings.castBar.showTimer then
                local remaining = duration - elapsedTime
                frame.castTimer:SetText(string.format("%.1f", remaining > 0 and remaining or 0))
            end
        else
            -- Don't hide if we're in preview mode (panel is open)
            if currentOpenPanel ~= frame.unit then
                self:Hide()
            end
        end
    end)
    
    -- Highlight
    frame.highlight = frame:CreateTexture(nil, "HIGHLIGHT")
    frame.highlight:SetAllPoints()
    frame.highlight:SetTexture("Interface\\Buttons\\WHITE8X8")
    frame.highlight:SetVertexColor(1, 1, 1, 0.08)
    frame.highlight:SetBlendMode("ADD")
    
    -- Custom tooltip to avoid secret value errors with SetUnit
    frame:SetScript("OnEnter", function(self)
        if not UnitExists(self.unit) then return end
        
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT")
        
        -- Get basic unit info safely
        local name = UnitName(self.unit) or "Unknown"
        local _, class = UnitClass(self.unit)
        local level = UnitLevel(self.unit) or "??"
        local isPlayer = UnitIsPlayer(self.unit)
        
        -- Name with class color for players
        if isPlayer and class then
            local classColor = RAID_CLASS_COLORS[class]
            if classColor then
                GameTooltip:AddLine(name, classColor.r, classColor.g, classColor.b)
            else
                GameTooltip:AddLine(name, 1, 1, 1)
            end
        else
            -- For NPCs, color by reaction
            local r, g, b = 1, 1, 1
            if UnitIsEnemy("player", self.unit) then
                r, g, b = 1, 0.2, 0.2
            elseif UnitIsFriend("player", self.unit) then
                r, g, b = 0.2, 1, 0.2
            else
                r, g, b = 1, 1, 0
            end
            GameTooltip:AddLine(name, r, g, b)
        end
        
        -- Level and class/type info
        if isPlayer then
            local classDisplayName = class and UnitClass(self.unit) or "Unknown"
            GameTooltip:AddLine("Level " .. level .. " " .. classDisplayName, 0.7, 0.7, 0.7)
            
            -- Role for group members
            local role = UnitGroupRolesAssigned(self.unit)
            if role and role ~= "NONE" then
                local roleNames = {TANK = "Tank", HEALER = "Healer", DAMAGER = "Damage"}
                GameTooltip:AddLine(roleNames[role] or role, 0.5, 0.5, 0.5)
            end
        else
            -- For NPCs, show creature type
            local creatureType = UnitCreatureType(self.unit) or ""
            if level == -1 then
                GameTooltip:AddLine("Boss " .. creatureType, 0.7, 0.7, 0.7)
            else
                GameTooltip:AddLine("Level " .. level .. " " .. creatureType, 0.7, 0.7, 0.7)
            end
        end
        
        GameTooltip:Show()
    end)
    
    frame:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    
    -- Register state driver for combat-safe visibility based on unit existence
    -- This allows the frame to show/hide during combat without taint
    local stateCondition
    if unit == "player" then
        -- Player frame should always show when enabled
        stateCondition = "show"
    elseif unit == "target" then
        stateCondition = "[@target,exists] show; hide"
    elseif unit == "focus" then
        stateCondition = "[@focus,exists] show; hide"
    elseif unit == "targettarget" then
        stateCondition = "[@targettarget,exists] show; hide"
    elseif unit == "pet" then
        stateCondition = "[@pet,exists] show; hide"
    else
        -- Default: just show
        stateCondition = "show"
    end
    
    RegisterStateDriver(frame, "visibility", stateCondition)
    frame._stateDriverRegistered = true
    
    customFrames[unit] = frame
    
    return frame
end

-- ============================================================================
-- UPDATE FRAME LAYOUT
-- ============================================================================

-- Calculate frame dimensions based on enabled elements
local function CalculateFrameSize(unit)
    local unitSettings = settings[unit]
    if not unitSettings then return 220, 46 end
    
    local fs = unitSettings.frame
    local hbs = unitSettings.healthBar
    local pbs = unitSettings.powerBar
    local ps = unitSettings.portrait
    
    local padding = fs.padding or 1
    local barSpacing = fs.barSpacing or 1
    local bgExtendTop = fs.bgExtendTop or 0
    local bgExtendBottom = fs.bgExtendBottom or 0
    
    -- Calculate height based on enabled bars
    local barsHeight = 0
    
    if hbs.enabled then
        barsHeight = barsHeight + hbs.height
    end
    
    if pbs.enabled then
        if barsHeight > 0 then
            barsHeight = barsHeight + barSpacing
        end
        barsHeight = barsHeight + pbs.height
    end
    
    -- Height is bars + padding + background extensions
    local height = barsHeight + (padding * 2) + bgExtendTop + bgExtendBottom
    
    -- If portrait is enabled and taller than content, use portrait height
    if ps.mode ~= "none" then
        local portraitHeight = ps.size + (padding * 2) + bgExtendTop + bgExtendBottom
        height = math.max(height, portraitHeight)
    end
    
    -- Calculate width (use user-set width)
    local width = fs.width or 220
    
    -- Minimum sizes
    height = math.max(height, 10)
    width = math.max(width, 50)
    
    return width, height
end

local function UpdateFrameLayout(unit)
    local frame = customFrames[unit]
    if not frame then return end
    
    local unitSettings = settings[unit]
    if not unitSettings then return end
    
    local fs = unitSettings.frame
    local hbs = unitSettings.healthBar
    local pbs = unitSettings.powerBar
    local ps = unitSettings.portrait
    
    local padding = fs.padding or 1
    local barSpacing = fs.barSpacing or 1
    
    -- Calculate frame size if autoSize is enabled
    local frameWidth, frameHeight
    if fs.autoSize then
        frameWidth, frameHeight = CalculateFrameSize(unit)
    else
        frameWidth = fs.width
        frameHeight = fs.height
    end
    
    -- Frame size and position
    frame:SetSize(frameWidth, frameHeight)
    frame:ClearAllPoints()
    frame:SetPoint(fs.anchor, UIParent, fs.anchor, fs.x, fs.y)
    frame:SetScale(fs.scale or 1.0)
    
    -- Frame backdrop appearance
    if fs.showBackground or fs.showBorder then
        local backdrop = {
            bgFile = fs.showBackground and "Interface\\Buttons\\WHITE8X8" or nil,
            edgeFile = fs.showBorder and "Interface\\Buttons\\WHITE8X8" or nil,
            edgeSize = fs.showBorder and (fs.borderSize or 1) or 0,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        }
        frame:SetBackdrop(backdrop)
        
        if fs.showBackground then
            frame:SetBackdropColor(unpack(fs.bgColor))
        end
        if fs.showBorder then
            frame:SetBackdropBorderColor(unpack(fs.borderColor))
        end
    else
        -- No background or border - invisible frame
        frame:SetBackdrop(nil)
    end
    
    -- Calculate portrait offset (only if portrait is inside the frame)
    local portraitWidth = 0
    local portraitOffsetLeft = 0
    local portraitOffsetRight = 0
    local bgExtendTop = fs.bgExtendTop or 0
    
    if ps.mode ~= "none" and not ps.outside then
        -- Portrait is inside the frame, reserve space for it
        portraitWidth = ps.size
        if ps.position == "left" then
            portraitOffsetLeft = portraitWidth + barSpacing
        else
            portraitOffsetRight = portraitWidth + barSpacing
        end
    end
    
    -- Health Bar layout (offset by bgExtendTop)
    if hbs.enabled then
        frame.healthBar:Show()
        frame.healthBar:ClearAllPoints()
        frame.healthBar:SetPoint("TOPLEFT", frame, "TOPLEFT", padding + portraitOffsetLeft, -padding - bgExtendTop)
        frame.healthBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -padding - portraitOffsetRight, -padding - bgExtendTop)
        frame.healthBar:SetHeight(hbs.height)
        
        local texturePath = "Interface\\TargetingFrame\\UI-StatusBar"
        if LibSharedMedia and hbs.texture then
            texturePath = LibSharedMedia:Fetch("statusbar", hbs.texture) or texturePath
        end
        frame.healthBar:SetStatusBarTexture(texturePath)
        frame.healthBar.bg:SetVertexColor(unpack(hbs.bgColor))
    else
        frame.healthBar:Hide()
    end
    
    -- Power Bar layout
    if pbs.enabled then
        frame.powerBar:Show()
        frame.powerBar:ClearAllPoints()
        frame.powerBar:SetPoint("TOPLEFT", frame.healthBar, "BOTTOMLEFT", 0, -barSpacing)
        frame.powerBar:SetPoint("TOPRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, -barSpacing)
        frame.powerBar:SetHeight(pbs.height)
        
        local texturePath = "Interface\\TargetingFrame\\UI-StatusBar"
        if LibSharedMedia and pbs.texture then
            texturePath = LibSharedMedia:Fetch("statusbar", pbs.texture) or texturePath
        end
        frame.powerBar:SetStatusBarTexture(texturePath)
        frame.powerBar.bg:SetVertexColor(unpack(pbs.bgColor))
    else
        frame.powerBar:Hide()
    end
    
    -- Helper function to convert hAlign + vAlign to anchor point
    local function GetAnchorFromAlign(hAlign, vAlign)
        hAlign = hAlign or "CENTER"
        vAlign = vAlign or "MIDDLE"
        
        if vAlign == "TOP" then
            if hAlign == "LEFT" then return "TOPLEFT"
            elseif hAlign == "RIGHT" then return "TOPRIGHT"
            else return "TOP" end
        elseif vAlign == "BOTTOM" then
            if hAlign == "LEFT" then return "BOTTOMLEFT"
            elseif hAlign == "RIGHT" then return "BOTTOMRIGHT"
            else return "BOTTOM" end
        else -- MIDDLE
            if hAlign == "LEFT" then return "LEFT"
            elseif hAlign == "RIGHT" then return "RIGHT"
            else return "CENTER" end
        end
    end
    
    -- Health Text layout
    local hts = unitSettings.healthText
    if hts.enabled and hts.format ~= "none" then
        frame.healthText:Show()
        frame.healthText:ClearAllPoints()
        local anchor = GetAnchorFromAlign(hts.hAlign, hts.vAlign)
        frame.healthText:SetPoint(anchor, frame.healthBar, anchor, hts.offsetX, hts.offsetY)
        frame.healthText:SetFont("Fonts\\FRIZQT__.TTF", hts.fontSize, hts.fontOutline)
        frame.healthText:SetTextColor(unpack(hts.color))
        frame.healthText:SetJustifyH(hts.hAlign or "CENTER")
        frame.healthText:SetJustifyV(hts.vAlign or "MIDDLE")
    else
        frame.healthText:Hide()
    end
    
    -- Power Text layout
    local pts = unitSettings.powerText
    if pts.enabled and pbs.enabled and pts.format ~= "none" then
        frame.powerText:Show()
        frame.powerText:ClearAllPoints()
        local anchor = GetAnchorFromAlign(pts.hAlign, pts.vAlign)
        frame.powerText:SetPoint(anchor, frame.powerBar, anchor, pts.offsetX, pts.offsetY)
        frame.powerText:SetFont("Fonts\\FRIZQT__.TTF", pts.fontSize, pts.fontOutline)
        frame.powerText:SetTextColor(unpack(pts.color))
        frame.powerText:SetJustifyH(pts.hAlign or "CENTER")
        frame.powerText:SetJustifyV(pts.vAlign or "MIDDLE")
    else
        frame.powerText:Hide()
    end
    
    -- Name Text layout
    local nts = unitSettings.nameText
    if nts.enabled then
        frame.nameText:Show()
        frame.nameText:ClearAllPoints()
        
        local hAlign = nts.hAlign or "CENTER"
        
        -- Check if we should anchor to health bar (for inside-frame positioning)
        if nts.anchorToHealthBar then
            -- Anchor to health bar like health text does
            local anchor = GetAnchorFromAlign(hAlign, nts.vAlign or "MIDDLE")
            frame.nameText:SetPoint(anchor, frame.healthBar, anchor, nts.offsetX, nts.offsetY)
        else
            -- Original behavior: anchor to frame edge
            local textAnchor = nts.frameAnchor
            
            -- Adjust text anchor based on hAlign
            if nts.frameAnchor == "TOP" then
                if hAlign == "LEFT" then textAnchor = "BOTTOMLEFT"
                elseif hAlign == "RIGHT" then textAnchor = "BOTTOMRIGHT"
                else textAnchor = "BOTTOM" end
            elseif nts.frameAnchor == "BOTTOM" then
                if hAlign == "LEFT" then textAnchor = "TOPLEFT"
                elseif hAlign == "RIGHT" then textAnchor = "TOPRIGHT"
                else textAnchor = "TOP" end
            elseif nts.frameAnchor == "LEFT" then
                textAnchor = "RIGHT"
            elseif nts.frameAnchor == "RIGHT" then
                textAnchor = "LEFT"
            else
                textAnchor = nts.frameAnchor -- CENTER, TOPLEFT, etc.
            end
            
            frame.nameText:SetPoint(textAnchor, frame, nts.frameAnchor, nts.offsetX, nts.offsetY)
        end
        
        frame.nameText:SetFont("Fonts\\FRIZQT__.TTF", nts.fontSize, nts.fontOutline)
        frame.nameText:SetJustifyH(hAlign)
        frame.nameText:SetJustifyV(nts.vAlign or "MIDDLE")
    else
        frame.nameText:Hide()
    end
    
    -- Level Text layout
    local lts = unitSettings.levelText
    if lts.enabled then
        frame.levelText:Show()
        frame.levelText:ClearAllPoints()
        -- Compute text anchor from frameAnchor and hAlign
        local textAnchor = lts.frameAnchor
        local hAlign = lts.hAlign or "CENTER"
        
        if lts.frameAnchor == "TOP" then
            if hAlign == "LEFT" then textAnchor = "BOTTOMLEFT"
            elseif hAlign == "RIGHT" then textAnchor = "BOTTOMRIGHT"
            else textAnchor = "BOTTOM" end
        elseif lts.frameAnchor == "BOTTOM" then
            if hAlign == "LEFT" then textAnchor = "TOPLEFT"
            elseif hAlign == "RIGHT" then textAnchor = "TOPRIGHT"
            else textAnchor = "TOP" end
        elseif lts.frameAnchor == "LEFT" then
            textAnchor = "RIGHT"
        elseif lts.frameAnchor == "RIGHT" then
            textAnchor = "LEFT"
        else
            textAnchor = lts.frameAnchor
        end
        
        frame.levelText:SetPoint(textAnchor, frame, lts.frameAnchor, lts.offsetX, lts.offsetY)
        frame.levelText:SetFont("Fonts\\FRIZQT__.TTF", lts.fontSize, lts.fontOutline)
        frame.levelText:SetJustifyH(hAlign)
        frame.levelText:SetJustifyV(lts.vAlign or "MIDDLE")
    else
        frame.levelText:Hide()
    end
    
    -- Portrait layout
    if ps.mode ~= "none" then
        frame.portraitFrame:Show()
        frame.portraitFrame:SetSize(ps.size, ps.size)
        frame.portraitFrame:ClearAllPoints()
        
        if ps.position == "left" then
            frame.portraitFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", padding + ps.offsetX, -padding - bgExtendTop + ps.offsetY)
        else
            frame.portraitFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -padding + ps.offsetX, -padding - bgExtendTop + ps.offsetY)
        end
        
        -- Show appropriate portrait type
        frame.portrait3D:Hide()
        frame.portrait2D:Hide()
        frame.classIcon:Hide()
        
        if ps.mode == "3d" then
            frame.portrait3D:Show()
        elseif ps.mode == "2d" then
            frame.portrait2D:Show()
        elseif ps.mode == "class" then
            frame.classIcon:Show()
        end
    else
        frame.portraitFrame:Hide()
    end
    
    -- Raid Target layout
    local rts = unitSettings.raidTarget
    if rts.enabled then
        frame.raidTarget:ClearAllPoints()
        frame.raidTarget:SetPoint(rts.anchor, frame, rts.frameAnchor, rts.offsetX, rts.offsetY)
        frame.raidTarget:SetSize(rts.size, rts.size)
    end
    
    -- Role Icon layout
    local ris = unitSettings.roleIcon
    if ris and ris.enabled then
        frame.roleIcon:ClearAllPoints()
        frame.roleIcon:SetPoint(ris.anchor, frame, ris.frameAnchor, ris.offsetX, ris.offsetY)
        frame.roleIcon:SetSize(ris.size, ris.size)
    end
    
    -- Debuff Indicators layout
    local dis = unitSettings.debuffIndicators
    if dis and dis.enabled then
        frame.debuffIndicators:Show()
        frame.debuffIndicators:ClearAllPoints()
        frame.debuffIndicators:SetPoint(dis.position, frame, dis.position, dis.offsetX, dis.offsetY)
        
        -- Size and position individual indicators
        local xOffset = 0
        for debuffType, indicator in pairs(frame.debuffIndicators.indicators) do
            indicator:SetSize(dis.size, dis.size)
            indicator:ClearAllPoints()
            indicator:SetPoint("LEFT", frame.debuffIndicators, "LEFT", xOffset, 0)
            
            -- Show/hide border
            if dis.showBorder then
                indicator:SetBackdropBorderColor(0, 0, 0, 1)
            else
                indicator:SetBackdropBorderColor(0, 0, 0, 0)
            end
            
            xOffset = xOffset + dis.size + 2
        end
        
        frame.debuffIndicators:SetSize(xOffset, dis.size)
    else
        frame.debuffIndicators:Hide()
    end
    
    -- Cast Bar layout
    local cbs = unitSettings.castBar
    if cbs and cbs.enabled and frame.castBar then
        local cbHeight = cbs.height or 12
        frame.castBar:ClearAllPoints()
        frame.castBar:SetHeight(cbHeight)
        
        if cbs.attachedTo == "health" then
            -- Inside the health bar
            frame.castBar:SetPoint("TOPLEFT", frame.healthBar, "TOPLEFT", 0, 0)
            frame.castBar:SetPoint("BOTTOMRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, 0)
        else
            -- Below the frame
            local offsetY = cbs.offsetY or 0
            frame.castBar:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", padding, -1 + offsetY)
            frame.castBar:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", -padding, -1 + offsetY)
        end
        
        -- Update cast bar elements visibility/position based on settings
        if frame.castIcon then
            if cbs.showIcon then
                frame.castIcon:SetSize(cbHeight, cbHeight)
                frame.castIcon:ClearAllPoints()
                frame.castIcon:SetPoint("LEFT", frame.castBar, "LEFT", 1, 0)
                frame.castIcon:Show()
            else
                frame.castIcon:Hide()
            end
        end
        
        if frame.castText then
            if cbs.showSpellName then
                frame.castText:ClearAllPoints()
                local leftOffset = (cbs.showIcon and (cbHeight + 2)) or 2
                frame.castText:SetPoint("LEFT", frame.castBar, "LEFT", leftOffset, 0)
                frame.castText:Show()
            else
                frame.castText:Hide()
            end
        end
        
        if frame.castTimer then
            if cbs.showTimer then
                frame.castTimer:Show()
            else
                frame.castTimer:Hide()
            end
        end
    elseif frame.castBar then
        frame.castBar:Hide()
    end
end

-- ============================================================================
-- UPDATE FRAME DATA
-- ============================================================================

-- Helper function to get simulated or real unit data
local function GetUnitData(unit)
    if simulationMode and SIMULATED_UNITS[unit] then
        return SIMULATED_UNITS[unit], true
    end
    return nil, false
end

local function UpdateFrameData(unit)
    local frame = customFrames[unit]
    if not frame then return end
    
    local simData, isSimulated = GetUnitData(unit)
    
    -- Check if unit exists (or we're in simulation mode)
    -- Note: For frames with state drivers, visibility is handled by the driver,
    -- but we still need to return early if there's no unit data to display
    if not isSimulated and not UnitExists(unit) then
        -- For frames without state drivers, hide them (legacy behavior)
        if not frame._stateDriverRegistered and not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    local unitSettings = settings[unit]
    if not unitSettings or not unitSettings.enabled then
        if not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    -- For frames with state drivers, don't call Show() - the driver handles visibility
    -- For frames without state drivers (legacy), show the frame
    if not frame._stateDriverRegistered and not InCombatLockdown() then
        frame:Show()
    end
    
    -- Health bar - pass values directly to StatusBar
    -- StatusBar widget handles secret values natively (confirmed working in NephUI/UnhaltedUnitFrames)
    if unitSettings.healthBar.enabled then
        local health, maxHealth
        if isSimulated then
            health = simData.health
            maxHealth = simData.maxHealth
        else
            health = UnitHealth(unit)
            maxHealth = UnitHealthMax(unit)
        end
        
        frame.healthBar:SetMinMaxValues(0, maxHealth)
        frame.healthBar:SetValue(health)
        
        local hbs = unitSettings.healthBar
        local r, g, b
        
        if hbs.colorMode == "class" then
            if isSimulated then
                local classColor = RAID_CLASS_COLORS[simData.class]
                if classColor then
                    r, g, b = classColor.r, classColor.g, classColor.b
                else
                    r, g, b = 1, 1, 1
                end
            else
                r, g, b = GetClassColor(unit)
            end
        elseif hbs.colorMode == "reaction" then
            if isSimulated then
                r, g, b = 0, 1, 0  -- Friendly for simulated
            else
                r, g, b = GetReactionColor(unit)
            end
        elseif hbs.colorMode == "gradient" then
            -- Gradient requires arithmetic on health percent
            if isSimulated then
                local pct = (simData.maxHealth > 0) and (simData.health / simData.maxHealth) or 1
                r, g, b = GetHealthGradientColor(pct)
            else
                -- For real units, arithmetic on secret values fails - use default green
                r, g, b = 0, 1, 0
            end
        else
            r, g, b = hbs.customColor[1], hbs.customColor[2], hbs.customColor[3]
        end
        
        frame.healthBar:SetStatusBarColor(r, g, b)
    end
    
    -- Health text - build text based on format
    -- Pattern matches NephUI which works with secret values
    local hts = unitSettings.healthText
    if hts.enabled and hts.format ~= "none" then
        local text = ""
        local health, maxHealth, pct
        
        if isSimulated then
            health = simData.health
            maxHealth = simData.maxHealth
            pct = (maxHealth > 0) and (health / maxHealth * 100) or 0
        else
            health = UnitHealth(unit)
            maxHealth = UnitHealthMax(unit)
            pct = UnitHealthPercent and UnitHealthPercent(unit, false, true) or 0
        end
        
        if hts.format == "current" then
            text = AbbreviateLargeNumbers(health) or ""
        elseif hts.format == "max" then
            text = AbbreviateLargeNumbers(maxHealth) or ""
        elseif hts.format == "percent" then
            text = string.format("%.0f%%", pct)
        elseif hts.format == "current_max" then
            text = (AbbreviateLargeNumbers(health) or "") .. " / " .. (AbbreviateLargeNumbers(maxHealth) or "")
        elseif hts.format == "current_percent" then
            text = (AbbreviateLargeNumbers(health) or "") .. " - " .. string.format("%.0f%%", pct)
        elseif hts.format == "percent_current" then
            text = string.format("%.0f%%", pct) .. " - " .. (AbbreviateLargeNumbers(health) or "")
        elseif hts.format == "deficit" then
            -- Deficit requires arithmetic - only safe with simulated data
            if isSimulated then
                if pct < 100 then
                    text = string.format("-%.0f%%", 100 - pct)
                end
            else
                -- For real units, just show current health (deficit arithmetic fails with secret values)
                text = AbbreviateLargeNumbers(health) or ""
            end
        end
        
        frame.healthText:SetText(text)
        
        -- Color by health - requires arithmetic, only safe with simulated data
        if hts.colorByHealth then
            if isSimulated then
                local r, g, b = GetHealthGradientColor(pct / 100)
                frame.healthText:SetTextColor(r, g, b)
            else
                -- For real units, use white (arithmetic on secret values fails)
                frame.healthText:SetTextColor(1, 1, 1)
            end
        end
    end
    
    -- Power bar - pass values directly to StatusBar
    if unitSettings.powerBar.enabled then
        local power, maxPower
        if isSimulated then
            power = simData.power
            maxPower = simData.maxPower
        else
            power = UnitPower(unit)
            maxPower = UnitPowerMax(unit)
        end
        
        frame.powerBar:SetMinMaxValues(0, maxPower)
        frame.powerBar:SetValue(power)
        
        local pbs = unitSettings.powerBar
        local r, g, b
        
        if pbs.colorMode == "power" then
            if isSimulated then
                -- Use power type colors for simulation
                local powerColors = {
                    [0] = { 0.0, 0.0, 1.0 },   -- Mana (blue)
                    [1] = { 1.0, 0.0, 0.0 },   -- Rage (red)
                    [2] = { 1.0, 0.5, 0.25 },  -- Focus (orange)
                    [3] = { 1.0, 1.0, 0.0 },   -- Energy (yellow)
                    [6] = { 0.0, 0.82, 1.0 },  -- Runic Power (light blue)
                }
                local powerType = simData.powerType or 0
                local pc = powerColors[powerType] or { 0.5, 0.5, 0.5 }
                r, g, b = pc[1], pc[2], pc[3]
            else
                r, g, b = GetPowerColor(unit)
            end
        else
            r, g, b = pbs.customColor[1], pbs.customColor[2], pbs.customColor[3]
        end
        
        frame.powerBar:SetStatusBarColor(r, g, b)
        frame.powerBar:Show()
    end
    
    -- Power text
    local pts = unitSettings.powerText
    if pts.enabled and unitSettings.powerBar.enabled then
        local text = ""
        local power, maxPower
        
        if isSimulated then
            power = simData.power
            maxPower = simData.maxPower
        else
            power = UnitPower(unit)
            maxPower = UnitPowerMax(unit)
        end
        
        if pts.format == "current" then
            text = AbbreviateLargeNumbers(power) or ""
        elseif pts.format == "max" then
            text = AbbreviateLargeNumbers(maxPower) or ""
        elseif pts.format == "percent" then
            -- Use UnitPowerPercent if available, otherwise calculate
            local pct = 0
            if UnitPowerPercent then
                pct = UnitPowerPercent(unit, Enum.PowerType.Mana, false, true) or 0
            elseif maxPower and maxPower > 0 then
                pct = power / maxPower * 100
            end
            text = string.format("%.0f%%", pct)
        elseif pts.format == "current_max" then
            text = (AbbreviateLargeNumbers(power) or "") .. " / " .. (AbbreviateLargeNumbers(maxPower) or "")
        end
        
        frame.powerText:SetText(text)
    end
    
    -- Name
    local nts = unitSettings.nameText
    if nts.enabled then
        local name
        if isSimulated then
            name = simData.name
        else
            name = UnitName(unit)
        end
        
        if type(name) == "string" then
            frame.nameText:SetText(name)
        else
            -- Keep existing text if secret value
        end
        
        local r, g, b
        if nts.colorMode == "class" then
            if isSimulated then
                local classColor = RAID_CLASS_COLORS[simData.class]
                if classColor then
                    r, g, b = classColor.r, classColor.g, classColor.b
                else
                    r, g, b = 1, 1, 1
                end
            else
                r, g, b = GetClassColor(unit)
            end
        elseif nts.colorMode == "reaction" then
            if isSimulated then
                r, g, b = 0, 1, 0  -- Friendly
            else
                r, g, b = GetReactionColor(unit)
            end
        elseif nts.colorMode == "custom" then
            r, g, b = nts.customColor[1], nts.customColor[2], nts.customColor[3]
        else
            r, g, b = 1, 1, 1
        end
        frame.nameText:SetTextColor(r, g, b)
    end
    
    -- Level - wrap in pcall since type() returns "number" for secret values
    local lts = unitSettings.levelText
    if lts.enabled then
        if isSimulated then
            -- Use simulated level data
            local level = simData.level or 80
            local playerLevel = UnitLevel("player") or 80
            
            if lts.hideAtMaxLevel and level == 80 then
                frame.levelText:Hide()
            else
                frame.levelText:Show()
                local levelText = ""
                local color = "|cffFFFF00"  -- Yellow for same level range
                levelText = color .. level .. "|r"
                frame.levelText:SetText(levelText)
            end
        else
            local success = pcall(function()
            local level = UnitLevel(unit)
            local playerLevel = UnitLevel("player")
            
            -- Force arithmetic to trigger error on secret values
            local test = level + 0
            test = playerLevel + 0
            
            local maxLevel = 80
            if GetMaxPlayerLevel then
                local ml = GetMaxPlayerLevel()
                if type(ml) == "number" then maxLevel = ml end
            end
            
            if lts.hideAtMaxLevel and level == playerLevel and level == maxLevel then
                frame.levelText:Hide()
            else
                frame.levelText:Show()
                
                local levelText = ""
                if lts.showClassification then
                    levelText = GetClassificationString(unit)
                end
                
                if level == -1 then
                    levelText = levelText .. "|cffFF0000??|r"
                else
                    local diff = level - playerLevel
                    local color
                    if diff >= 5 then
                        color = "|cffFF0000"
                    elseif diff >= 3 then
                        color = "|cffFF6600"
                    elseif diff >= -2 then
                        color = "|cffFFFF00"
                    elseif playerLevel > 0 and diff >= -math.floor(playerLevel * 0.2) then
                        color = "|cff00FF00"
                    else
                        color = "|cff888888"
                    end
                    levelText = levelText .. color .. level .. "|r"
                end
                
                frame.levelText:SetText(levelText)
            end
        end)
        -- If pcall failed (secret values), keep existing text
        end  -- end of else (non-simulated)
    end
    
    -- Portrait
    local ps = unitSettings.portrait
    if ps.mode ~= "none" then
        if isSimulated then
            -- For simulation, show class icon
            if ps.mode == "class" or ps.mode == "2d" then
                local class = simData.class
                if class and CLASS_ICON_TCOORDS[class] then
                    local coords = CLASS_ICON_TCOORDS[class]
                    frame.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                    frame.classIcon:SetTexCoord(unpack(coords))
                    frame.classIcon:Show()
                    frame.portrait2D:Hide()
                    frame.portrait3D:Hide()
                end
            elseif ps.mode == "3d" then
                -- Can't show 3D model for simulated, fallback to class
                local class = simData.class
                if class and CLASS_ICON_TCOORDS[class] then
                    local coords = CLASS_ICON_TCOORDS[class]
                    frame.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                    frame.classIcon:SetTexCoord(unpack(coords))
                    frame.classIcon:Show()
                    frame.portrait2D:Hide()
                    frame.portrait3D:Hide()
                end
            end
        else
            if ps.mode == "3d" then
                frame.portrait3D:SetUnit(unit)
                frame.portrait3D:SetCamera(0)
            elseif ps.mode == "2d" then
                SetPortraitTexture(frame.portrait2D, unit)
            elseif ps.mode == "class" then
                local _, class = UnitClass(unit)
                if type(class) == "string" and class ~= "" then
                    local coords = CLASS_ICON_TCOORDS[class]
                    if coords then
                        frame.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
                        frame.classIcon:SetTexCoord(unpack(coords))
                    end
                end
            end
        end  -- end of else (non-simulated portrait)
    end
    
    -- Raid Target
    local rts = unitSettings.raidTarget
    if rts.enabled then
        local index = GetRaidTargetIndex(unit)
        if index then
            -- SetRaidTargetIconTexture can accept secret values
            SetRaidTargetIconTexture(frame.raidTarget, index)
            frame.raidTarget:Show()
        else
            frame.raidTarget:Hide()
        end
    else
        frame.raidTarget:Hide()
    end
    
    -- Role Icon
    local ris = unitSettings.roleIcon
    if ris and ris.enabled then
        local role
        if isSimulated then
            role = simData.role or "NONE"
        else
            role = UnitGroupRolesAssigned(unit) or "NONE"
        end
        
        if role and role ~= "NONE" then
            -- Try multiple atlas names in order of preference
            local atlasOptions = {
                TANK = {
                    "groupfinder-icon-role-large-tank",
                    "roleicon-tank",
                },
                HEALER = {
                    "groupfinder-icon-role-large-heal",
                    "groupfinder-icon-role-large-healer",
                    "roleicon-healer",
                    "roleicon-heal",
                },
                DAMAGER = {
                    "groupfinder-icon-role-large-dps",
                    "groupfinder-icon-role-large-damage",
                    "roleicon-dps",
                },
            }
            
            local options = atlasOptions[role]
            local atlasSet = false
            
            if options then
                for _, atlasName in ipairs(options) do
                    local success = pcall(function()
                        frame.roleIcon:SetAtlas(atlasName, true)
                    end)
                    if success then
                        local currentAtlas = frame.roleIcon:GetAtlas()
                        if currentAtlas and currentAtlas ~= "" then
                            atlasSet = true
                            break
                        end
                    end
                end
            end
            
            if atlasSet then
                frame.roleIcon:Show()
            else
                frame.roleIcon:Hide()
            end
        else
            frame.roleIcon:Hide()
        end
    else
        frame.roleIcon:Hide()
    end
    
    -- Debuff Indicators
    local dis = unitSettings.debuffIndicators
    if dis and dis.enabled and frame.debuffIndicators then
        -- Hide all indicators first
        for _, indicator in pairs(frame.debuffIndicators.indicators) do
            indicator:Hide()
        end
        
        -- Check for dispellable debuffs (or use simulated data)
        local debuffsFound = {}
        
        if isSimulated and simData.debuffType then
            -- Show simulated debuff
            debuffsFound[simData.debuffType] = true
        else
            -- Scan real debuffs using modern API
            -- dispelName can be a secret value in combat, so we must use pcall
            for i = 1, 40 do
                local auraData = C_UnitAuras.GetDebuffDataByIndex(unit, i)
                if not auraData then break end
                
                -- Use pcall to safely check debuff type - secret values will cause comparison to error
                local success, result = pcall(function()
                    local dt = auraData.dispelName
                    if dt == "Magic" then return "Magic"
                    elseif dt == "Curse" then return "Curse"
                    elseif dt == "Disease" then return "Disease"
                    elseif dt == "Poison" then return "Poison"
                    elseif dt == "Bleed" then return "Bleed"
                    end
                    return nil
                end)
                
                if success and result then
                    debuffsFound[result] = true
                end
            end
        end
        
        -- Show indicators for found debuff types
        local xOffset = 0
        for debuffType, indicator in pairs(frame.debuffIndicators.indicators) do
            local shouldShow = false
            
            if debuffsFound[debuffType] then
                if debuffType == "Magic" and dis.showMagic then shouldShow = true
                elseif debuffType == "Curse" and dis.showCurse then shouldShow = true
                elseif debuffType == "Disease" and dis.showDisease then shouldShow = true
                elseif debuffType == "Poison" and dis.showPoison then shouldShow = true
                elseif debuffType == "Bleed" and dis.showBleed then shouldShow = true
                end
            end
            
            if shouldShow then
                indicator:ClearAllPoints()
                indicator:SetPoint("LEFT", frame.debuffIndicators, "LEFT", xOffset, 0)
                indicator:Show()
                xOffset = xOffset + dis.size + 2
            end
        end
    end
    
    -- Cast Bar
    local cbs = unitSettings.castBar
    if cbs and cbs.enabled and frame.castBar then
        -- Handle simulation mode
        if isSimulated then
            -- Show a simulated cast bar
            frame.castBar:SetMinMaxValues(0, 3)
            frame.castBar:SetValue(1.5)
            if frame.castText then 
                if cbs.showSpellName then
                    frame.castText:SetText("Simulated Cast")
                    frame.castText:Show()
                else
                    frame.castText:Hide()
                end
            end
            if frame.castTimer then 
                if cbs.showTimer then
                    frame.castTimer:SetText("1.5")
                    frame.castTimer:Show()
                else
                    frame.castTimer:Hide()
                end
            end
            if frame.castIcon then
                if cbs.showIcon then
                    frame.castIcon:SetTexture("Interface\\Icons\\Spell_Nature_Heal")
                    frame.castIcon:Show()
                else
                    frame.castIcon:Hide()
                end
            end
            frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
            frame.castBar:Show()
        else
            local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(unit)
            if not SafeValue(castName) then
                castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(unit)
            end
            
            -- Safe extract values for Midnight compatibility
            local safeCastName = SafeValue(castName)
            local safeStartTime = SafeValue(startTime)
            local safeEndTime = SafeValue(endTime)
            local safeSpellID = SafeValue(spellID)
            local safeNotInterruptible = SafeValue(notInterruptible)
            
            if safeCastName and safeStartTime and safeEndTime then
                local duration = (safeEndTime - safeStartTime) / 1000
                local elapsed = (GetTime() * 1000 - safeStartTime) / 1000
                frame.castBar:SetMinMaxValues(0, duration)
                frame.castBar:SetValue(elapsed)
                
                if frame.castText and cbs.showSpellName then
                    frame.castText:SetText(safeCastName)
                end
                
                if frame.castIcon and cbs.showIcon and safeSpellID then
                    local spellTexture = GetSpellTextureByID(safeSpellID)
                    if spellTexture then
                        frame.castIcon:SetTexture(spellTexture)
                        frame.castIcon:Show()
                    end
                end
                
                if frame.castTimer and cbs.showTimer then
                    frame.castTimer:SetText(string.format("%.1f", duration - elapsed))
                end
                
                if safeNotInterruptible then
                    frame.castBar:SetStatusBarColor(0.7, 0.7, 0.7, 1)
                else
                    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                end
                
                frame.castBar:Show()
            else
                -- Don't hide if we're in preview mode (panel is open)
                if currentOpenPanel ~= unit then
                    frame.castBar:Hide()
                end
            end
        end
    elseif frame.castBar then
        -- Don't hide if we're in preview mode
        if currentOpenPanel ~= unit then
            frame.castBar:Hide()
        end
    end
end

-- ============================================================================
-- VISIBILITY MANAGER (Per-Frame)
-- ============================================================================

local VisibilityManager = {
    mouseoverFrames = {},  -- Per-unit mouseover detection frames
    mouseoverStates = {},  -- Per-unit mouseover state
    initialized = false,
}

-- Get visibility settings for a specific unit
local function GetVisibilitySettings(unitType)
    if not settings then return nil end
    
    -- Map unit types to their settings
    if unitType == "raid_small" then
        return settings.raid and settings.raid.small and settings.raid.small.visibility
    elseif unitType == "raid_large" then
        return settings.raid and settings.raid.large and settings.raid.large.visibility
    elseif unitType == "tanks" then
        return settings.tanks and settings.tanks.visibility
    elseif unitType == "boss" then
        return settings.boss and settings.boss.visibility
    elseif unitType == "party" then
        return settings.party and settings.party.visibility
    else
        return settings[unitType] and settings[unitType].visibility
    end
end

-- Check if a specific unit should be shown based on its visibility settings
function VisibilityManager:ShouldShowUnit(unitType)
    -- Always show if the settings panel for this unit is open
    if currentOpenPanel == unitType then
        return true
    end
    
    local vis = GetVisibilitySettings(unitType)
    if not vis or not vis.enabled then return true end  -- No visibility controls = always show
    
    -- Check if ANY condition is met (OR logic)
    
    -- Combat check
    if vis.combat and UnitAffectingCombat("player") then
        return true
    end
    
    -- Mouseover check
    if vis.mouseover and self.mouseoverStates[unitType] then
        return true
    end
    
    -- Target check
    if vis.target and UnitExists("target") then
        return true
    end
    
    -- Group check
    if vis.group and (IsInGroup() or IsInRaid()) then
        return true
    end
    
    -- Instance check
    if vis.instance then
        local _, instanceType = IsInInstance()
        local allowedTypes = vis.instanceTypes or {}
        if allowedTypes[instanceType] then
            return true
        end
    end
    
    -- No conditions met = hide
    return false
end

-- Apply visibility to a specific unit's frame(s)
function VisibilityManager:ApplyVisibilityForUnit(unitType, instant)
    local vis = GetVisibilitySettings(unitType)
    
    -- Get the frame(s) for this unit
    local frames = {}
    
    if unitType == "party" then
        for i, frame in pairs(partyMemberFrames) do
            if frame then table.insert(frames, frame) end
        end
    elseif unitType == "raid_small" then
        for i, frame in pairs(raidSmallMemberFrames) do
            if frame then table.insert(frames, frame) end
        end
    elseif unitType == "raid_large" then
        for i, frame in pairs(raidLargeMemberFrames) do
            if frame then table.insert(frames, frame) end
        end
    elseif unitType == "tanks" then
        for i, frame in pairs(tankMemberFrames) do
            if frame then table.insert(frames, frame) end
        end
    elseif unitType == "boss" then
        for i, frame in pairs(bossMemberFrames) do
            if frame then table.insert(frames, frame) end
        end
    elseif customFrames[unitType] then
        table.insert(frames, customFrames[unitType])
    end
    
    if #frames == 0 then return end
    
    -- Calculate target alpha
    local targetAlpha
    if not vis or not vis.enabled then
        targetAlpha = 1  -- No visibility controls = full opacity
    else
        local shouldShow = self:ShouldShowUnit(unitType)
        targetAlpha = shouldShow and 1 or (vis.fadeAlpha / 100)
    end
    
    -- Apply alpha to all frames for this unit
    for _, frame in ipairs(frames) do
        if instant then
            frame:SetAlpha(targetAlpha)
        else
            -- Smooth fade (simple version - just set immediately for now)
            frame:SetAlpha(targetAlpha)
        end
    end
end

-- Apply visibility to all frames
function VisibilityManager:ApplyAllVisibility(instant)
    -- Individual units
    for _, unitType in ipairs(INDIVIDUAL_UNITS) do
        self:ApplyVisibilityForUnit(unitType, instant)
    end
    
    -- Group frames
    self:ApplyVisibilityForUnit("party", instant)
    self:ApplyVisibilityForUnit("raid_small", instant)
    self:ApplyVisibilityForUnit("raid_large", instant)
    self:ApplyVisibilityForUnit("tanks", instant)
    self:ApplyVisibilityForUnit("boss", instant)
end

-- Update mouseover detection for a specific unit
function VisibilityManager:UpdateMouseoverForUnit(unitType)
    local vis = GetVisibilitySettings(unitType)
    
    -- If no visibility settings or mouseover not enabled, remove detection
    if not vis or not vis.enabled or not vis.mouseover then
        if self.mouseoverFrames[unitType] then
            self.mouseoverFrames[unitType]:Hide()
        end
        return
    end
    
    -- Get the frame(s) for this unit to calculate bounds
    local targetFrame
    if unitType == "party" then
        targetFrame = partyContainer
    elseif unitType == "raid_small" then
        targetFrame = raidSmallContainer
    elseif unitType == "raid_large" then
        targetFrame = raidLargeContainer
    elseif unitType == "tanks" then
        targetFrame = tankContainer
    elseif unitType == "boss" then
        targetFrame = bossContainer
    else
        targetFrame = customFrames[unitType]
    end
    
    if not targetFrame or not targetFrame:IsShown() then
        if self.mouseoverFrames[unitType] then
            self.mouseoverFrames[unitType]:Hide()
        end
        return
    end
    
    -- Create or get mouseover frame
    if not self.mouseoverFrames[unitType] then
        local mf = CreateFrame("Frame", nil, UIParent)
        mf:SetFrameStrata("BACKGROUND")
        mf.unitType = unitType
        self.mouseoverFrames[unitType] = mf
        
        mf:SetScript("OnEnter", function(self)
            VisibilityManager.mouseoverStates[self.unitType] = true
            VisibilityManager:ApplyVisibilityForUnit(self.unitType, false)
        end)
        
        mf:SetScript("OnLeave", function(self)
            VisibilityManager.mouseoverStates[self.unitType] = false
            VisibilityManager:ApplyVisibilityForUnit(self.unitType, false)
        end)
        
        mf:EnableMouse(true)
    end
    
    local mf = self.mouseoverFrames[unitType]
    
    -- Position to cover the target frame with padding
    local padding = 15
    local left = targetFrame:GetLeft()
    local bottom = targetFrame:GetBottom()
    local width = targetFrame:GetWidth()
    local height = targetFrame:GetHeight()
    
    if left and bottom and width and height then
        mf:ClearAllPoints()
        mf:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left - padding, bottom - padding)
        mf:SetSize(width + padding * 2, height + padding * 2)
        mf:Show()
    else
        mf:Hide()
    end
end

-- Update all mouseover detections
function VisibilityManager:UpdateAllMouseover()
    for _, unitType in ipairs(INDIVIDUAL_UNITS) do
        self:UpdateMouseoverForUnit(unitType)
    end
    self:UpdateMouseoverForUnit("party")
    self:UpdateMouseoverForUnit("raid_small")
    self:UpdateMouseoverForUnit("raid_large")
    self:UpdateMouseoverForUnit("tanks")
    self:UpdateMouseoverForUnit("boss")
end

-- Initialize visibility system
function VisibilityManager:Initialize()
    if self.initialized then return end
    self.initialized = true
    
    -- Create event frame for visibility-related events
    local visFrame = CreateFrame("Frame")
    visFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    visFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    visFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    visFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    visFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    visFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    
    visFrame:SetScript("OnEvent", function(self, event)
        if not settings then return end
        
        -- Check which units need updating based on event
        local unitsToUpdate = {}
        
        -- Determine which units have visibility enabled for this event type
        local function CheckUnit(unitType)
            local vis = GetVisibilitySettings(unitType)
            if vis and vis.enabled then
                if event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED" then
                    if vis.combat then table.insert(unitsToUpdate, unitType) end
                elseif event == "PLAYER_TARGET_CHANGED" then
                    if vis.target then table.insert(unitsToUpdate, unitType) end
                elseif event == "GROUP_ROSTER_UPDATE" then
                    if vis.group then table.insert(unitsToUpdate, unitType) end
                elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
                    table.insert(unitsToUpdate, unitType)
                end
            end
        end
        
        -- Check all unit types
        for _, unitType in ipairs(INDIVIDUAL_UNITS) do
            CheckUnit(unitType)
        end
        CheckUnit("party")
        CheckUnit("raid_small")
        CheckUnit("raid_large")
        CheckUnit("tanks")
        CheckUnit("boss")
        
        -- Apply updates
        if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
            C_Timer.After(0.5, function()
                VisibilityManager:ApplyAllVisibility(true)
                VisibilityManager:UpdateAllMouseover()
            end)
        else
            for _, unitType in ipairs(unitsToUpdate) do
                VisibilityManager:ApplyVisibilityForUnit(unitType, true)
            end
        end
    end)
    
    -- Initial application
    C_Timer.After(1, function()
        self:ApplyAllVisibility(true)
        self:UpdateAllMouseover()
    end)
end

-- ============================================================================
-- EVENT HANDLING
-- ============================================================================

local function SetupEventFrame()
    if eventFrame then return end
    
    eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    eventFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
    eventFrame:RegisterEvent("UNIT_PET")
    eventFrame:RegisterEvent("UNIT_HEALTH")
    eventFrame:RegisterEvent("UNIT_MAXHEALTH")
    eventFrame:RegisterEvent("UNIT_POWER_UPDATE")
    eventFrame:RegisterEvent("UNIT_MAXPOWER")
    eventFrame:RegisterEvent("UNIT_DISPLAYPOWER")
    eventFrame:RegisterEvent("UNIT_NAME_UPDATE")
    eventFrame:RegisterEvent("UNIT_LEVEL")
    eventFrame:RegisterEvent("UNIT_FACTION")
    eventFrame:RegisterEvent("UNIT_CLASSIFICATION_CHANGED")
    eventFrame:RegisterEvent("RAID_TARGET_UPDATE")
    eventFrame:RegisterEvent("UNIT_PORTRAIT_UPDATE")
    eventFrame:RegisterEvent("PORTRAITS_UPDATED")
    eventFrame:RegisterEvent("UNIT_TARGET")
    -- Party events
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    eventFrame:RegisterEvent("PARTY_MEMBER_ENABLE")
    eventFrame:RegisterEvent("PARTY_MEMBER_DISABLE")
    -- Debuff events
    eventFrame:RegisterEvent("UNIT_AURA")
    -- Combat state events (for deferred updates)
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    -- Boss events
    eventFrame:RegisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT")
    eventFrame:RegisterEvent("UNIT_TARGETABLE_CHANGED")
    -- Cast bar events
    eventFrame:RegisterEvent("UNIT_SPELLCAST_START")
    eventFrame:RegisterEvent("UNIT_SPELLCAST_STOP")
    eventFrame:RegisterEvent("UNIT_SPELLCAST_FAILED")
    eventFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
    eventFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
    eventFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
    
    eventFrame:SetScript("OnEvent", function(self, event, arg1, ...)
        if not settings then return end
        
        if event == "PLAYER_REGEN_ENABLED" then
            -- Combat ended - refresh frames that may need layout updates
            -- UpdateFrameData handles show/hide based on unit existence
            C_Timer.After(0.1, function()
                -- Refresh individual frames - let UpdateFrameData handle visibility
                for unit, frame in pairs(customFrames) do
                    if frame and settings[unit] and settings[unit].enabled then
                        UpdateFrameLayout(unit)
                        UpdateFrameData(unit)
                        -- Don't force show - UpdateFrameData handles visibility properly
                    end
                end
                -- Refresh party frames
                if settings.party and settings.party.enabled then
                    pcall(function() UnitFrames:UpdatePartyFrames() end)
                end
            end)
            
        elseif event == "PLAYER_ENTERING_WORLD" then
            C_Timer.After(0.5, function()
                for unit, _ in pairs(customFrames) do
                    UpdateFrameLayout(unit)
                    UpdateFrameData(unit)
                end
                -- Also update party frames after zoning
                if settings.party and settings.party.enabled then
                    pcall(function() UnitFrames:UpdatePartyFrames() end)
                end
                -- Check if Blizzard cast bars should be hidden
                UpdateBlizzardCastBarVisibility()
            end)
            -- Additional delayed call to ensure Blizzard frames stay hidden
            C_Timer.After(1.5, function()
                if settings.party and settings.party.enabled then
                    pcall(function() UnitFrames:UpdatePartyFrames() end)
                end
                -- Recheck Blizzard cast bar visibility
                UpdateBlizzardCastBarVisibility()
            end)
            
        elseif event == "PLAYER_TARGET_CHANGED" then
            if customFrames["target"] then
                UpdateFrameData("target")
            end
            if customFrames["targettarget"] then
                UpdateFrameData("targettarget")
            end
            
        elseif event == "PLAYER_FOCUS_CHANGED" then
            if customFrames["focus"] then
                UpdateFrameData("focus")
            end
            
        elseif event == "UNIT_PET" then
            if customFrames["pet"] then
                UpdateFrameData("pet")
            end
            
        elseif event == "UNIT_TARGET" then
            -- Update target of target when target changes their target
            if arg1 == "target" and customFrames["targettarget"] then
                UpdateFrameData("targettarget")
            end
            
        elseif event == "GROUP_ROSTER_UPDATE" or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" then
            -- Update party container frames (protected)
            pcall(function() UnitFrames:UpdatePartyFrames() end)
            -- Update raid container frames (protected)
            pcall(function() UnitFrames:UpdateRaidFrames() end)
            -- Update tank frames (protected)
            pcall(function() UnitFrames:UpdateTankFrames() end)
            
        elseif event == "INSTANCE_ENCOUNTER_ENGAGE_UNIT" or event == "UNIT_TARGETABLE_CHANGED" then
            -- Update boss frames when bosses appear/disappear
            if settings.boss and settings.boss.enabled then
                pcall(function() UnitFrames:UpdateBossFrames() end)
            end
            
        elseif event == "UNIT_AURA" then
            -- Update debuff indicators for the affected unit
            if arg1 and customFrames[arg1] then
                UpdateFrameData(arg1)
            end
            -- Also update party frames if it's a party member (protected)
            if arg1 and (arg1 == "player" or arg1:match("^party%d$")) then
                pcall(function() UnitFrames:UpdatePartyFrames() end)
            end
            -- Also update raid frames if it's a raid member (protected)
            if arg1 and (arg1 == "player" or arg1:match("^raid%d+$")) then
                pcall(function() UnitFrames:UpdateRaidFrames() end)
            end
            
        elseif event == "UNIT_HEALTH" or event == "UNIT_MAXHEALTH" or 
               event == "UNIT_POWER_UPDATE" or event == "UNIT_MAXPOWER" or
               event == "UNIT_DISPLAYPOWER" then
            if arg1 and customFrames[arg1] then
                UpdateFrameData(arg1)
            end
            -- Also update party frames if it's a party member (protected)
            if arg1 and (arg1 == "player" or arg1:match("^party%d$")) then
                pcall(function() UnitFrames:UpdatePartyFrames() end)
            end
            -- Also update raid frames if it's a raid member (protected)
            if arg1 and (arg1 == "player" or arg1:match("^raid%d+$")) then
                pcall(function() UnitFrames:UpdateRaidFrames() end)
            end
            -- Also update boss frames if it's a boss unit
            if arg1 and arg1:match("^boss%d$") then
                pcall(function() UnitFrames:UpdateBossFrames() end)
            end
            
        elseif event == "UNIT_NAME_UPDATE" or event == "UNIT_LEVEL" or
               event == "UNIT_FACTION" or event == "UNIT_CLASSIFICATION_CHANGED" then
            if arg1 and customFrames[arg1] then
                UpdateFrameData(arg1)
            end
            
        elseif event == "RAID_TARGET_UPDATE" then
            for unit, _ in pairs(customFrames) do
                UpdateFrameData(unit)
            end
            -- Also update party and raid frames
            pcall(function() UnitFrames:UpdatePartyFrames() end)
            pcall(function() UnitFrames:UpdateRaidFrames() end)
            pcall(function() UnitFrames:UpdateTankFrames() end)
            
        elseif event == "UNIT_PORTRAIT_UPDATE" or event == "PORTRAITS_UPDATED" then
            for unit, frame in pairs(customFrames) do
                local us = settings[unit]
                if us and us.portrait and us.portrait.enabled then
                    UpdateFrameData(unit)
                end
            end
            
        elseif event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_STOP" or
               event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" or
               event == "UNIT_SPELLCAST_CHANNEL_START" or event == "UNIT_SPELLCAST_CHANNEL_STOP" then
            -- Update cast bar for the unit
            if arg1 and customFrames[arg1] then
                UpdateFrameData(arg1)
            end
            -- Also update party frames if it's a party member
            if arg1 and (arg1 == "player" or arg1:match("^party%d$")) then
                pcall(function() UnitFrames:UpdatePartyFrames() end)
            end
            -- Also update raid frames if it's a raid member
            if arg1 and (arg1 == "player" or arg1:match("^raid%d+$")) then
                pcall(function() UnitFrames:UpdateRaidFrames() end)
            end
            -- Also update tank frames
            if arg1 and arg1:match("^raid%d+$") then
                pcall(function() UnitFrames:UpdateTankFrames() end)
            end
            -- Also update boss frames if it's a boss unit
            if arg1 and arg1:match("^boss%d$") then
                pcall(function() UnitFrames:UpdateBossFrames() end)
            end
        end
    end)
end

-- ============================================================================
-- EDIT MODE INTEGRATION
-- ============================================================================

local function RegisterWithEditMode(unit)
    local frame = customFrames[unit]
    if not frame then return end
    
    -- Use centralized EditModeManager
    if not TweaksUI.EditMode then return end
    
    local unitSettings = settings[unit]
    if not unitSettings then return end
    
    -- Check if already registered
    if frame._editModeRegistered then return end
    
    local function OnPositionChanged(movedFrame, point, x, y)
        local fs = unitSettings.frame
        fs.anchor = point
        fs.x = x
        fs.y = y
        TweaksUI:PrintDebug("UnitFrame " .. unit .. " moved to " .. x .. ", " .. y)
    end
    
    TweaksUI.EditMode:RegisterFrame(frame, {
        name = "TweaksUI: " .. unit:gsub("^%l", string.upper) .. " Frame",
        onPositionChanged = OnPositionChanged,
        default = {
            point = unitSettings.frame.anchor,
            x = unitSettings.frame.x,
            y = unitSettings.frame.y,
        },
    })
    
    frame._editModeRegistered = true
end

-- ============================================================================
-- MODULE LIFECYCLE
-- ============================================================================

function UnitFrames:OnInitialize()
    TweaksUI:PrintDebug("Unit Frames module initializing...")
    
    settings = self:GetSettings()
    
    -- Apply defaults
    if settings.enabled == nil then
        settings.enabled = DEFAULTS.enabled
    end
    
    -- Individual unit types (not party)
    local initUnits = {"player", "target", "focus", "targettarget", "pet"}
    
    -- Per-unit defaults for individual unit types
    for _, unit in ipairs(initUnits) do
        if not settings[unit] then
            settings[unit] = GetDefaultFrameSettings(unit)
        else
            -- Merge with defaults
            local defaults = GetDefaultFrameSettings(unit)
            for category, catDefaults in pairs(defaults) do
                if type(catDefaults) == "table" then
                    if not settings[unit][category] then
                        settings[unit][category] = {}
                    end
                    for key, value in pairs(catDefaults) do
                        if settings[unit][category][key] == nil then
                            settings[unit][category][key] = type(value) == "table" and CopyTable(value) or value
                        end
                    end
                elseif settings[unit][category] == nil then
                    settings[unit][category] = catDefaults
                end
            end
        end
    end
    
    -- Party container defaults - uses same structure as individual frames
    if not settings.party then
        -- Start with GetDefaultFrameSettings for party-style frame
        settings.party = GetDefaultFrameSettings("party1")
        
        -- Add container-specific settings
        settings.party.container = {
            x = -450,
            y = 100,
            anchor = "CENTER",
            growthDirection = "DOWN",
            spacing = 2,
            scale = 1.0,
        }
        settings.party.sorting = "NONE"  -- TANK_HEALER_DPS, HEALER_TANK_DPS, etc.
    else
        -- Check if party settings structure is valid (has required tables)
        -- If old/corrupted structure, reset to defaults
        local needsReset = false
        if settings.party.memberFrame then needsReset = true end  -- Old structure
        if not settings.party.frame then needsReset = true end
        if not settings.party.healthBar then needsReset = true end
        if not settings.party.healthText then needsReset = true end
        if not settings.party.powerText then needsReset = true end
        if not settings.party.nameText then needsReset = true end
        if not settings.party.levelText then needsReset = true end
        if not settings.party.portrait then needsReset = true end
        if not settings.party.powerBar then needsReset = true end
        if not settings.party.raidTarget then needsReset = true end
        if not settings.party.roleIcon then needsReset = true end
        if not settings.party.debuffIndicators then needsReset = true end
        
        if needsReset then
            local wasEnabled = settings.party.enabled
            local oldContainer = settings.party.container
            
            -- Reset to fresh defaults
            settings.party = GetDefaultFrameSettings("party1")
            
            -- Only override enabled if it was explicitly set (not nil)
            if wasEnabled ~= nil then
                settings.party.enabled = wasEnabled
            end
            
            -- Preserve container position if it existed
            if oldContainer then
                settings.party.container = oldContainer
            else
                settings.party.container = {
                    x = -450,
                    y = 100,
                    anchor = "CENTER",
                    growthDirection = "DOWN",
                    spacing = 2,
                    scale = 1.0,
                }
            end
            settings.party.sorting = "NONE"
        else
            -- Get complete defaults for party frame
            local defaults = GetDefaultFrameSettings("party1")
            
            -- Helper to deep merge defaults into existing settings (only adds missing fields)
            local function MergeDefaults(existing, default)
                if type(existing) ~= "table" or type(default) ~= "table" then return end
                for k, v in pairs(default) do
                    if existing[k] == nil then
                        if type(v) == "table" then
                            existing[k] = CopyTable(v)
                        else
                            existing[k] = v
                        end
                    elseif type(v) == "table" and type(existing[k]) == "table" then
                        MergeDefaults(existing[k], v)
                    end
                end
            end
            
            -- Ensure all sections exist and have all required fields
            MergeDefaults(settings.party.frame, defaults.frame)
            MergeDefaults(settings.party.healthBar, defaults.healthBar)
            MergeDefaults(settings.party.powerBar, defaults.powerBar)
            MergeDefaults(settings.party.healthText, defaults.healthText)
            MergeDefaults(settings.party.powerText, defaults.powerText)
            MergeDefaults(settings.party.nameText, defaults.nameText)
            MergeDefaults(settings.party.levelText, defaults.levelText)
            MergeDefaults(settings.party.portrait, defaults.portrait)
            MergeDefaults(settings.party.raidTarget, defaults.raidTarget)
            MergeDefaults(settings.party.roleIcon, defaults.roleIcon)
            MergeDefaults(settings.party.debuffIndicators, defaults.debuffIndicators)
            
            if not settings.party.container then
                settings.party.container = {
                    x = -450,
                    y = 100,
                    anchor = "CENTER",
                    growthDirection = "DOWN",
                    spacing = 2,
                    scale = 1.0,
                }
            else
                -- Ensure scale exists
                if settings.party.container.scale == nil then
                    settings.party.container.scale = 1.0
                end
            end
        end
    end
    
    -- Enforce minimum icon sizes for party frames (fixes small icons from old settings)
    if settings.party then
        if settings.party.roleIcon and settings.party.roleIcon.size and settings.party.roleIcon.size < 14 then
            settings.party.roleIcon.size = 16
        end
        if settings.party.raidTarget and settings.party.raidTarget.size and settings.party.raidTarget.size < 14 then
            settings.party.raidTarget.size = 18
        end
        if settings.party.debuffIndicators and settings.party.debuffIndicators.size and settings.party.debuffIndicators.size < 12 then
            settings.party.debuffIndicators.size = 14
        end
        
        -- Fix bad offsets that put icons outside frame (from old settings)
        if settings.party.roleIcon then
            local ri = settings.party.roleIcon
            -- If offset is way outside (like -50), reset to sensible inside values
            if ri.offsetX and (ri.offsetX < -20 or ri.offsetX > 20) then
                ri.offsetX = 2
            end
            if ri.offsetY and (ri.offsetY < -20 or ri.offsetY > 20) then
                ri.offsetY = -2
            end
        end
        if settings.party.raidTarget then
            local rt = settings.party.raidTarget
            if rt.offsetX and (rt.offsetX < -20 or rt.offsetX > 20) then
                rt.offsetX = 0
            end
            if rt.offsetY and (rt.offsetY < -20 or rt.offsetY > 20) then
                rt.offsetY = -2
            end
        end
    end
    
    -- Raid container defaults - now with small/large layouts
    if not settings.raid then
        settings.raid = CopyTable(RAID_DEFAULTS)
        -- Fill in small layout visual defaults from shared
        for k, v in pairs(RAID_FRAME_VISUAL_DEFAULTS) do
            if settings.raid.small[k] == nil then
                settings.raid.small[k] = CopyTable(v)
            end
        end
    else
        -- Check if raid settings structure is valid (new structure)
        local needsReset = false
        if not settings.raid.small then needsReset = true end
        if not settings.raid.large then needsReset = true end
        if settings.raid.small and not settings.raid.small.layout then needsReset = true end
        if settings.raid.large and not settings.raid.large.layout then needsReset = true end
        -- Also reset if old structure detected (had container at top level)
        if settings.raid.container and not settings.raid.small then needsReset = true end
        
        if needsReset then
            local wasEnabled = settings.raid.enabled
            
            -- Reset to fresh defaults
            settings.raid = CopyTable(RAID_DEFAULTS)
            -- Fill in small layout visual defaults
            for k, v in pairs(RAID_FRAME_VISUAL_DEFAULTS) do
                if settings.raid.small[k] == nil then
                    settings.raid.small[k] = CopyTable(v)
                end
            end
            
            if wasEnabled ~= nil then
                settings.raid.enabled = wasEnabled
            end
        else
            -- Merge defaults into existing settings
            local function MergeRaidDefaults(existing, default)
                if type(existing) ~= "table" or type(default) ~= "table" then return end
                for k, v in pairs(default) do
                    if existing[k] == nil then
                        if type(v) == "table" then
                            existing[k] = CopyTable(v)
                        else
                            existing[k] = v
                        end
                    elseif type(v) == "table" and type(existing[k]) == "table" then
                        MergeRaidDefaults(existing[k], v)
                    end
                end
            end
            
            MergeRaidDefaults(settings.raid, RAID_DEFAULTS)
            -- Also merge visual defaults into small
            for k, v in pairs(RAID_FRAME_VISUAL_DEFAULTS) do
                if settings.raid.small[k] == nil then
                    settings.raid.small[k] = CopyTable(v)
                end
            end
        end
    end
    
    -- Tank frames defaults
    if not settings.tanks then
        settings.tanks = CopyTable(TANK_DEFAULTS)
    else
        -- Merge defaults into existing settings
        local function MergeTankDefaults(existing, default)
            if type(existing) ~= "table" or type(default) ~= "table" then return end
            for k, v in pairs(default) do
                if existing[k] == nil then
                    if type(v) == "table" then
                        existing[k] = CopyTable(v)
                    else
                        existing[k] = v
                    end
                elseif type(v) == "table" and type(existing[k]) == "table" then
                    MergeTankDefaults(existing[k], v)
                end
            end
        end
        MergeTankDefaults(settings.tanks, TANK_DEFAULTS)
    end
    
    -- Boss frames defaults
    if not settings.boss then
        settings.boss = CopyTable(BOSS_DEFAULTS)
    else
        -- Merge defaults into existing settings
        local function MergeBossDefaults(existing, default)
            if type(existing) ~= "table" or type(default) ~= "table" then return end
            for k, v in pairs(default) do
                if existing[k] == nil then
                    if type(v) == "table" then
                        existing[k] = CopyTable(v)
                    else
                        existing[k] = v
                    end
                elseif type(v) == "table" and type(existing[k]) == "table" then
                    MergeBossDefaults(existing[k], v)
                end
            end
        end
        MergeBossDefaults(settings.boss, BOSS_DEFAULTS)
    end
    
    -- Get libraries
    LibSharedMedia = LibStub and LibStub("LibSharedMedia-3.0", true)
    -- LibEditMode is now managed by TweaksUI.EditMode (Core/EditModeManager.lua)
    TweaksUI:PrintDebug("Unit Frames: Using centralized EditModeManager")
end

-- Party member units (for party container)
local PARTY_UNITS = {"player", "party1", "party2", "party3", "party4"}

-- Simulated party data for preview
local SIMULATED_PARTY = {
    { unit = "player", name = "You", class = "WARRIOR", health = 100000, maxHealth = 100000, power = 100, maxPower = 100, powerType = 1, role = "TANK" },
    { unit = "party1", name = "Healbot", class = "PRIEST", health = 72000, maxHealth = 80000, power = 65000, maxPower = 80000, powerType = 0, role = "HEALER", debuffType = "Magic" },
    { unit = "party2", name = "Tankadin", class = "PALADIN", health = 95000, maxHealth = 120000, power = 40000, maxPower = 50000, powerType = 0, role = "TANK" },
    { unit = "party3", name = "Stabsworth", class = "ROGUE", health = 68000, maxHealth = 85000, power = 100, maxPower = 100, powerType = 3, role = "DAMAGER", debuffType = "Poison" },
    { unit = "party4", name = "Pyromancer", class = "MAGE", health = 55000, maxHealth = 70000, power = 45000, maxPower = 60000, powerType = 0, role = "DAMAGER", debuffType = "Curse" },
}

-- Simulated raid data (40 players in 8 groups)
local SIMULATED_RAID = {}
local raidClasses = {"WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "DEATHKNIGHT", "SHAMAN", "MAGE", "WARLOCK", "MONK", "DRUID", "DEMONHUNTER", "EVOKER"}
local raidRoles = {"TANK", "HEALER", "DAMAGER", "DAMAGER", "DAMAGER"}  -- Weight toward DPS
local raidNames = {"Aegis", "Blade", "Cinder", "Dawn", "Echo", "Frost", "Gale", "Haven", "Iron", "Jade", "Kite", "Luna", "Mist", "Nova", "Oak", "Pyre", "Quinn", "Rune", "Storm", "Thorn", "Uma", "Vale", "Wind", "Xen", "Yara", "Zephyr", "Arrow", "Blaze", "Cloud", "Dusk", "Ember", "Flare", "Grove", "Hawk", "Ivy", "Jinx", "Keeper", "Lark", "Moss", "Night"}
for i = 1, 40 do
    local group = math.ceil(i / 5)
    local healthMax = math.random(70000, 120000)
    local powerMax = math.random(40000, 80000)
    local healthPct = math.random(50, 100) / 100
    local powerPct = math.random(30, 100) / 100
    local classIndex = ((i - 1) % #raidClasses) + 1
    local roleIndex = ((i - 1) % #raidRoles) + 1
    local debuffTypes = {nil, nil, nil, "Magic", "Curse", "Disease", "Poison"}  -- Mostly nil
    local debuffIndex = math.random(1, #debuffTypes)
    
    SIMULATED_RAID[i] = {
        unit = i == 1 and "player" or "raid" .. i,
        name = raidNames[i] or ("Raider" .. i),
        class = raidClasses[classIndex],
        health = math.floor(healthMax * healthPct),
        maxHealth = healthMax,
        power = math.floor(powerMax * powerPct),
        maxPower = powerMax,
        powerType = (classIndex == 4 or classIndex == 12) and 3 or 0,  -- Energy for rogues/DH
        role = roleIndex <= 2 and raidRoles[roleIndex] or "DAMAGER",
        group = group,
        debuffType = debuffTypes[debuffIndex],
    }
end
-- Ensure first 2 are tanks, next 4 are healers
SIMULATED_RAID[1].role = "TANK"
SIMULATED_RAID[2].role = "TANK"
SIMULATED_RAID[3].role = "HEALER"
SIMULATED_RAID[4].role = "HEALER"
SIMULATED_RAID[5].role = "HEALER"
SIMULATED_RAID[6].role = "HEALER"

-- ============================================================================
-- BLIZZARD PARTY FRAME HIDING
-- ============================================================================

local function HideBlizzardPartyFrames()
    -- IMPORTANT: Don't modify Blizzard secure frames during combat to avoid taint
    if InCombatLockdown() then return end
    
    -- Hide the main PartyFrame container
    if PartyFrame then
        PartyFrame:SetAlpha(0)
        PartyFrame:EnableMouse(false)
        PartyFrame:SetScale(0.001)  -- Scale down to essentially hide
        if PartyFrame.UnregisterAllEvents then
            pcall(function() PartyFrame:UnregisterAllEvents() end)
        end
        
        -- Hide all member frames and their children
        for i = 1, 4 do
            local memberFrame = PartyFrame["MemberFrame" .. i]
            if memberFrame then
                memberFrame:SetAlpha(0)
                memberFrame:EnableMouse(false)
                memberFrame:SetScale(0.001)
                if memberFrame.UnregisterAllEvents then
                    pcall(function() memberFrame:UnregisterAllEvents() end)
                end
                -- Hide all children
                for _, child in pairs({memberFrame:GetChildren()}) do
                    pcall(function()
                        child:SetAlpha(0)
                        child:Hide()
                    end)
                end
                pcall(function() memberFrame:Hide() end)
            end
        end
        
        pcall(function() PartyFrame:Hide() end)
    end
    
    -- Also hide CompactPartyFrame (raid-style party frames)
    if CompactPartyFrame then
        CompactPartyFrame:SetAlpha(0)
        CompactPartyFrame:EnableMouse(false)
        CompactPartyFrame:SetScale(0.001)
        pcall(function() CompactPartyFrame:Hide() end)
    end
    
    -- Hide CompactRaidFrameContainer if showing party as raid
    if CompactRaidFrameContainer then
        pcall(function()
            CompactRaidFrameContainer:SetAlpha(0)
            CompactRaidFrameContainer:EnableMouse(false)
        end)
    end
    
    -- Hide any EditModeManagerFrame party elements
    if EditModeManagerFrame then
        pcall(function()
            local partyFrame = EditModeManagerFrame:GetRegisteredSystemFrame(Enum.EditModeSystem.PartyFrame)
            if partyFrame then
                partyFrame:SetAlpha(0)
                partyFrame:SetScale(0.001)
            end
        end)
    end
end

-- Track if we've hooked the Blizzard frames
local blizzardPartyHooked = false

-- Hook Blizzard party frames to prevent them from showing
local function HookBlizzardPartyFrames()
    if blizzardPartyHooked then return end
    blizzardPartyHooked = true
    
    -- Hook PartyFrame's Show method
    if PartyFrame then
        hooksecurefunc(PartyFrame, "Show", function(self)
            if settings and settings.party and settings.party.enabled then
                -- Re-hide immediately
                C_Timer.After(0, function()
                    if not InCombatLockdown() then
                        HideBlizzardPartyFrames()
                    end
                end)
            end
        end)
        
        -- Also hook SetShown
        local origSetShown = PartyFrame.SetShown
        if origSetShown then
            hooksecurefunc(PartyFrame, "SetShown", function(self, shown)
                if shown and settings and settings.party and settings.party.enabled then
                    C_Timer.After(0, function()
                        if not InCombatLockdown() then
                            HideBlizzardPartyFrames()
                        end
                    end)
                end
            end)
        end
    end
    
    -- Hook CompactPartyFrame if it exists
    if CompactPartyFrame then
        hooksecurefunc(CompactPartyFrame, "Show", function(self)
            if settings and settings.party and settings.party.enabled then
                C_Timer.After(0, function()
                    if not InCombatLockdown() then
                        HideBlizzardPartyFrames()
                    end
                end)
            end
        end)
    end
end

-- ============================================================================
-- PARTY CONTAINER SYSTEM
-- ============================================================================

function UnitFrames:CreatePartyContainer()
    if partyContainer then 
        return partyContainer 
    end
    
    local ps = settings.party
    if not ps then 
        return 
    end
    
    local spacing = ps.container.spacing or 2
    local scale = ps.container.scale or 1.0
    local growthDirection = ps.container.growthDirection or "DOWN"
    
    -- Create main container
    partyContainer = CreateFrame("Frame", "TweaksUI_PartyContainer", UIParent, "BackdropTemplate")
    
    -- Set initial size based on growth direction
    if growthDirection == "DOWN" or growthDirection == "UP" then
        partyContainer:SetSize(ps.frame.width + 4, (ps.frame.height + spacing) * 5 + 4)
    else
        partyContainer:SetSize((ps.frame.width + spacing) * 5 + 4, ps.frame.height + 4)
    end
    
    partyContainer:SetPoint(ps.container.anchor, UIParent, ps.container.anchor, ps.container.x, ps.container.y)
    partyContainer:SetScale(scale)
    partyContainer:SetMovable(true)
    partyContainer:EnableMouse(true)
    partyContainer:SetClampedToScreen(true)
    partyContainer:RegisterForDrag("LeftButton")
    partyContainer:SetScript("OnDragStart", partyContainer.StartMoving)
    partyContainer:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        ps.container.anchor = point
        ps.container.x = x
        ps.container.y = y
    end)
    
    -- Create member frames
    for i, unitData in ipairs(PARTY_UNITS) do
        self:CreatePartyMemberFrame(i, unitData)
    end
    
    -- Hide Blizzard party frame completely
    HideBlizzardPartyFrames()
    
    return partyContainer
end

function UnitFrames:CreatePartyMemberFrame(index, unit)
    local ps = settings.party
    local mf = ps.frame
    local spacing = ps.container.spacing or 2
    local growthDirection = ps.container.growthDirection or "DOWN"
    
    -- Create secure button for click interactions
    local frame = CreateFrame("Button", "TweaksUI_PartyMember" .. index, partyContainer, "SecureUnitButtonTemplate, BackdropTemplate")
    frame:SetSize(mf.width, mf.height)
    
    -- Position based on growth direction
    if growthDirection == "DOWN" then
        local yOffset = -2 - ((index - 1) * (mf.height + spacing))
        frame:SetPoint("TOPLEFT", partyContainer, "TOPLEFT", 2, yOffset)
    elseif growthDirection == "UP" then
        local yOffset = 2 + ((index - 1) * (mf.height + spacing))
        frame:SetPoint("BOTTOMLEFT", partyContainer, "BOTTOMLEFT", 2, yOffset)
    elseif growthDirection == "RIGHT" then
        local xOffset = 2 + ((index - 1) * (mf.width + spacing))
        frame:SetPoint("TOPLEFT", partyContainer, "TOPLEFT", xOffset, -2)
    elseif growthDirection == "LEFT" then
        local xOffset = -2 - ((index - 1) * (mf.width + spacing))
        frame:SetPoint("TOPRIGHT", partyContainer, "TOPRIGHT", xOffset, -2)
    end
    
    -- Set unit attribute for secure clicking
    frame:SetAttribute("unit", unit)
    frame:SetAttribute("type1", "target")  -- Left click targets
    frame:SetAttribute("type2", "togglemenu")  -- Right click opens menu
    
    -- Register for clicks
    frame:RegisterForClicks("AnyUp")
    
    -- Background
    if mf.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = mf.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = mf.borderSize,
        })
        frame:SetBackdropColor(mf.bgColor[1], mf.bgColor[2], mf.bgColor[3], mf.bgColor[4])
        if mf.showBorder then
            frame:SetBackdropBorderColor(mf.borderColor[1], mf.borderColor[2], mf.borderColor[3], mf.borderColor[4])
        end
    end
    
    -- Health bar
    local healthBar = CreateFrame("StatusBar", nil, frame)
    healthBar:SetPoint("TOPLEFT", 2, -2)
    healthBar:SetPoint("TOPRIGHT", -2, -2)
    healthBar:SetHeight(ps.healthBar.height)
    healthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    healthBar:SetStatusBarColor(0.2, 0.8, 0.2)  -- Default green color
    -- Min/max will be set by UpdatePartyMemberFrame with actual health values
    frame.healthBar = healthBar
    
    -- Health bar background
    local healthBg = healthBar:CreateTexture(nil, "BACKGROUND")
    healthBg:SetAllPoints()
    healthBg:SetColorTexture(0.1, 0.1, 0.1, 0.8)
    
    -- Power bar
    local powerBar = CreateFrame("StatusBar", nil, frame)
    powerBar:SetPoint("TOPLEFT", healthBar, "BOTTOMLEFT", 0, -1)
    powerBar:SetPoint("TOPRIGHT", healthBar, "BOTTOMRIGHT", 0, -1)
    powerBar:SetHeight(ps.powerBar.height)
    powerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    powerBar:SetStatusBarColor(0.2, 0.2, 0.8)  -- Default blue color
    -- Min/max will be set by UpdatePartyMemberFrame with actual power values
    frame.powerBar = powerBar
    
    -- Power bar background
    local powerBg = powerBar:CreateTexture(nil, "BACKGROUND")
    powerBg:SetAllPoints()
    powerBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
    
    -- Portrait frame (similar to solo frames)
    local portraitFrame = CreateFrame("Frame", "TweaksUI_PartyMember" .. index .. "_Portrait", frame)
    portraitFrame:SetFrameLevel(frame:GetFrameLevel() + 2)
    
    -- 3D Portrait (PlayerModel)
    local portrait3D = CreateFrame("PlayerModel", "TweaksUI_PartyMember" .. index .. "_Portrait3D", portraitFrame)
    portrait3D:SetAllPoints()
    
    -- 2D Portrait texture
    local portrait2D = portraitFrame:CreateTexture(nil, "ARTWORK")
    portrait2D:SetAllPoints()
    
    -- Class icon texture
    local classIcon = portraitFrame:CreateTexture(nil, "ARTWORK")
    classIcon:SetAllPoints()
    
    -- Portrait background
    local portraitBg = portraitFrame:CreateTexture(nil, "BACKGROUND")
    portraitBg:SetAllPoints()
    portraitBg:SetColorTexture(0, 0, 0, 0.8)
    portraitFrame.bg = portraitBg
    
    frame.portraitFrame = portraitFrame
    frame.portrait3D = portrait3D
    frame.portrait2D = portrait2D
    frame.classIcon = classIcon
    portraitFrame:Hide()  -- Hidden by default, shown if enabled in settings
    
    -- Name text
    local nameText = healthBar:CreateFontString(nil, "OVERLAY")
    nameText:SetFont(STANDARD_TEXT_FONT, ps.nameText.fontSize, ps.nameText.fontOutline)
    nameText:SetPoint("LEFT", healthBar, "LEFT", 4, 0)
    nameText:SetJustifyH("LEFT")
    frame.nameText = nameText
    
    -- Health text
    local healthText = healthBar:CreateFontString(nil, "OVERLAY")
    healthText:SetFont(STANDARD_TEXT_FONT, ps.healthText.fontSize, "OUTLINE")
    healthText:SetPoint("RIGHT", healthBar, "RIGHT", -4, 0)
    healthText:SetJustifyH("RIGHT")
    frame.healthText = healthText
    
    -- Role icon - use a frame container for proper z-ordering
    local roleIconFrame = CreateFrame("Frame", nil, frame)
    roleIconFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
    local riSize = ps.roleIcon.size or 16
    roleIconFrame:SetSize(riSize, riSize)
    local riAnchor = ps.roleIcon.anchor or "CENTER"
    local riFrameAnchor = ps.roleIcon.frameAnchor or "TOPLEFT"
    local riOffsetX = ps.roleIcon.offsetX or 2
    local riOffsetY = ps.roleIcon.offsetY or -2
    roleIconFrame:SetPoint(riAnchor, frame, riFrameAnchor, riOffsetX, riOffsetY)
    
    local roleIcon = roleIconFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    roleIcon:SetAllPoints()
    -- Texture will be set via SetAtlas in UpdatePartyMemberFrame
    roleIconFrame:Hide()
    frame.roleIcon = roleIcon
    frame.roleIconFrame = roleIconFrame
    
    -- Raid target icon - use a frame container for proper z-ordering
    local raidTargetFrame = CreateFrame("Frame", nil, frame)
    raidTargetFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
    local rtSize = ps.raidTarget.size or 18
    raidTargetFrame:SetSize(rtSize, rtSize)
    local rtAnchor = ps.raidTarget.anchor or "CENTER"
    local rtFrameAnchor = ps.raidTarget.frameAnchor or "TOP"
    local rtOffsetX = ps.raidTarget.offsetX or 0
    local rtOffsetY = ps.raidTarget.offsetY or -2
    raidTargetFrame:SetPoint(rtAnchor, frame, rtFrameAnchor, rtOffsetX, rtOffsetY)
    
    local raidTarget = raidTargetFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    raidTarget:SetAllPoints()
    raidTarget:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
    raidTargetFrame:Hide()
    frame.raidTarget = raidTarget
    frame.raidTargetFrame = raidTargetFrame
    
    -- Cast Bar
    if ps.castBar and ps.castBar.enabled then
        local cbHeight = ps.castBar.height or 8
        local castBar = CreateFrame("StatusBar", nil, frame)
        castBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
        castBar:SetStatusBarColor(1, 0.7, 0, 1)
        castBar:SetHeight(cbHeight)
        castBar:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 1, -1)
        castBar:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", -1, -1)
        castBar:SetMinMaxValues(0, 1)
        castBar:SetValue(0)
        castBar:Hide()
        frame.castBar = castBar
        
        local castBg = castBar:CreateTexture(nil, "BACKGROUND")
        castBg:SetAllPoints()
        castBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
        
        if ps.castBar.showSpellName then
            local castText = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castText:SetPoint("LEFT", castBar, "LEFT", ps.castBar.showIcon and (cbHeight + 2) or 2, 0)
            frame.castText = castText
        end
        
        if ps.castBar.showIcon then
            local castIcon = castBar:CreateTexture(nil, "OVERLAY")
            castIcon:SetSize(cbHeight, cbHeight)
            castIcon:SetPoint("LEFT", castBar, "LEFT", 1, 0)
            frame.castIcon = castIcon
        end
        
        if ps.castBar.showTimer then
            local castTimer = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castTimer:SetPoint("RIGHT", castBar, "RIGHT", -2, 0)
            frame.castTimer = castTimer
        end
    end
    
    -- Debuff indicator container - use higher frame level
    local debuffContainer = CreateFrame("Frame", nil, frame)
    debuffContainer:SetFrameLevel(frame:GetFrameLevel() + 10)
    local diSize = ps.debuffIndicators.size or 14
    debuffContainer:SetSize(diSize * 4, diSize)
    local diPosition = ps.debuffIndicators.position or "BOTTOMRIGHT"
    local diOffsetX = ps.debuffIndicators.offsetX or -2
    local diOffsetY = ps.debuffIndicators.offsetY or 2
    debuffContainer:SetPoint(diPosition, frame, diPosition, diOffsetX, diOffsetY)
    frame.debuffContainer = debuffContainer
    
    -- Debuff type colors (same as solo frames)
    local DEBUFF_TYPE_COLORS = {
        Magic = {0.2, 0.6, 1.0},     -- Blue
        Curse = {0.6, 0.0, 1.0},     -- Purple
        Disease = {0.6, 0.4, 0.0},   -- Brown
        Poison = {0.0, 0.6, 0.0},    -- Green
    }
    
    -- Create debuff indicator icons using colored frames (same approach as solo)
    frame.debuffIndicators = {}
    local debuffTypes = {"Magic", "Curse", "Disease", "Poison"}
    for j, debuffType in ipairs(debuffTypes) do
        local indicator = CreateFrame("Frame", nil, debuffContainer, "BackdropTemplate")
        indicator:SetSize(diSize, diSize)
        indicator:SetPoint("RIGHT", debuffContainer, "RIGHT", -((j-1) * (diSize + 1)), 0)
        indicator:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        local color = DEBUFF_TYPE_COLORS[debuffType]
        indicator:SetBackdropColor(color[1], color[2], color[3], 1)
        indicator:SetBackdropBorderColor(0, 0, 0, 1)
        indicator:Hide()
        frame.debuffIndicators[debuffType] = indicator
    end
    
    -- Highlight on mouseover
    local highlight = frame:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints()
    highlight:SetColorTexture(1, 1, 1, 0.1)
    
    -- Store unit reference
    frame.unit = unit
    frame.index = index
    
    -- Tooltip - custom tooltip to avoid secret value errors with SetUnit
    frame:SetScript("OnEnter", function(self)
        local showTooltip = false
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        
        local isSimulating = simulationMode or (currentOpenPanel == "party")
        if isSimulating and not UnitExists(self.unit) then
            local simData = SIMULATED_PARTY[self.index]
            if simData then
                local classColor = RAID_CLASS_COLORS[simData.class]
                if classColor then
                    GameTooltip:AddLine(simData.name, classColor.r, classColor.g, classColor.b)
                else
                    GameTooltip:AddLine(simData.name, 1, 1, 1)
                end
                GameTooltip:AddLine("Level 80 " .. simData.class, 0.7, 0.7, 0.7)
                if simData.role and simData.role ~= "NONE" then
                    GameTooltip:AddLine(simData.role, 0.5, 0.5, 0.5)
                end
                showTooltip = true
            end
        elseif UnitExists(self.unit) then
            -- Build custom tooltip to avoid secret value issues
            local name = UnitName(self.unit) or "Unknown"
            local _, class = UnitClass(self.unit)
            local level = UnitLevel(self.unit) or "??"
            local role = UnitGroupRolesAssigned(self.unit)
            
            local classColor = class and RAID_CLASS_COLORS[class]
            if classColor then
                GameTooltip:AddLine(name, classColor.r, classColor.g, classColor.b)
            else
                GameTooltip:AddLine(name, 1, 1, 1)
            end
            
            local classDisplayName = class and UnitClass(self.unit) or "Unknown"
            GameTooltip:AddLine("Level " .. level .. " " .. classDisplayName, 0.7, 0.7, 0.7)
            
            if role and role ~= "NONE" then
                local roleNames = {TANK = "Tank", HEALER = "Healer", DAMAGER = "Damage"}
                GameTooltip:AddLine(roleNames[role] or role, 0.5, 0.5, 0.5)
            end
            showTooltip = true
        end
        
        if showTooltip then
            GameTooltip:Show()
        end
    end)
    frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    partyMemberFrames[index] = frame
    return frame
end

function UnitFrames:UpdatePartyMemberFrame(index)
    local frame = partyMemberFrames[index]
    if not frame then return end
    
    local ps = settings.party
    if not ps then return end
    
    local unit = frame.unit
    local panelOpen = currentOpenPanel == "party"
    local isSimulating = simulationMode or panelOpen
    local simData = isSimulating and SIMULATED_PARTY[index] or nil
    local unitExists = UnitExists(unit) or (isSimulating and simData)
    
    -- For player slot, always show if in a group or simulating
    if unit == "player" then
        unitExists = IsInGroup() or isSimulating
    end
    
    if not unitExists then
        -- Only hide outside of combat (secure frame restriction)
        if not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    -- Only show outside of combat (secure frame restriction)
    if not InCombatLockdown() then
        frame:Show()
    end
    
    -- Get unit data - only non-secret values stored
    local name, class, role, powerType
    local healthPercent = 100  -- Default for simulation
    
    if isSimulating and simData then
        -- Use simulated data in simulation mode
        powerType = simData.powerType or 0
        name = simData.name or "Unknown"
        class = simData.class or "WARRIOR"
        role = simData.role or "NONE"
        -- Calculate percent for simulation (safe - not secret values)
        if simData.maxHealth and simData.maxHealth > 0 then
            healthPercent = (simData.health / simData.maxHealth) * 100
        end
    elseif UnitExists(unit) then
        powerType = UnitPowerType(unit) or 0
        name = UnitName(unit) or "Unknown"
        _, class = UnitClass(unit)
        class = class or "WARRIOR"
        role = UnitGroupRolesAssigned(unit) or "NONE"
        -- Use WoW's built-in percent function (avoids secret value arithmetic)
        if UnitHealthPercent then
            local pct = UnitHealthPercent(unit, false, true)
            if type(pct) == "number" then
                healthPercent = pct
            end
        end
    else
        -- Unit doesn't exist - hide frame (only outside combat)
        if not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    -- Update frame size from settings (only outside combat - secure frame restriction)
    local mf = ps.frame
    if mf and not InCombatLockdown() then
        frame:SetSize(mf.width, mf.height)
    end
    
    -- Calculate portrait offset for bar positioning
    local portraitOffset = 0
    local pps = ps.portrait
    if pps and pps.enabled and frame.portraitFrame then
        local portraitSize = pps.size or 32
        local portraitPosition = pps.position or "left"
        if portraitPosition == "left" and not pps.outside then
            portraitOffset = portraitSize + 2
        end
    end
    
    -- Update health bar size and position
    if frame.healthBar and ps.healthBar then
        frame.healthBar:SetHeight(ps.healthBar.height or 20)
        frame.healthBar:ClearAllPoints()
        frame.healthBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 2 + portraitOffset, -2)
        frame.healthBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -2, -2)
        
        -- Update texture from settings
        local texturePath = "Interface\\TargetingFrame\\UI-StatusBar"
        if LibSharedMedia and ps.healthBar.texture then
            texturePath = LibSharedMedia:Fetch("statusbar", ps.healthBar.texture) or texturePath
        end
        frame.healthBar:SetStatusBarTexture(texturePath)
    end
    
    -- Update power bar size and position
    if frame.powerBar and ps.powerBar then
        frame.powerBar:SetHeight(ps.powerBar.height or 6)
        frame.powerBar:ClearAllPoints()
        frame.powerBar:SetPoint("TOPLEFT", frame.healthBar, "BOTTOMLEFT", 0, -1)
        frame.powerBar:SetPoint("TOPRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, -1)
        
        -- Update texture from settings
        local texturePath = "Interface\\TargetingFrame\\UI-StatusBar"
        if LibSharedMedia and ps.powerBar.texture then
            texturePath = LibSharedMedia:Fetch("statusbar", ps.powerBar.texture) or texturePath
        end
        frame.powerBar:SetStatusBarTexture(texturePath)
    end
    
    -- Update health bar - pass values directly to StatusBar
    local health, maxHealth
    if isSimulating and simData then
        health = simData.health
        maxHealth = simData.maxHealth
    else
        health = UnitHealth(unit)
        maxHealth = UnitHealthMax(unit)
    end
    frame.healthBar:SetMinMaxValues(0, maxHealth)
    frame.healthBar:SetValue(health)
    
    -- Health bar color - use class color (no arithmetic needed)
    if ps.healthBar and ps.healthBar.colorMode == "class" and class then
        local color = RAID_CLASS_COLORS[class]
        if color then
            frame.healthBar:SetStatusBarColor(color.r, color.g, color.b)
        else
            frame.healthBar:SetStatusBarColor(0.5, 0.5, 0.5)
        end
    else
        -- Default green if not class-colored
        frame.healthBar:SetStatusBarColor(0, 0.8, 0)
    end
    
    -- Update power bar - pass values directly to StatusBar
    local power, maxPower
    if isSimulating and simData then
        power = simData.power
        maxPower = simData.maxPower
    else
        power = UnitPower(unit)
        maxPower = UnitPowerMax(unit)
    end
    frame.powerBar:SetMinMaxValues(0, maxPower)
    frame.powerBar:SetValue(power)
    
    -- Power bar color
    local powerColor = PowerBarColor and PowerBarColor[powerType]
    if powerColor then
        frame.powerBar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
    else
        frame.powerBar:SetStatusBarColor(0.2, 0.2, 0.8)
    end
    
    -- Update name text with dynamic settings
    if frame.nameText then
        local ns = ps.nameText
        if ns and ns.enabled then
            -- Update font
            local fontSize = ns.fontSize or 10
            local fontOutline = ns.fontOutline or "OUTLINE"
            frame.nameText:SetFont(STANDARD_TEXT_FONT, fontSize, fontOutline)
            
            -- Update position
            frame.nameText:ClearAllPoints()
            local anchor = ns.frameAnchor or "LEFT"
            local offsetX = ns.offsetX or 4
            local offsetY = ns.offsetY or 0
            if ns.anchorToHealthBar then
                frame.nameText:SetPoint(anchor, frame.healthBar, anchor, offsetX, offsetY)
            else
                frame.nameText:SetPoint(anchor, frame, anchor, offsetX, offsetY)
            end
            frame.nameText:SetJustifyH(ns.hAlign or "LEFT")
            
            -- Set text
            frame.nameText:SetText(name or "")
            
            -- Set color
            if ns.colorMode == "class" and class then
                local color = RAID_CLASS_COLORS[class]
                if color then
                    frame.nameText:SetTextColor(color.r, color.g, color.b)
                else
                    frame.nameText:SetTextColor(1, 1, 1)
                end
            elseif ns.customColor then
                frame.nameText:SetTextColor(ns.customColor[1] or 1, ns.customColor[2] or 1, ns.customColor[3] or 1, ns.customColor[4] or 1)
            else
                frame.nameText:SetTextColor(1, 1, 1)
            end
            frame.nameText:Show()
        else
            frame.nameText:Hide()
        end
    end
    
    -- Update health text with proper formatting
    if frame.healthText then
        local hs = ps.healthText
        if hs and hs.enabled then
            -- Update font
            local fontSize = hs.fontSize or 10
            local fontOutline = hs.fontOutline or "OUTLINE"
            frame.healthText:SetFont(STANDARD_TEXT_FONT, fontSize, fontOutline)
            
            -- Update position
            frame.healthText:ClearAllPoints()
            local anchor = hs.hAlign or "RIGHT"
            local offsetX = hs.offsetX or -4
            local offsetY = hs.offsetY or 0
            frame.healthText:SetPoint(anchor, frame.healthBar, anchor, offsetX, offsetY)
            frame.healthText:SetJustifyH(anchor)
            
            -- Format health text based on settings
            local format = hs.format or "percent"
            local healthStr = ""
            
            if UnitIsDeadOrGhost(unit) and not isSimulating then
                healthStr = "Dead"
            else
                if format == "percent" then
                    healthStr = string.format("%.0f%%", healthPercent)
                elseif format == "current" then
                    if isSimulating and simData then
                        healthStr = AbbreviateNumber(simData.health)
                    else
                        healthStr = AbbreviateLargeNumbers(UnitHealth(unit)) or ""
                    end
                elseif format == "both" or format == "current_percent" then
                    local currentStr
                    if isSimulating and simData then
                        currentStr = AbbreviateNumber(simData.health)
                    else
                        currentStr = AbbreviateLargeNumbers(UnitHealth(unit)) or ""
                    end
                    healthStr = currentStr .. " - " .. string.format("%.0f%%", healthPercent)
                elseif format == "deficit" then
                    -- Deficit requires arithmetic - only safe with simulated data
                    if isSimulating and simData then
                        if healthPercent < 100 then
                            healthStr = string.format("-%.0f%%", 100 - healthPercent)
                        end
                    else
                        -- For real units, show current health instead
                        healthStr = AbbreviateLargeNumbers(UnitHealth(unit)) or ""
                    end
                else
                    -- Default to percent
                    healthStr = string.format("%.0f%%", healthPercent)
                end
            end
            
            frame.healthText:SetText(healthStr)
            
            -- Set color based on health percentage - requires arithmetic
            if hs.colorByHealth then
                if isSimulating and simData then
                    local pct = healthPercent / 100
                    frame.healthText:SetTextColor(1 - pct, pct, 0)
                else
                    -- For real units, use white (arithmetic on secret values fails)
                    frame.healthText:SetTextColor(1, 1, 1)
                end
            else
                frame.healthText:SetTextColor(1, 1, 1)
            end
            
            frame.healthText:Show()
        else
            frame.healthText:Hide()
        end
    end
    
    -- Update role icon using Blizzard's atlas system (most reliable method)
    if ps.roleIcon and ps.roleIcon.enabled and role and role ~= "NONE" then
        -- Dynamically update size and position from settings
        local riSize = ps.roleIcon.size or 16
        local riAnchor = ps.roleIcon.anchor or "CENTER"
        local riFrameAnchor = ps.roleIcon.frameAnchor or "TOPLEFT"
        local riOffsetX = ps.roleIcon.offsetX or 2
        local riOffsetY = ps.roleIcon.offsetY or -2
        
        if frame.roleIconFrame then
            frame.roleIconFrame:SetSize(riSize, riSize)
            frame.roleIconFrame:ClearAllPoints()
            frame.roleIconFrame:SetPoint(riAnchor, frame, riFrameAnchor, riOffsetX, riOffsetY)
        end
        
        -- Try multiple atlas names in order of preference
        local atlasOptions = {
            TANK = {
                "groupfinder-icon-role-large-tank",
                "roleicon-tank",
            },
            HEALER = {
                "groupfinder-icon-role-large-heal",
                "groupfinder-icon-role-large-healer",
                "roleicon-healer",
                "roleicon-heal",
            },
            DAMAGER = {
                "groupfinder-icon-role-large-dps",
                "groupfinder-icon-role-large-damage",
                "roleicon-dps",
            },
        }
        
        local options = atlasOptions[role]
        local atlasSet = false
        
        if options then
            for _, atlasName in ipairs(options) do
                local success = pcall(function()
                    frame.roleIcon:SetAtlas(atlasName, true)
                end)
                -- Check if atlas was actually set (GetAtlas returns the name if successful)
                if success then
                    local currentAtlas = frame.roleIcon:GetAtlas()
                    if currentAtlas and currentAtlas ~= "" then
                        atlasSet = true
                        break
                    end
                end
            end
        end
        
        if atlasSet then
            frame.roleIcon:Show()
            if frame.roleIconFrame then frame.roleIconFrame:Show() end
        else
            frame.roleIcon:Hide()
            if frame.roleIconFrame then frame.roleIconFrame:Hide() end
        end
    else
        if frame.roleIcon then frame.roleIcon:Hide() end
        if frame.roleIconFrame then frame.roleIconFrame:Hide() end
    end
    
    -- Update portrait
    if frame.portraitFrame then
        local pps = ps.portrait
        if pps and pps.enabled then
            local portraitSize = pps.size or 32
            local portraitPosition = pps.position or "left"
            local portraitOffsetX = pps.offsetX or 0
            local portraitOffsetY = pps.offsetY or 0
            
            -- Position and size portrait
            frame.portraitFrame:SetSize(portraitSize, portraitSize)
            frame.portraitFrame:ClearAllPoints()
            if portraitPosition == "left" then
                frame.portraitFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 2 + portraitOffsetX, -2 + portraitOffsetY)
            else
                frame.portraitFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -2 + portraitOffsetX, -2 + portraitOffsetY)
            end
            
            -- Show appropriate portrait type
            frame.portrait3D:Hide()
            frame.portrait2D:Hide()
            frame.classIcon:Hide()
            
            local portraitMode = string.lower(pps.mode or "3d")
            
            if isSimulating and not UnitExists(unit) then
                -- Simulation mode - use class icon
                local simData = SIMULATED_PARTY[frame.index]
                if simData and simData.class then
                    frame.classIcon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
                    local coords = CLASS_ICON_TCOORDS[simData.class]
                    if coords then
                        frame.classIcon:SetTexCoord(unpack(coords))
                    end
                    frame.classIcon:Show()
                end
            elseif UnitExists(unit) then
                if portraitMode == "3d" then
                    frame.portrait3D:SetUnit(unit)
                    frame.portrait3D:SetCamera(0)
                    frame.portrait3D:Show()
                elseif portraitMode == "2d" then
                    SetPortraitTexture(frame.portrait2D, unit)
                    frame.portrait2D:SetTexCoord(0, 1, 0, 1)  -- Reset tex coords
                    frame.portrait2D:Show()
                elseif portraitMode == "class" then
                    frame.classIcon:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
                    local _, unitClass = UnitClass(unit)
                    if unitClass then
                        local coords = CLASS_ICON_TCOORDS[unitClass]
                        if coords then
                            frame.classIcon:SetTexCoord(unpack(coords))
                        end
                    end
                    frame.classIcon:Show()
                elseif portraitMode == "none" then
                    -- None mode - hide all portrait elements
                    frame.portrait3D:Hide()
                    frame.portrait2D:Hide()
                    frame.classIcon:Hide()
                end
            end
            
            -- Only show portrait frame if mode is not "none"
            if portraitMode ~= "none" then
                frame.portraitFrame:Show()
            else
                frame.portraitFrame:Hide()
            end
        else
            frame.portraitFrame:Hide()
        end
    end
    
    -- Update raid target
    if ps.raidTarget and ps.raidTarget.enabled then
        -- Dynamically update size and position from settings
        local rtSize = ps.raidTarget.size or 18
        local rtAnchor = ps.raidTarget.anchor or "CENTER"
        local rtFrameAnchor = ps.raidTarget.frameAnchor or "TOP"
        local rtOffsetX = ps.raidTarget.offsetX or 0
        local rtOffsetY = ps.raidTarget.offsetY or -2
        
        if frame.raidTargetFrame then
            frame.raidTargetFrame:SetSize(rtSize, rtSize)
            frame.raidTargetFrame:ClearAllPoints()
            frame.raidTargetFrame:SetPoint(rtAnchor, frame, rtFrameAnchor, rtOffsetX, rtOffsetY)
        end
        
        local raidIndex = GetRaidTargetIndex(unit)
        if raidIndex then
            SetRaidTargetIconTexture(frame.raidTarget, raidIndex)
            frame.raidTarget:Show()
            if frame.raidTargetFrame then frame.raidTargetFrame:Show() end
        else
            frame.raidTarget:Hide()
            if frame.raidTargetFrame then frame.raidTargetFrame:Hide() end
        end
    else
        frame.raidTarget:Hide()
        if frame.raidTargetFrame then frame.raidTargetFrame:Hide() end
    end
    
    -- Update debuff indicators
    if ps.debuffIndicators and ps.debuffIndicators.enabled then
        -- Dynamically update size and position from settings
        local diSize = ps.debuffIndicators.size or 14
        local diPosition = ps.debuffIndicators.position or "BOTTOMRIGHT"
        local diOffsetX = ps.debuffIndicators.offsetX or -2
        local diOffsetY = ps.debuffIndicators.offsetY or 2
        
        if frame.debuffContainer then
            frame.debuffContainer:SetSize(diSize * 4, diSize)
            frame.debuffContainer:ClearAllPoints()
            frame.debuffContainer:SetPoint(diPosition, frame, diPosition, diOffsetX, diOffsetY)
            frame.debuffContainer:Show()  -- Make sure container is visible
        end
        
        -- Hide all first
        for debuffType, indicator in pairs(frame.debuffIndicators) do
            indicator:Hide()
        end
        
        -- Check for debuffs (simulated or real)
        local debuffsFound = {}
        if isSimulating and simData and simData.debuffType then
            debuffsFound[simData.debuffType] = true
        elseif UnitExists(unit) then
            -- Use AuraUtil.ForEachAura for modern debuff iteration
            local function CheckDebuff(auraData)
                if auraData and auraData.dispelName then
                    local dispelName = auraData.dispelName
                    if dispelName == "Magic" or dispelName == "Curse" or 
                       dispelName == "Disease" or dispelName == "Poison" then
                        debuffsFound[dispelName] = true
                    end
                end
            end
            
            -- Try AuraUtil.ForEachAura first (modern API)
            if AuraUtil and AuraUtil.ForEachAura then
                AuraUtil.ForEachAura(unit, "HARMFUL", nil, CheckDebuff)
            else
                -- Fallback to manual iteration
                for i = 1, 40 do
                    local auraData = C_UnitAuras.GetDebuffDataByIndex(unit, i)
                    if not auraData then break end
                    CheckDebuff(auraData)
                end
            end
        end
        
        -- Show found debuffs - stack them compactly like solo frames
        local xOffset = 0
        local debuffTypes = {"Magic", "Curse", "Disease", "Poison"}
        for _, debuffType in ipairs(debuffTypes) do
            local indicator = frame.debuffIndicators[debuffType]
            if indicator and debuffsFound[debuffType] then
                local shouldShow = false
                if debuffType == "Magic" and ps.debuffIndicators.showMagic then shouldShow = true
                elseif debuffType == "Curse" and ps.debuffIndicators.showCurse then shouldShow = true
                elseif debuffType == "Disease" and ps.debuffIndicators.showDisease then shouldShow = true
                elseif debuffType == "Poison" and ps.debuffIndicators.showPoison then shouldShow = true
                end
                
                if shouldShow then
                    indicator:SetSize(diSize, diSize)
                    indicator:ClearAllPoints()
                    indicator:SetPoint("RIGHT", frame.debuffContainer, "RIGHT", -xOffset, 0)
                    indicator:Show()
                    xOffset = xOffset + diSize + 1
                end
            end
        end
    end
    
    -- Update cast bar
    if frame.castBar and ps.castBar and ps.castBar.enabled then
        local unitID = unit
        local cbs = ps.castBar
        
        -- Handle simulation mode
        if isSimulating and not UnitExists(unitID) then
            -- Show a simulated cast bar on the first frame only
            if frame.index == 1 then
                frame.castBar:SetMinMaxValues(0, 3)
                frame.castBar:SetValue(1.5)
                if frame.castText then 
                    if cbs.showSpellName then
                        frame.castText:SetText("Simulated Cast")
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                if frame.castTimer then 
                    if cbs.showTimer then
                        frame.castTimer:SetText("1.5")
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                if frame.castIcon then 
                    if cbs.showIcon then
                        frame.castIcon:SetTexture("Interface\\Icons\\Spell_Nature_Heal")
                        frame.castIcon:Show()
                    else
                        frame.castIcon:Hide()
                    end
                end
                frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        else
            local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(unitID)
            if not castName then
                castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(unitID)
            end
            
            if castName then
                local duration = (endTime - startTime) / 1000
                local elapsed = (GetTime() * 1000 - startTime) / 1000
                frame.castBar:SetMinMaxValues(0, duration)
                frame.castBar:SetValue(elapsed)
                
                if frame.castText then
                    if cbs.showSpellName then
                        frame.castText:SetText(castName)
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                
                if frame.castIcon then
                    if cbs.showIcon and spellID then
                        local spellTexture = GetSpellTextureByID(spellID)
                        if spellTexture then
                            frame.castIcon:SetTexture(spellTexture)
                            frame.castIcon:Show()
                        end
                    else
                        frame.castIcon:Hide()
                    end
                end
                
                if frame.castTimer then
                    if cbs.showTimer then
                        frame.castTimer:SetText(string.format("%.1f", duration - elapsed))
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                
                if notInterruptible then
                    frame.castBar:SetStatusBarColor(0.7, 0.7, 0.7, 1)
                else
                    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                end
                
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        end
    elseif frame.castBar then
        frame.castBar:Hide()
    end
end

function UnitFrames:UpdatePartyFrames()
    if not partyContainer then return end
    
    local editModeOpen = EditModeManagerFrame and EditModeManagerFrame:IsShown()
    local panelOpen = currentOpenPanel == "party"
    
    -- If not enabled AND not in Edit Mode AND panel not open, hide and return
    if not settings.party or not settings.party.enabled then
        if not editModeOpen and not panelOpen then
            if not InCombatLockdown() then
                partyContainer:Hide()
            end
            return
        end
    end
    
    -- Keep Blizzard party frames hidden (already protected internally)
    HideBlizzardPartyFrames()
    
    -- Enable simulation if panel is open or edit mode is open without a real group
    if panelOpen or (editModeOpen and not IsInGroup()) then
        simulationMode = true
    end
    
    local inGroup = IsInGroup() or simulationMode or panelOpen
    
    if not inGroup and not editModeOpen then
        if not InCombatLockdown() then
            partyContainer:Hide()
        end
        return
    end
    
    if not InCombatLockdown() then
        partyContainer:Show()
    end
    
    local ps = settings.party
    local mf = ps.frame
    local spacing = ps.container.spacing or 2
    local scale = ps.container.scale or 1.0
    local growthDirection = ps.container.growthDirection or "DOWN"
    
    -- Only update layout/positions outside of combat (secure frame restrictions)
    if not InCombatLockdown() then
        -- Apply scale to container
        partyContainer:SetScale(scale)
        
        -- Update container position from settings
        partyContainer:ClearAllPoints()
        partyContainer:SetPoint(ps.container.anchor, UIParent, ps.container.anchor, ps.container.x, ps.container.y)
        
        -- Update each member frame position
        for i = 1, 5 do
            local frame = partyMemberFrames[i]
            if frame then
                -- Update frame position based on growth direction and spacing
                frame:ClearAllPoints()
                if growthDirection == "DOWN" then
                    local yOffset = -2 - ((i - 1) * (mf.height + spacing))
                    frame:SetPoint("TOPLEFT", partyContainer, "TOPLEFT", 2, yOffset)
                elseif growthDirection == "UP" then
                    local yOffset = 2 + ((i - 1) * (mf.height + spacing))
                    frame:SetPoint("BOTTOMLEFT", partyContainer, "BOTTOMLEFT", 2, yOffset)
                elseif growthDirection == "RIGHT" then
                    local xOffset = 2 + ((i - 1) * (mf.width + spacing))
                    frame:SetPoint("TOPLEFT", partyContainer, "TOPLEFT", xOffset, -2)
                elseif growthDirection == "LEFT" then
                    local xOffset = -2 - ((i - 1) * (mf.width + spacing))
                    frame:SetPoint("TOPRIGHT", partyContainer, "TOPRIGHT", xOffset, -2)
                end
            end
        end
        
        -- Resize container based on visible frames
        local visibleCount = 0
        for i = 1, 5 do
            if partyMemberFrames[i] and partyMemberFrames[i]:IsShown() then
                visibleCount = visibleCount + 1
            end
        end
        
        -- Set container size based on growth direction
        if growthDirection == "DOWN" or growthDirection == "UP" then
            local height = (mf.height + spacing) * visibleCount + 4
            partyContainer:SetSize(mf.width + 4, math.max(height, mf.height + 4))
        else
            local width = (mf.width + spacing) * visibleCount + 4
            partyContainer:SetSize(math.max(width, mf.width + 4), mf.height + 4)
        end
    end
    
    -- Always update frame content (health, power, names, etc.) - this is safe during combat
    for i = 1, 5 do
        self:UpdatePartyMemberFrame(i)
    end
end

function UnitFrames:DestroyPartyContainer()
    -- Can't destroy secure frames during combat
    if InCombatLockdown() then return end
    
    if partyContainer then
        partyContainer:Hide()
        partyContainer = nil
    end
    for i, frame in pairs(partyMemberFrames) do
        if frame then
            frame:Hide()
            frame:SetParent(nil)
        end
    end
    partyMemberFrames = {}
    
    -- Restore Blizzard party frame
    if PartyFrame then
        PartyFrame:SetAlpha(1)
        PartyFrame:EnableMouse(true)
    end
end

-- ============================================================================
-- RAID FRAMES
-- ============================================================================

local function HideBlizzardRaidFrames()
    if InCombatLockdown() then return end
    
    -- Hide CompactRaidFrameContainer
    if CompactRaidFrameContainer then
        CompactRaidFrameContainer:SetAlpha(0)
        CompactRaidFrameContainer:EnableMouse(false)
        CompactRaidFrameContainer:SetScale(0.001)
    end
    
    -- Hide CompactRaidFrameManager
    if CompactRaidFrameManager then
        CompactRaidFrameManager:SetAlpha(0)
        CompactRaidFrameManager:EnableMouse(false)
    end
end

local function ShowBlizzardRaidFrames()
    if InCombatLockdown() then return end
    
    if CompactRaidFrameContainer then
        CompactRaidFrameContainer:SetAlpha(1)
        CompactRaidFrameContainer:EnableMouse(true)
        CompactRaidFrameContainer:SetScale(1)
    end
    
    if CompactRaidFrameManager then
        CompactRaidFrameManager:SetAlpha(1)
        CompactRaidFrameManager:EnableMouse(true)
    end
end

-- Helper to get the active raid layout settings based on raid size
local function GetRaidLayoutSettings(raidSize)
    local rs = settings.raid
    if not rs then return nil, nil end
    
    local threshold = rs.sizeThreshold or 20
    if raidSize <= threshold then
        return rs.small, "small"
    else
        return rs.large, "large"
    end
end

-- Helper to get current raid size
local function GetCurrentRaidSize()
    if simulationMode then
        -- In simulation, use 40 for large layout testing, or could be configurable
        return 40
    end
    return GetNumGroupMembers()
end

function UnitFrames:CreateRaidContainer(sizeType)
    sizeType = sizeType or "small"
    
    local container, memberFrames
    if sizeType == "small" then
        if raidSmallContainer then return raidSmallContainer end
        container = nil
        memberFrames = raidSmallMemberFrames
    else
        if raidLargeContainer then return raidLargeContainer end
        container = nil
        memberFrames = raidLargeMemberFrames
    end
    
    local rs = settings.raid
    if not rs then return end
    
    local layoutSettings = rs[sizeType]
    if not layoutSettings then return end
    
    local containerSettings = layoutSettings.container
    local scale = containerSettings.scale or 1.0
    
    -- Create main container
    local frameName = "TweaksUI_RaidContainer_" .. sizeType
    container = CreateFrame("Frame", frameName, UIParent, "BackdropTemplate")
    container:SetPoint(containerSettings.anchor or "CENTER", UIParent, containerSettings.anchor or "CENTER", containerSettings.x or 0, containerSettings.y or 0)
    container:SetScale(scale)
    container:SetMovable(true)
    container:EnableMouse(true)
    container:SetClampedToScreen(true)
    container:RegisterForDrag("LeftButton")
    container:SetScript("OnDragStart", container.StartMoving)
    container:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        containerSettings.anchor = point
        containerSettings.x = x
        containerSettings.y = y
    end)
    
    -- Initial size will be calculated by UpdateRaidFrames
    container:SetSize(400, 200)
    container.sizeType = sizeType
    
    -- Store reference
    if sizeType == "small" then
        raidSmallContainer = container
    else
        raidLargeContainer = container
    end
    
    -- Create member frames
    local maxFrames = sizeType == "small" and 20 or 40
    for i = 1, maxFrames do
        self:CreateRaidMemberFrame(sizeType, i)
    end
    
    -- Hide Blizzard raid frames
    HideBlizzardRaidFrames()
    
    return container
end

function UnitFrames:CreateRaidMemberFrame(sizeType, index)
    local rs = settings.raid
    if not rs then return end
    
    local layoutSettings = rs[sizeType]
    if not layoutSettings then return end
    
    local mf = layoutSettings.frame
    local container = sizeType == "small" and raidSmallContainer or raidLargeContainer
    local memberFrames = sizeType == "small" and raidSmallMemberFrames or raidLargeMemberFrames
    
    if not container then return end
    
    -- Create secure button for click interactions
    local frameName = "TweaksUI_RaidMember_" .. sizeType .. "_" .. index
    local frame = CreateFrame("Button", frameName, container, "SecureUnitButtonTemplate, BackdropTemplate")
    frame:SetSize(mf.width, mf.height)
    
    -- Set unit attribute (will be updated dynamically)
    local unit = "raid" .. index
    frame:SetAttribute("unit", unit)
    frame.unit = unit  -- Store for easy access
    frame:SetAttribute("type1", "target")
    frame:SetAttribute("type2", "togglemenu")
    frame:RegisterForClicks("AnyUp")
    
    -- Background
    if mf.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = mf.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = mf.borderSize or 1,
        })
        frame:SetBackdropColor(mf.bgColor[1], mf.bgColor[2], mf.bgColor[3], mf.bgColor[4])
        if mf.showBorder then
            frame:SetBackdropBorderColor(mf.borderColor[1], mf.borderColor[2], mf.borderColor[3], mf.borderColor[4])
        end
    end
    
    -- Health bar
    local healthBar = CreateFrame("StatusBar", nil, frame)
    healthBar:SetPoint("TOPLEFT", 1, -1)
    healthBar:SetPoint("TOPRIGHT", -1, -1)
    healthBar:SetHeight(layoutSettings.healthBar.height)
    healthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    healthBar:SetStatusBarColor(0.2, 0.8, 0.2)
    frame.healthBar = healthBar
    
    local healthBg = healthBar:CreateTexture(nil, "BACKGROUND")
    healthBg:SetAllPoints()
    healthBg:SetColorTexture(0.1, 0.1, 0.1, 0.8)
    
    -- Power bar
    local powerBar = CreateFrame("StatusBar", nil, frame)
    powerBar:SetPoint("TOPLEFT", healthBar, "BOTTOMLEFT", 0, -1)
    powerBar:SetPoint("TOPRIGHT", healthBar, "BOTTOMRIGHT", 0, -1)
    powerBar:SetHeight(layoutSettings.powerBar.height)
    powerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    powerBar:SetStatusBarColor(0.2, 0.2, 0.8)
    frame.powerBar = powerBar
    
    local powerBg = powerBar:CreateTexture(nil, "BACKGROUND")
    powerBg:SetAllPoints()
    powerBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
    
    -- Name text
    local nameText = healthBar:CreateFontString(nil, "OVERLAY")
    nameText:SetFont(STANDARD_TEXT_FONT, layoutSettings.nameText.fontSize, layoutSettings.nameText.fontOutline)
    nameText:SetPoint("LEFT", healthBar, "LEFT", 2, 0)
    nameText:SetJustifyH("LEFT")
    frame.nameText = nameText
    
    -- Health text
    local healthText = healthBar:CreateFontString(nil, "OVERLAY")
    healthText:SetFont(STANDARD_TEXT_FONT, layoutSettings.healthText.fontSize, "OUTLINE")
    healthText:SetPoint("RIGHT", healthBar, "RIGHT", -2, 0)
    healthText:SetJustifyH("RIGHT")
    frame.healthText = healthText
    
    -- Role icon
    local roleIconFrame = CreateFrame("Frame", nil, frame)
    roleIconFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
    local riSize = layoutSettings.roleIcon.size or 12
    roleIconFrame:SetSize(riSize, riSize)
    roleIconFrame:SetPoint(layoutSettings.roleIcon.anchor or "CENTER", frame, layoutSettings.roleIcon.frameAnchor or "TOPLEFT", layoutSettings.roleIcon.offsetX or 1, layoutSettings.roleIcon.offsetY or -1)
    
    local roleIcon = roleIconFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    roleIcon:SetAllPoints()
    roleIconFrame:Hide()
    frame.roleIcon = roleIcon
    frame.roleIconFrame = roleIconFrame
    
    -- Raid target icon
    local raidTargetFrame = CreateFrame("Frame", nil, frame)
    raidTargetFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
    local rtSize = layoutSettings.raidTarget.size or 14
    raidTargetFrame:SetSize(rtSize, rtSize)
    raidTargetFrame:SetPoint(layoutSettings.raidTarget.anchor or "CENTER", frame, layoutSettings.raidTarget.frameAnchor or "TOP", layoutSettings.raidTarget.offsetX or 0, layoutSettings.raidTarget.offsetY or -2)
    
    local raidTarget = raidTargetFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    raidTarget:SetAllPoints()
    raidTarget:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
    raidTargetFrame:Hide()
    frame.raidTarget = raidTarget
    frame.raidTargetFrame = raidTargetFrame
    
    -- Debuff indicators
    local debuffContainer = CreateFrame("Frame", nil, frame)
    debuffContainer:SetFrameLevel(frame:GetFrameLevel() + 10)
    local diSize = layoutSettings.debuffIndicators.size or 10
    debuffContainer:SetSize(diSize * 4, diSize)
    debuffContainer:SetPoint(layoutSettings.debuffIndicators.position or "BOTTOMRIGHT", frame, layoutSettings.debuffIndicators.position or "BOTTOMRIGHT", layoutSettings.debuffIndicators.offsetX or -1, layoutSettings.debuffIndicators.offsetY or 1)
    frame.debuffContainer = debuffContainer
    
    local DEBUFF_TYPE_COLORS = {
        Magic = {0.2, 0.6, 1.0},
        Curse = {0.6, 0.0, 1.0},
        Disease = {0.6, 0.4, 0.0},
        Poison = {0.0, 0.6, 0.0},
    }
    
    frame.debuffIndicators = {}
    local debuffTypes = {"Magic", "Curse", "Disease", "Poison"}
    for j, debuffType in ipairs(debuffTypes) do
        local indicator = CreateFrame("Frame", nil, debuffContainer, "BackdropTemplate")
        indicator:SetSize(diSize, diSize)
        indicator:SetPoint("RIGHT", debuffContainer, "RIGHT", -((j-1) * (diSize + 1)), 0)
        indicator:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        local color = DEBUFF_TYPE_COLORS[debuffType]
        indicator:SetBackdropColor(color[1], color[2], color[3], 1)
        indicator:SetBackdropBorderColor(0, 0, 0, 1)
        indicator:Hide()
        frame.debuffIndicators[debuffType] = indicator
    end
    
    -- Cast Bar
    if layoutSettings.castBar and layoutSettings.castBar.enabled then
        local cbHeight = layoutSettings.castBar.height or 6
        local castBar = CreateFrame("StatusBar", nil, frame)
        castBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
        castBar:SetStatusBarColor(1, 0.7, 0, 1)
        castBar:SetHeight(cbHeight)
        castBar:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 1, -1)
        castBar:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", -1, -1)
        castBar:SetMinMaxValues(0, 1)
        castBar:SetValue(0)
        castBar:Hide()
        frame.castBar = castBar
        
        local castBg = castBar:CreateTexture(nil, "BACKGROUND")
        castBg:SetAllPoints()
        castBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
        
        if layoutSettings.castBar.showSpellName then
            local castText = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castText:SetPoint("LEFT", castBar, "LEFT", layoutSettings.castBar.showIcon and (cbHeight + 2) or 2, 0)
            frame.castText = castText
        end
        
        if layoutSettings.castBar.showIcon then
            local castIcon = castBar:CreateTexture(nil, "OVERLAY")
            castIcon:SetSize(cbHeight, cbHeight)
            castIcon:SetPoint("LEFT", castBar, "LEFT", 1, 0)
            frame.castIcon = castIcon
        end
        
        if layoutSettings.castBar.showTimer then
            local castTimer = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castTimer:SetPoint("RIGHT", castBar, "RIGHT", -2, 0)
            frame.castTimer = castTimer
        end
    end
    
    -- Highlight
    local highlight = frame:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints()
    highlight:SetColorTexture(1, 1, 1, 0.1)
    
    frame.unit = unit
    frame.index = index
    frame.sizeType = sizeType
    
    -- Tooltip
    frame:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        local showTooltip = false
        
        local panelName = self.sizeType == "small" and "raid_small" or "raid_large"
        local isSimulating = (self.sizeType == "small" and simulateRaidSmall) or 
                             (self.sizeType == "large" and simulateRaidLarge) or
                             (currentOpenPanel == panelName)
        if isSimulating then
            local simData = SIMULATED_RAID[self.index]
            if simData then
                local classColor = RAID_CLASS_COLORS[simData.class]
                if classColor then
                    GameTooltip:AddLine(simData.name, classColor.r, classColor.g, classColor.b)
                else
                    GameTooltip:AddLine(simData.name, 1, 1, 1)
                end
                GameTooltip:AddLine("Group " .. simData.group, 0.7, 0.7, 0.7)
                showTooltip = true
            end
        elseif UnitExists(self.unit) then
            local name = UnitName(self.unit) or "Unknown"
            local _, class = UnitClass(self.unit)
            local classColor = class and RAID_CLASS_COLORS[class]
            if classColor then
                GameTooltip:AddLine(name, classColor.r, classColor.g, classColor.b)
            else
                GameTooltip:AddLine(name, 1, 1, 1)
            end
            showTooltip = true
        end
        
        if showTooltip then
            GameTooltip:Show()
        end
    end)
    frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    frame:Hide()
    memberFrames[index] = frame
    return frame
end

function UnitFrames:UpdateRaidMemberFrame(sizeType, index)
    local memberFrames = sizeType == "small" and raidSmallMemberFrames or raidLargeMemberFrames
    local frame = memberFrames[index]
    if not frame then return end
    
    local rs = settings.raid
    if not rs then return end
    
    local layoutSettings = rs[sizeType]
    if not layoutSettings then return end
    
    -- Check the appropriate simulation flag for this size type, or if panel is open
    local panelName = sizeType == "small" and "raid_small" or "raid_large"
    local isSimulating = (sizeType == "small" and simulateRaidSmall) or 
                         (sizeType == "large" and simulateRaidLarge) or 
                         (currentOpenPanel == panelName)
    local simData = isSimulating and SIMULATED_RAID[index] or nil
    local unit = frame.unit
    local unitExists = UnitExists(unit) or (isSimulating and simData)
    
    if not unitExists then
        if not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    if not InCombatLockdown() then
        frame:Show()
    end
    
    -- Update frame visual layout based on current settings
    local mf = layoutSettings.frame
    
    -- Update frame background/border
    if mf.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = mf.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = mf.borderSize or 1,
        })
        frame:SetBackdropColor(mf.bgColor[1], mf.bgColor[2], mf.bgColor[3], mf.bgColor[4])
        if mf.showBorder then
            frame:SetBackdropBorderColor(mf.borderColor[1], mf.borderColor[2], mf.borderColor[3], mf.borderColor[4])
        end
    else
        frame:SetBackdrop(nil)
    end
    
    -- Update health bar size and position
    frame.healthBar:ClearAllPoints()
    frame.healthBar:SetPoint("TOPLEFT", 1, -1)
    frame.healthBar:SetPoint("TOPRIGHT", -1, -1)
    frame.healthBar:SetHeight(layoutSettings.healthBar.height)
    
    -- Update power bar size and position
    frame.powerBar:ClearAllPoints()
    frame.powerBar:SetPoint("TOPLEFT", frame.healthBar, "BOTTOMLEFT", 0, -1)
    frame.powerBar:SetPoint("TOPRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, -1)
    frame.powerBar:SetHeight(layoutSettings.powerBar.height)
    
    -- Update text fonts
    frame.nameText:SetFont(STANDARD_TEXT_FONT, layoutSettings.nameText.fontSize, layoutSettings.nameText.fontOutline or "OUTLINE")
    frame.healthText:SetFont(STANDARD_TEXT_FONT, layoutSettings.healthText.fontSize, "OUTLINE")
    
    -- Get unit data
    local name, class, role, powerType
    
    if isSimulating and simData then
        name = simData.name or "Unknown"
        class = simData.class or "WARRIOR"
        role = simData.role or "NONE"
        powerType = simData.powerType or 0
    elseif UnitExists(unit) then
        name = UnitName(unit) or "Unknown"
        _, class = UnitClass(unit)
        class = class or "WARRIOR"
        role = UnitGroupRolesAssigned(unit) or "NONE"
        powerType = UnitPowerType(unit) or 0
    end
    
    -- Update health bar - pass values directly to StatusBar
    local health, maxHealth
    if isSimulating and simData then
        health = simData.health or 0
        maxHealth = simData.maxHealth or 1
    else
        health = UnitHealth(unit)
        maxHealth = UnitHealthMax(unit)
    end
    frame.healthBar:SetMinMaxValues(0, maxHealth)
    frame.healthBar:SetValue(health)
    
    -- Health bar color
    local classColor = RAID_CLASS_COLORS[class]
    if layoutSettings.healthBar.colorMode == "class" and classColor then
        frame.healthBar:SetStatusBarColor(classColor.r, classColor.g, classColor.b)
    elseif layoutSettings.healthBar.colorMode == "health" then
        -- Health-based color requires arithmetic - only safe with simulated data
        if isSimulating and simData and simData.maxHealth > 0 then
            local pct = simData.health / simData.maxHealth
            frame.healthBar:SetStatusBarColor(1 - pct, pct, 0)
        else
            -- For real units, use green (arithmetic on secret values fails)
            frame.healthBar:SetStatusBarColor(0, 1, 0)
        end
    else
        local c = layoutSettings.healthBar.customColor or {0.2, 0.8, 0.2, 1}
        frame.healthBar:SetStatusBarColor(c[1], c[2], c[3])
    end
    
    -- Update power bar - pass values directly to StatusBar
    if layoutSettings.powerBar.enabled then
        frame.powerBar:Show()
        local power, maxPower
        if isSimulating and simData then
            power = simData.power or 0
            maxPower = simData.maxPower or 1
        else
            power = UnitPower(unit)
            maxPower = UnitPowerMax(unit)
        end
        frame.powerBar:SetMinMaxValues(0, maxPower)
        frame.powerBar:SetValue(power)
        
        local powerColor = PowerBarColor[powerType] or {r = 0.2, g = 0.2, b = 0.8}
        frame.powerBar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
    else
        frame.powerBar:Hide()
    end
    
    -- Update name text
    if layoutSettings.nameText.enabled then
        local displayName = name
        if layoutSettings.nameText.maxLength and layoutSettings.nameText.maxLength > 0 and #displayName > layoutSettings.nameText.maxLength then
            displayName = displayName:sub(1, layoutSettings.nameText.maxLength)
        end
        frame.nameText:SetText(displayName)
        
        if layoutSettings.nameText.colorMode == "class" and classColor then
            frame.nameText:SetTextColor(classColor.r, classColor.g, classColor.b)
        else
            frame.nameText:SetTextColor(1, 1, 1)
        end
        frame.nameText:Show()
    else
        frame.nameText:Hide()
    end
    
    -- Update health text
    if layoutSettings.healthText.enabled then
        local healthStr = ""
        if layoutSettings.healthText.format == "percent" then
            local pct = maxHealth and maxHealth > 0 and math.floor((health / maxHealth) * 100) or 0
            healthStr = pct .. "%"
        elseif layoutSettings.healthText.format == "current" then
            healthStr = AbbreviateNumber(health)
        elseif layoutSettings.healthText.format == "deficit" then
            local deficit = (maxHealth or 0) - (health or 0)
            if deficit > 0 then
                healthStr = "-" .. AbbreviateNumber(deficit)
            end
        end
        frame.healthText:SetText(healthStr)
        frame.healthText:Show()
    else
        frame.healthText:Hide()
    end
    
    -- Update role icon
    if layoutSettings.roleIcon.enabled and role and role ~= "NONE" then
        local atlasOptions = {
            TANK = {"roleicon-guardian", "roleicon-tank", "UI-LFG-RoleIcon-Tank"},
            HEALER = {"roleicon-healer", "UI-LFG-RoleIcon-Healer"},
            DAMAGER = {"roleicon-damage", "UI-LFG-RoleIcon-DPS"},
        }
        local options = atlasOptions[role]
        local atlasSet = false
        if options then
            for _, atlasName in ipairs(options) do
                local success = pcall(function()
                    frame.roleIcon:SetAtlas(atlasName, true)
                end)
                if success then
                    local currentAtlas = frame.roleIcon:GetAtlas()
                    if currentAtlas and currentAtlas ~= "" then
                        atlasSet = true
                        break
                    end
                end
            end
        end
        if atlasSet then
            frame.roleIcon:Show()
            if frame.roleIconFrame then frame.roleIconFrame:Show() end
        else
            frame.roleIcon:Hide()
            if frame.roleIconFrame then frame.roleIconFrame:Hide() end
        end
    else
        if frame.roleIcon then frame.roleIcon:Hide() end
        if frame.roleIconFrame then frame.roleIconFrame:Hide() end
    end
    
    -- Update raid target
    local raidTargetIndex = isSimulating and (index % 8 == 0 and (index / 8) or nil) or GetRaidTargetIndex(unit)
    if layoutSettings.raidTarget.enabled and raidTargetIndex then
        SetRaidTargetIconTexture(frame.raidTarget, raidTargetIndex)
        frame.raidTargetFrame:Show()
    else
        frame.raidTargetFrame:Hide()
    end
    
    -- Update debuff indicators
    if layoutSettings.debuffIndicators and layoutSettings.debuffIndicators.enabled then
        for _, indicator in pairs(frame.debuffIndicators) do
            indicator:Hide()
        end
        
        local debuffsFound = {}
        if isSimulating and simData and simData.debuffType then
            debuffsFound[simData.debuffType] = true
        elseif UnitExists(unit) then
            local function CheckDebuff(auraData)
                if auraData and auraData.dispelName then
                    local dispelName = auraData.dispelName
                    if dispelName == "Magic" or dispelName == "Curse" or dispelName == "Disease" or dispelName == "Poison" then
                        debuffsFound[dispelName] = true
                    end
                end
            end
            if AuraUtil and AuraUtil.ForEachAura then
                AuraUtil.ForEachAura(unit, "HARMFUL", nil, CheckDebuff)
            end
        end
        
        local xOffset = 0
        local diSize = layoutSettings.debuffIndicators.size or 10
        for _, debuffType in ipairs({"Magic", "Curse", "Disease", "Poison"}) do
            local indicator = frame.debuffIndicators[debuffType]
            if indicator and debuffsFound[debuffType] then
                local shouldShow = false
                if debuffType == "Magic" and layoutSettings.debuffIndicators.showMagic then shouldShow = true
                elseif debuffType == "Curse" and layoutSettings.debuffIndicators.showCurse then shouldShow = true
                elseif debuffType == "Disease" and layoutSettings.debuffIndicators.showDisease then shouldShow = true
                elseif debuffType == "Poison" and layoutSettings.debuffIndicators.showPoison then shouldShow = true
                end
                if shouldShow then
                    indicator:SetSize(diSize, diSize)
                    indicator:ClearAllPoints()
                    indicator:SetPoint("RIGHT", frame.debuffContainer, "RIGHT", -xOffset, 0)
                    indicator:Show()
                    xOffset = xOffset + diSize + 1
                end
            end
        end
    end
    
    -- Update cast bar
    if frame.castBar and layoutSettings.castBar and layoutSettings.castBar.enabled then
        local unitID = unit
        local cbs = layoutSettings.castBar
        
        -- Handle simulation mode
        if isSimulating and not UnitExists(unitID) then
            -- Show a simulated cast bar on the first frame only
            if frame.index == 1 then
                frame.castBar:SetMinMaxValues(0, 3)
                frame.castBar:SetValue(1.5)
                if frame.castText then 
                    if cbs.showSpellName then
                        frame.castText:SetText("Simulated Cast")
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                if frame.castTimer then 
                    if cbs.showTimer then
                        frame.castTimer:SetText("1.5")
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                if frame.castIcon then 
                    if cbs.showIcon then
                        frame.castIcon:SetTexture("Interface\\Icons\\Spell_Nature_Heal")
                        frame.castIcon:Show()
                    else
                        frame.castIcon:Hide()
                    end
                end
                frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        else
            local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(unitID)
            if not castName then
                castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(unitID)
            end
            
            if castName then
                local duration = (endTime - startTime) / 1000
                local elapsed = (GetTime() * 1000 - startTime) / 1000
                frame.castBar:SetMinMaxValues(0, duration)
                frame.castBar:SetValue(elapsed)
                
                if frame.castText then
                    if cbs.showSpellName then
                        frame.castText:SetText(castName)
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                
                if frame.castIcon then
                    if cbs.showIcon and spellID then
                        local spellTexture = GetSpellTextureByID(spellID)
                        if spellTexture then
                            frame.castIcon:SetTexture(spellTexture)
                            frame.castIcon:Show()
                        end
                    else
                        frame.castIcon:Hide()
                    end
                end
                
                if frame.castTimer then
                    if cbs.showTimer then
                        frame.castTimer:SetText(string.format("%.1f", duration - elapsed))
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                
                if notInterruptible then
                    frame.castBar:SetStatusBarColor(0.7, 0.7, 0.7, 1)
                else
                    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                end
                
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        end
    elseif frame.castBar then
        frame.castBar:Hide()
    end
end

function UnitFrames:UpdateRaidFrames()
    local rs = settings.raid
    if not rs then return end
    
    local editModeOpen = EditModeManagerFrame and EditModeManagerFrame:IsShown()
    local smallPanelOpen = currentOpenPanel == "raid_small"
    local largePanelOpen = currentOpenPanel == "raid_large"
    local anyPanelOpen = smallPanelOpen or largePanelOpen
    
    -- Check if any simulation is active
    local anySimulating = simulateRaidSmall or simulateRaidLarge
    
    -- If not enabled AND not in Edit Mode AND not simulating AND no panel open, hide both containers and return
    if not rs.enabled and not anySimulating and not anyPanelOpen then
        if not editModeOpen then
            if not InCombatLockdown() then
                if raidSmallContainer then raidSmallContainer:Hide() end
                if raidLargeContainer then raidLargeContainer:Hide() end
            end
            return
        end
    end
    
    HideBlizzardRaidFrames()
    
    local inRaid = IsInRaid() or simulationMode or anySimulating or anyPanelOpen
    
    if not inRaid and not editModeOpen then
        if not InCombatLockdown() then
            if raidSmallContainer then raidSmallContainer:Hide() end
            if raidLargeContainer then raidLargeContainer:Hide() end
        end
        return
    end
    
    -- If Edit Mode is open but not in raid, enable simulation
    if editModeOpen and not IsInRaid() then
        simulationMode = true
    end
    
    -- Handle per-panel simulation - if either is simulating, update those specifically
    if simulateRaidSmall and not editModeOpen then
        self:UpdateRaidLayoutForSize("small", 20)
        -- Hide large if not also simulating and panel not open
        if not simulateRaidLarge and not largePanelOpen and raidLargeContainer and not InCombatLockdown() then
            raidLargeContainer:Hide()
        end
    end
    
    if simulateRaidLarge and not editModeOpen then
        self:UpdateRaidLayoutForSize("large", 40)
        -- Hide small if not also simulating and panel not open
        if not simulateRaidSmall and not smallPanelOpen and raidSmallContainer and not InCombatLockdown() then
            raidSmallContainer:Hide()
        end
    end
    
    -- If simulating via per-panel checkboxes, don't do the normal logic
    if anySimulating and not editModeOpen then
        return
    end
    
    -- Determine raid size and which layout to use
    local raidSize = simulationMode and 40 or GetNumGroupMembers()
    local threshold = rs.sizeThreshold or 20
    local sizeType = raidSize <= threshold and "small" or "large"
    
    -- In Edit Mode, show BOTH containers so user can position them
    if editModeOpen then
        self:UpdateRaidLayoutForSize("small", math.min(raidSize, 20))
        self:UpdateRaidLayoutForSize("large", raidSize)
        return
    end
    
    -- Normal operation: show only the appropriate container
    local activeContainer = sizeType == "small" and raidSmallContainer or raidLargeContainer
    local inactiveContainer = sizeType == "small" and raidLargeContainer or raidSmallContainer
    
    if not InCombatLockdown() then
        if inactiveContainer then inactiveContainer:Hide() end
    end
    
    self:UpdateRaidLayoutForSize(sizeType, raidSize)
end

-- Update layout for a specific size type (small or large)
function UnitFrames:UpdateRaidLayoutForSize(sizeType, raidSize)
    local rs = settings.raid
    if not rs then return end
    
    local layoutSettings = rs[sizeType]
    if not layoutSettings then return end
    
    local container = sizeType == "small" and raidSmallContainer or raidLargeContainer
    local memberFrames = sizeType == "small" and raidSmallMemberFrames or raidLargeMemberFrames
    
    if not container then
        container = self:CreateRaidContainer(sizeType)
        if not container then return end
    end
    
    if not InCombatLockdown() then
        container:Show()
    end
    
    local mf = layoutSettings.frame
    local layout = layoutSettings.layout
    local containerSettings = layoutSettings.container
    
    local spacing = layout.spacing or 2
    local scale = containerSettings.scale or 1.0
    
    if not InCombatLockdown() then
        container:SetScale(scale)
        container:ClearAllPoints()
        container:SetPoint(containerSettings.anchor or "CENTER", UIParent, containerSettings.anchor or "CENTER", containerSettings.x or 0, containerSettings.y or 0)
    end
    
    local totalWidth, totalHeight = 0, 0
    local maxFrames = sizeType == "small" and 20 or 40
    local displayCount = math.min(raidSize, maxFrames)
    
    -- Handle group-based layouts (GROUP_ROWS, GROUP_COLUMNS, or legacy GROUPS)
    local isGroupMode = (layout.mode == "GROUP_ROWS" or layout.mode == "GROUP_COLUMNS" or layout.mode == "GROUPS")
    
    if isGroupMode then
        local groupSpacing = layout.groupSpacing or 8
        local membersPerRow = layout.membersPerRow or 5
        local memberGrowth = layout.memberGrowth or layout.growthDirection or "DOWN"
        
        -- Determine if we're doing rows of groups or columns of groups
        local isColumnMode = (layout.mode == "GROUP_COLUMNS") or 
                            (layout.mode == "GROUPS" and (layout.groupGrowthDirection == "DOWN" or layout.groupGrowthDirection == "UP"))
        
        local groupsBeforeWrap
        if isColumnMode then
            groupsBeforeWrap = layout.groupsPerColumn or layout.groupsPerRow or 4
        else
            groupsBeforeWrap = layout.groupsPerRow or 4
        end
        
        local numGroups = math.ceil(displayCount / 5)
        
        -- Calculate group dimensions based on member arrangement
        local groupWidth, groupHeight
        if memberGrowth == "DOWN" or memberGrowth == "UP" then
            -- Members arranged in rows within group
            local membersWide = math.min(membersPerRow, 5)
            local membersHigh = math.ceil(5 / membersPerRow)
            groupWidth = membersWide * (mf.width + spacing)
            groupHeight = membersHigh * (mf.height + spacing)
        else
            -- Members arranged in columns within group (RIGHT/LEFT)
            local membersHigh = math.min(membersPerRow, 5)
            local membersWide = math.ceil(5 / membersPerRow)
            groupWidth = membersWide * (mf.width + spacing)
            groupHeight = membersHigh * (mf.height + spacing)
        end
        
        for g = 1, 8 do
            local groupStartIndex = (g - 1) * 5 + 1
            local groupEndIndex = math.min(g * 5, displayCount)
            
            if groupStartIndex <= displayCount then
                -- Calculate group position
                local groupRow, groupCol
                
                if isColumnMode then
                    -- GROUP_COLUMNS: fill vertically first, then wrap to next column
                    -- G1 G3 G5 G7
                    -- G2 G4 G6 G8
                    groupCol = math.floor((g - 1) / groupsBeforeWrap)
                    groupRow = (g - 1) % groupsBeforeWrap
                else
                    -- GROUP_ROWS: fill horizontally first, then wrap to next row
                    -- G1 G2 G3 G4
                    -- G5 G6 G7 G8
                    groupRow = math.floor((g - 1) / groupsBeforeWrap)
                    groupCol = (g - 1) % groupsBeforeWrap
                end
                
                local groupOffsetX = groupCol * (groupWidth + groupSpacing)
                local groupOffsetY = -groupRow * (groupHeight + groupSpacing)
                
                -- Position members within group
                for i = groupStartIndex, groupEndIndex do
                    local frame = memberFrames[i]
                    if frame and not InCombatLockdown() then
                        local memberIndex = i - groupStartIndex
                        local memberRow, memberCol
                        
                        if memberGrowth == "DOWN" or memberGrowth == "UP" then
                            memberRow = math.floor(memberIndex / membersPerRow)
                            memberCol = memberIndex % membersPerRow
                        else
                            memberCol = math.floor(memberIndex / membersPerRow)
                            memberRow = memberIndex % membersPerRow
                        end
                        
                        local x = groupOffsetX + (memberCol * (mf.width + spacing))
                        local y = groupOffsetY - (memberRow * (mf.height + spacing))
                        
                        frame:ClearAllPoints()
                        frame:SetPoint("TOPLEFT", container, "TOPLEFT", x + 2, y - 2)
                        frame:SetSize(mf.width, mf.height)
                    end
                end
            end
        end
        
        -- Calculate total container size
        local groupsAcross, groupsDown
        if isColumnMode then
            groupsDown = math.min(numGroups, groupsBeforeWrap)
            groupsAcross = math.ceil(numGroups / groupsBeforeWrap)
        else
            groupsAcross = math.min(numGroups, groupsBeforeWrap)
            groupsDown = math.ceil(numGroups / groupsBeforeWrap)
        end
        totalWidth = groupsAcross * (groupWidth + groupSpacing)
        totalHeight = groupsDown * (groupHeight + groupSpacing)
    else
        -- GRID mode: arrange all players in a simple grid
        local columns = layout.columns or 5
        local rows = layout.rows  -- nil means auto-calculate
        local growthDir = layout.growthDirection or "DOWN"
        
        -- Auto-calculate rows/columns if one is nil
        if not rows then
            rows = math.ceil(displayCount / columns)
        elseif not columns then
            columns = math.ceil(displayCount / rows)
        end
        
        for i = 1, displayCount do
            local frame = memberFrames[i]
            if frame and not InCombatLockdown() then
                local idx = i - 1
                local row, col
                
                -- Fill direction based on growth
                if growthDir == "DOWN" or growthDir == "UP" then
                    -- Fill columns first, then move to next row
                    row = math.floor(idx / columns)
                    col = idx % columns
                else
                    -- Fill rows first, then move to next column
                    col = math.floor(idx / rows)
                    row = idx % rows
                end
                
                local x, y = 0, 0
                
                if growthDir == "DOWN" then
                    y = -(row * (mf.height + spacing))
                    x = col * (mf.width + spacing)
                elseif growthDir == "UP" then
                    y = row * (mf.height + spacing)
                    x = col * (mf.width + spacing)
                elseif growthDir == "RIGHT" then
                    x = col * (mf.width + spacing)
                    y = -(row * (mf.height + spacing))
                elseif growthDir == "LEFT" then
                    x = -(col * (mf.width + spacing))
                    y = -(row * (mf.height + spacing))
                end
                
                frame:ClearAllPoints()
                frame:SetPoint("TOPLEFT", container, "TOPLEFT", x + 2, y - 2)
                frame:SetSize(mf.width, mf.height)
            end
        end
        
        -- Calculate total container size for GRID mode
        local actualCols = math.min(displayCount, columns)
        local actualRows = math.ceil(displayCount / columns)
        totalWidth = actualCols * (mf.width + spacing) + 4
        totalHeight = actualRows * (mf.height + spacing) + 4
    end
    
    -- Update container size
    if not InCombatLockdown() then
        container:SetSize(math.max(totalWidth, mf.width + 4), math.max(totalHeight, mf.height + 4))
    end
    
    -- Hide frames beyond display count
    for i = displayCount + 1, maxFrames do
        local frame = memberFrames[i]
        if frame and not InCombatLockdown() then
            frame:Hide()
        end
    end
    
    -- Update each visible frame
    for i = 1, displayCount do
        self:UpdateRaidMemberFrame(sizeType, i)
    end
end

function UnitFrames:DestroyRaidContainer()
    if InCombatLockdown() then return end
    
    -- Destroy small container
    if raidSmallContainer then
        raidSmallContainer:Hide()
        raidSmallContainer = nil
    end
    for i, frame in pairs(raidSmallMemberFrames) do
        if frame then
            frame:Hide()
            frame:SetParent(nil)
        end
    end
    raidSmallMemberFrames = {}
    
    -- Destroy large container
    if raidLargeContainer then
        raidLargeContainer:Hide()
        raidLargeContainer = nil
    end
    for i, frame in pairs(raidLargeMemberFrames) do
        if frame then
            frame:Hide()
            frame:SetParent(nil)
        end
    end
    raidLargeMemberFrames = {}
    
    -- Clear legacy references
    raidContainer = nil
    raidMemberFrames = {}
    
    ShowBlizzardRaidFrames()
end

-- ============================================================================
-- TANK FRAMES
-- ============================================================================

function UnitFrames:CreateTankContainer()
    if tankContainer then return tankContainer end
    if InCombatLockdown() then return end
    
    local ts = settings.tanks
    if not ts then return end
    
    local containerSettings = ts.container
    local scale = containerSettings.scale or 1.0
    
    -- Create main container
    local container = CreateFrame("Frame", "TweaksUI_TankContainer", UIParent, "BackdropTemplate")
    container:SetPoint(containerSettings.anchor or "CENTER", UIParent, containerSettings.anchor or "CENTER", containerSettings.x or 0, containerSettings.y or 0)
    container:SetScale(scale)
    container:SetMovable(true)
    container:EnableMouse(true)
    container:SetClampedToScreen(true)
    container:RegisterForDrag("LeftButton")
    container:SetScript("OnDragStart", container.StartMoving)
    container:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        containerSettings.anchor = point
        containerSettings.x = x
        containerSettings.y = y
    end)
    
    -- Initial size will be calculated by UpdateTankFrames
    container:SetSize(ts.frame.width + 4, (ts.frame.height + ts.layout.spacing) * ts.maxTanks)
    
    tankContainer = container
    
    -- Create member frames for max tanks
    for i = 1, ts.maxTanks do
        self:CreateTankMemberFrame(i)
    end
    
    return container
end

function UnitFrames:CreateTankMemberFrame(index)
    local ts = settings.tanks
    if not ts then return end
    if not tankContainer then return end
    
    local mf = ts.frame
    
    -- Create secure button for click interactions
    local frameName = "TweaksUI_TankMember_" .. index
    local frame = CreateFrame("Button", frameName, tankContainer, "SecureUnitButtonTemplate, BackdropTemplate")
    frame:SetSize(mf.width, mf.height)
    
    -- Unit will be set dynamically
    frame:SetAttribute("type1", "target")
    frame:SetAttribute("type2", "togglemenu")
    frame:RegisterForClicks("AnyUp")
    frame.unit = nil
    frame.index = index
    
    -- Background
    if mf.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = mf.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = mf.borderSize or 1,
        })
        frame:SetBackdropColor(mf.bgColor[1], mf.bgColor[2], mf.bgColor[3], mf.bgColor[4])
        if mf.showBorder then
            frame:SetBackdropBorderColor(mf.borderColor[1], mf.borderColor[2], mf.borderColor[3], mf.borderColor[4])
        end
    end
    
    -- Health bar
    local healthBar = CreateFrame("StatusBar", nil, frame)
    healthBar:SetPoint("TOPLEFT", 1, -1)
    healthBar:SetPoint("TOPRIGHT", -1, -1)
    healthBar:SetHeight(ts.healthBar.height)
    healthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    healthBar:SetStatusBarColor(0.2, 0.8, 0.2)
    frame.healthBar = healthBar
    
    local healthBg = healthBar:CreateTexture(nil, "BACKGROUND")
    healthBg:SetAllPoints()
    healthBg:SetColorTexture(0.1, 0.1, 0.1, 0.8)
    
    -- Power bar
    local powerBar = CreateFrame("StatusBar", nil, frame)
    powerBar:SetPoint("TOPLEFT", healthBar, "BOTTOMLEFT", 0, -1)
    powerBar:SetPoint("TOPRIGHT", healthBar, "BOTTOMRIGHT", 0, -1)
    powerBar:SetHeight(ts.powerBar.height)
    powerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    powerBar:SetStatusBarColor(0.2, 0.2, 0.8)
    frame.powerBar = powerBar
    
    local powerBg = powerBar:CreateTexture(nil, "BACKGROUND")
    powerBg:SetAllPoints()
    powerBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
    
    -- Name text
    local nameText = healthBar:CreateFontString(nil, "OVERLAY")
    nameText:SetFont(STANDARD_TEXT_FONT, ts.nameText.fontSize, ts.nameText.fontOutline)
    nameText:SetPoint("LEFT", healthBar, "LEFT", 2, 0)
    nameText:SetJustifyH("LEFT")
    frame.nameText = nameText
    
    -- Health text
    local healthText = healthBar:CreateFontString(nil, "OVERLAY")
    healthText:SetFont(STANDARD_TEXT_FONT, ts.healthText.fontSize, "OUTLINE")
    healthText:SetPoint("RIGHT", healthBar, "RIGHT", -2, 0)
    healthText:SetJustifyH("RIGHT")
    frame.healthText = healthText
    
    -- Role icon
    local roleIconFrame = CreateFrame("Frame", nil, frame)
    roleIconFrame:SetSize(ts.roleIcon.size, ts.roleIcon.size)
    roleIconFrame:SetPoint(ts.roleIcon.position, frame, ts.roleIcon.position, ts.roleIcon.offsetX, ts.roleIcon.offsetY)
    roleIconFrame:SetFrameLevel(frame:GetFrameLevel() + 5)
    local roleIcon = roleIconFrame:CreateTexture(nil, "OVERLAY")
    roleIcon:SetAllPoints()
    frame.roleIcon = roleIcon
    frame.roleIconFrame = roleIconFrame
    
    -- Raid target icon
    local raidTargetFrame = CreateFrame("Frame", nil, frame)
    raidTargetFrame:SetSize(ts.raidTarget.size, ts.raidTarget.size)
    raidTargetFrame:SetPoint(ts.raidTarget.position, frame, ts.raidTarget.position, ts.raidTarget.offsetX, ts.raidTarget.offsetY)
    raidTargetFrame:SetFrameLevel(frame:GetFrameLevel() + 5)
    local raidTarget = raidTargetFrame:CreateTexture(nil, "OVERLAY")
    raidTarget:SetAllPoints()
    raidTarget:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
    frame.raidTarget = raidTarget
    frame.raidTargetFrame = raidTargetFrame
    
    -- Debuff indicators
    local debuffContainer = CreateFrame("Frame", nil, frame)
    debuffContainer:SetFrameLevel(frame:GetFrameLevel() + 10)
    local diSize = ts.debuffIndicators.size or 8
    debuffContainer:SetSize(diSize * 4, diSize)
    debuffContainer:SetPoint(ts.debuffIndicators.position or "BOTTOMRIGHT", frame, ts.debuffIndicators.position or "BOTTOMRIGHT", ts.debuffIndicators.offsetX or -1, ts.debuffIndicators.offsetY or 1)
    frame.debuffContainer = debuffContainer
    
    local DEBUFF_TYPE_COLORS = {
        Magic = {0.2, 0.6, 1.0},
        Curse = {0.6, 0.0, 1.0},
        Disease = {0.6, 0.4, 0.0},
        Poison = {0.0, 0.6, 0.0},
    }
    
    frame.debuffIndicators = {}
    local debuffTypes = {"Magic", "Curse", "Disease", "Poison"}
    for j, debuffType in ipairs(debuffTypes) do
        local indicator = CreateFrame("Frame", nil, debuffContainer, "BackdropTemplate")
        indicator:SetSize(diSize, diSize)
        indicator:SetPoint("RIGHT", debuffContainer, "RIGHT", -((j-1) * (diSize + 1)), 0)
        indicator:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        local color = DEBUFF_TYPE_COLORS[debuffType]
        indicator:SetBackdropColor(color[1], color[2], color[3], 1)
        indicator:SetBackdropBorderColor(0, 0, 0, 1)
        indicator:Hide()
        frame.debuffIndicators[debuffType] = indicator
    end
    
    -- Cast Bar
    if ts.castBar and ts.castBar.enabled then
        local cbHeight = ts.castBar.height or 8
        local castBar = CreateFrame("StatusBar", nil, frame)
        castBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
        castBar:SetStatusBarColor(1, 0.7, 0, 1)
        castBar:SetHeight(cbHeight)
        castBar:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 1, -1)
        castBar:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", -1, -1)
        castBar:SetMinMaxValues(0, 1)
        castBar:SetValue(0)
        castBar:Hide()
        frame.castBar = castBar
        
        local castBg = castBar:CreateTexture(nil, "BACKGROUND")
        castBg:SetAllPoints()
        castBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
        
        if ts.castBar.showSpellName then
            local castText = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castText:SetPoint("LEFT", castBar, "LEFT", ts.castBar.showIcon and (cbHeight + 2) or 2, 0)
            frame.castText = castText
        end
        
        if ts.castBar.showIcon then
            local castIcon = castBar:CreateTexture(nil, "OVERLAY")
            castIcon:SetSize(cbHeight, cbHeight)
            castIcon:SetPoint("LEFT", castBar, "LEFT", 1, 0)
            frame.castIcon = castIcon
        end
        
        if ts.castBar.showTimer then
            local castTimer = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castTimer:SetPoint("RIGHT", castBar, "RIGHT", -2, 0)
            frame.castTimer = castTimer
        end
    end
    
    -- Highlight
    local highlight = frame:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints()
    highlight:SetColorTexture(1, 1, 1, 0.1)
    
    -- Tooltip
    frame:SetScript("OnEnter", function(self)
        if self.unit and UnitExists(self.unit) then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetUnit(self.unit)
            GameTooltip:Show()
        elseif simulateTanks or (currentOpenPanel == "tanks") then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Simulated Tank " .. self.index, 1, 1, 1)
            GameTooltip:Show()
        end
    end)
    frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    frame:Hide()
    tankMemberFrames[index] = frame
    return frame
end

function UnitFrames:GetTankUnits()
    local tanks = {}
    local ts = settings.tanks
    if not ts then return tanks end
    
    local panelOpen = currentOpenPanel == "tanks"
    
    -- In simulation mode or panel is open, return fake tanks
    if simulateTanks or panelOpen then
        for i = 1, ts.maxTanks do
            tanks[i] = {
                unit = "raid" .. i,
                name = SIMULATED_RAID[i] and SIMULATED_RAID[i].name or ("Tank" .. i),
                class = SIMULATED_RAID[i] and SIMULATED_RAID[i].class or "WARRIOR",
                isMainTank = (i == 1),
                isMainAssist = (i == 2),
                simulated = true,
                simIndex = i,
            }
        end
        return tanks
    end
    
    -- Not in a group
    if not IsInGroup() then return tanks end
    
    local seen = {}
    
    -- Check for Main Tank assignments first
    if ts.showMainTank then
        for i = 1, MAX_RAID_MEMBERS do
            local unit = "raid" .. i
            if UnitExists(unit) then
                local name = GetRaidRosterInfo(i)
                if name then
                    local _, _, _, _, _, _, _, _, _, role = GetRaidRosterInfo(i)
                    if role == "MAINTANK" and not seen[unit] then
                        table.insert(tanks, {
                            unit = unit,
                            name = UnitName(unit),
                            class = select(2, UnitClass(unit)),
                            isMainTank = true,
                            isMainAssist = false,
                        })
                        seen[unit] = true
                    end
                end
            end
        end
    end
    
    -- Check for Main Assist assignments
    if ts.showMainAssist then
        for i = 1, MAX_RAID_MEMBERS do
            local unit = "raid" .. i
            if UnitExists(unit) and not seen[unit] then
                local name = GetRaidRosterInfo(i)
                if name then
                    local _, _, _, _, _, _, _, _, _, role = GetRaidRosterInfo(i)
                    if role == "MAINASSIST" then
                        table.insert(tanks, {
                            unit = unit,
                            name = UnitName(unit),
                            class = select(2, UnitClass(unit)),
                            isMainTank = false,
                            isMainAssist = true,
                        })
                        seen[unit] = true
                    end
                end
            end
        end
    end
    
    -- Check for players with Tank role
    if ts.showRoleTanks then
        for i = 1, GetNumGroupMembers() do
            local unit = IsInRaid() and ("raid" .. i) or (i == 1 and "player" or ("party" .. (i - 1)))
            if UnitExists(unit) and not seen[unit] then
                local role = UnitGroupRolesAssigned(unit)
                if role == "TANK" then
                    table.insert(tanks, {
                        unit = unit,
                        name = UnitName(unit),
                        class = select(2, UnitClass(unit)),
                        isMainTank = false,
                        isMainAssist = false,
                    })
                    seen[unit] = true
                end
            end
        end
    end
    
    -- Limit to maxTanks
    while #tanks > ts.maxTanks do
        table.remove(tanks)
    end
    
    return tanks
end

function UnitFrames:UpdateTankFrames()
    local ts = settings.tanks
    if not ts then return end
    
    local panelOpen = currentOpenPanel == "tanks"
    
    -- If not enabled and not simulating and panel not open, hide container and return
    if not ts.enabled and not simulateTanks and not panelOpen then
        if tankContainer and not InCombatLockdown() then
            tankContainer:Hide()
        end
        return
    end
    
    if not tankContainer then
        self:CreateTankContainer()
        if not tankContainer then return end
    end
    
    local tanks = self:GetTankUnits()
    local layout = ts.layout
    local mf = ts.frame
    local spacing = layout.spacing or 2
    local direction = layout.direction or "DOWN"
    
    -- Position and show tank frames
    for i = 1, ts.maxTanks do
        local frame = tankMemberFrames[i]
        if frame then
            local tankData = tanks[i]
            if tankData then
                -- Set unit
                frame.unit = tankData.unit
                frame.tankData = tankData
                if not InCombatLockdown() then
                    frame:SetAttribute("unit", tankData.unit)
                end
                
                -- Position frame
                local x, y = 0, 0
                if direction == "DOWN" then
                    y = -((i - 1) * (mf.height + spacing))
                elseif direction == "UP" then
                    y = (i - 1) * (mf.height + spacing)
                elseif direction == "RIGHT" then
                    x = (i - 1) * (mf.width + spacing)
                elseif direction == "LEFT" then
                    x = -((i - 1) * (mf.width + spacing))
                end
                
                if not InCombatLockdown() then
                    frame:ClearAllPoints()
                    frame:SetPoint("TOPLEFT", tankContainer, "TOPLEFT", x + 2, y - 2)
                    frame:SetSize(mf.width, mf.height)
                    frame:Show()
                end
                
                -- Update frame data
                self:UpdateTankMemberFrame(i)
            else
                -- No tank for this slot
                if not InCombatLockdown() then
                    frame:Hide()
                end
                frame.unit = nil
                frame.tankData = nil
            end
        end
    end
    
    -- Update container size
    local numTanks = #tanks
    if numTanks > 0 and not InCombatLockdown() then
        local totalWidth, totalHeight
        if direction == "DOWN" or direction == "UP" then
            totalWidth = mf.width + 4
            totalHeight = numTanks * (mf.height + spacing) + 4
        else
            totalWidth = numTanks * (mf.width + spacing) + 4
            totalHeight = mf.height + 4
        end
        tankContainer:SetSize(totalWidth, totalHeight)
        tankContainer:Show()
    elseif not InCombatLockdown() and not simulateTanks then
        tankContainer:Hide()
    end
end

function UnitFrames:UpdateTankMemberFrame(index)
    local frame = tankMemberFrames[index]
    if not frame then return end
    
    local ts = settings.tanks
    if not ts then return end
    
    local tankData = frame.tankData
    local unit = frame.unit
    local panelOpen = currentOpenPanel == "tanks"
    local isSimulating = (simulateTanks or panelOpen) and tankData and tankData.simulated
    
    local unitExists = (unit and UnitExists(unit)) or isSimulating
    if not unitExists then
        if not InCombatLockdown() then
            frame:Hide()
        end
        return
    end
    
    -- Update frame visual layout
    local mf = ts.frame
    
    if mf.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = mf.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = mf.borderSize or 1,
        })
        frame:SetBackdropColor(mf.bgColor[1], mf.bgColor[2], mf.bgColor[3], mf.bgColor[4])
        if mf.showBorder then
            frame:SetBackdropBorderColor(mf.borderColor[1], mf.borderColor[2], mf.borderColor[3], mf.borderColor[4])
        end
    end
    
    frame.healthBar:ClearAllPoints()
    frame.healthBar:SetPoint("TOPLEFT", 1, -1)
    frame.healthBar:SetPoint("TOPRIGHT", -1, -1)
    frame.healthBar:SetHeight(ts.healthBar.height)
    
    frame.powerBar:ClearAllPoints()
    frame.powerBar:SetPoint("TOPLEFT", frame.healthBar, "BOTTOMLEFT", 0, -1)
    frame.powerBar:SetPoint("TOPRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, -1)
    frame.powerBar:SetHeight(ts.powerBar.height)
    
    frame.nameText:SetFont(STANDARD_TEXT_FONT, ts.nameText.fontSize, ts.nameText.fontOutline or "OUTLINE")
    frame.healthText:SetFont(STANDARD_TEXT_FONT, ts.healthText.fontSize, "OUTLINE")
    
    -- Get unit data (non-secret values only)
    local name, class, powerType
    local simData
    
    if isSimulating then
        simData = SIMULATED_RAID[tankData.simIndex]
        powerType = simData.powerType or 0
        name = simData.name
        class = simData.class
    else
        powerType = UnitPowerType(unit) or 0
        name = UnitName(unit) or "Unknown"
        _, class = UnitClass(unit)
        class = class or "WARRIOR"
    end
    
    -- Update health bar - pass values directly to StatusBar
    local health, maxHealth
    if isSimulating and simData then
        health = simData.health or 0
        maxHealth = simData.maxHealth or 1
    else
        health = UnitHealth(unit)
        maxHealth = UnitHealthMax(unit)
    end
    frame.healthBar:SetMinMaxValues(0, maxHealth)
    frame.healthBar:SetValue(health)
    
    local classColor = RAID_CLASS_COLORS[class]
    if ts.healthBar.colorMode == "class" and classColor then
        frame.healthBar:SetStatusBarColor(classColor.r, classColor.g, classColor.b)
    elseif ts.healthBar.colorMode == "health" then
        -- Health-based color requires arithmetic - only safe with simulated data
        if isSimulating and simData and simData.maxHealth > 0 then
            local pct = simData.health / simData.maxHealth
            frame.healthBar:SetStatusBarColor(1 - pct, pct, 0)
        else
            -- For real units, use green (arithmetic on secret values fails)
            frame.healthBar:SetStatusBarColor(0, 1, 0)
        end
    else
        local c = ts.healthBar.customColor or {0.2, 0.8, 0.2, 1}
        frame.healthBar:SetStatusBarColor(c[1], c[2], c[3])
    end
    
    -- Update power bar - pass values directly to StatusBar
    if ts.powerBar.enabled then
        frame.powerBar:Show()
        local power, maxPower
        if isSimulating and simData then
            power = simData.power or 0
            maxPower = simData.maxPower or 1
        else
            power = UnitPower(unit)
            maxPower = UnitPowerMax(unit)
        end
        frame.powerBar:SetMinMaxValues(0, maxPower)
        frame.powerBar:SetValue(power)
        local powerColor = PowerBarColor[powerType] or {r = 0.2, g = 0.2, b = 0.8}
        frame.powerBar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
    else
        frame.powerBar:Hide()
    end
    
    -- Update name text
    if ts.nameText.enabled then
        local displayName = name or "Unknown"
        if ts.nameText.maxLength and ts.nameText.maxLength > 0 and #displayName > ts.nameText.maxLength then
            displayName = displayName:sub(1, ts.nameText.maxLength)
        end
        frame.nameText:SetText(displayName)
        if ts.nameText.colorMode == "class" and classColor then
            frame.nameText:SetTextColor(classColor.r, classColor.g, classColor.b)
        else
            frame.nameText:SetTextColor(1, 1, 1)
        end
        frame.nameText:Show()
    else
        frame.nameText:Hide()
    end
    
    -- Update health text
    if ts.healthText.enabled then
        local healthStr = ""
        if ts.healthText.format == "percent" then
            local pct = maxHealth and maxHealth > 0 and math.floor((health / maxHealth) * 100) or 0
            healthStr = pct .. "%"
        elseif ts.healthText.format == "current" then
            healthStr = AbbreviateNumber(health)
        elseif ts.healthText.format == "deficit" then
            local deficit = (maxHealth or 0) - (health or 0)
            if deficit > 0 then
                healthStr = "-" .. AbbreviateNumber(deficit)
            end
        end
        frame.healthText:SetText(healthStr)
        frame.healthText:Show()
    else
        frame.healthText:Hide()
    end
    
    -- Update role icon (always show tank icon for tank frames)
    if ts.roleIcon.enabled then
        local atlasOptions = {"roleicon-guardian", "roleicon-tank", "UI-LFG-RoleIcon-Tank"}
        local atlasSet = false
        for _, atlasName in ipairs(atlasOptions) do
            local success = pcall(function()
                frame.roleIcon:SetAtlas(atlasName, true)
            end)
            if success then
                local currentAtlas = frame.roleIcon:GetAtlas()
                if currentAtlas and currentAtlas ~= "" then
                    atlasSet = true
                    break
                end
            end
        end
        if atlasSet then
            frame.roleIcon:Show()
            frame.roleIconFrame:Show()
        else
            frame.roleIcon:Hide()
            frame.roleIconFrame:Hide()
        end
    else
        frame.roleIcon:Hide()
        frame.roleIconFrame:Hide()
    end
    
    -- Update raid target
    local raidTargetIndex = isSimulating and nil or GetRaidTargetIndex(unit)
    if ts.raidTarget.enabled and raidTargetIndex then
        SetRaidTargetIconTexture(frame.raidTarget, raidTargetIndex)
        frame.raidTargetFrame:Show()
    else
        frame.raidTargetFrame:Hide()
    end
    
    -- Update cast bar
    if frame.castBar and ts.castBar and ts.castBar.enabled then
        local unitID = unit
        local cbs = ts.castBar
        
        -- Handle simulation mode
        if isSimulating then
            -- Show a simulated cast bar on the first tank only
            if frame.index == 1 then
                frame.castBar:SetMinMaxValues(0, 3)
                frame.castBar:SetValue(1.5)
                if frame.castText then 
                    if cbs.showSpellName then
                        frame.castText:SetText("Simulated Cast")
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                if frame.castTimer then 
                    if cbs.showTimer then
                        frame.castTimer:SetText("1.5")
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                if frame.castIcon then 
                    if cbs.showIcon then
                        frame.castIcon:SetTexture("Interface\\Icons\\Spell_Holy_ShieldOfTheRighteous")
                        frame.castIcon:Show()
                    else
                        frame.castIcon:Hide()
                    end
                end
                frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        else
            local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(unitID)
            if not castName then
                castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(unitID)
            end
            
            if castName then
                local duration = (endTime - startTime) / 1000
                local elapsed = (GetTime() * 1000 - startTime) / 1000
                frame.castBar:SetMinMaxValues(0, duration)
                frame.castBar:SetValue(elapsed)
                
                if frame.castText then
                    if cbs.showSpellName then
                        frame.castText:SetText(castName)
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                
                if frame.castIcon then
                    if cbs.showIcon and spellID then
                        local spellTexture = GetSpellTextureByID(spellID)
                        if spellTexture then
                            frame.castIcon:SetTexture(spellTexture)
                            frame.castIcon:Show()
                        end
                    else
                        frame.castIcon:Hide()
                    end
                end
                
                if frame.castTimer then
                    if cbs.showTimer then
                        frame.castTimer:SetText(string.format("%.1f", duration - elapsed))
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                
                if notInterruptible then
                    frame.castBar:SetStatusBarColor(0.7, 0.7, 0.7, 1)
                else
                    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                end
                
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        end
    elseif frame.castBar then
        frame.castBar:Hide()
    end
end

function UnitFrames:DestroyTankContainer()
    if InCombatLockdown() then return end
    
    if tankContainer then
        tankContainer:Hide()
        tankContainer = nil
    end
    for i, frame in pairs(tankMemberFrames) do
        if frame then
            frame:Hide()
            frame:SetParent(nil)
        end
    end
    tankMemberFrames = {}
end

-- ============================================================================
-- BOSS FRAMES
-- ============================================================================

function UnitFrames:CreateBossContainer()
    if bossContainer then return bossContainer end
    if InCombatLockdown() then return end
    
    local bs = settings.boss
    if not bs then return end
    
    local containerSettings = bs.container
    local scale = containerSettings.scale or 1.0
    
    -- Create main container
    local container = CreateFrame("Frame", "TweaksUI_BossContainer", UIParent, "BackdropTemplate")
    container:SetPoint(containerSettings.anchor or "CENTER", UIParent, containerSettings.anchor or "CENTER", containerSettings.x or 0, containerSettings.y or 0)
    container:SetScale(scale)
    container:SetMovable(true)
    container:EnableMouse(true)
    container:SetClampedToScreen(true)
    container:RegisterForDrag("LeftButton")
    container:SetScript("OnDragStart", container.StartMoving)
    container:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        containerSettings.anchor = point
        containerSettings.x = x
        containerSettings.y = y
    end)
    
    -- Initial size will be calculated by UpdateBossFrames
    container:SetSize(bs.frame.width + 4, (bs.frame.height + bs.layout.spacing) * bs.maxBosses)
    
    bossContainer = container
    
    -- Create member frames for max bosses
    for i = 1, bs.maxBosses do
        self:CreateBossMemberFrame(i)
    end
    
    return container
end

function UnitFrames:CreateBossMemberFrame(index)
    if InCombatLockdown() then return end
    if not bossContainer then return end
    
    local bs = settings.boss
    if not bs then return end
    
    local frameName = "TweaksUI_BossFrame" .. index
    local frame = CreateFrame("Button", frameName, bossContainer, "SecureUnitButtonTemplate, BackdropTemplate")
    
    local unitID = "boss" .. index
    frame:SetAttribute("unit", unitID)
    frame:SetAttribute("type1", "target")
    frame:SetAttribute("type2", "menu")
    -- Note: RegisterUnitWatch is managed in UpdateBossFrames based on simulation state
    
    -- Frame size
    frame:SetSize(bs.frame.width, bs.frame.height)
    
    -- Background
    if bs.frame.showBackground then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = bs.frame.showBorder and "Interface\\Buttons\\WHITE8x8" or nil,
            edgeSize = bs.frame.borderSize or 1,
        })
        local bgColor = bs.frame.bgColor or {0.05, 0.05, 0.05, 0.9}
        frame:SetBackdropColor(bgColor[1], bgColor[2], bgColor[3], bgColor[4])
        local borderColor = bs.frame.borderColor or {0.5, 0.1, 0.1, 1}
        frame:SetBackdropBorderColor(borderColor[1], borderColor[2], borderColor[3], borderColor[4])
    end
    
    -- Health bar
    local healthBar = CreateFrame("StatusBar", nil, frame)
    healthBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
    healthBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -1)
    healthBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -1, -1)
    healthBar:SetHeight(bs.healthBar.height)
    healthBar:SetMinMaxValues(0, 1)
    healthBar:SetValue(1)
    frame.healthBar = healthBar
    
    local healthBg = healthBar:CreateTexture(nil, "BACKGROUND")
    healthBg:SetAllPoints()
    healthBg:SetColorTexture(unpack(bs.healthBar.bgColor or {0.1, 0.1, 0.1, 0.8}))
    frame.healthBg = healthBg
    
    -- Power bar
    local powerBar = CreateFrame("StatusBar", nil, frame)
    powerBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
    powerBar:SetPoint("TOPLEFT", healthBar, "BOTTOMLEFT", 0, -1)
    powerBar:SetPoint("TOPRIGHT", healthBar, "BOTTOMRIGHT", 0, -1)
    powerBar:SetHeight(bs.powerBar.height)
    powerBar:SetMinMaxValues(0, 1)
    powerBar:SetValue(1)
    frame.powerBar = powerBar
    
    local powerBg = powerBar:CreateTexture(nil, "BACKGROUND")
    powerBg:SetAllPoints()
    powerBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
    
    -- Name text
    local nameText = healthBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    nameText:SetPoint("LEFT", healthBar, "LEFT", 3, 0)
    nameText:SetJustifyH("LEFT")
    frame.nameText = nameText
    
    -- Health text
    local healthText = healthBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    healthText:SetPoint("RIGHT", healthBar, "RIGHT", -3, 0)
    healthText:SetJustifyH("RIGHT")
    frame.healthText = healthText
    
    -- Raid target icon
    local raidTarget = frame:CreateTexture(nil, "OVERLAY")
    raidTarget:SetSize(bs.raidTarget.size, bs.raidTarget.size)
    raidTarget:SetPoint(bs.raidTarget.position, frame, bs.raidTarget.position, bs.raidTarget.offsetX, bs.raidTarget.offsetY)
    raidTarget:Hide()
    frame.raidTarget = raidTarget
    
    -- Cast bar (optional)
    if bs.castBar and bs.castBar.enabled then
        local castBar = CreateFrame("StatusBar", nil, frame)
        castBar:SetStatusBarTexture("Interface\\RaidFrame\\Raid-Bar-Hp-Fill")
        castBar:SetStatusBarColor(1, 0.7, 0, 1)
        castBar:SetPoint("TOPLEFT", powerBar, "BOTTOMLEFT", 0, -1)
        castBar:SetPoint("TOPRIGHT", powerBar, "BOTTOMRIGHT", 0, -1)
        castBar:SetHeight(bs.castBar.height or 10)
        castBar:SetMinMaxValues(0, 1)
        castBar:SetValue(0)
        castBar:Hide()
        frame.castBar = castBar
        
        local castBg = castBar:CreateTexture(nil, "BACKGROUND")
        castBg:SetAllPoints()
        castBg:SetColorTexture(0.05, 0.05, 0.05, 0.8)
        
        local castText = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        castText:SetPoint("CENTER", castBar, "CENTER", 0, 0)
        frame.castText = castText
        
        if bs.castBar.showIcon then
            local castIcon = castBar:CreateTexture(nil, "OVERLAY")
            castIcon:SetSize(bs.castBar.height or 10, bs.castBar.height or 10)
            castIcon:SetPoint("LEFT", castBar, "LEFT", 1, 0)
            frame.castIcon = castIcon
        end
        
        if bs.castBar.showTimer then
            local castTimer = castBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            castTimer:SetPoint("RIGHT", castBar, "RIGHT", -2, 0)
            frame.castTimer = castTimer
        end
    end
    
    -- Store index
    frame.bossIndex = index
    frame.unitID = unitID
    
    -- Hide initially
    frame:Hide()
    
    bossMemberFrames[index] = frame
    return frame
end

function UnitFrames:UpdateBossFrames()
    local bs = settings.boss
    if not bs then return end
    
    local panelOpen = currentOpenPanel == "boss"
    
    -- If not enabled and not simulating and panel not open, hide container and return
    if not bs.enabled and not simulateBoss and not panelOpen then
        if bossContainer and not InCombatLockdown() then
            bossContainer:Hide()
        end
        return
    end
    
    if not bossContainer then
        self:CreateBossContainer()
        if not bossContainer then return end
    end
    
    -- Simulation mode check
    local isSimulating = simulateBoss or panelOpen
    local visibleCount = 0
    
    for i = 1, bs.maxBosses do
        local frame = bossMemberFrames[i]
        if not frame then
            self:CreateBossMemberFrame(i)
            frame = bossMemberFrames[i]
        end
        
        if frame then
            -- Handle RegisterUnitWatch based on simulation state
            if isSimulating then
                -- Unregister unit watch so we can manually control visibility
                UnregisterUnitWatch(frame)
                visibleCount = visibleCount + 1
                self:UpdateBossMemberFrame(i, isSimulating)
            else
                -- Re-register unit watch for normal operation
                RegisterUnitWatch(frame)
                local unitID = "boss" .. i
                if UnitExists(unitID) then
                    visibleCount = visibleCount + 1
                    self:UpdateBossMemberFrame(i, isSimulating)
                end
            end
        end
    end
    
    -- Position visible frames
    if visibleCount > 0 then
        local direction = bs.layout.direction or "DOWN"
        local spacing = bs.layout.spacing or 2
        local frameWidth = bs.frame.width
        local frameHeight = bs.frame.height
        
        local x, y = 2, -2
        local visIndex = 0
        
        for i = 1, bs.maxBosses do
            local frame = bossMemberFrames[i]
            if frame then
                -- Check if this frame should be visible
                local shouldShow = isSimulating or UnitExists("boss" .. i)
                if shouldShow then
                    visIndex = visIndex + 1
                    
                    frame:ClearAllPoints()
                    if direction == "DOWN" then
                        y = -2 - ((visIndex - 1) * (frameHeight + spacing))
                        frame:SetPoint("TOPLEFT", bossContainer, "TOPLEFT", x, y)
                    elseif direction == "UP" then
                        y = 2 + ((visIndex - 1) * (frameHeight + spacing))
                        frame:SetPoint("BOTTOMLEFT", bossContainer, "BOTTOMLEFT", x, y)
                    elseif direction == "RIGHT" then
                        x = 2 + ((visIndex - 1) * (frameWidth + spacing))
                        frame:SetPoint("TOPLEFT", bossContainer, "TOPLEFT", x, y)
                    elseif direction == "LEFT" then
                        x = -2 - ((visIndex - 1) * (frameWidth + spacing))
                        frame:SetPoint("TOPRIGHT", bossContainer, "TOPRIGHT", x, y)
                    end
                end
            end
        end
        
        -- Update container size
        local totalWidth, totalHeight
        if direction == "DOWN" or direction == "UP" then
            totalWidth = frameWidth + 4
            totalHeight = (frameHeight + spacing) * visibleCount + 4
        else
            totalWidth = (frameWidth + spacing) * visibleCount + 4
            totalHeight = frameHeight + 4
        end
        bossContainer:SetSize(totalWidth, totalHeight)
        bossContainer:Show()
    else
        bossContainer:Hide()
    end
end

function UnitFrames:UpdateBossMemberFrame(index, isSimulating)
    local frame = bossMemberFrames[index]
    if not frame then return end
    
    local bs = settings.boss
    if not bs then return end
    
    local unitID = "boss" .. index
    
    -- Get unit data (real or simulated)
    local name, powerType
    local simData
    
    if isSimulating then
        -- Simulated boss data
        local simBosses = {
            { name = "Raid Boss", health = 85, maxHealth = 100, power = 100, maxPower = 100, powerType = 0 },
            { name = "Boss Add 1", health = 60, maxHealth = 100, power = 50, maxPower = 100, powerType = 0 },
            { name = "Boss Add 2", health = 45, maxHealth = 100, power = 30, maxPower = 100, powerType = 0 },
            { name = "Mini Boss", health = 90, maxHealth = 100, power = 80, maxPower = 100, powerType = 0 },
            { name = "Boss Pet", health = 30, maxHealth = 100, power = 100, maxPower = 100, powerType = 0 },
        }
        simData = simBosses[index] or simBosses[1]
        name = simData.name
        powerType = simData.powerType
        frame:Show()
    else
        if not UnitExists(unitID) then
            frame:Hide()
            return
        end
        name = UnitName(unitID)
        powerType = UnitPowerType(unitID)
        frame:Show()
    end
    
    -- Update health bar - pass values directly to StatusBar
    local health, maxHealth
    if isSimulating and simData then
        health = simData.health * 10000000  -- Scale for boss-like numbers
        maxHealth = simData.maxHealth * 10000000
    else
        health = UnitHealth(unitID)
        maxHealth = UnitHealthMax(unitID)
    end
    frame.healthBar:SetMinMaxValues(0, maxHealth)
    frame.healthBar:SetValue(health)
    
    if bs.healthBar.colorMode == "health" then
        -- Health-based color requires arithmetic - only safe with simulated data
        if isSimulating and simData and maxHealth > 0 then
            local pct = health / maxHealth
            frame.healthBar:SetStatusBarColor(1 - pct, pct, 0)
        else
            -- For real units, use default boss red (arithmetic on secret values fails)
            frame.healthBar:SetStatusBarColor(0.8, 0.2, 0.2)
        end
    else
        local c = bs.healthBar.customColor or {0.8, 0.2, 0.2, 1}
        frame.healthBar:SetStatusBarColor(c[1], c[2], c[3])
    end
    
    -- Update power bar - pass values directly to StatusBar
    if bs.powerBar.enabled then
        frame.powerBar:Show()
        local power, maxPower
        if isSimulating and simData then
            power = simData.power * 1000
            maxPower = simData.maxPower * 1000
        else
            power = UnitPower(unitID)
            maxPower = UnitPowerMax(unitID)
        end
        frame.powerBar:SetMinMaxValues(0, maxPower)
        frame.powerBar:SetValue(power)
        local powerColor = PowerBarColor[powerType] or {r = 0.2, g = 0.2, b = 0.8}
        frame.powerBar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
    else
        frame.powerBar:Hide()
    end
    
    -- Update name text
    if bs.nameText.enabled then
        local displayName = name or "Boss"
        if bs.nameText.maxLength and bs.nameText.maxLength > 0 and #displayName > bs.nameText.maxLength then
            displayName = displayName:sub(1, bs.nameText.maxLength)
        end
        frame.nameText:SetText(displayName)
        if bs.nameText.colorMode == "custom" then
            local c = bs.nameText.customColor or {1, 0.8, 0.2, 1}
            frame.nameText:SetTextColor(c[1], c[2], c[3])
        else
            frame.nameText:SetTextColor(1, 1, 1)
        end
        frame.nameText:Show()
    else
        frame.nameText:Hide()
    end
    
    -- Update health text
    if bs.healthText.enabled then
        local healthStr = ""
        if isSimulating and simData then
            local health = simData.health * 10000000
            local maxHealth = simData.maxHealth * 10000000
            if bs.healthText.format == "percent" then
                local pct = maxHealth > 0 and math.floor((health / maxHealth) * 100) or 0
                healthStr = pct .. "%"
            elseif bs.healthText.format == "current" then
                healthStr = AbbreviateNumber(health)
            elseif bs.healthText.format == "deficit" then
                local deficit = maxHealth - health
                if deficit > 0 then
                    healthStr = "-" .. AbbreviateNumber(deficit)
                end
            end
        else
            if bs.healthText.format == "percent" then
                local pct = UnitHealthPercent and UnitHealthPercent(unitID, false, true)
                if pct then
                    healthStr = string.format("%.0f%%", pct)
                end
            elseif bs.healthText.format == "current" then
                healthStr = AbbreviateLargeNumbers and AbbreviateLargeNumbers(UnitHealth(unitID)) or ""
            elseif bs.healthText.format == "deficit" then
                -- Deficit requires arithmetic - show current health instead for real units
                healthStr = AbbreviateLargeNumbers and AbbreviateLargeNumbers(UnitHealth(unitID)) or ""
            end
        end
        frame.healthText:SetText(healthStr)
        frame.healthText:Show()
    else
        frame.healthText:Hide()
    end
    
    -- Update raid target
    if bs.raidTarget.enabled then
        local raidTargetIndex = isSimulating and (index <= 2 and index or 0) or GetRaidTargetIndex(unitID)
        if raidTargetIndex and raidTargetIndex > 0 then
            frame.raidTarget:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. raidTargetIndex)
            frame.raidTarget:Show()
        else
            frame.raidTarget:Hide()
        end
    else
        frame.raidTarget:Hide()
    end
    
    -- Update cast bar (if enabled and not simulating)
    if frame.castBar and bs.castBar and bs.castBar.enabled then
        local cbs = bs.castBar
        if not isSimulating then
            local castName, _, _, startTime, endTime, _, _, notInterruptible, spellID = UnitCastingInfo(unitID)
            if not castName then
                castName, _, _, startTime, endTime, _, notInterruptible, spellID = UnitChannelInfo(unitID)
            end
            
            if castName then
                local duration = (endTime - startTime) / 1000
                local elapsed = (GetTime() * 1000 - startTime) / 1000
                frame.castBar:SetMinMaxValues(0, duration)
                frame.castBar:SetValue(elapsed)
                
                if frame.castText then
                    if cbs.showSpellName then
                        frame.castText:SetText(castName)
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                
                if frame.castIcon then
                    if cbs.showIcon and spellID then
                        local spellTexture = GetSpellTextureByID(spellID)
                        if spellTexture then
                            frame.castIcon:SetTexture(spellTexture)
                            frame.castIcon:Show()
                        end
                    else
                        frame.castIcon:Hide()
                    end
                end
                
                if frame.castTimer then
                    if cbs.showTimer then
                        frame.castTimer:SetText(string.format("%.1f", duration - elapsed))
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                
                if notInterruptible then
                    frame.castBar:SetStatusBarColor(0.7, 0.7, 0.7, 1)
                else
                    frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                end
                
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        else
            -- Show a simulated cast bar
            if index == 1 then
                frame.castBar:SetMinMaxValues(0, 3)
                frame.castBar:SetValue(1.5)
                if frame.castText then 
                    if cbs.showSpellName then
                        frame.castText:SetText("Simulated Cast")
                        frame.castText:Show()
                    else
                        frame.castText:Hide()
                    end
                end
                if frame.castTimer then 
                    if cbs.showTimer then
                        frame.castTimer:SetText("1.5")
                        frame.castTimer:Show()
                    else
                        frame.castTimer:Hide()
                    end
                end
                if frame.castIcon then 
                    if cbs.showIcon then
                        frame.castIcon:SetTexture("Interface\\Icons\\Spell_Shadow_UnholyFrenzy")
                        frame.castIcon:Show()
                    else
                        frame.castIcon:Hide()
                    end
                end
                frame.castBar:SetStatusBarColor(1, 0.7, 0, 1)
                frame.castBar:Show()
            else
                frame.castBar:Hide()
            end
        end
    end
end

function UnitFrames:DestroyBossContainer()
    if InCombatLockdown() then return end
    
    if bossContainer then
        bossContainer:Hide()
        bossContainer = nil
    end
    for i, frame in pairs(bossMemberFrames) do
        if frame then
            frame:Hide()
            frame:SetParent(nil)
        end
    end
    bossMemberFrames = {}
end

function UnitFrames:OnEnable()
    TweaksUI:PrintDebug("Unit Frames module enabling...")
    
    self.enabled = true
    
    -- If we're in combat, defer most initialization until after combat
    if InCombatLockdown() then
        TweaksUI:PrintDebug("Unit Frames: In combat, deferring frame creation...")
        local deferFrame = CreateFrame("Frame")
        deferFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        deferFrame:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            TweaksUI:PrintDebug("Unit Frames: Combat ended, completing initialization...")
            UnitFrames:CompleteEnableAfterCombat()
        end)
        
        -- Still setup events so we're ready when combat ends
        SetupEventFrame()
        return
    end
    
    self:CompleteEnableAfterCombat()
end

function UnitFrames:CompleteEnableAfterCombat()
    TweaksUI:PrintDebug("CompleteEnableAfterCombat starting")
    
    -- Setup Edit Mode callbacks via centralized manager
    SetupEditModeCallbacks()
    
    -- Create and show frames for individual units
    for _, unit in ipairs(INDIVIDUAL_UNITS) do
        if settings[unit] and settings[unit].enabled then
            CreateCustomUnitFrame(unit)
            UpdateFrameLayout(unit)
            MaskBlizzardFrame(unit)
        end
    end
    
    -- Always create party container for Edit Mode support (hidden if not enabled/in group)
    if settings.party then
        TweaksUI:PrintDebug("Creating party container for Edit Mode support")
        self:CreatePartyContainer()
        
        if settings.party.enabled then
            HookBlizzardPartyFrames()
            self:UpdatePartyFrames()
            -- Show if in group, otherwise hide
            if partyContainer and not IsInGroup() then
                partyContainer:Hide()
            end
        else
            -- Not enabled, keep hidden
            if partyContainer then
                partyContainer:Hide()
            end
        end
        TweaksUI:PrintDebug("Party container created: " .. tostring(partyContainer))
    end
    
    -- Always create BOTH raid containers for Edit Mode support (hidden if not enabled/in raid)
    if settings.raid then
        TweaksUI:PrintDebug("Creating raid containers for Edit Mode support")
        self:CreateRaidContainer("small")
        self:CreateRaidContainer("large")
        
        if settings.raid.enabled then
            self:UpdateRaidFrames()
            -- Hide containers if not in raid
            if not IsInRaid() then
                if raidSmallContainer then raidSmallContainer:Hide() end
                if raidLargeContainer then raidLargeContainer:Hide() end
            end
        else
            -- Not enabled, keep hidden
            if raidSmallContainer then raidSmallContainer:Hide() end
            if raidLargeContainer then raidLargeContainer:Hide() end
        end
        TweaksUI:PrintDebug("Raid containers created: small=" .. tostring(raidSmallContainer) .. ", large=" .. tostring(raidLargeContainer))
    end
    
    -- Setup events (if not already set up)
    SetupEventFrame()
    
    -- Initial data update - this populates the frames with current unit data
    C_Timer.After(0.3, function()
        TweaksUI:PrintDebug("C_Timer.After 0.3 running - registering frames with Edit Mode")
        
        for unit, _ in pairs(customFrames) do
            UpdateFrameData(unit)
            RegisterWithEditMode(unit)
        end
        
        -- Register party container with Edit Mode
        if partyContainer then
            TweaksUI:PrintDebug("Registering party container with Edit Mode")
            self:RegisterContainerWithEditMode("party")
        else
            TweaksUI:PrintDebug("Party container is nil, skipping registration")
        end
        
        -- Register raid containers with Edit Mode
        if raidSmallContainer then
            TweaksUI:PrintDebug("Registering small raid container with Edit Mode")
            self:RegisterContainerWithEditMode("raid_small")
        else
            TweaksUI:PrintDebug("Small raid container is nil, skipping registration")
        end
        
        if raidLargeContainer then
            TweaksUI:PrintDebug("Registering large raid container with Edit Mode")
            self:RegisterContainerWithEditMode("raid_large")
        else
            TweaksUI:PrintDebug("Large raid container is nil, skipping registration")
        end
        
        -- Update party frames if enabled
        if settings.party and settings.party.enabled then
            self:UpdatePartyFrames()
        end
        
        -- Update raid frames if enabled
        if settings.raid and settings.raid.enabled then
            self:UpdateRaidFrames()
        end
        
        -- Update tank frames if enabled
        if settings.tanks and settings.tanks.enabled then
            self:CreateTankContainer()
            self:UpdateTankFrames()
        end
        
        -- Update boss frames if enabled
        if settings.boss and settings.boss.enabled then
            self:CreateBossContainer()
            self:UpdateBossFrames()
        end
        
        -- If Edit Mode is currently active, hide Blizzard unit frame selections
        if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
            HideAllCustomUnitFramesFromEditMode()
        end
        
        -- Initialize visibility manager
        VisibilityManager:Initialize()
    end)
end

function UnitFrames:OnDisable()
    TweaksUI:PrintDebug("Unit Frames module disabling...")
    
    -- Can't modify secure frames during combat
    if InCombatLockdown() then
        -- Queue for after combat
        local f = CreateFrame("Frame")
        f:RegisterEvent("PLAYER_REGEN_ENABLED")
        f:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            UnitFrames:OnDisable()
        end)
        return
    end
    
    self.enabled = false
    
    -- Hide custom frames and unregister state drivers
    for _, frame in pairs(customFrames) do
        if frame._stateDriverRegistered then
            UnregisterStateDriver(frame, "visibility")
            frame._stateDriverRegistered = nil
        end
        frame:Hide()
    end
    
    -- Destroy group containers
    self:DestroyPartyContainer()
    self:DestroyRaidContainer()
    self:DestroyTankContainer()
    self:DestroyBossContainer()
    
    -- Unmask Blizzard frames
    for unit, _ in pairs(blizzardFramesMasked) do
        UnmaskBlizzardFrame(unit)
    end
end

function UnitFrames:RefreshFrame(unit)
    -- Handle raid_small and raid_large by refreshing the appropriate raid container
    if unit == "raid_small" or unit == "raid_large" then
        local sizeType = unit == "raid_small" and "small" or "large"
        local container = sizeType == "small" and raidSmallContainer or raidLargeContainer
        local isSimulating = (sizeType == "small" and simulateRaidSmall) or (sizeType == "large" and simulateRaidLarge)
        local displayCount = sizeType == "small" and 20 or 40
        
        if container then
            -- Update the layout and all frames
            self:UpdateRaidLayoutForSize(sizeType, displayCount)
        end
        return
    end
    
    -- Handle tank frames
    if unit == "tanks" then
        if settings.tanks and settings.tanks.enabled then
            if not tankContainer then
                self:CreateTankContainer()
            end
            if tankContainer then
                self:UpdateTankFrames()
                self:RegisterContainerWithEditMode("tanks")
            end
        end
        return
    end
    
    -- Handle boss frames
    if unit == "boss" then
        if settings.boss and settings.boss.enabled then
            if not bossContainer then
                self:CreateBossContainer()
            end
            if bossContainer then
                self:UpdateBossFrames()
                self:RegisterContainerWithEditMode("boss")
            end
        end
        return
    end
    
    if not settings or not settings[unit] then return end
    
    -- Special handling for party frames
    if unit == "party" then
        if settings.party.enabled then
            if partyContainer then
                -- Light-weight refresh: just update existing frames
                self:UpdatePartyFrames()
            else
                -- Container doesn't exist, create it
                self:CreatePartyContainer()
                self:UpdatePartyFrames()
                self:RegisterContainerWithEditMode("party")
            end
            -- Hide if not in group (unless Edit Mode is open, panel is open, or simulating)
            if partyContainer and not IsInGroup() and not simulationMode then
                if not (EditModeManagerFrame and EditModeManagerFrame:IsShown()) and currentOpenPanel ~= "party" then
                    partyContainer:Hide()
                end
            end
        else
            -- Party disabled, destroy container
            self:DestroyPartyContainer()
        end
        return
    end
    
    -- Special handling for raid frames
    if unit == "raid" then
        if settings.raid.enabled then
            -- Ensure both containers exist
            if not raidSmallContainer then
                self:CreateRaidContainer("small")
                self:RegisterContainerWithEditMode("raid_small")
            end
            if not raidLargeContainer then
                self:CreateRaidContainer("large")
                self:RegisterContainerWithEditMode("raid_large")
            end
            self:UpdateRaidFrames()
            
            -- Hide if not in raid (unless Edit Mode is open, panel is open, or simulating)
            if not IsInRaid() then
                local editModeOpen = EditModeManagerFrame and EditModeManagerFrame:IsShown()
                if not editModeOpen then
                    if raidSmallContainer and not simulateRaidSmall and currentOpenPanel ~= "raid_small" then 
                        raidSmallContainer:Hide() 
                    end
                    if raidLargeContainer and not simulateRaidLarge and currentOpenPanel ~= "raid_large" then 
                        raidLargeContainer:Hide() 
                    end
                end
            end
        else
            -- Raid disabled, destroy containers
            self:DestroyRaidContainer()
        end
        return
    end
    
    if settings[unit].enabled then
        if not customFrames[unit] then
            CreateCustomUnitFrame(unit)
        end
        UpdateFrameLayout(unit)
        UpdateFrameData(unit)
        MaskBlizzardFrame(unit)
        
        -- Hide Edit Mode selection if Edit Mode is active
        if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
            HideUnitFrameFromEditMode(unit)
        end
        
        -- Update Blizzard cast bar visibility based on custom cast bar settings
        UpdateBlizzardCastBarVisibility()
    else
        if customFrames[unit] then
            -- Unregister state driver before hiding
            if customFrames[unit]._stateDriverRegistered then
                UnregisterStateDriver(customFrames[unit], "visibility")
                customFrames[unit]._stateDriverRegistered = nil
            end
            if not InCombatLockdown() then
                customFrames[unit]:Hide()
            end
        end
        UnmaskBlizzardFrame(unit)
        
        -- Update Blizzard cast bar visibility
        UpdateBlizzardCastBarVisibility()
    end
end

function UnitFrames:CopySettings(fromUnit, toUnit)
    if not settings[fromUnit] or not settings[toUnit] then return end
    
    local function DeepCopy(orig)
        if type(orig) ~= "table" then return orig end
        local copy = {}
        for k, v in pairs(orig) do
            copy[k] = DeepCopy(v)
        end
        return copy
    end
    
    -- Save position
    local savedPos = {
        x = settings[toUnit].frame.x,
        y = settings[toUnit].frame.y,
        anchor = settings[toUnit].frame.anchor,
    }
    
    -- Copy
    settings[toUnit] = DeepCopy(settings[fromUnit])
    
    -- Restore position
    settings[toUnit].frame.x = savedPos.x
    settings[toUnit].frame.y = savedPos.y
    settings[toUnit].frame.anchor = savedPos.anchor
    
    self:RefreshFrame(toUnit)
    TweaksUI:Print("Settings copied from " .. fromUnit .. " to " .. toUnit)
end

-- ============================================================================
-- PROFILE IMPORT/EXPORT
-- ============================================================================

-- JSON-like serialization
local function serializeValue(val)
    local t = type(val)
    if t == "string" then
        return "\"" .. val:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n") .. "\""
    elseif t == "number" then
        return tostring(val)
    elseif t == "boolean" then
        return val and "true" or "false"
    elseif t == "table" then
        local parts = {}
        -- Check if it's an array
        local isArray = true
        local maxIndex = 0
        for k, v in pairs(val) do
            if type(k) ~= "number" or k < 1 or k ~= math.floor(k) then
                isArray = false
                break
            end
            maxIndex = math.max(maxIndex, k)
        end
        
        if isArray and maxIndex > 0 then
            for i = 1, maxIndex do
                table.insert(parts, serializeValue(val[i]))
            end
            return "[" .. table.concat(parts, ",") .. "]"
        else
            for k, v in pairs(val) do
                table.insert(parts, serializeValue(tostring(k)) .. ":" .. serializeValue(v))
            end
            return "{" .. table.concat(parts, ",") .. "}"
        end
    end
    return "null"
end

local function deserializeValue(str, pos)
    pos = pos or 1
    while pos <= #str and str:sub(pos, pos):match("%s") do
        pos = pos + 1
    end
    
    if pos > #str then return nil, pos end
    
    local char = str:sub(pos, pos)
    
    -- String
    if char == '"' then
        local endPos = pos + 1
        local result = ""
        while endPos <= #str do
            local c = str:sub(endPos, endPos)
            if c == "\\" and endPos < #str then
                local next = str:sub(endPos + 1, endPos + 1)
                if next == "\\" or next == '"' then
                    result = result .. next
                    endPos = endPos + 2
                elseif next == "n" then
                    result = result .. "\n"
                    endPos = endPos + 2
                else
                    endPos = endPos + 1
                end
            elseif c == '"' then
                return result, endPos + 1
            else
                result = result .. c
                endPos = endPos + 1
            end
        end
        return nil, pos
    end
    
    -- Number
    if char:match("[%-0-9]") then
        local numStr = str:match("^%-?[0-9]+%.?[0-9]*", pos)
        if numStr then
            return tonumber(numStr), pos + #numStr
        end
    end
    
    -- Boolean/null
    if str:sub(pos, pos + 3) == "true" then
        return true, pos + 4
    elseif str:sub(pos, pos + 4) == "false" then
        return false, pos + 5
    elseif str:sub(pos, pos + 3) == "null" then
        return nil, pos + 4
    end
    
    -- Array
    if char == "[" then
        local arr = {}
        pos = pos + 1
        while pos <= #str do
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            if str:sub(pos, pos) == "]" then
                return arr, pos + 1
            end
            local val
            val, pos = deserializeValue(str, pos)
            table.insert(arr, val)
            while pos <= #str and str:sub(pos, pos):match("[%s,]") do
                pos = pos + 1
            end
        end
        return arr, pos
    end
    
    -- Object
    if char == "{" then
        local obj = {}
        pos = pos + 1
        while pos <= #str do
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            if str:sub(pos, pos) == "}" then
                return obj, pos + 1
            end
            local key
            key, pos = deserializeValue(str, pos)
            while pos <= #str and str:sub(pos, pos):match("[%s:]") do
                pos = pos + 1
            end
            local val
            val, pos = deserializeValue(str, pos)
            if key then
                -- Convert numeric string keys back to numbers
                local numKey = tonumber(key)
                if numKey then
                    obj[numKey] = val
                else
                    obj[key] = val
                end
            end
            while pos <= #str and str:sub(pos, pos):match("[%s,]") do
                pos = pos + 1
            end
        end
        return obj, pos
    end
    
    return nil, pos + 1
end

function UnitFrames:SerializeSettings()
    -- Build export data
    -- Note: visibility settings are included in each unit's settings automatically
    local exportData = {
        version = 1,
        player = settings.player and CopyTable(settings.player) or nil,
        target = settings.target and CopyTable(settings.target) or nil,
        focus = settings.focus and CopyTable(settings.focus) or nil,
        targettarget = settings.targettarget and CopyTable(settings.targettarget) or nil,
        pet = settings.pet and CopyTable(settings.pet) or nil,
        party = settings.party and CopyTable(settings.party) or nil,
        raid = settings.raid and CopyTable(settings.raid) or nil,
        tanks = settings.tanks and CopyTable(settings.tanks) or nil,
        boss = settings.boss and CopyTable(settings.boss) or nil,
    }
    
    local json = serializeValue(exportData)
    
    -- Try to use LibDeflate if available
    local LibDeflate = LibStub and LibStub("LibDeflate", true)
    if LibDeflate then
        local compressed = LibDeflate:CompressDeflate(json)
        local encoded = LibDeflate:EncodeForPrint(compressed)
        return "TUI_UF1:" .. encoded
    else
        -- Fallback: just base64-ish encode
        return "TUI_UF1:" .. json
    end
end

function UnitFrames:DeserializeSettings(encoded)
    if not encoded or not encoded:match("^TUI_UF1:") then
        return nil, "Invalid format: String must start with TUI_UF1:"
    end
    
    local data = encoded:sub(9) -- Remove "TUI_UF1:" prefix
    
    -- Try to use LibDeflate if available
    local LibDeflate = LibStub and LibStub("LibDeflate", true)
    local json
    if LibDeflate then
        local decoded = LibDeflate:DecodeForPrint(data)
        if decoded then
            json = LibDeflate:DecompressDeflate(decoded)
        end
    end
    
    -- Fallback if not compressed or LibDeflate unavailable
    if not json then
        json = data
    end
    
    if not json or json == "" then
        return nil, "Failed to decode profile string"
    end
    
    local result, _ = deserializeValue(json, 1)
    if not result then
        return nil, "Failed to parse profile data"
    end
    
    if not result.version then
        return nil, "Invalid profile: missing version"
    end
    
    return result, nil
end

function UnitFrames:ImportSettings(importData)
    if not importData then return false, "No data to import" end
    
    -- Import each unit type if present
    -- Note: visibility settings are included in each unit's settings automatically
    local units = {"player", "target", "focus", "targettarget", "pet", "party", "raid", "tanks", "boss"}
    local imported = {}
    
    for _, unit in ipairs(units) do
        if importData[unit] then
            if unit == "raid" then
                settings.raid = CopyTable(importData.raid)
            elseif unit == "tanks" then
                settings.tanks = CopyTable(importData.tanks)
            elseif unit == "boss" then
                settings.boss = CopyTable(importData.boss)
            else
                settings[unit] = CopyTable(importData[unit])
            end
            table.insert(imported, unit)
        end
    end
    
    -- Refresh all frames
    for _, unit in ipairs(imported) do
        if unit == "raid" then
            self:RefreshFrame("raid_small")
            self:RefreshFrame("raid_large")
        elseif unit == "tanks" then
            self:RefreshFrame("tanks")
        elseif unit == "boss" then
            self:RefreshFrame("boss")
        else
            self:RefreshFrame(unit)
        end
    end
    
    -- Apply all visibility settings (they're now per-frame in each unit's settings)
    VisibilityManager:ApplyAllVisibility(true)
    VisibilityManager:UpdateAllMouseover()
    
    return true, "Imported: " .. table.concat(imported, ", ")
end

-- Export window
local exportFrame = nil
function UnitFrames:ShowExportWindow()
    if exportFrame then
        exportFrame:Show()
        -- Update the export string
        local editBox = exportFrame.editBox
        editBox:SetText(self:SerializeSettings())
        return
    end
    
    local frame = CreateFrame("Frame", "TweaksUI_UF_ExportFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(500, 350)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetFrameStrata("DIALOG")
    
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5)
    frame.title:SetText("Export Unit Frames Settings")
    
    local info = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    info:SetPoint("TOPLEFT", 15, -35)
    info:SetText("Copy this string to share your settings:")
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -55)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 45)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject("ChatFontNormal")
    editBox:SetWidth(scrollFrame:GetWidth())
    editBox:SetText(self:SerializeSettings())
    editBox:SetAutoFocus(false)
    editBox:SetScript("OnEscapePressed", function() frame:Hide() end)
    scrollFrame:SetScrollChild(editBox)
    frame.editBox = editBox
    
    local selectBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    selectBtn:SetSize(100, 22)
    selectBtn:SetPoint("BOTTOMLEFT", 10, 10)
    selectBtn:SetText("Select All")
    selectBtn:SetScript("OnClick", function()
        editBox:SetFocus()
        editBox:HighlightText()
    end)
    
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    closeBtn:SetSize(80, 22)
    closeBtn:SetPoint("BOTTOMRIGHT", -10, 10)
    closeBtn:SetText("Close")
    closeBtn:SetScript("OnClick", function() frame:Hide() end)
    
    exportFrame = frame
    frame:Show()
end

-- Import window
local importFrame = nil
function UnitFrames:ShowImportWindow()
    if importFrame then
        importFrame:Show()
        importFrame.editBox:SetText("")
        importFrame.statusText:SetText("")
        return
    end
    
    local frame = CreateFrame("Frame", "TweaksUI_UF_ImportFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(500, 380)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetFrameStrata("DIALOG")
    
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5)
    frame.title:SetText("Import Unit Frames Settings")
    
    local info = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    info:SetPoint("TOPLEFT", 15, -35)
    info:SetWidth(470)
    info:SetJustifyH("LEFT")
    info:SetText("Paste a settings string below:")
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -55)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 70)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject("ChatFontNormal")
    editBox:SetWidth(scrollFrame:GetWidth())
    editBox:SetAutoFocus(true)
    editBox:SetScript("OnEscapePressed", function() frame:Hide() end)
    scrollFrame:SetScrollChild(editBox)
    frame.editBox = editBox
    
    local statusText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    statusText:SetPoint("BOTTOMLEFT", 15, 45)
    statusText:SetPoint("BOTTOMRIGHT", -15, 45)
    statusText:SetJustifyH("LEFT")
    statusText:SetTextColor(1, 0.82, 0)
    frame.statusText = statusText
    
    local module = self
    local importBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    importBtn:SetSize(100, 22)
    importBtn:SetPoint("BOTTOMLEFT", 10, 10)
    importBtn:SetText("Import")
    importBtn:SetScript("OnClick", function()
        local importString = editBox:GetText()
        
        if not importString or importString == "" then
            statusText:SetTextColor(1, 0, 0)
            statusText:SetText("Error: Please paste a settings string")
            return
        end
        
        local data, err = module:DeserializeSettings(importString)
        if not data then
            statusText:SetTextColor(1, 0, 0)
            statusText:SetText("Error: " .. (err or "Invalid data"))
            return
        end
        
        local success, msg = module:ImportSettings(data)
        if success then
            statusText:SetTextColor(0, 1, 0)
            statusText:SetText("Success! " .. msg)
            C_Timer.After(1.5, function()
                frame:Hide()
            end)
        else
            statusText:SetTextColor(1, 0, 0)
            statusText:SetText("Error: " .. msg)
        end
    end)
    
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    closeBtn:SetSize(80, 22)
    closeBtn:SetPoint("BOTTOMRIGHT", -10, 10)
    closeBtn:SetText("Cancel")
    closeBtn:SetScript("OnClick", function() frame:Hide() end)
    
    importFrame = frame
    frame:Show()
end

-- ============================================================================
-- SETTINGS UI: HUB
-- ============================================================================

function UnitFrames:CreateUnitFramesHub()
    if unitFramesHub then return unitFramesHub end
    
    local hub = CreateFrame("Frame", "TweaksUI_UnitFramesHub", UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, 300)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetMovable(true)
    hub:EnableMouse(true)
    hub:SetClampedToScreen(true)
    hub:SetFrameStrata("DIALOG")
    
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Unit Frames")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function()
        self:HideAllPanels()
        hub:Hide()
    end)
    
    hub:RegisterForDrag("LeftButton")
    hub:SetScript("OnDragStart", hub.StartMoving)
    hub:SetScript("OnDragStop", hub.StopMovingOrSizing)
    
    local yOffset = -42
    local buttonWidth = HUB_WIDTH - 20
    
    -- ===== INDIVIDUAL FRAMES SECTION =====
    local indivLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    indivLabel:SetPoint("TOP", 0, yOffset)
    indivLabel:SetText("|cff888888Individual Frames|r")
    yOffset = yOffset - 16
    
    -- Player Frame button
    local playerBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    playerBtn:SetPoint("TOP", 0, yOffset)
    playerBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    playerBtn:SetText("Player Frame")
    playerBtn:SetScript("OnClick", function() self:TogglePanel("player") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Target Frame button
    local targetBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    targetBtn:SetPoint("TOP", 0, yOffset)
    targetBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    targetBtn:SetText("Target Frame")
    targetBtn:SetScript("OnClick", function() self:TogglePanel("target") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Focus Frame button
    local focusBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    focusBtn:SetPoint("TOP", 0, yOffset)
    focusBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    focusBtn:SetText("Focus Frame")
    focusBtn:SetScript("OnClick", function() self:TogglePanel("focus") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Target of Target button
    local totBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    totBtn:SetPoint("TOP", 0, yOffset)
    totBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    totBtn:SetText("Target of Target")
    totBtn:SetScript("OnClick", function() self:TogglePanel("targettarget") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Pet Frame button
    local petBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    petBtn:SetPoint("TOP", 0, yOffset)
    petBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    petBtn:SetText("Pet Frame")
    petBtn:SetScript("OnClick", function() self:TogglePanel("pet") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING * 2
    
    -- ===== PARTY FRAMES SECTION =====
    local sep1 = hub:CreateTexture(nil, "ARTWORK")
    sep1:SetPoint("TOP", 0, yOffset)
    sep1:SetSize(buttonWidth, 1)
    sep1:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 8
    
    local partyLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    partyLabel:SetPoint("TOP", 0, yOffset)
    partyLabel:SetText("|cff888888Group Frames|r")
    yOffset = yOffset - 16
    
    -- Party Frames button
    local partyBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    partyBtn:SetPoint("TOP", 0, yOffset)
    partyBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    partyBtn:SetText("Party Frames")
    partyBtn:SetScript("OnClick", function() self:TogglePanel("party") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Small Raid Frames button
    local raidSmallBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    raidSmallBtn:SetPoint("TOP", 0, yOffset)
    raidSmallBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    raidSmallBtn:SetText("Raid (10-20)")
    raidSmallBtn:SetScript("OnClick", function() self:TogglePanel("raid_small") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Large Raid Frames button
    local raidLargeBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    raidLargeBtn:SetPoint("TOP", 0, yOffset)
    raidLargeBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    raidLargeBtn:SetText("Raid (21-40)")
    raidLargeBtn:SetScript("OnClick", function() self:TogglePanel("raid_large") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Tank Frames button
    local tankBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    tankBtn:SetPoint("TOP", 0, yOffset)
    tankBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    tankBtn:SetText("Tank Frames")
    tankBtn:SetScript("OnClick", function() self:TogglePanel("tanks") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Boss Frames button
    local bossBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    bossBtn:SetPoint("TOP", 0, yOffset)
    bossBtn:SetSize(buttonWidth, BUTTON_HEIGHT)
    bossBtn:SetText("Boss Frames")
    bossBtn:SetScript("OnClick", function() self:TogglePanel("boss") end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING * 2
    
    -- ===== SIMULATION SECTION =====
    local sep2 = hub:CreateTexture(nil, "ARTWORK")
    sep2:SetPoint("TOP", 0, yOffset)
    yOffset = yOffset - 12
    
    -- ===== IMPORT/EXPORT SECTION =====
    local sep3 = hub:CreateTexture(nil, "ARTWORK")
    sep3:SetPoint("TOP", 0, yOffset)
    sep3:SetSize(buttonWidth, 1)
    sep3:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 12
    
    local ieLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ieLabel:SetPoint("TOP", 0, yOffset)
    ieLabel:SetText("Import / Export")
    yOffset = yOffset - 18
    
    local exportBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    exportBtn:SetSize(buttonWidth / 2 - 4, 24)
    exportBtn:SetPoint("TOPLEFT", hub, "TOPLEFT", 10, yOffset)
    exportBtn:SetText("Export")
    exportBtn:SetScript("OnClick", function() self:ShowExportWindow() end)
    
    local importBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    importBtn:SetSize(buttonWidth / 2 - 4, 24)
    importBtn:SetPoint("TOPRIGHT", hub, "TOPRIGHT", -10, yOffset)
    importBtn:SetText("Import")
    importBtn:SetScript("OnClick", function() self:ShowImportWindow() end)
    
    yOffset = yOffset - 30
    
    -- Update hub height based on content
    hub:SetSize(HUB_WIDTH, -yOffset + 20)
    
    hub:Hide()
    unitFramesHub = hub
    return hub
end

function UnitFrames:OpenUnitFramesHubDocked(parentPanel)
    self:CreateUnitFramesHub()
    
    if parentPanel and unitFramesHub then
        unitFramesHub:ClearAllPoints()
        unitFramesHub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
    end
    
    unitFramesHub:Show()
end

function UnitFrames:HideAllPanels()
    if unitFramesHub then
        unitFramesHub:Hide()
    end
    for _, panel in pairs(settingsPanels) do
        if panel and panel.Hide then
            panel:Hide()
        end
    end
    
    -- Clear preview state and restore normal visibility
    if currentOpenPanel then
        local prevPanel = currentOpenPanel
        currentOpenPanel = nil
        self:HidePanelPreview(prevPanel)
    end
end

function UnitFrames:TogglePanel(panelName)
    -- Hide other panels and clear their preview state
    for name, panel in pairs(settingsPanels) do
        if panel and name ~= panelName then
            panel:Hide()
            -- Clear preview for the closed panel
            if currentOpenPanel == name then
                local prevPanel = currentOpenPanel
                currentOpenPanel = nil
                self:HidePanelPreview(prevPanel)
            end
        end
    end
    
    if settingsPanels[panelName] then
        if settingsPanels[panelName]:IsShown() then
            settingsPanels[panelName]:Hide()
            -- Clear preview state when closing
            if currentOpenPanel == panelName then
                currentOpenPanel = nil
                self:HidePanelPreview(panelName)
            end
        else
            settingsPanels[panelName]:Show()
            currentOpenPanel = panelName
            -- Show the frame and preview cast bar
            self:ShowPanelPreview(panelName)
        end
    else
        self:CreateUnitPanel(panelName)
        if settingsPanels[panelName] then
            settingsPanels[panelName]:Show()
            currentOpenPanel = panelName
            -- Show the frame and preview cast bar
            self:ShowPanelPreview(panelName)
        end
    end
end

-- Show preview for the currently open panel
function UnitFrames:ShowPanelPreview(panelName)
    -- Individual unit frames
    local individualUnits = {player = true, target = true, focus = true, targettarget = true, pet = true}
    if individualUnits[panelName] then
        local unitSettings = settings[panelName]
        
        -- Enable simulation for individual frames
        simulationMode = true
        
        -- Create the frame if it doesn't exist yet
        if not customFrames[panelName] and unitSettings and unitSettings.enabled then
            CreateCustomUnitFrame(panelName)
            UpdateFrameLayout(panelName)
            MaskBlizzardFrame(panelName)
        end
        
        local frame = customFrames[panelName]
        if frame then
            -- Force show the frame while panel is open (even if visibility settings hide it)
            if not InCombatLockdown() and unitSettings and unitSettings.enabled then
                frame:Show()
                frame:SetAlpha(1)  -- Override visibility alpha
                -- Make sure layout is up to date
                UpdateFrameLayout(panelName)
                -- Update with simulation data
                UpdateFrameData(panelName)
            end
        end
    end
    
    -- Party frames
    if panelName == "party" then
        -- Enable simulation for party
        simulationMode = true
        
        if not partyContainer then
            self:CreatePartyContainer()
        end
        if partyContainer and not InCombatLockdown() then
            partyContainer:Show()
            partyContainer:SetAlpha(1)
        end
        -- Update party frames with simulation data
        self:UpdatePartyFrames()
    end
    
    -- Tank frames
    if panelName == "tanks" then
        -- Enable simulation for tanks
        simulateTanks = true
        
        if not tankContainer then
            self:CreateTankContainer()
        end
        if tankContainer and not InCombatLockdown() then
            tankContainer:Show()
            tankContainer:SetAlpha(1)
        end
        self:UpdateTankFrames()
    end
    
    -- Boss frames
    if panelName == "boss" then
        -- Enable simulation for boss
        simulateBoss = true
        
        if not bossContainer then
            self:CreateBossContainer()
        end
        if bossContainer and not InCombatLockdown() then
            bossContainer:Show()
            bossContainer:SetAlpha(1)
        end
        self:UpdateBossFrames()
    end
    
    -- Raid frames
    if panelName == "raid_small" then
        -- Enable simulation for small raid
        simulateRaidSmall = true
        
        if not raidSmallContainer then
            self:CreateRaidContainer("small")
        end
        if raidSmallContainer and not InCombatLockdown() then
            raidSmallContainer:Show()
            raidSmallContainer:SetAlpha(1)
        end
        self:UpdateRaidLayoutForSize("small", 20)
    end
    
    if panelName == "raid_large" then
        -- Enable simulation for large raid
        simulateRaidLarge = true
        
        if not raidLargeContainer then
            self:CreateRaidContainer("large")
        end
        if raidLargeContainer and not InCombatLockdown() then
            raidLargeContainer:Show()
            raidLargeContainer:SetAlpha(1)
        end
        self:UpdateRaidLayoutForSize("large", 40)
    end
end

-- Hide preview and restore normal visibility state
function UnitFrames:HidePanelPreview(panelName)
    if not panelName then return end
    
    -- Individual unit frames
    local individualUnits = {player = true, target = true, focus = true, targettarget = true, pet = true}
    if individualUnits[panelName] then
        -- Disable simulation for individual frames
        simulationMode = false
        
        local frame = customFrames[panelName]
        if frame then
            -- Update with real data (no simulation)
            UpdateFrameData(panelName)
            
            -- Re-evaluate visibility - should this frame be shown?
            if not InCombatLockdown() then
                local unitExists = UnitExists(panelName)
                local unitSettings = settings[panelName]
                
                if unitSettings and unitSettings.enabled and unitExists then
                    frame:Show()
                    -- Restore proper visibility alpha
                    VisibilityManager:ApplyVisibilityForUnit(panelName, true)
                else
                    frame:Hide()
                end
            end
        end
    end
    
    -- Party frames
    if panelName == "party" then
        -- Disable simulation for party
        simulationMode = false
        
        -- Update party frames with real data
        self:UpdatePartyFrames()
        
        -- Re-evaluate party visibility
        if partyContainer and not InCombatLockdown() then
            local inGroup = IsInGroup() and not IsInRaid()
            if settings.party and settings.party.enabled and inGroup then
                partyContainer:Show()
                VisibilityManager:ApplyVisibilityForUnit("party", true)
            else
                partyContainer:Hide()
            end
        end
    end
    
    -- Tank frames
    if panelName == "tanks" then
        -- Disable simulation for tanks
        simulateTanks = false
        
        -- Update tank frames - this will hide simulated ones
        self:UpdateTankFrames()
        
        if tankContainer and not InCombatLockdown() then
            -- Hide if no real tanks
            local hasTanks = false
            if IsInGroup() then
                for i = 1, GetNumGroupMembers() do
                    local unit = IsInRaid() and "raid"..i or "party"..i
                    if UnitExists(unit) then
                        local role = UnitGroupRolesAssigned(unit)
                        if role == "TANK" then
                            hasTanks = true
                            break
                        end
                    end
                end
            end
            if not hasTanks then
                tankContainer:Hide()
            else
                VisibilityManager:ApplyVisibilityForUnit("tanks", true)
            end
        end
    end
    
    -- Boss frames
    if panelName == "boss" then
        -- Disable simulation for boss
        simulateBoss = false
        
        -- Update boss frames - this will hide simulated ones
        self:UpdateBossFrames()
        
        if bossContainer and not InCombatLockdown() then
            -- Check if any real bosses exist
            local hasBoss = false
            for i = 1, 5 do
                if UnitExists("boss" .. i) then
                    hasBoss = true
                    break
                end
            end
            if not hasBoss then
                bossContainer:Hide()
            else
                VisibilityManager:ApplyVisibilityForUnit("boss", true)
            end
        end
    end
    
    -- Raid frames
    if panelName == "raid_small" then
        -- Disable simulation for small raid
        simulateRaidSmall = false
        
        -- Update raid frames
        self:UpdateRaidLayoutForSize("small", 20)
        
        if raidSmallContainer and not InCombatLockdown() then
            local inRaid = IsInRaid()
            if settings.raid and settings.raid.enabled and inRaid then
                VisibilityManager:ApplyVisibilityForUnit("raid_small", true)
            else
                raidSmallContainer:Hide()
            end
        end
    end
    
    if panelName == "raid_large" then
        -- Disable simulation for large raid
        simulateRaidLarge = false
        
        -- Update raid frames
        self:UpdateRaidLayoutForSize("large", 40)
        
        if raidLargeContainer and not InCombatLockdown() then
            local inRaid = IsInRaid()
            if settings.raid and settings.raid.enabled and inRaid then
                VisibilityManager:ApplyVisibilityForUnit("raid_large", true)
            else
                raidLargeContainer:Hide()
            end
        end
    end
end

-- Check if a panel is currently open (for visibility manager)
function UnitFrames:IsPanelOpen(panelName)
    return currentOpenPanel == panelName
end


-- ============================================================================
-- SETTINGS UI: UNIT PANEL WITH SUB-HUB
-- ============================================================================

function UnitFrames:CreateUnitPanel(unit)
    local displayNames = {
        player = "Player Frame",
        target = "Target Frame",
        focus = "Focus Frame",
        targettarget = "Target of Target",
        pet = "Pet Frame",
        party = "Party Frames",
        raid_small = "Small Raid (10-20)",
        raid_large = "Large Raid (21-40)",
        tanks = "Tank Frames",
        boss = "Boss Frames",
    }
    
    local isParty = (unit == "party")
    local isRaidSmall = (unit == "raid_small")
    local isRaidLarge = (unit == "raid_large")
    local isRaid = isRaidSmall or isRaidLarge
    local isTanks = (unit == "tanks")
    local isBoss = (unit == "boss")
    local isGroupFrame = isParty or isRaid or isTanks or isBoss
    
    -- Panel dimensions - single tabbed panel instead of sub-hub + sub-panel
    local PANEL_WIDTH = 380
    local PANEL_HEIGHT = 620
    
    -- Main panel frame with tabs
    local container = CreateFrame("Frame", "TweaksUI_UF_" .. unit .. "_Container", UIParent, "BackdropTemplate")
    container:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    container:SetBackdrop(darkBackdrop)
    container:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    container:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    container:EnableMouse(true)
    container:SetFrameStrata("DIALOG")
    
    if unitFramesHub then
        container:SetPoint("TOPLEFT", unitFramesHub, "TOPRIGHT", 0, 0)
    end
    
    -- Title
    local panelTitle = container:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    panelTitle:SetPoint("TOP", 0, -10)
    panelTitle:SetText(displayNames[unit] or unit)
    panelTitle:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, container, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function() container:Hide() end)
    
    -- Category definitions - party/raid get Container first, all get same core categories
    local categories = {}
    
    if isGroupFrame then
        table.insert(categories, { id = "container", name = "Layout" })
    end
    
    table.insert(categories, { id = "frame", name = "Frame" })
    table.insert(categories, { id = "health", name = "Health" })
    table.insert(categories, { id = "power", name = "Power" })
    table.insert(categories, { id = "castbar", name = "Cast" })
    table.insert(categories, { id = "portrait", name = "Portrait" })
    table.insert(categories, { id = "text", name = "Text" })
    table.insert(categories, { id = "debuffs", name = "Debuffs" })
    table.insert(categories, { id = "visibility", name = "Visibility" })
    
    local categoryPanels = {}
    local tabButtons = {}
    local activeCategory = nil
    
    -- Get unit settings - for raid_small/raid_large, get from settings.raid.small/large
    local unitSettings
    local raidSizeType = nil  -- "small" or "large" for raid frames
    
    if isRaidSmall then
        unitSettings = settings.raid and settings.raid.small
        raidSizeType = "small"
    elseif isRaidLarge then
        unitSettings = settings.raid and settings.raid.large
        raidSizeType = "large"
    elseif isTanks then
        unitSettings = settings.tanks
    elseif isBoss then
        unitSettings = settings.boss
    else
        unitSettings = settings[unit]
    end
    
    if not unitSettings then
        container:Hide()
        return
    end
    
    -- For raid frames, also need access to the parent raid settings (for enabled checkbox)
    local parentRaidSettings = (isRaid) and settings.raid or nil
    
    local module = self
    
    -- ========================================================================
    -- HELPER FUNCTIONS FOR BUILDING UI
    -- ========================================================================
    
    -- Helper to copy values in-place (preserves table reference for UI bindings)
    local function CopyValuesInPlace(dest, source)
        for k, v in pairs(source) do
            if type(v) == "table" then
                if type(dest[k]) == "table" then
                    CopyValuesInPlace(dest[k], v)
                else
                    dest[k] = CopyTable(v)
                end
            else
                dest[k] = v
            end
        end
    end
    
    local function CreateCategoryContent(categoryId)
        -- Create a content frame for this tab (not a separate panel)
        local contentFrame = CreateFrame("ScrollFrame", nil, container, "UIPanelScrollFrameTemplate")
        contentFrame:SetPoint("TOPLEFT", 10, -60)
        contentFrame:SetPoint("BOTTOMRIGHT", -28, 50)
        
        local content = CreateFrame("Frame", nil, contentFrame)
        content:SetSize(PANEL_WIDTH - 50, 900)
        contentFrame:SetScrollChild(content)
        
        contentFrame.content = content
        contentFrame.categoryId = categoryId
        contentFrame:Hide()
        
        return contentFrame
    end
    
    -- Bottom section with copy dropdown (shared across all tabs)
    local bottomSep = container:CreateTexture(nil, "ARTWORK")
    bottomSep:SetPoint("BOTTOMLEFT", 10, 42)
    bottomSep:SetPoint("BOTTOMRIGHT", -10, 42)
    bottomSep:SetHeight(1)
    bottomSep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    
    local copyLabel = container:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    copyLabel:SetPoint("BOTTOMLEFT", 12, 16)
    copyLabel:SetText("Copy from:")
    
    local copyDropdownName = "TweaksUI_UF_" .. unit .. "_CopyDD"
    local copyDropdown = CreateFrame("Frame", copyDropdownName, container, "UIDropDownMenuTemplate")
    copyDropdown:SetPoint("BOTTOMLEFT", 65, 6)
    UIDropDownMenu_SetWidth(copyDropdown, 160)
    UIDropDownMenu_SetText(copyDropdown, "Select...")
    container.copyDropdown = copyDropdown
    
    -- Category name for display
    local categoryNames = {
        container = "Layout",
        frame = "Frame",
        health = "Health",
        power = "Power",
        castbar = "Cast Bar",
        portrait = "Portrait",
        text = "Text/Icons",
        debuffs = "Debuffs",
        visibility = "Visibility",
    }
    
    -- Function to update copy dropdown for current category
    local function UpdateCopyDropdown(categoryId)
        UIDropDownMenu_Initialize(copyDropdown, function(self, level)
            -- For container/visibility, no copy options
            if categoryId == "container" or categoryId == "visibility" then return end
            
            -- Copy sources
            local sources = {}
            
            if isGroupFrame then
                -- Party/Raid can copy from presets
                for presetId, preset in pairs(PRESET_LAYOUTS) do
                    if preset.name then
                        table.insert(sources, { name = preset.name .. " Preset", data = preset, isPreset = true })
                    end
                end
            else
                -- Individual frames can copy from other units
                for _, u in ipairs(INDIVIDUAL_UNITS) do
                    if u ~= unit and settings[u] then
                        table.insert(sources, { name = displayNames[u] or u, data = settings[u], isPreset = false })
                    end
                end
            end
            
            for _, source in ipairs(sources) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = source.name .. " " .. (categoryNames[categoryId] or categoryId)
                info.func = function()
                    local sourceData = source.data
                    if sourceData then
                        if categoryId == "frame" then
                            local oldX, oldY = unitSettings.frame.x, unitSettings.frame.y
                            local oldAnchor = unitSettings.frame.anchor
                            CopyValuesInPlace(unitSettings.frame, sourceData.frame)
                            unitSettings.frame.x = oldX
                            unitSettings.frame.y = oldY
                            unitSettings.frame.anchor = oldAnchor
                        elseif categoryId == "health" then
                            CopyValuesInPlace(unitSettings.healthBar, sourceData.healthBar)
                            if sourceData.healthText then
                                CopyValuesInPlace(unitSettings.healthText, sourceData.healthText)
                            end
                        elseif categoryId == "power" then
                            CopyValuesInPlace(unitSettings.powerBar, sourceData.powerBar)
                            if sourceData.powerText then
                                CopyValuesInPlace(unitSettings.powerText, sourceData.powerText)
                            end
                        elseif categoryId == "castbar" then
                            if sourceData.castBar and unitSettings.castBar then
                                CopyValuesInPlace(unitSettings.castBar, sourceData.castBar)
                            end
                        elseif categoryId == "portrait" then
                            if sourceData.portrait then
                                CopyValuesInPlace(unitSettings.portrait, sourceData.portrait)
                            end
                        elseif categoryId == "text" then
                            CopyValuesInPlace(unitSettings.nameText, sourceData.nameText)
                            if sourceData.levelText then
                                CopyValuesInPlace(unitSettings.levelText, sourceData.levelText)
                            end
                            if sourceData.raidTarget then
                                CopyValuesInPlace(unitSettings.raidTarget, sourceData.raidTarget)
                            end
                            if sourceData.roleIcon and unitSettings.roleIcon then
                                CopyValuesInPlace(unitSettings.roleIcon, sourceData.roleIcon)
                            end
                        elseif categoryId == "debuffs" then
                            if sourceData.debuffIndicators and unitSettings.debuffIndicators then
                                CopyValuesInPlace(unitSettings.debuffIndicators, sourceData.debuffIndicators)
                            end
                        end
                        module:RefreshFrame(unit)
                        UIDropDownMenu_SetText(copyDropdown, "Copied!")
                        C_Timer.After(1, function()
                            UIDropDownMenu_SetText(copyDropdown, "Select...")
                        end)
                    end
                end
                UIDropDownMenu_AddButton(info)
            end
        end)
    end
    
    local function BuildCategoryUI(contentFrame, categoryId)
        local content = contentFrame.content
        local yOffset = -5
        local controlIndex = 0
        
        -- For raid_small/raid_large, unitSettings already points to the correct sub-table
        -- So visualSettings is just unitSettings for all unit types now
        local visualSettings = unitSettings
        
        -- Helper: Section header
        local function CreateHeader(text)
            yOffset = yOffset - 8
            local header = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            header:SetPoint("TOPLEFT", 0, yOffset)
            header:SetText("|cffffd100" .. text .. "|r")
            yOffset = yOffset - 18
            return header
        end
        
        -- Helper: Checkbox
        local function CreateCheckbox(text, settingsTable, key, callback)
            local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
            cb:SetPoint("TOPLEFT", 0, yOffset)
            cb:SetSize(22, 22)
            cb.text:SetText(text)
            cb.text:SetFontObject("GameFontHighlightSmall")
            cb:SetChecked(settingsTable[key])
            cb:SetScript("OnClick", function(self)
                settingsTable[key] = self:GetChecked()
                if callback then callback() end
                module:RefreshFrame(unit)
            end)
            yOffset = yOffset - 24
            return cb
        end
        
        -- Helper: Slider
        local function CreateSlider(label, settingsTable, key, minVal, maxVal, step, isFloat)
            local sliderContainer = CreateFrame("Frame", nil, content)
            sliderContainer:SetPoint("TOPLEFT", 5, yOffset)
            sliderContainer:SetSize(280, 20)
            
            local sliderLabel = sliderContainer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            sliderLabel:SetPoint("LEFT", 0, 0)
            sliderLabel:SetText(label)
            sliderLabel:SetWidth(85)
            sliderLabel:SetJustifyH("LEFT")
            
            local slider = CreateFrame("Slider", nil, sliderContainer, "OptionsSliderTemplate")
            slider:SetPoint("LEFT", 88, 0)
            slider:SetSize(140, 16)
            slider:SetMinMaxValues(minVal, maxVal)
            slider:SetValueStep(step)
            slider:SetObeyStepOnDrag(true)
            slider:SetValue(settingsTable[key] or minVal)
            slider.Low:SetText("")
            slider.High:SetText("")
            
            local valueText = sliderContainer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            valueText:SetPoint("LEFT", slider, "RIGHT", 6, 0)
            
            local function UpdateText(value)
                if isFloat then
                    valueText:SetText(string.format("%.2f", value))
                else
                    valueText:SetText(string.format("%.0f", value))
                end
            end
            
            UpdateText(settingsTable[key] or minVal)
            
            slider:SetScript("OnValueChanged", function(self, value)
                settingsTable[key] = value
                UpdateText(value)
                module:RefreshFrame(unit)
            end)
            
            yOffset = yOffset - 22
            return slider
        end
        
        -- Helper: Dropdown
        local function CreateDropdown(label, options, settingsTable, key, callback)
            controlIndex = controlIndex + 1
            
            local dropContainer = CreateFrame("Frame", nil, content)
            dropContainer:SetPoint("TOPLEFT", 5, yOffset)
            dropContainer:SetSize(280, 26)
            
            local dropLabel = dropContainer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            dropLabel:SetPoint("LEFT", 0, 0)
            dropLabel:SetText(label)
            dropLabel:SetWidth(85)
            dropLabel:SetJustifyH("LEFT")
            
            local dropdownName = "TweaksUI_UF_" .. unit .. "_" .. categoryId .. "_DD" .. controlIndex
            local dropdown = CreateFrame("Frame", dropdownName, dropContainer, "UIDropDownMenuTemplate")
            dropdown:SetPoint("LEFT", 68, 0)
            UIDropDownMenu_SetWidth(dropdown, 130)
            
            local currentName = settingsTable[key]
            for _, opt in ipairs(options) do
                if opt.id == settingsTable[key] then
                    currentName = opt.name
                    break
                end
            end
            UIDropDownMenu_SetText(dropdown, currentName)
            
            UIDropDownMenu_Initialize(dropdown, function(self, level)
                for _, opt in ipairs(options) do
                    local info = UIDropDownMenu_CreateInfo()
                    info.text = opt.name
                    info.checked = (settingsTable[key] == opt.id)
                    info.func = function()
                        settingsTable[key] = opt.id
                        UIDropDownMenu_SetText(dropdown, opt.name)
                        if callback then callback(opt.id) end
                        module:RefreshFrame(unit)
                    end
                    UIDropDownMenu_AddButton(info)
                end
            end)
            
            yOffset = yOffset - 26
            return dropdown
        end
        
        -- Helper: Color picker
        local function CreateColorPicker(label, settingsTable, key)
            local colorContainer = CreateFrame("Frame", nil, content)
            colorContainer:SetPoint("TOPLEFT", 5, yOffset)
            colorContainer:SetSize(280, 22)
            
            local colorLabel = colorContainer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            colorLabel:SetPoint("LEFT", 0, 0)
            colorLabel:SetText(label)
            colorLabel:SetWidth(85)
            colorLabel:SetJustifyH("LEFT")
            
            -- Ensure color exists with defaults
            local color = settingsTable[key]
            if not color or type(color) ~= "table" then
                color = {1, 1, 1, 1}
                settingsTable[key] = color
            end
            
            local swatch = CreateFrame("Button", nil, colorContainer)
            swatch:SetPoint("LEFT", 88, 0)
            swatch:SetSize(22, 22)
            
            local swatchColor = swatch:CreateTexture(nil, "OVERLAY")
            swatchColor:SetAllPoints()
            swatchColor:SetColorTexture(color[1] or 1, color[2] or 1, color[3] or 1, color[4] or 1)
            
            local swatchBorder = swatch:CreateTexture(nil, "BORDER")
            swatchBorder:SetPoint("TOPLEFT", -1, 1)
            swatchBorder:SetPoint("BOTTOMRIGHT", 1, -1)
            swatchBorder:SetColorTexture(0.3, 0.3, 0.3, 1)
            
            swatch:SetScript("OnClick", function()
                local prev = { r = color[1], g = color[2], b = color[3], opacity = color[4] or 1 }
                ColorPickerFrame:SetupColorPickerAndShow({
                    r = color[1], g = color[2], b = color[3], opacity = color[4] or 1,
                    hasOpacity = true,
                    swatchFunc = function()
                        local r, g, b = ColorPickerFrame:GetColorRGB()
                        local a = ColorPickerFrame:GetColorAlpha()
                        settingsTable[key] = { r, g, b, a }
                        swatchColor:SetColorTexture(r, g, b, a)
                        module:RefreshFrame(unit)
                    end,
                    cancelFunc = function()
                        settingsTable[key] = { prev.r, prev.g, prev.b, prev.opacity }
                        swatchColor:SetColorTexture(prev.r, prev.g, prev.b, prev.opacity)
                        module:RefreshFrame(unit)
                    end,
                })
            end)
            
            yOffset = yOffset - 24
            return swatch
        end
        
        -- ====================================================================
        -- BUILD CATEGORY-SPECIFIC UI
        -- ====================================================================
        
        if categoryId == "frame" then
            -- FRAME & BACKGROUND
            
            CreateHeader("General")
            -- For raid frames, use parent settings for enable checkbox
            if isRaid and parentRaidSettings then
                CreateCheckbox("Enable Raid Frames", parentRaidSettings, "enabled")
            else
                CreateCheckbox("Enable " .. (displayNames[unit] or unit), unitSettings, "enabled")
            end
            
            -- Skip Scale for party/raid - container handles scaling
            if not isGroupFrame then
                CreateSlider("Scale:", visualSettings.frame, "scale", 0.5, 2.0, 0.05, true)
            end
            
            -- Skip X/Y/Anchor for party/raid - container handles positioning
            if not isGroupFrame then
                CreateSlider("X Position:", visualSettings.frame, "x", -800, 800, 1)
                CreateSlider("Y Position:", visualSettings.frame, "y", -500, 500, 1)
                CreateDropdown("Anchor:", ANCHOR_POINTS, visualSettings.frame, "anchor")
            end
            
            CreateHeader("Size")
            if visualSettings.frame.autoSize ~= nil then
                CreateCheckbox("Auto Size (fit to bars)", visualSettings.frame, "autoSize")
            end
            CreateSlider("Width:", visualSettings.frame, "width", 50, 400, 1)
            CreateSlider("Height:", visualSettings.frame, "height", 20, 100, 1)
            
            if visualSettings.frame.padding ~= nil then
                CreateHeader("Spacing")
                CreateSlider("Padding:", visualSettings.frame, "padding", 0, 10, 1)
                CreateSlider("Bar Spacing:", visualSettings.frame, "barSpacing", 0, 10, 1)
                CreateSlider("Extend Top:", visualSettings.frame, "bgExtendTop", 0, 30, 1)
                CreateSlider("Extend Bottom:", visualSettings.frame, "bgExtendBottom", 0, 30, 1)
            end
            
            CreateHeader("Background")
            CreateCheckbox("Show Background", visualSettings.frame, "showBackground")
            CreateColorPicker("BG Color:", visualSettings.frame, "bgColor")
            
            CreateHeader("Border")
            CreateCheckbox("Show Border", visualSettings.frame, "showBorder")
            CreateColorPicker("Border Color:", visualSettings.frame, "borderColor")
            CreateSlider("Border Size:", visualSettings.frame, "borderSize", 1, 5, 1)
            
        elseif categoryId == "health" then
            -- HEALTH BAR
            
            
            CreateHeader("Health Bar")
            if visualSettings.healthBar then
                if visualSettings.healthBar.enabled ~= nil then
                    CreateCheckbox("Enable Health Bar", visualSettings.healthBar, "enabled")
                end
                CreateSlider("Height:", visualSettings.healthBar, "height", 4, 60, 1)
                CreateDropdown("Color Mode:", HEALTH_COLOR_MODES, visualSettings.healthBar, "colorMode")
                CreateColorPicker("Custom Color:", visualSettings.healthBar, "customColor")
                if visualSettings.healthBar.bgColor then
                    CreateColorPicker("Background:", visualSettings.healthBar, "bgColor")
                end
                
                if LibSharedMedia then
                    local textures = LibSharedMedia:List("statusbar")
                    local texOpts = {}
                    for _, tex in ipairs(textures) do
                        table.insert(texOpts, { id = tex, name = tex })
                    end
                    CreateDropdown("Texture:", texOpts, visualSettings.healthBar, "texture")
                end
            end
            
            if visualSettings.healthText then
                CreateHeader("Health Text")
                CreateCheckbox("Enable Health Text", visualSettings.healthText, "enabled")
                CreateDropdown("Format:", HEALTH_TEXT_FORMATS, visualSettings.healthText, "format")
                if visualSettings.healthText.abbreviate ~= nil then
                    CreateCheckbox("Abbreviate Numbers", visualSettings.healthText, "abbreviate")
                end
                if visualSettings.healthText.colorByHealth ~= nil then
                    CreateCheckbox("Color by Health %", visualSettings.healthText, "colorByHealth")
                end
                CreateSlider("Font Size:", visualSettings.healthText, "fontSize", 8, 24, 1)
                CreateDropdown("Outline:", FONT_OUTLINES, visualSettings.healthText, "fontOutline")
                if visualSettings.healthText.color then
                    CreateColorPicker("Text Color:", visualSettings.healthText, "color")
                end
                
                CreateHeader("Health Text Position")
                if visualSettings.healthText.hAlign then
                    CreateDropdown("H Align:", HORIZONTAL_ALIGN, visualSettings.healthText, "hAlign")
                    CreateDropdown("V Align:", VERTICAL_ALIGN, visualSettings.healthText, "vAlign")
                end
                CreateSlider("Offset X:", visualSettings.healthText, "offsetX", -100, 100, 1)
                CreateSlider("Offset Y:", visualSettings.healthText, "offsetY", -50, 50, 1)
            end
            
        elseif categoryId == "power" then
            -- POWER BAR
            
            
            CreateHeader("Power Bar")
            if visualSettings.powerBar then
                CreateCheckbox("Enable Power Bar", visualSettings.powerBar, "enabled")
                CreateSlider("Height:", visualSettings.powerBar, "height", 2, 30, 1)
                if visualSettings.powerBar.colorMode then
                    CreateDropdown("Color Mode:", POWER_COLOR_MODES, visualSettings.powerBar, "colorMode")
                    CreateColorPicker("Custom Color:", visualSettings.powerBar, "customColor")
                end
                if visualSettings.powerBar.bgColor then
                    CreateColorPicker("Background:", visualSettings.powerBar, "bgColor")
                end
                
                if LibSharedMedia then
                    local textures = LibSharedMedia:List("statusbar")
                    local texOpts = {}
                    for _, tex in ipairs(textures) do
                        table.insert(texOpts, { id = tex, name = tex })
                    end
                    CreateDropdown("Texture:", texOpts, visualSettings.powerBar, "texture")
                end
            end
            
            if visualSettings.powerText then
                CreateHeader("Power Text")
                CreateCheckbox("Enable Power Text", visualSettings.powerText, "enabled")
                CreateDropdown("Format:", POWER_TEXT_FORMATS, visualSettings.powerText, "format")
                if visualSettings.powerText.abbreviate ~= nil then
                    CreateCheckbox("Abbreviate Numbers", visualSettings.powerText, "abbreviate")
                end
                CreateSlider("Font Size:", visualSettings.powerText, "fontSize", 8, 18, 1)
                CreateDropdown("Outline:", FONT_OUTLINES, visualSettings.powerText, "fontOutline")
                if visualSettings.powerText.color then
                    CreateColorPicker("Text Color:", visualSettings.powerText, "color")
                end
                
                if visualSettings.powerText.hAlign then
                    CreateHeader("Power Text Position")
                    CreateDropdown("H Align:", HORIZONTAL_ALIGN, visualSettings.powerText, "hAlign")
                    CreateDropdown("V Align:", VERTICAL_ALIGN, visualSettings.powerText, "vAlign")
                    CreateSlider("Offset X:", visualSettings.powerText, "offsetX", -100, 100, 1)
                    CreateSlider("Offset Y:", visualSettings.powerText, "offsetY", -50, 50, 1)
                end
            end
            
        elseif categoryId == "castbar" then
            -- CAST BAR
            
            -- Helper function to update preview after cast bar changes
            local function UpdateCastBarPreview()
                if currentOpenPanel then
                    module:ShowPanelPreview(currentOpenPanel)
                end
            end
            
            CreateHeader("Cast Bar Settings")
            if visualSettings.castBar then
                CreateCheckbox("Enable Cast Bar", visualSettings.castBar, "enabled", UpdateCastBarPreview)
                CreateSlider("Height:", visualSettings.castBar, "height", 4, 20, 1)
                CreateCheckbox("Show Spell Icon", visualSettings.castBar, "showIcon", UpdateCastBarPreview)
                CreateCheckbox("Show Timer", visualSettings.castBar, "showTimer", UpdateCastBarPreview)
                CreateCheckbox("Show Spell Name", visualSettings.castBar, "showSpellName", UpdateCastBarPreview)
                if visualSettings.castBar.attachedTo then
                    local CASTBAR_POSITIONS = {
                        { id = "bottom", name = "Below Frame" },
                        { id = "health", name = "Inside Health Bar" },
                    }
                    CreateDropdown("Position:", CASTBAR_POSITIONS, visualSettings.castBar, "attachedTo")
                    CreateSlider("Offset Y:", visualSettings.castBar, "offsetY", -20, 20, 1)
                end
            else
                local label = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                label:SetPoint("TOPLEFT", 5, yOffset)
                label:SetText("|cffff6666Cast bar settings unavailable for this layout.|r")
                yOffset = yOffset - 20
            end
            
        elseif categoryId == "text" then
            -- TEXT & ICONS
            
            
            if visualSettings.nameText then
                CreateHeader("Name Text")
                CreateCheckbox("Enable Name", visualSettings.nameText, "enabled")
                if visualSettings.nameText.anchorToHealthBar ~= nil then
                    CreateCheckbox("Inside Health Bar", visualSettings.nameText, "anchorToHealthBar")
                end
                CreateSlider("Font Size:", visualSettings.nameText, "fontSize", 8, 24, 1)
                CreateDropdown("Outline:", FONT_OUTLINES, visualSettings.nameText, "fontOutline")
                CreateDropdown("Color Mode:", NAME_COLOR_MODES, visualSettings.nameText, "colorMode")
                CreateColorPicker("Custom Color:", visualSettings.nameText, "customColor")
                if visualSettings.nameText.frameAnchor then
                    CreateDropdown("Position:", ANCHOR_POINTS, visualSettings.nameText, "frameAnchor")
                end
                if visualSettings.nameText.hAlign then
                    CreateDropdown("H Align:", HORIZONTAL_ALIGN, visualSettings.nameText, "hAlign")
                end
                CreateSlider("Offset X:", visualSettings.nameText, "offsetX", -100, 100, 1)
                CreateSlider("Offset Y:", visualSettings.nameText, "offsetY", -50, 50, 1)
                if visualSettings.nameText.maxLength then
                    CreateSlider("Max Length:", visualSettings.nameText, "maxLength", 0, 20, 1)
                end
            end
            
            -- Level Text - skip for party/raid frames (level synced in instances)
            if visualSettings.levelText and not isGroupFrame then
                CreateHeader("Level Text")
                CreateCheckbox("Enable Level", visualSettings.levelText, "enabled")
                CreateCheckbox("Show Classification", visualSettings.levelText, "showClassification")
                CreateCheckbox("Hide at Max Level", visualSettings.levelText, "hideAtMaxLevel")
                CreateSlider("Font Size:", visualSettings.levelText, "fontSize", 8, 18, 1)
                CreateDropdown("Outline:", FONT_OUTLINES, visualSettings.levelText, "fontOutline")
                CreateDropdown("Position:", ANCHOR_POINTS, visualSettings.levelText, "frameAnchor")
                CreateDropdown("H Align:", HORIZONTAL_ALIGN, visualSettings.levelText, "hAlign")
                CreateSlider("Offset X:", visualSettings.levelText, "offsetX", -100, 100, 1)
                CreateSlider("Offset Y:", visualSettings.levelText, "offsetY", -50, 50, 1)
            end
            
            if visualSettings.raidTarget then
                CreateHeader("Raid Target Icon")
                CreateCheckbox("Enable Raid Target", visualSettings.raidTarget, "enabled")
                CreateSlider("Size:", visualSettings.raidTarget, "size", 8, 64, 1)
                CreateDropdown("Icon Anchor:", ANCHOR_POINTS, visualSettings.raidTarget, "anchor")
                CreateDropdown("Frame Anchor:", ANCHOR_POINTS, visualSettings.raidTarget, "frameAnchor")
                CreateSlider("Offset X:", visualSettings.raidTarget, "offsetX", -50, 50, 1)
                CreateSlider("Offset Y:", visualSettings.raidTarget, "offsetY", -50, 50, 1)
            end
            
            if visualSettings.roleIcon then
                CreateHeader("Role Icon")
                CreateCheckbox("Enable Role Icon", visualSettings.roleIcon, "enabled")
                CreateSlider("Size:", visualSettings.roleIcon, "size", 8, 64, 1)
                CreateDropdown("Icon Anchor:", ANCHOR_POINTS, visualSettings.roleIcon, "anchor")
                CreateDropdown("Frame Anchor:", ANCHOR_POINTS, visualSettings.roleIcon, "frameAnchor")
                CreateSlider("Offset X:", visualSettings.roleIcon, "offsetX", -50, 50, 1)
                CreateSlider("Offset Y:", visualSettings.roleIcon, "offsetY", -50, 50, 1)
            end
            
        elseif categoryId == "portrait" then
            -- PORTRAIT
            
            
            CreateHeader("Portrait Settings")
            if visualSettings.portrait then
                CreateDropdown("Mode:", PORTRAIT_MODES, visualSettings.portrait, "mode", function(newMode)
                    visualSettings.portrait.enabled = (newMode ~= "none")
                end)
                CreateDropdown("Position:", PORTRAIT_POSITIONS, visualSettings.portrait, "position")
                CreateCheckbox("Outside Frame", visualSettings.portrait, "outside")
                CreateSlider("Size:", visualSettings.portrait, "size", 10, 80, 1)
                CreateSlider("Offset X:", visualSettings.portrait, "offsetX", -80, 50, 1)
                CreateSlider("Offset Y:", visualSettings.portrait, "offsetY", -50, 50, 1)
            else
                local label = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                label:SetPoint("TOPLEFT", 5, yOffset)
                label:SetText("|cffff6666Portrait settings unavailable for this layout.|r")
                yOffset = yOffset - 20
            end
            
        elseif categoryId == "container" then
            -- PARTY/RAID CONTAINER (group-specific)
            if isParty then
                CreateHeader("Party Container")
                CreateCheckbox("Enable Party Frames", unitSettings, "enabled")
                
                if unitSettings.container then
                    CreateHeader("Growth Direction")
                    local growthOptions = {
                        { id = "DOWN", name = "Down" },
                        { id = "UP", name = "Up" },
                        { id = "RIGHT", name = "Right" },
                        { id = "LEFT", name = "Left" },
                    }
                    CreateDropdown("Direction:", growthOptions, unitSettings.container, "growthDirection")
                    CreateSlider("Spacing:", unitSettings.container, "spacing", 0, 20, 1)
                    CreateSlider("Scale:", unitSettings.container, "scale", 0.5, 2.0, 0.05, true)
                    
                    CreateHeader("Container Position")
                    CreateSlider("X Position:", unitSettings.container, "x", -800, 800, 1)
                    CreateSlider("Y Position:", unitSettings.container, "y", -500, 500, 1)
                    CreateDropdown("Anchor:", ANCHOR_POINTS, unitSettings.container, "anchor")
                    
                    CreateHeader("Sorting")
                    local sortOptions = {
                        { id = "NONE", name = "None (Group Order)" },
                        { id = "TANK_HEALER_DPS", name = "Tank > Healer > DPS" },
                        { id = "HEALER_TANK_DPS", name = "Healer > Tank > DPS" },
                        { id = "DPS_TANK_HEALER", name = "DPS > Tank > Healer" },
                        { id = "DPS_HEALER_TANK", name = "DPS > Healer > Tank" },
                    }
                    CreateDropdown("Sort By:", sortOptions, unitSettings.container, "sortBy")
                end
            elseif isRaid then
                -- RAID FRAMES - separate panels for small and large
                local layoutLabel = isRaidSmall and "Small Raid (10-20)" or "Large Raid (21-40)"
                CreateHeader(layoutLabel)
                
                -- Enable checkbox controls the master raid enabled flag
                if parentRaidSettings then
                    CreateCheckbox("Enable Raid Frames", parentRaidSettings, "enabled")
                    
                    -- Size threshold only shown in small raid panel
                    if isRaidSmall then
                        CreateHeader("Size Threshold")
                        local thresholdInfo = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                        thresholdInfo:SetPoint("TOPLEFT", 10, yOffset)
                        thresholdInfo:SetWidth(300)
                        thresholdInfo:SetJustifyH("LEFT")
                        thresholdInfo:SetText("|cff888888Small layout for ≤ threshold players|r")
                        yOffset = yOffset - 18
                        CreateSlider("Threshold:", parentRaidSettings, "sizeThreshold", 10, 30, 1)
                    end
                end
                
                -- Layout settings for this specific size
                if unitSettings.layout then
                    CreateHeader("Layout Mode")
                    local layoutModes = {
                        { id = "GRID", name = "Grid (ignore groups)" },
                        { id = "GROUP_ROWS", name = "Group Rows (G1 G2 G3...)" },
                        { id = "GROUP_COLUMNS", name = "Group Columns (G1 over G2)" },
                    }
                    CreateDropdown("Mode:", layoutModes, unitSettings.layout, "mode")
                    
                    -- Grid-specific settings
                    CreateHeader("Grid Settings")
                    local gridInfo = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    gridInfo:SetPoint("TOPLEFT", 10, yOffset)
                    gridInfo:SetText("|cff888888(Only used in Grid mode)|r")
                    yOffset = yOffset - 16
                    
                    CreateSlider("Columns:", unitSettings.layout, "columns", 1, 10, 1)
                    CreateSlider("Spacing:", unitSettings.layout, "spacing", 0, 10, 1)
                    
                    local growthOptions = {
                        { id = "DOWN", name = "Down" },
                        { id = "UP", name = "Up" },
                        { id = "RIGHT", name = "Right" },
                        { id = "LEFT", name = "Left" },
                    }
                    CreateDropdown("Fill Direction:", growthOptions, unitSettings.layout, "growthDirection")
                    
                    -- Group-specific settings
                    CreateHeader("Group Layout Settings")
                    local groupInfo = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    groupInfo:SetPoint("TOPLEFT", 10, yOffset)
                    groupInfo:SetText("|cff888888(Only used in Group Rows/Columns modes)|r")
                    yOffset = yOffset - 16
                    
                    CreateSlider("Groups per Row:", unitSettings.layout, "groupsPerRow", 1, 8, 1)
                    CreateSlider("Groups per Column:", unitSettings.layout, "groupsPerColumn", 1, 8, 1)
                    CreateSlider("Group Spacing:", unitSettings.layout, "groupSpacing", 0, 20, 1)
                    
                    CreateHeader("Members Within Group")
                    CreateSlider("Members per Row:", unitSettings.layout, "membersPerRow", 1, 5, 1)
                    
                    local memberGrowthOptions = {
                        { id = "DOWN", name = "Down (rows of members)" },
                        { id = "RIGHT", name = "Right (columns of members)" },
                    }
                    CreateDropdown("Member Fill:", memberGrowthOptions, unitSettings.layout, "memberGrowth")
                end
                
                -- Container position
                if unitSettings.container then
                    CreateHeader("Container")
                    CreateSlider("Scale:", unitSettings.container, "scale", 0.5, 2.0, 0.05, true)
                    CreateSlider("X Position:", unitSettings.container, "x", -800, 800, 1)
                    CreateSlider("Y Position:", unitSettings.container, "y", -500, 500, 1)
                    CreateDropdown("Anchor:", ANCHOR_POINTS, unitSettings.container, "anchor")
                end
            elseif isTanks then
                -- TANK FRAMES
                CreateHeader("Tank Frames")
                CreateCheckbox("Enable Tank Frames", unitSettings, "enabled")
                
                CreateHeader("Which Tanks to Show")
                CreateCheckbox("Show Main Tanks", unitSettings, "showMainTank")
                CreateCheckbox("Show Main Assists", unitSettings, "showMainAssist")
                CreateCheckbox("Show Role Tanks", unitSettings, "showRoleTanks")
                CreateSlider("Max Tanks:", unitSettings, "maxTanks", 2, 6, 1)
                
                if unitSettings.layout then
                    CreateHeader("Layout")
                    local dirOptions = {
                        { id = "DOWN", name = "Stack Down" },
                        { id = "UP", name = "Stack Up" },
                        { id = "RIGHT", name = "Stack Right" },
                        { id = "LEFT", name = "Stack Left" },
                    }
                    CreateDropdown("Direction:", dirOptions, unitSettings.layout, "direction")
                    CreateSlider("Spacing:", unitSettings.layout, "spacing", 0, 10, 1)
                end
                
                if unitSettings.container then
                    CreateHeader("Container Position")
                    CreateSlider("Scale:", unitSettings.container, "scale", 0.5, 2.0, 0.05, true)
                    CreateSlider("X Position:", unitSettings.container, "x", -800, 800, 1)
                    CreateSlider("Y Position:", unitSettings.container, "y", -500, 500, 1)
                    CreateDropdown("Anchor:", ANCHOR_POINTS, unitSettings.container, "anchor")
                end
            elseif isBoss then
                -- BOSS FRAMES
                CreateHeader("Boss Frames")
                CreateCheckbox("Enable Boss Frames", unitSettings, "enabled")
                
                CreateSlider("Max Bosses:", unitSettings, "maxBosses", 1, 5, 1)
                
                if unitSettings.layout then
                    CreateHeader("Layout")
                    local dirOptions = {
                        { id = "DOWN", name = "Stack Down" },
                        { id = "UP", name = "Stack Up" },
                        { id = "RIGHT", name = "Stack Right" },
                        { id = "LEFT", name = "Stack Left" },
                    }
                    CreateDropdown("Direction:", dirOptions, unitSettings.layout, "direction")
                    CreateSlider("Spacing:", unitSettings.layout, "spacing", 0, 10, 1)
                end
                
                if unitSettings.container then
                    CreateHeader("Container Position")
                    CreateSlider("Scale:", unitSettings.container, "scale", 0.5, 2.0, 0.05, true)
                    CreateSlider("X Position:", unitSettings.container, "x", -800, 800, 1)
                    CreateSlider("Y Position:", unitSettings.container, "y", -500, 500, 1)
                    CreateDropdown("Anchor:", ANCHOR_POINTS, unitSettings.container, "anchor")
                end
                
                if unitSettings.castBar then
                    CreateHeader("Cast Bar")
                    CreateCheckbox("Show Cast Bar", unitSettings.castBar, "enabled")
                    CreateSlider("Height:", unitSettings.castBar, "height", 5, 20, 1)
                    CreateCheckbox("Show Spell Icon", unitSettings.castBar, "showIcon")
                    CreateCheckbox("Show Timer", unitSettings.castBar, "showTimer")
                end
            end
            
        elseif categoryId == "debuffs" then
            -- DEBUFF INDICATORS
            
            
            if visualSettings.debuffIndicators then
                CreateHeader("Debuff Indicators")
                CreateCheckbox("Enable Debuff Indicators", visualSettings.debuffIndicators, "enabled")
                
                CreateHeader("Debuff Types to Show")
                CreateCheckbox("Magic (Blue)", visualSettings.debuffIndicators, "showMagic")
                CreateCheckbox("Curse (Purple)", visualSettings.debuffIndicators, "showCurse")
                CreateCheckbox("Disease (Brown)", visualSettings.debuffIndicators, "showDisease")
                CreateCheckbox("Poison (Green)", visualSettings.debuffIndicators, "showPoison")
                if visualSettings.debuffIndicators.showBleed ~= nil then
                    CreateCheckbox("Bleed (Red)", visualSettings.debuffIndicators, "showBleed")
                end
                
                CreateHeader("Appearance")
                CreateSlider("Size:", visualSettings.debuffIndicators, "size", 6, 24, 1)
                CreateDropdown("Position:", ANCHOR_POINTS, visualSettings.debuffIndicators, "position")
                CreateSlider("Offset X:", visualSettings.debuffIndicators, "offsetX", -50, 50, 1)
                CreateSlider("Offset Y:", visualSettings.debuffIndicators, "offsetY", -50, 50, 1)
                CreateCheckbox("Show Border", visualSettings.debuffIndicators, "showBorder")
            else
                local label = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                label:SetPoint("TOPLEFT", 5, yOffset)
                label:SetText("|cff888888Debuff indicators not available for this frame type.|r")
                yOffset = yOffset - 20
            end
        
        elseif categoryId == "visibility" then
            -- VISIBILITY SETTINGS
            
            -- Ensure visibility settings exist for this frame
            if not visualSettings.visibility then
                visualSettings.visibility = {
                    enabled = false,
                    combat = false,
                    mouseover = false,
                    target = false,
                    group = false,
                    instance = false,
                    instanceTypes = {},
                    fadeAlpha = 0,
                }
            end
            local vis = visualSettings.visibility
            
            -- Description
            local desc = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            desc:SetPoint("TOPLEFT", 5, yOffset)
            desc:SetWidth(PANEL_WIDTH - 60)
            desc:SetText("Control when this frame is visible. When enabled, the frame hides until ANY checked condition is met.")
            desc:SetTextColor(0.7, 0.7, 0.7)
            desc:SetJustifyH("LEFT")
            yOffset = yOffset - 40
            
            CreateHeader("Visibility Controls")
            
            -- Enable checkbox
            local enableCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            enableCB:SetPoint("TOPLEFT", 5, yOffset)
            enableCB.Text:SetText("Enable visibility controls for this frame")
            enableCB:SetChecked(vis.enabled or false)
            enableCB:SetScript("OnClick", function(self)
                vis.enabled = self:GetChecked() and true or false
                VisibilityManager:ApplyVisibilityForUnit(unit)
                VisibilityManager:UpdateMouseoverForUnit(unit)
            end)
            yOffset = yOffset - 28
            
            -- Conditions header
            local condLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            condLabel:SetPoint("TOPLEFT", 5, yOffset)
            condLabel:SetText("Show this frame when:")
            condLabel:SetTextColor(1, 0.82, 0)
            yOffset = yOffset - 22
            
            -- Combat
            local combatCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            combatCB:SetPoint("TOPLEFT", 15, yOffset)
            combatCB.Text:SetText("In combat")
            combatCB:SetChecked(vis.combat or false)
            combatCB:SetScript("OnClick", function(self)
                vis.combat = self:GetChecked() and true or false
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            yOffset = yOffset - 24
            
            -- Mouseover
            local mouseoverCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            mouseoverCB:SetPoint("TOPLEFT", 15, yOffset)
            mouseoverCB.Text:SetText("Mouse over this frame")
            mouseoverCB:SetChecked(vis.mouseover or false)
            mouseoverCB:SetScript("OnClick", function(self)
                vis.mouseover = self:GetChecked() and true or false
                VisibilityManager:UpdateMouseoverForUnit(unit)
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            yOffset = yOffset - 24
            
            -- Target
            local targetCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            targetCB:SetPoint("TOPLEFT", 15, yOffset)
            targetCB.Text:SetText("Have a target")
            targetCB:SetChecked(vis.target or false)
            targetCB:SetScript("OnClick", function(self)
                vis.target = self:GetChecked() and true or false
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            yOffset = yOffset - 24
            
            -- Group
            local groupCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            groupCB:SetPoint("TOPLEFT", 15, yOffset)
            groupCB.Text:SetText("In a party or raid")
            groupCB:SetChecked(vis.group or false)
            groupCB:SetScript("OnClick", function(self)
                vis.group = self:GetChecked() and true or false
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            yOffset = yOffset - 24
            
            -- Instance
            local instanceCB = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
            instanceCB:SetPoint("TOPLEFT", 15, yOffset)
            instanceCB.Text:SetText("In specific instances:")
            instanceCB:SetChecked(vis.instance or false)
            instanceCB:SetScript("OnClick", function(self)
                vis.instance = self:GetChecked() and true or false
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            yOffset = yOffset - 22
            
            -- Instance type sub-options
            local instanceTypes = {
                { id = "party", text = "Dungeons" },
                { id = "raid", text = "Raids" },
                { id = "arena", text = "Arenas" },
                { id = "pvp", text = "Battlegrounds" },
                { id = "scenario", text = "Scenarios" },
            }
            
            vis.instanceTypes = vis.instanceTypes or {}
            for _, inst in ipairs(instanceTypes) do
                local cb = CreateFrame("CheckButton", nil, content, "ChatConfigCheckButtonTemplate")
                cb:SetPoint("TOPLEFT", 35, yOffset)
                cb.Text:SetText(inst.text)
                cb.Text:SetFontObject("GameFontNormalSmall")
                cb:SetChecked(vis.instanceTypes[inst.id] or false)
                cb:SetScript("OnClick", function(self)
                    vis.instanceTypes[inst.id] = self:GetChecked() and true or false
                    VisibilityManager:ApplyVisibilityForUnit(unit)
                end)
                yOffset = yOffset - 20
            end
            yOffset = yOffset - 15
            
            -- Fade alpha section
            CreateHeader("Hidden Opacity")
            
            local fadeDesc = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            fadeDesc:SetPoint("TOPLEFT", 5, yOffset)
            fadeDesc:SetWidth(PANEL_WIDTH - 60)
            fadeDesc:SetText("When conditions are not met, fade to this opacity (0 = invisible)")
            fadeDesc:SetTextColor(0.6, 0.6, 0.6)
            yOffset = yOffset - 22
            
            local fadeLabel = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            fadeLabel:SetPoint("TOPLEFT", 5, yOffset)
            fadeLabel:SetText(string.format("Opacity: %d%%", vis.fadeAlpha or 0))
            yOffset = yOffset - 22
            
            local fadeSlider = CreateFrame("Slider", nil, content, "OptionsSliderTemplate")
            fadeSlider:SetPoint("TOPLEFT", 5, yOffset)
            fadeSlider:SetMinMaxValues(0, 100)
            fadeSlider:SetValueStep(5)
            fadeSlider:SetObeyStepOnDrag(true)
            fadeSlider:SetWidth(200)
            fadeSlider.Low:SetText("0%")
            fadeSlider.High:SetText("100%")
            
            local initSlider = true
            fadeSlider:SetScript("OnValueChanged", function(self, value)
                if initSlider then return end
                fadeLabel:SetText(string.format("Opacity: %d%%", value))
                vis.fadeAlpha = value
                VisibilityManager:ApplyVisibilityForUnit(unit)
            end)
            fadeSlider:SetValue(vis.fadeAlpha or 0)
            initSlider = false
            yOffset = yOffset - 45
        end
    end
    
    -- ========================================================================
    -- CREATE TAB BUTTONS AND CONTENT
    -- ========================================================================
    
    -- Tab container
    local tabContainer = CreateFrame("Frame", nil, container)
    tabContainer:SetPoint("TOPLEFT", 5, -32)
    tabContainer:SetPoint("TOPRIGHT", -5, -32)
    tabContainer:SetHeight(24)
    
    local currentTabIndex = 1
    
    local function ShowTab(categoryId)
        -- Hide all content frames
        for id, contentFrame in pairs(categoryPanels) do
            contentFrame:Hide()
        end
        -- Update tab button appearance
        for i, btn in ipairs(tabButtons) do
            if btn.categoryId == categoryId then
                btn.bg:SetColorTexture(0.25, 0.25, 0.4, 1)
                btn.text:SetTextColor(1, 1, 1)
                currentTabIndex = i
            else
                btn.bg:SetColorTexture(0.15, 0.15, 0.15, 0.9)
                btn.text:SetTextColor(0.7, 0.7, 0.7)
            end
        end
        -- Show selected content
        if categoryPanels[categoryId] then
            categoryPanels[categoryId]:Show()
            activeCategory = categoryId
        end
        -- Update copy dropdown for this category
        UpdateCopyDropdown(categoryId)
    end
    
    local tabWidth = (PANEL_WIDTH - 14) / #categories
    
    for i, cat in ipairs(categories) do
        -- Create tab button
        local tabBtn = CreateFrame("Button", nil, tabContainer)
        tabBtn:SetSize(tabWidth - 1, 22)
        tabBtn:SetPoint("LEFT", (i - 1) * tabWidth, 0)
        
        tabBtn.bg = tabBtn:CreateTexture(nil, "BACKGROUND")
        tabBtn.bg:SetAllPoints()
        tabBtn.bg:SetColorTexture(0.15, 0.15, 0.15, 0.9)
        
        tabBtn.text = tabBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        tabBtn.text:SetPoint("CENTER")
        tabBtn.text:SetText(cat.name)
        tabBtn.text:SetTextColor(0.7, 0.7, 0.7)
        
        tabBtn.categoryId = cat.id
        
        tabBtn:SetScript("OnClick", function()
            ShowTab(cat.id)
        end)
        
        tabBtn:SetScript("OnEnter", function(self)
            if activeCategory ~= cat.id then
                self.bg:SetColorTexture(0.2, 0.2, 0.3, 0.95)
            end
        end)
        
        tabBtn:SetScript("OnLeave", function(self)
            if activeCategory ~= cat.id then
                self.bg:SetColorTexture(0.15, 0.15, 0.15, 0.9)
            end
        end)
        
        tabButtons[i] = tabBtn
        
        -- Create the content frame for this tab
        local contentFrame = CreateCategoryContent(cat.id)
        BuildCategoryUI(contentFrame, cat.id)
        categoryPanels[cat.id] = contentFrame
    end
    
    -- Show first tab by default (container for party/raid, frame for others)
    ShowTab(isGroupFrame and "container" or "frame")
    
    container:Hide()
    settingsPanels[unit] = container
end

-- Return module
return UnitFrames
