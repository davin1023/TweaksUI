-- TweaksUI Database
-- Profile and settings management

local ADDON_NAME, TweaksUI = ...

TweaksUI.Database = {}
local DB = TweaksUI.Database

-- Default database structure
local DATABASE_DEFAULTS = {
    -- Global settings (not per-profile)
    global = {
        version = TweaksUI.VERSION,
        lastSeenVersion = nil,
        debugMode = false,
        
        -- Module enable/disable states (global, not per-profile)
        modules = {
            cooldowns = false,
            chat = false,
            actionBars = false,
            unitFrames = false,
            resourceBars = false,
            castBars = false,
            nameplates = false,
        },
    },
    
    -- Profile-specific settings
    profiles = {
        ["Default"] = {
            -- Each module stores its settings here
            -- e.g., chat = { ... }, unitFrames = { ... }
        },
    },
    
    -- Profile assignments per character
    profileAssignments = {
        -- ["CharacterName-RealmName"] = "ProfileName"
    },
    
    -- Spec-based auto-switching
    specProfiles = {
        -- ["CharacterName-RealmName"] = { [1] = "ProfileName", [2] = "ProfileName", ... }
    },
}

-- Deep copy utility
local function DeepCopy(orig)
    local copy
    if type(orig) == 'table' then
        copy = {}
        for k, v in pairs(orig) do
            copy[DeepCopy(k)] = DeepCopy(v)
        end
        setmetatable(copy, DeepCopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

-- Merge defaults into existing table (only adds missing keys)
local function MergeDefaults(existing, defaults)
    if type(existing) ~= "table" or type(defaults) ~= "table" then
        return existing or defaults
    end
    
    for key, defaultValue in pairs(defaults) do
        if existing[key] == nil then
            if type(defaultValue) == "table" then
                existing[key] = DeepCopy(defaultValue)
            else
                existing[key] = defaultValue
            end
        elseif type(defaultValue) == "table" and type(existing[key]) == "table" then
            MergeDefaults(existing[key], defaultValue)
        end
    end
    
    return existing
end

-- Initialize database
function DB:Initialize()
    -- Create or update saved variables
    if not TweaksUI_DB then
        TweaksUI_DB = DeepCopy(DATABASE_DEFAULTS)
    end
    
    -- Store reference
    self.db = TweaksUI_DB
    
    -- Initialize per-character database
    if not TweaksUI_CharDB then
        TweaksUI_CharDB = {}
    end
    self.charDb = TweaksUI_CharDB
    
    -- Run migrations if needed
    self:RunMigrations()
    
    -- Ensure all default keys exist
    self:EnsureDefaults()
    
    -- Set up current profile
    self:InitializeCurrentProfile()
    
    TweaksUI:PrintDebug("Database initialized")
end

-- Ensure all default values exist
function DB:EnsureDefaults()
    -- Ensure global section exists
    if not self.db.global then
        self.db.global = DeepCopy(DATABASE_DEFAULTS.global)
    end
    
    -- Ensure modules table exists with all modules
    if not self.db.global.modules then
        self.db.global.modules = DeepCopy(DATABASE_DEFAULTS.global.modules)
    else
        -- Add any missing module entries
        for moduleId, default in pairs(DATABASE_DEFAULTS.global.modules) do
            if self.db.global.modules[moduleId] == nil then
                self.db.global.modules[moduleId] = default
            end
        end
    end
    
    -- Ensure profiles section exists
    if not self.db.profiles then
        self.db.profiles = DeepCopy(DATABASE_DEFAULTS.profiles)
    end
    
    -- Ensure Default profile exists
    if not self.db.profiles["Default"] then
        self.db.profiles["Default"] = {}
    end
    
    -- Ensure profile assignments exist
    if not self.db.profileAssignments then
        self.db.profileAssignments = {}
    end
    
    -- Ensure spec profiles exist
    if not self.db.specProfiles then
        self.db.specProfiles = {}
    end
end

-- Run database migrations
function DB:RunMigrations()
    local currentVersion = self.db.global and self.db.global.version or "0.0.0"
    
    -- Future migrations go here
    -- if self:CompareVersions(currentVersion, "1.1.0") < 0 then
    --     self:MigrateTo_1_1_0()
    -- end
    
    -- Update version
    if self.db.global then
        self.db.global.version = TweaksUI.VERSION
    end
end

-- Compare version strings (returns -1, 0, or 1)
function DB:CompareVersions(v1, v2)
    local function parseVersion(v)
        local major, minor, patch = v:match("(%d+)%.(%d+)%.(%d+)")
        return tonumber(major) or 0, tonumber(minor) or 0, tonumber(patch) or 0
    end
    
    local m1, n1, p1 = parseVersion(v1)
    local m2, n2, p2 = parseVersion(v2)
    
    if m1 ~= m2 then return m1 < m2 and -1 or 1 end
    if n1 ~= n2 then return n1 < n2 and -1 or 1 end
    if p1 ~= p2 then return p1 < p2 and -1 or 1 end
    return 0
end

-- Initialize current profile for this character
function DB:InitializeCurrentProfile()
    local charKey = self:GetCharacterKey()
    
    -- Get assigned profile or default
    local profileName = self.db.profileAssignments[charKey] or "Default"
    
    -- Ensure the profile exists
    if not self.db.profiles[profileName] then
        profileName = "Default"
        self.db.profileAssignments[charKey] = profileName
    end
    
    self.currentProfileName = profileName
    self.currentProfile = self.db.profiles[profileName]
end

-- Get character key for this character
function DB:GetCharacterKey()
    local name = UnitName("player")
    local realm = GetRealmName()
    return name .. "-" .. realm
end

-- ============================================================================
-- PROFILE MANAGEMENT
-- ============================================================================

-- Get current profile
function DB:GetProfile(profileName)
    if profileName then
        return self.db.profiles[profileName]
    end
    return self.currentProfile
end

-- Get current profile name
function DB:GetProfileName()
    return self.currentProfileName
end

-- Check if profile exists
function DB:ProfileExists(profileName)
    return self.db.profiles[profileName] ~= nil
end

-- Set current profile
function DB:SetProfile(profileName)
    if not self.db.profiles[profileName] then
        TweaksUI:PrintError("Profile '" .. profileName .. "' does not exist")
        return false
    end
    
    local charKey = self:GetCharacterKey()
    self.db.profileAssignments[charKey] = profileName
    self.currentProfileName = profileName
    self.currentProfile = self.db.profiles[profileName]
    
    -- Notify modules of profile change
    TweaksUI.Events:Fire(TweaksUI.EVENTS.PROFILE_CHANGED, profileName)
    
    TweaksUI:Print("Switched to profile: " .. profileName)
    return true
end

-- Create a new profile
function DB:CreateProfile(profileName, copyFrom)
    if self.db.profiles[profileName] then
        TweaksUI:PrintError("Profile '" .. profileName .. "' already exists")
        return false
    end
    
    if copyFrom and self.db.profiles[copyFrom] then
        self.db.profiles[profileName] = DeepCopy(self.db.profiles[copyFrom])
    else
        self.db.profiles[profileName] = {}
    end
    
    TweaksUI:Print("Created profile: " .. profileName)
    return true
end

-- Delete a profile
function DB:DeleteProfile(profileName)
    if profileName == "Default" then
        TweaksUI:PrintError("Cannot delete the Default profile")
        return false
    end
    
    if not self.db.profiles[profileName] then
        return false
    end
    
    -- Switch anyone using this profile to Default
    for charKey, assignedProfile in pairs(self.db.profileAssignments) do
        if assignedProfile == profileName then
            self.db.profileAssignments[charKey] = "Default"
        end
    end
    
    -- If current profile, switch to Default
    if self.currentProfileName == profileName then
        self:SetProfile("Default")
    end
    
    self.db.profiles[profileName] = nil
    TweaksUI:Print("Deleted profile: " .. profileName)
    return true
end

-- Copy profile
function DB:CopyProfile(sourceName, destName)
    if not self.db.profiles[sourceName] then
        TweaksUI:PrintError("Source profile '" .. sourceName .. "' does not exist")
        return false
    end
    
    if self.db.profiles[destName] then
        TweaksUI:PrintError("Destination profile '" .. destName .. "' already exists")
        return false
    end
    
    self.db.profiles[destName] = DeepCopy(self.db.profiles[sourceName])
    TweaksUI:Print("Copied profile '" .. sourceName .. "' to '" .. destName .. "'")
    return true
end

-- Get list of profile names
function DB:GetProfileList()
    local list = {}
    for name in pairs(self.db.profiles) do
        table.insert(list, name)
    end
    table.sort(list)
    return list
end

-- Rename profile
function DB:RenameProfile(oldName, newName)
    if oldName == "Default" then
        TweaksUI:PrintError("Cannot rename the Default profile")
        return false
    end
    
    if not self.db.profiles[oldName] then
        TweaksUI:PrintError("Profile '" .. oldName .. "' does not exist")
        return false
    end
    
    if self.db.profiles[newName] then
        TweaksUI:PrintError("Profile '" .. newName .. "' already exists")
        return false
    end
    
    -- Copy to new name
    self.db.profiles[newName] = self.db.profiles[oldName]
    self.db.profiles[oldName] = nil
    
    -- Update any character assignments
    for charKey, profile in pairs(self.db.profileAssignments) do
        if profile == oldName then
            self.db.profileAssignments[charKey] = newName
        end
    end
    
    -- Update spec profiles
    for charKey, specs in pairs(self.db.specProfiles) do
        for specIndex, profile in pairs(specs) do
            if profile == oldName then
                specs[specIndex] = newName
            end
        end
    end
    
    -- Update current profile name if needed
    if self.currentProfileName == oldName then
        self.currentProfileName = newName
    end
    
    TweaksUI:Print("Renamed profile '" .. oldName .. "' to '" .. newName .. "'")
    return true
end

-- ============================================================================
-- SPEC PROFILES
-- ============================================================================

-- Get spec profile for a character and spec
function DB:GetSpecProfile(charKey, specIndex)
    charKey = charKey or self:GetCharacterKey()
    if not self.db.specProfiles[charKey] then
        return nil
    end
    return self.db.specProfiles[charKey][specIndex]
end

-- Set spec profile for a character and spec
function DB:SetSpecProfile(charKey, specIndex, profileName)
    charKey = charKey or self:GetCharacterKey()
    if not self.db.specProfiles[charKey] then
        self.db.specProfiles[charKey] = {}
    end
    
    if profileName and profileName ~= "" then
        self.db.specProfiles[charKey][specIndex] = profileName
    else
        self.db.specProfiles[charKey][specIndex] = nil
    end
end

-- Check if spec profiles are enabled for this character
function DB:IsSpecProfilesEnabled(charKey)
    charKey = charKey or self:GetCharacterKey()
    return self.db.specProfiles[charKey] and next(self.db.specProfiles[charKey]) ~= nil
end

-- Clear all spec profiles for a character
function DB:ClearSpecProfiles(charKey)
    charKey = charKey or self:GetCharacterKey()
    self.db.specProfiles[charKey] = nil
end

-- Get all spec profiles for current character
function DB:GetAllSpecProfiles(charKey)
    charKey = charKey or self:GetCharacterKey()
    return self.db.specProfiles[charKey] or {}
end

-- Handle spec change - switch profile if needed
function DB:OnSpecChanged()
    local charKey = self:GetCharacterKey()
    local specIndex = GetSpecialization()
    
    if not specIndex then return end
    
    local specProfile = self:GetSpecProfile(charKey, specIndex)
    if specProfile and self.db.profiles[specProfile] then
        if self.currentProfileName ~= specProfile then
            self:SetProfile(specProfile)
            TweaksUI:Print("Switched to spec profile: " .. specProfile)
        end
    end
end

-- ============================================================================
-- MODULE SETTINGS
-- ============================================================================

-- Module enable/disable (per-character setting)
function DB:IsModuleEnabled(moduleId)
    -- Use per-character storage
    if not self.charDb.modules then
        self.charDb.modules = {}
    end
    return self.charDb.modules[moduleId] == true
end

function DB:SetModuleEnabled(moduleId, enabled)
    -- Use per-character storage
    if not self.charDb.modules then
        self.charDb.modules = {}
    end
    self.charDb.modules[moduleId] = enabled
    
    if enabled then
        TweaksUI.Events:Fire(TweaksUI.EVENTS.MODULE_ENABLED, moduleId)
    else
        TweaksUI.Events:Fire(TweaksUI.EVENTS.MODULE_DISABLED, moduleId)
    end
end

-- Get module-specific settings from current profile
function DB:GetModuleSettings(moduleId)
    if not self.currentProfile[moduleId] then
        self.currentProfile[moduleId] = {}
    end
    return self.currentProfile[moduleId]
end

-- Set all module-specific settings at once (replaces entire settings table)
function DB:SetModuleSettings(moduleId, settingsTable)
    if not settingsTable then return end
    self.currentProfile[moduleId] = settingsTable
    TweaksUI.Events:Fire(TweaksUI.EVENTS.SETTINGS_CHANGED, moduleId, nil, nil)
end

-- Set module-specific setting
function DB:SetModuleSetting(moduleId, key, value)
    if not self.currentProfile[moduleId] then
        self.currentProfile[moduleId] = {}
    end
    self.currentProfile[moduleId][key] = value
    
    TweaksUI.Events:Fire(TweaksUI.EVENTS.SETTINGS_CHANGED, moduleId, key, value)
end

-- Get a specific module setting
function DB:GetModuleSetting(moduleId, key)
    if not self.currentProfile[moduleId] then
        return nil
    end
    return self.currentProfile[moduleId][key]
end

-- ============================================================================
-- GLOBAL SETTINGS
-- ============================================================================

-- Get global setting
function DB:GetGlobal(key)
    return self.db.global[key]
end

-- Set global setting
function DB:SetGlobal(key, value)
    self.db.global[key] = value
end

-- ============================================================================
-- CHARACTER-SPECIFIC DATA
-- ============================================================================

-- Get character database
function DB:GetCharacterDB()
    return self.charDb
end

-- Get character-specific data
function DB:GetCharacterData(key)
    return self.charDb[key]
end

-- Set character-specific data
function DB:SetCharacterData(key, value)
    self.charDb[key] = value
end
