-- TweaksUI Main
-- Core addon initialization and slash commands

local ADDON_NAME, TweaksUI = ...

-- Make TweaksUI accessible globally
_G.TweaksUI = TweaksUI

-- Print helper
function TweaksUI:Print(message)
    print(TweaksUI.CHAT_PREFIX .. message)
end

function TweaksUI:PrintError(message)
    print(TweaksUI.CHAT_PREFIX .. "|cffff0000" .. message .. "|r")
end

function TweaksUI:PrintDebug(message)
    if self.debugMode then
        print(TweaksUI.CHAT_PREFIX .. "|cff888888[DEBUG]|r " .. message)
    end
end

-- Central helper to toggle the main TweaksUI settings hub
function TweaksUI:ToggleSettings()
    if self.Settings and self.Settings.Toggle then
        self.Settings:Toggle()
    else
        self:PrintError("Settings UI not ready yet. Try again in a moment.")
    end
end

-- Debug mode
TweaksUI.debugMode = false

function TweaksUI:SetDebugMode(enabled)
    self.debugMode = enabled
    self:Print("Debug mode " .. (enabled and "enabled" or "disabled"))
end

-- ============================================================================
-- WELCOME SCREEN
-- ============================================================================

local welcomeFrame = nil

function TweaksUI:ShowWelcomeScreen(forceShow)
    -- Check if we should skip showing (only on auto-show, not manual)
    local welcomeShown = self.Database:GetGlobal("welcomeShown")
    if not forceShow and welcomeShown then
        return
    end
    
    -- Don't create multiple frames
    if welcomeFrame and welcomeFrame:IsShown() then
        return
    end
    
    -- Create the frame
    local frame = CreateFrame("Frame", "TweaksUI_WelcomeFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(550, 580)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    
    -- Allow ESC to close
    tinsert(UISpecialFrames, "TweaksUI_WelcomeFrame")
    
    -- Title
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    frame.title:SetPoint("TOP", 0, -5)
    frame.title:SetText("Welcome to TweaksUI!")
    
    -- Version
    local versionText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    versionText:SetPoint("TOP", 0, -28)
    versionText:SetText("|cff00ff00Version " .. TweaksUI.VERSION .. "|r")
    
    -- Scroll frame for content
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 12, -50)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 55)
    
    -- Enable mouse wheel scrolling
    scrollFrame:EnableMouseWheel(true)
    scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll()
        local maxScroll = self:GetVerticalScrollRange()
        local step = 60
        if delta > 0 then
            self:SetVerticalScroll(math.max(0, current - step))
        else
            self:SetVerticalScroll(math.min(maxScroll, current + step))
        end
    end)
    
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(490, 800)
    scrollFrame:SetScrollChild(scrollChild)
    
    -- Content
    local content = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    content:SetPoint("TOPLEFT", 5, -5)
    content:SetWidth(480)
    content:SetJustifyH("LEFT")
    content:SetSpacing(3)
    
    local welcomeText = [[
|cffFFD700What is TweaksUI?|r

TweaksUI enhances Blizzard's default UI without replacing it. Unlike total conversion addons, TweaksUI works |cffFFFFFFwith|r Blizzard's frames - giving you customization options while keeping the native look and feel.

Each module can be enabled or disabled independently, so you only use what you need.


|cffFFD700Getting Started|r

  |cff00FF00-|r Type |cffFFFFFF/tui|r to open the settings hub
  |cff00FF00-|r Enable modules using the checkboxes
  |cff00FF00-|r Click module names to open their settings


|cffFFD700Tips & Tricks|r

|cff87CEEB>|r |cffFFFFFFProfiles:|r Create different setups for different characters or specs. Access via the Profiles button in the hub.

|cff87CEEB>|r |cffFFFFFFImport/Export:|r Share your settings between characters or with friends. Find it in the Import/Export panel.

|cff87CEEB>|r |cffFFFFFFEdit Mode Integration:|r Many TweaksUI frames work with WoW's Edit Mode for positioning.

|cff87CEEB>|r |cffFFFFFFVisibility Controls:|r Most modules let you show/hide elements based on combat, group, or mouseover.


|cffFFD700Module Overview|r

|cffFFFFFFAction Bars|r - Customize button size, spacing, rows/columns, and visibility per bar.

|cffFFFFFFCast Bars|r - Style player, target, and focus cast bars with consistent visuals.

|cffFFFFFFChat|r - Custom chat frames, button fading, timestamps, and more.

|cffFFFFFFCooldown Trackers|r - Enhanced layouts and visibility for Blizzard's cooldown trackers.

|cffFFFFFFNameplates|r - |cffFF8800See recommendation below.|r

|cffFFFFFFResource Bars|r - Customize class resource displays (combo points, soul shards, etc).

|cffFFFFFFUnit Frames|r - Style player, target, focus, and pet frames. |cffFF8800Group frames coming soon.|r


|cffFFD700About Nameplates|r

While TweaksUI includes a Nameplates module, we recommend using |cff00FF00Plater|r or |cff00FF00Platynator|r for nameplates instead.

|cff888888Why? Nameplate addons like Plater offer threat coloring, cast bar customization, debuff tracking, and extensive scripting that would take significant development to replicate. Our module provides basic enhancements, but dedicated nameplate addons are more mature and feature-complete.|r


|cffFFD700Work in Progress|r

|cffFF8800Party and Raid Frames|r are currently marked as "Work in Progress" in the Unit Frames module.

Blizzard is releasing a major update to their raid frames in the |cffFFFFFFMidnight|r expansion. We're waiting for that update before finalizing our group frame enhancements to ensure compatibility.


|cffFFD700Helpful Commands|r

  |cffFFFFFF/tui|r - Open settings
  |cffFFFFFF/tui welcome|r - Show this screen again
  |cffFFFFFF/tui help|r - List all commands
  |cffFFFFFF/rl|r - Reload UI
  |cffFFFFFF/em|r - Toggle Edit Mode
  |cffFFFFFF/cdm|r - Open Blizzard's Cooldown Settings


|cffFFD700Feedback & Support|r

TweaksUI is actively developed. If you encounter issues or have suggestions, please reach out via CurseForge.

|cff888888Thank you for trying TweaksUI!|r
]]
    
    content:SetText(welcomeText)
    
    -- Adjust scroll child height based on content
    local textHeight = content:GetStringHeight()
    scrollChild:SetHeight(math.max(500, textHeight + 20))
    
    -- Scroll hint
    local scrollHint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    scrollHint:SetPoint("BOTTOM", 0, 38)
    scrollHint:SetText("|cff888888Scroll down to read more|r")
    
    -- Buttons
    local openSettingsBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    openSettingsBtn:SetSize(120, 25)
    openSettingsBtn:SetPoint("BOTTOMLEFT", 15, 12)
    openSettingsBtn:SetText("Open Settings")
    openSettingsBtn:SetScript("OnClick", function()
        TweaksUI.Database:SetGlobal("welcomeShown", true)
        frame:Hide()
        TweaksUI:ToggleSettings()
    end)
    
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    closeBtn:SetSize(100, 25)
    closeBtn:SetPoint("BOTTOMRIGHT", -15, 12)
    closeBtn:SetText("Close")
    closeBtn:SetScript("OnClick", function()
        TweaksUI.Database:SetGlobal("welcomeShown", true)
        frame:Hide()
        TweaksUI:Print("Type |cffFFFFFF/tui|r anytime to open settings, or |cffFFFFFF/tui welcome|r to see this again.")
    end)
    
    frame.CloseButton:SetScript("OnClick", function()
        TweaksUI.Database:SetGlobal("welcomeShown", true)
        frame:Hide()
    end)
    
    welcomeFrame = frame
    frame:Show()
end

-- ============================================================================
-- INITIALIZATION
-- ============================================================================

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("ADDON_LOADED")
initFrame:RegisterEvent("PLAYER_LOGIN")

local addonLoaded = false
local playerLoggedIn = false

local function Initialize()
    if not addonLoaded or not playerLoggedIn then
        return
    end
    
    TweaksUI:Print("Initializing v" .. TweaksUI.VERSION)
    
    -- Initialize database
    TweaksUI.Database:Initialize()
    
    -- Initialize media
    TweaksUI.Media:Initialize()
    
    -- Initialize all modules
    TweaksUI.ModuleManager:InitializeAll()
    
    -- Enable modules that should be enabled
    TweaksUI.ModuleManager:EnableAll()
    
    -- Initialize General module (not a standard module, always active)
    C_Timer.After(0.5, function()
        if TweaksUI.General then
            TweaksUI.General:Initialize()
        end
    end)
    
    -- Check if this is a new version or first install
    local lastSeen = TweaksUI.Database:GetGlobal("lastSeenVersion")
    local welcomeShown = TweaksUI.Database:GetGlobal("welcomeShown")
    
    if lastSeen ~= TweaksUI.VERSION then
        TweaksUI.Database:SetGlobal("lastSeenVersion", TweaksUI.VERSION)
        
        if not lastSeen then
            -- First install - show welcome screen after a short delay
            C_Timer.After(2, function()
                TweaksUI:ShowWelcomeScreen()
            end)
        else
            -- Updated from previous version
            TweaksUI:Print("Updated to v" .. TweaksUI.VERSION .. "! Type /tui to open settings.")
            -- Future: Show patch notes here
        end
    end
    
    TweaksUI:Print("Loaded successfully")
end

initFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        addonLoaded = true
        Initialize()
    elseif event == "PLAYER_LOGIN" then
        playerLoggedIn = true
        Initialize()
    end
end)

-- Spec change handling for profile switching
local specFrame = CreateFrame("Frame")
specFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
specFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
specFrame:SetScript("OnEvent", function(self, event, unit)
    -- Only handle player spec changes
    if event == "PLAYER_SPECIALIZATION_CHANGED" and unit ~= "player" then
        return
    end
    
    -- Wait for database to be initialized (db is set during Initialize())
    if TweaksUI.Database and TweaksUI.Database.db and TweaksUI.Database.OnSpecChanged then
        TweaksUI.Database:OnSpecChanged()
    end
end)

-- Slash commands
local function HandleSlashCommand(msg)
    msg = msg:lower():trim()
    local args = {}
    for word in msg:gmatch("%S+") do
        table.insert(args, word)
    end
    local cmd = args[1] or ""
    
    if cmd == "" or cmd == "config" or cmd == "settings" then
        -- Open settings
        TweaksUI:ToggleSettings()
        
    
    elseif cmd == "help" then
        TweaksUI:Print("Commands:")
        print("  /tui - Open settings panel")
        print("  /tui modules - List all modules")
        print("  /tui enable <module> - Enable a module")
        print("  /tui disable <module> - Disable a module")
        print("  /tui profile <name> - Switch profile")
        print("  /tui profiles - List profiles")
        print("  /tui import - Open import dialog ")
        print("  /tui export - Export current profile settings")
        print("  /tui debug - Toggle debug mode")
        print("  /tui version - Show version")
        print("  /tui welcome - Show welcome screen")
        
    elseif cmd == "welcome" then
        TweaksUI:ShowWelcomeScreen(true)  -- forceShow=true
        
    elseif cmd == "modules" then
        TweaksUI:Print("Modules:")
        for moduleId, moduleName in pairs(TweaksUI.MODULE_NAMES) do
            local module = TweaksUI.ModuleManager:GetModule(moduleId)
            local status = ""
            if module then
                if module.enabled then
                    status = "|cff00ff00[Enabled]|r"
                elseif module.loaded then
                    status = "|cffff0000[Disabled]|r"
                else
                    status = "|cff888888[Not Loaded]|r"
                end
            else
                status = "|cff888888[Not Registered]|r"
            end
            print("  " .. moduleId .. " - " .. moduleName .. " " .. status)
        end
        
    elseif cmd == "enable" then
        local moduleId = args[2]
        if moduleId then
            TweaksUI.ModuleManager:EnableModule(moduleId)
        else
            TweaksUI:Print("Usage: /tui enable <module>")
        end
        
    elseif cmd == "disable" then
        local moduleId = args[2]
        if moduleId then
            TweaksUI.ModuleManager:DisableModule(moduleId)
        else
            TweaksUI:Print("Usage: /tui disable <module>")
        end
        
    elseif cmd == "profile" then
        local profileName = args[2]
        if profileName then
            TweaksUI.Database:SetProfile(profileName)
        else
            TweaksUI:Print("Current profile: " .. TweaksUI.Database:GetProfileName())
        end
        
    elseif cmd == "profiles" then
        TweaksUI:Print("Profiles:")
        local current = TweaksUI.Database:GetProfileName()
        for _, name in ipairs(TweaksUI.Database:GetProfileList()) do
            if name == current then
                print("  |cff00ff00" .. name .. " (active)|r")
            else
                print("  " .. name)
            end
        end
        
    elseif cmd == "debug" then
        TweaksUI:SetDebugMode(not TweaksUI.debugMode)
        
    elseif cmd == "import" then
        if TweaksUI.Import then
            TweaksUI.Import:ShowImportDialog()
        else
            TweaksUI:PrintError("Import system not available")
        end
        
    elseif cmd == "export" then
        if TweaksUI.Import then
            TweaksUI.Import:ShowExportDialog()
        else
            TweaksUI:PrintError("Export system not available")
        end
        
    elseif cmd == "version" then
        TweaksUI:Print("Version " .. TweaksUI.VERSION)
        TweaksUI:Print("Build: " .. TweaksUI.BUILD_VERSION)
        TweaksUI:Print("Midnight compatible: " .. (TweaksUI.IS_MIDNIGHT and "Yes" or "No"))
        
    elseif cmd == "npdebug" then
        -- Toggle nameplate debug mode
        if TweaksUI.Nameplates and TweaksUI.Nameplates.ToggleDebug then
            TweaksUI.Nameplates:ToggleDebug()
        else
            TweaksUI:PrintError("Nameplates module not loaded")
        end
        
    else
        TweaksUI:Print("Unknown command: " .. cmd)
        TweaksUI:Print("Type /tui help for commands")
    end
end

-- Register slash commands
for _, cmd in ipairs(TweaksUI.SLASH_COMMANDS) do
    local cmdName = cmd:upper():gsub("/", "")
    _G["SLASH_" .. cmdName .. "1"] = cmd
    SlashCmdList[cmdName] = HandleSlashCommand
end
