-- TweaksUI Utilities
-- Common utility functions used across modules

local ADDON_NAME, TweaksUI = ...

TweaksUI.Utilities = {}
local Utils = TweaksUI.Utilities

-- Safe call wrapper (handles combat lockdown and errors)
function Utils:SafeCall(func, ...)
    local success, err = pcall(func, ...)
    if not success then
        TweaksUI:PrintError("Error: " .. tostring(err))
    end
    return success, err
end

-- Defer execution until out of combat
local combatQueue = {}
local combatFrame = CreateFrame("Frame")

function Utils:AfterCombat(func)
    if InCombatLockdown() then
        table.insert(combatQueue, func)
        combatFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    else
        func()
    end
end

combatFrame:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        for _, func in ipairs(combatQueue) do
            Utils:SafeCall(func)
        end
        wipe(combatQueue)
    end
end)

-- Throttle function execution
function Utils:Throttle(func, delay)
    local lastCall = 0
    return function(...)
        local now = GetTime()
        if now - lastCall >= delay then
            lastCall = now
            return func(...)
        end
    end
end

-- Debounce function execution
function Utils:Debounce(func, delay)
    local timer = nil
    return function(...)
        local args = {...}
        if timer then
            timer:Cancel()
        end
        timer = C_Timer.NewTimer(delay, function()
            func(unpack(args))
            timer = nil
        end)
    end
end

-- Deep copy a table
function Utils:DeepCopy(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for k, v in pairs(orig) do
            copy[Utils:DeepCopy(k)] = Utils:DeepCopy(v)
        end
        setmetatable(copy, Utils:DeepCopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

-- Merge tables (source into target)
function Utils:MergeTables(target, source)
    for k, v in pairs(source) do
        if type(v) == "table" and type(target[k]) == "table" then
            Utils:MergeTables(target[k], v)
        else
            target[k] = v
        end
    end
    return target
end

-- Format number with commas
function Utils:FormatNumber(num)
    if num >= 1000000 then
        return string.format("%.1fM", num / 1000000)
    elseif num >= 1000 then
        return string.format("%.1fK", num / 1000)
    else
        return tostring(num)
    end
end

-- Format time (seconds to MM:SS or SS)
function Utils:FormatTime(seconds)
    if seconds >= 60 then
        return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
    elseif seconds >= 10 then
        return string.format("%d", seconds)
    else
        return string.format("%.1f", seconds)
    end
end

-- Get class color
function Utils:GetClassColor(class)
    local color = RAID_CLASS_COLORS[class]
    if color then
        return color.r, color.g, color.b
    end
    return 1, 1, 1
end

-- Get unit class color
function Utils:GetUnitClassColor(unit)
    if UnitIsPlayer(unit) then
        local _, class = UnitClass(unit)
        if class then
            return Utils:GetClassColor(class)
        end
    end
    return 1, 1, 1
end

-- Get reaction color
function Utils:GetReactionColor(unit)
    local reaction = UnitReaction(unit, "player")
    if reaction then
        if reaction >= 5 then
            return 0, 1, 0 -- Friendly
        elseif reaction == 4 then
            return 1, 1, 0 -- Neutral
        else
            return 1, 0, 0 -- Hostile
        end
    end
    return 1, 1, 1
end

-- Create a color string
function Utils:ColorText(text, r, g, b)
    return string.format("|cff%02x%02x%02x%s|r", r * 255, g * 255, b * 255, text)
end

-- RGB hex to color values
function Utils:HexToRGB(hex)
    hex = hex:gsub("#", "")
    return tonumber("0x" .. hex:sub(1, 2)) / 255,
           tonumber("0x" .. hex:sub(3, 4)) / 255,
           tonumber("0x" .. hex:sub(5, 6)) / 255
end

-- RGB to hex
function Utils:RGBToHex(r, g, b)
    return string.format("%02x%02x%02x", r * 255, g * 255, b * 255)
end

-- Check if in combat
function Utils:InCombat()
    return InCombatLockdown() or UnitAffectingCombat("player")
end

-- Get current spec ID
function Utils:GetSpecID()
    local specIndex = GetSpecialization()
    if specIndex then
        return GetSpecializationInfo(specIndex)
    end
    return nil
end

-- Round number
function Utils:Round(num, decimals)
    local mult = 10 ^ (decimals or 0)
    return math.floor(num * mult + 0.5) / mult
end

-- Clamp number
function Utils:Clamp(num, min, max)
    return math.max(min, math.min(max, num))
end

-- Linear interpolation
function Utils:Lerp(a, b, t)
    return a + (b - a) * t
end

-- Create frame with backdrop
function Utils:CreateBackdropFrame(parent, name, template)
    local frame = CreateFrame("Frame", name, parent, template or "BackdropTemplate")
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.1, 0.1, 0.1, 0.9)
    frame:SetBackdropBorderColor(0, 0, 0, 1)
    return frame
end

-- Hook function safely
function Utils:SecureHook(object, method, hookFunc)
    if type(object) == "string" then
        -- Global function
        hooksecurefunc(object, method)
    else
        -- Object method
        hooksecurefunc(object, method, hookFunc)
    end
end
