-- ============================================================================
-- TweaksUI Cooldowns Module
-- Hooks Blizzard's Cooldown Manager viewers and applies custom layouts
-- ============================================================================

local ADDON_NAME, TweaksUI = ...

-- Ensure module IDs exist
if not TweaksUI.MODULE_IDS then return end
if not TweaksUI.MODULE_IDS.COOLDOWNS then
    TweaksUI.MODULE_IDS.COOLDOWNS = "cooldowns"
    TweaksUI.MODULE_NAMES[TweaksUI.MODULE_IDS.COOLDOWNS] = "Cooldown Trackers"
    table.insert(TweaksUI.MODULE_LOAD_ORDER, 1, TweaksUI.MODULE_IDS.COOLDOWNS)
end

-- Create the module
local Cooldowns = TweaksUI.ModuleManager:NewModule(TweaksUI.MODULE_IDS.COOLDOWNS)

-- ============================================================================
-- BLIZZARD VIEWER DEFINITIONS
-- ============================================================================

-- These are the frames Blizzard creates for the Cooldown Manager system
local TRACKERS = {
    { 
        name = "EssentialCooldownViewer", 
        displayName = "Essential Cooldowns", 
        key = "essential",
        isBarType = false 
    },
    { 
        name = "UtilityCooldownViewer", 
        displayName = "Utility Cooldowns", 
        key = "utility",
        isBarType = false 
    },
    { 
        name = "BuffIconCooldownViewer", 
        displayName = "Buff Tracker", 
        key = "buffs",
        isBarType = false 
    },
}

-- ============================================================================
-- CONSTANTS
-- ============================================================================

local HUB_WIDTH = 220
local HUB_HEIGHT = 480
local PANEL_WIDTH = 420
local PANEL_HEIGHT = 600
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 6

-- Dark backdrop
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

-- Aspect ratio presets
local ASPECT_PRESETS = {
    { label = "1:1 (Square)", value = "1:1" },
    { label = "4:3", value = "4:3" },
    { label = "3:4", value = "3:4" },
    { label = "16:9 (Wide)", value = "16:9" },
    { label = "9:16 (Tall)", value = "9:16" },
    { label = "2:1", value = "2:1" },
    { label = "1:2", value = "1:2" },
    { label = "Custom", value = "custom" },
}

-- Shared tracker defaults (used by all trackers)
local TRACKER_DEFAULTS = {
    enabled = false,  -- Default to disabled for new installs
    -- Icon size
    iconSize = 36,              -- Base size (used with aspect ratio)
    iconWidth = nil,            -- Custom width (nil = use iconSize + aspect)
    iconHeight = nil,           -- Custom height (nil = use iconSize + aspect)
    aspectRatio = "1:1",        -- Preset or "custom"
    -- Layout
    columns = 8,
    rows = 0,                   -- 0 = unlimited
    customLayout = "",          -- Custom pattern like "4,4,2" (empty = use columns)
    spacingH = 2,               -- Horizontal spacing between icons
    spacingV = 2,               -- Vertical spacing between rows
    growDirection = "RIGHT",    -- PRIMARY: LEFT, RIGHT, UP, or DOWN
    growSecondary = "DOWN",     -- SECONDARY: LEFT, RIGHT, UP, or DOWN
    alignment = "LEFT",         -- LEFT, CENTER, or RIGHT
    reverseOrder = false,
    -- Appearance
    zoom = 0.08,                -- Texture inset (0 = full, higher = more zoom)
    borderAlpha = 1.0,
    iconOpacity = 1.0,
    -- Text
    cooldownTextScale = 1.0,    -- Scale of countdown numbers
    countTextScale = 1.0,       -- Scale of stack counts
    -- Visibility
    visibilityEnabled = false,  -- Master toggle for visibility conditions
    showInCombat = true,
    showOutOfCombat = true,
    showSolo = true,
    showInParty = true,
    showInRaid = true,
    showInInstance = true,
    showInArena = true,
    showInBattleground = true,
    showHasTarget = true,       -- Has a target selected
    showNoTarget = true,        -- No target selected
    -- Fade
    fadeEnabled = false,
    fadeDelay = 3.0,            -- Seconds before fading
    fadeAlpha = 0.3,            -- Alpha when faded
    fadeDuration = 0.3,         -- Fade animation duration
    -- Persistent icon order (saved by texture fileID)
    savedIconOrder = {},        -- Array of texture fileIDs in desired order
}

-- Copy defaults for each tracker
local function CreateTrackerDefaults()
    local t = {}
    for k, v in pairs(TRACKER_DEFAULTS) do
        t[k] = v
    end
    return t
end

local DEFAULTS = {
    -- Per-tracker settings (copy shared defaults)
    essential = CreateTrackerDefaults(),
    utility = CreateTrackerDefaults(),
    buffs = CreateTrackerDefaults(),
    -- Global settings
    global = {
        debugMode = false,
    },
}

-- Add buff-specific settings
DEFAULTS.buffs.greyscaleInactive = true
DEFAULTS.buffs.inactiveAlpha = 0.5

-- Add customTrackers settings
DEFAULTS.customTrackers = CreateTrackerDefaults()
DEFAULTS.customTrackers.enabled = false  -- Default to disabled for new installs
DEFAULTS.customTrackers.columns = 4  -- Smaller default for custom trackers
DEFAULTS.customTrackers.point = "CENTER"  -- Edit Mode position
DEFAULTS.customTrackers.x = 0
DEFAULTS.customTrackers.y = -200

-- Equipment slots that can have on-use abilities
local TRACKABLE_EQUIPMENT_SLOTS = {
    [1] = "Head",
    [2] = "Neck",
    [3] = "Shoulder",
    [5] = "Chest",
    [6] = "Waist",
    [7] = "Legs",
    [8] = "Feet",
    [9] = "Wrist",
    [10] = "Hands",
    [11] = "Ring 1",
    [12] = "Ring 2",
    [13] = "Trinket 1",
    [14] = "Trinket 2",
    [15] = "Back",
    [16] = "Main Hand",
    [17] = "Off Hand",
}

-- ============================================================================
-- LOCAL VARIABLES
-- ============================================================================

local settings = nil
local cooldownHub = nil
local settingsPanels = {}
local currentOpenPanel = nil

-- Tracker state
local hookedViewers = {}  -- [viewerFrame] = trackerKey
local baselineOrders = {} -- [viewerFrame] = { icon1, icon2, ... }

-- Update flags (combat-safe pattern)
local needsLayoutUpdate = {}  -- [trackerKey] = true

-- Custom Tracker system
local customTrackerFrame = nil      -- The display frame for custom trackers
local customTrackerIcons = {}       -- [entryKey] = iconFrame (entryKey = "spell_123" or "item_456")
local equippedOnUseItems = {}       -- [slotID] = { itemID, spellID, spellName, texture }
local customTrackerUpdateTicker = nil
local CUSTOM_TRACKER_UPDATE_INTERVAL = 0.1  -- Update cooldowns 10x per second

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

local function DeepCopy(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for k, v in pairs(orig) do
            copy[k] = DeepCopy(v)
        end
    else
        copy = orig
    end
    return copy
end

local function dprint(...)
    if settings and settings.global and settings.global.debugMode then
        print("|cff00ff00[TweaksUI CD]|r", ...)
    end
end

local function GetSetting(trackerKey, settingName)
    if not settings or not settings[trackerKey] then return nil end
    return settings[trackerKey][settingName]
end

local function SetSetting(trackerKey, settingName, value)
    if not settings then return end
    settings[trackerKey] = settings[trackerKey] or {}
    settings[trackerKey][settingName] = value
    
    -- Also immediately persist to database
    if TweaksUI and TweaksUI.Database and TweaksUI.Database.SetModuleSettings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
end

-- Public function to get all settings (used by Export All)
function Cooldowns:GetSettings()
    -- Ensure settings are initialized with proper merge logic
    if not settings then
        -- Start with defaults
        settings = DeepCopy(DEFAULTS)
        
        -- Merge any saved settings from database
        local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
        if dbSettings then
            for key, trackerSettings in pairs(dbSettings) do
                if settings[key] and type(trackerSettings) == "table" then
                    for k, v in pairs(trackerSettings) do
                        settings[key][k] = v
                    end
                elseif key == "global" and type(trackerSettings) == "table" then
                    for k, v in pairs(trackerSettings) do
                        settings.global[k] = v
                    end
                end
            end
        end
    end
    
    -- Save to database to ensure it's up to date with full settings
    if TweaksUI and TweaksUI.Database and TweaksUI.Database.SetModuleSettings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
    return settings
end

local function GetTrackerInfo(key)
    for _, t in ipairs(TRACKERS) do
        if t.key == key then return t end
    end
    return nil
end

local function GetTrackerByName(name)
    for _, t in ipairs(TRACKERS) do
        if t.name == name then return t end
    end
    return nil
end

-- ============================================================================
-- ICON COLLECTION
-- ============================================================================

-- Check if a frame is an icon (has Icon texture and typical icon properties)
local function IsIcon(frame)
    if not frame then return false end
    if not frame.GetWidth then return false end
    
    local w, h = frame:GetWidth(), frame:GetHeight()
    if not w or not h or w < 10 or h < 10 then return false end
    
    -- Check for Icon texture (Blizzard's cooldown icons have this)
    if frame.Icon then return true end
    if frame.icon then return true end
    
    -- Check for cooldown element
    if frame.Cooldown then return true end
    if frame.cooldown then return true end
    
    return false
end

-- Collect all icon children from a viewer frame
local function CollectIcons(viewer)
    local icons = {}
    if not viewer or not viewer.GetNumChildren then return icons end
    
    local numChildren = viewer:GetNumChildren() or 0
    
    for i = 1, numChildren do
        local child = select(i, viewer:GetChildren())
        if child and IsIcon(child) then
            icons[#icons + 1] = child
        elseif child and child.GetNumChildren then
            -- Check nested children (some viewers have container frames)
            local numNested = child:GetNumChildren() or 0
            for j = 1, numNested do
                local nested = select(j, child:GetChildren())
                if nested and IsIcon(nested) then
                    icons[#icons + 1] = nested
                end
            end
        end
    end
    
    return icons
end


-- Get texture fileID from an icon (stable identifier across sessions)
-- Uses pcall to safely handle "secret values" during combat/targeting
local function GetIconTextureID(icon)
    if not icon then return 0 end
    local textureObj = icon.Icon or icon.icon
    if textureObj then
        if textureObj.GetTextureFileID then
            local ok, fileID = pcall(function()
                local id = textureObj:GetTextureFileID()
                if id and id > 0 then return id end
                return nil
            end)
            if ok and fileID then return fileID end
        end
        if textureObj.GetTexture then
            local ok, tex = pcall(function()
                local t = textureObj:GetTexture()
                if type(t) == "number" and t > 0 then return t end
                return nil
            end)
            if ok and tex then return tex end
        end
    end
    return 0
end

-- Session cache for stable icon ordering per tracker
-- Once we establish an order, we keep it stable to prevent icons jumping around
local iconOrderCache = {}  -- [trackerKey] = { icon1, icon2, ... }


-- Sort icons by visual position (reading order: top-to-bottom, left-to-right)
local function SortVisual(a, b)
    local at, bt = a:GetTop() or 0, b:GetTop() or 0
    local al, bl = a:GetLeft() or 0, b:GetLeft() or 0
    
    -- Sort top-to-bottom first (higher Y = higher on screen)
    if math.abs(at - bt) > 5 then return at > bt end
    
    -- Then left-to-right for icons in same row
    return al < bl
end

-- Get icons in stable order
-- Uses session cache for all trackers + persistent savedIconOrder for buffs
local function GetOrderedIcons(viewer, trackerKey)
    local all = CollectIcons(viewer)
    local shown = {}
    local shownSet = {}  -- For quick lookup
    
    -- Filter to only shown icons and create lookup set
    for _, icon in ipairs(all) do
        if icon:IsShown() then
            shown[#shown + 1] = icon
            shownSet[icon] = true
        end
    end
    
    if #shown == 0 then
        dprint(string.format("GetOrderedIcons [%s]: 0 shown", trackerKey))
        return shown
    end
    
    dprint(string.format("GetOrderedIcons [%s]: %d total, %d shown", trackerKey, #all, #shown))
    
    -- If no session cache exists, create initial order
    if not iconOrderCache[trackerKey] then
        -- BUFFS: Try to restore from persistent savedIconOrder first
        if trackerKey == "buffs" then
            local savedOrder = GetSetting(trackerKey, "savedIconOrder")
            if savedOrder and #savedOrder > 0 then
                -- Build lookup: fileID -> desired position
                local orderLookup = {}
                for i, fileID in ipairs(savedOrder) do
                    orderLookup[fileID] = i
                end
                
                -- Sort by saved position, unknowns go to end sorted by fileID
                table.sort(shown, function(a, b)
                    local idA = GetIconTextureID(a)
                    local idB = GetIconTextureID(b)
                    local posA = orderLookup[idA]
                    local posB = orderLookup[idB]
                    
                    if posA and posB then return posA < posB end
                    if posA then return true end
                    if posB then return false end
                    return idA < idB
                end)
                
                dprint(string.format("GetOrderedIcons [%s]: Restored from saved order", trackerKey))
            else
                -- No saved order - sort by fileID for consistency
                table.sort(shown, function(a, b)
                    return GetIconTextureID(a) < GetIconTextureID(b)
                end)
                dprint(string.format("GetOrderedIcons [%s]: No saved order, sorted by fileID", trackerKey))
            end
        else
            -- ESSENTIALS/UTILITY: Sort by visual position
            table.sort(shown, SortVisual)
            dprint(string.format("GetOrderedIcons [%s]: Sorted by visual position", trackerKey))
        end
        
        -- Store in session cache
        iconOrderCache[trackerKey] = {}
        for i, icon in ipairs(shown) do
            iconOrderCache[trackerKey][i] = icon
        end
        
        return shown
    end
    
    -- Session cache exists - use cached order, filter to currently shown icons
    local cached = iconOrderCache[trackerKey]
    local result = {}
    local usedIcons = {}
    
    -- First, add icons from cache that are still shown (preserves order)
    for _, cachedIcon in ipairs(cached) do
        if shownSet[cachedIcon] then
            result[#result + 1] = cachedIcon
            usedIcons[cachedIcon] = true
        end
    end
    
    -- Then add any new icons that weren't in cache (at the end)
    for _, icon in ipairs(shown) do
        if not usedIcons[icon] then
            result[#result + 1] = icon
        end
    end
    
    -- Update session cache with current set
    iconOrderCache[trackerKey] = {}
    for i, icon in ipairs(result) do
        iconOrderCache[trackerKey][i] = icon
    end
    
    return result
end

-- Clear icon order cache (session cache and optionally persistent for buffs)
local function ClearIconOrderCache(trackerKey)
    if trackerKey then
        iconOrderCache[trackerKey] = nil
        if trackerKey == "buffs" then
            SetSetting(trackerKey, "savedIconOrder", {})
        end
        dprint(string.format("Cleared icon order cache for [%s]", trackerKey))
    else
        iconOrderCache = {}
        SetSetting("buffs", "savedIconOrder", {})
        dprint("Cleared all icon order caches")
    end
end

-- ============================================================================
-- LAYOUT SYSTEM
-- ============================================================================

-- Apply border alpha to an icon
local function ApplyBorderAlpha(icon, alpha)
    if not icon then return end
    alpha = alpha or 1.0
    
    pcall(function()
        -- Try common border texture names
        if icon.Border then icon.Border:SetAlpha(alpha) end
        if icon.border then icon.border:SetAlpha(alpha) end
        if icon.IconBorder then icon.IconBorder:SetAlpha(alpha) end
        if icon.iconBorder then icon.iconBorder:SetAlpha(alpha) end
        
        -- Some icons use NormalTexture for the border
        if icon.GetNormalTexture then
            local normalTexture = icon:GetNormalTexture()
            if normalTexture then normalTexture:SetAlpha(alpha) end
        end
        
        -- Search through regions for border textures
        if icon.GetRegions then
            local iconTexture = icon.Icon or icon.icon
            for _, region in ipairs({icon:GetRegions()}) do
                if region and region:GetObjectType() == "Texture" and region ~= iconTexture then
                    local texturePath = region:GetTexture()
                    if texturePath then
                        if type(texturePath) == "string" then
                            -- String path - check for border keywords
                            if texturePath:find("Border") or texturePath:find("border") or 
                               texturePath:find("Highlight") or texturePath:find("Normal") or
                               texturePath:find("Edge") or texturePath:find("Frame") then
                                region:SetAlpha(alpha)
                            end
                        elseif type(texturePath) == "number" then
                            -- Numeric file ID - assume non-icon textures are borders
                            region:SetAlpha(alpha)
                        end
                    end
                end
            end
        end
        
        -- Check children frames for borders
        if icon.GetChildren then
            for _, child in ipairs({icon:GetChildren()}) do
                if child and child:GetObjectType() == "Frame" then
                    local name = child:GetName()
                    if name and (name:find("Border") or name:find("border")) then
                        child:SetAlpha(alpha)
                    end
                end
            end
        end
    end)
end

-- Apply cooldown text scale to an icon
local function ApplyCooldownTextScale(icon, scale)
    if not icon then return end
    scale = scale or 1.0
    
    local cd = icon.Cooldown or icon.cooldown
    if not cd then return end
    
    pcall(function()
        -- Method 1: Direct cooldown.text (OmniCC style)
        if cd.text then
            if not cd.text._TUI_origFontSize then
                local font, size, flags = cd.text:GetFont()
                if font and size then
                    cd.text._TUI_origFontSize = size
                    cd.text._TUI_origFont = font
                    cd.text._TUI_origFlags = flags or ""
                end
            end
            if cd.text._TUI_origFontSize then
                cd.text:SetFont(cd.text._TUI_origFont, cd.text._TUI_origFontSize * scale, cd.text._TUI_origFlags)
            end
        end
        
        -- Method 2: Check for Text fontstring in cooldown frame
        if cd.Text then
            if not cd.Text._TUI_origFontSize then
                local font, size, flags = cd.Text:GetFont()
                if font and size then
                    cd.Text._TUI_origFontSize = size
                    cd.Text._TUI_origFont = font
                    cd.Text._TUI_origFlags = flags or ""
                end
            end
            if cd.Text._TUI_origFontSize then
                cd.Text:SetFont(cd.Text._TUI_origFont, cd.Text._TUI_origFontSize * scale, cd.Text._TUI_origFlags)
            end
        end
        
        -- Method 3: Search cooldown frame regions for fontstrings
        if cd.GetRegions then
            for _, region in ipairs({cd:GetRegions()}) do
                if region and region:GetObjectType() == "FontString" then
                    if not region._TUI_origFontSize then
                        local font, size, flags = region:GetFont()
                        if font and size then
                            region._TUI_origFontSize = size
                            region._TUI_origFont = font
                            region._TUI_origFlags = flags or ""
                        end
                    end
                    if region._TUI_origFontSize then
                        region:SetFont(region._TUI_origFont, region._TUI_origFontSize * scale, region._TUI_origFlags)
                    end
                end
            end
        end
    end)
end

-- Apply count/charge text scale to an icon
local function ApplyCountTextScale(icon, scale)
    if not icon then return end
    scale = scale or 1.0
    
    -- Helper to apply scale to a fontstring
    local function ScaleFontString(fs)
        if not fs or not fs.GetFont then return end
        if not fs._TUI_origFontSize then
            local font, size, flags = fs:GetFont()
            if font and size then
                fs._TUI_origFontSize = size
                fs._TUI_origFont = font
                fs._TUI_origFlags = flags or ""
            end
        end
        if fs._TUI_origFontSize then
            fs:SetFont(fs._TUI_origFont, fs._TUI_origFontSize * scale, fs._TUI_origFlags)
        end
    end
    
    -- Helper to recursively search a frame for FontStrings
    local function SearchFrame(frame, depth)
        if not frame or depth > 5 then return end  -- Limit recursion depth
        
        -- Search regions (direct children textures/fontstrings)
        if frame.GetRegions then
            for _, region in ipairs({frame:GetRegions()}) do
                if region and region:GetObjectType() == "FontString" then
                    -- Check if this looks like a count (small text, usually at corner)
                    local text = region:GetText()
                    local name = region:GetName() or ""
                    -- Scale any fontstring that:
                    -- 1. Has a name containing count/charge/stack
                    -- 2. Or displays a number
                    -- 3. Or is positioned at bottom-right (typical count position)
                    if name:lower():find("count") or name:lower():find("charge") or name:lower():find("stack") then
                        ScaleFontString(region)
                    elseif text and text:match("^%d+$") then
                        -- Pure number text - likely a count
                        ScaleFontString(region)
                    end
                end
            end
        end
        
        -- Search child frames recursively
        if frame.GetChildren then
            for _, child in ipairs({frame:GetChildren()}) do
                if child then
                    local childName = child:GetName() or ""
                    local childType = child:GetObjectType()
                    
                    -- Check child frame name for count-related keywords
                    if childName:lower():find("count") or childName:lower():find("charge") or childName:lower():find("stack") then
                        -- This frame is likely count-related, scale all its fontstrings
                        if child.GetRegions then
                            for _, region in ipairs({child:GetRegions()}) do
                                if region and region:GetObjectType() == "FontString" then
                                    ScaleFontString(region)
                                end
                            end
                        end
                    end
                    
                    -- Recurse into child frames
                    SearchFrame(child, depth + 1)
                end
            end
        end
    end
    
    pcall(function()
        -- Method 1: Direct common count text fields
        local countText = icon.Count or icon.count or icon.CountText or icon.countText
        if countText then
            ScaleFontString(countText)
        end
        
        -- Method 2: Check cooldown frame for charge display
        local cooldown = icon.Cooldown or icon.cooldown
        if cooldown then
            -- Some cooldown frames have a charges fontstring
            if cooldown.Count then ScaleFontString(cooldown.Count) end
            if cooldown.count then ScaleFontString(cooldown.count) end
            if cooldown.Charges then ScaleFontString(cooldown.Charges) end
            if cooldown.charges then ScaleFontString(cooldown.charges) end
            
            -- Search cooldown's children too
            SearchFrame(cooldown, 0)
        end
        
        -- Method 3: Recursive search of icon frame
        SearchFrame(icon, 0)
    end)
end

-- Debug helper to dump icon structure
local function DumpIconStructure(icon, trackerKey)
    if not icon then return end
    
    local info = {
        name = icon:GetName() or "unnamed",
        objectType = icon:GetObjectType(),
        fields = {},
        regions = {},
        children = {},
    }
    
    -- Check common fields
    local fieldsToCheck = {"Icon", "icon", "Cooldown", "cooldown", "Count", "count", 
                          "Border", "border", "IconBorder", "NormalTexture"}
    for _, field in ipairs(fieldsToCheck) do
        if icon[field] then
            info.fields[field] = type(icon[field])
        end
    end
    
    -- Get regions
    if icon.GetRegions then
        for i, region in ipairs({icon:GetRegions()}) do
            local regionInfo = {
                type = region:GetObjectType(),
                name = region:GetName(),
            }
            if region:GetObjectType() == "Texture" then
                local tex = region:GetTexture()
                regionInfo.texture = type(tex) == "string" and tex or ("fileID:" .. tostring(tex))
            end
            info.regions[i] = regionInfo
        end
    end
    
    -- Get children
    if icon.GetChildren then
        for i, child in ipairs({icon:GetChildren()}) do
            info.children[i] = {
                type = child:GetObjectType(),
                name = child:GetName(),
            }
        end
    end
    
    dprint(string.format("[%s] Icon structure: %s", trackerKey, info.name))
    dprint(string.format("  Fields: %s", table.concat((function()
        local t = {}
        for k, v in pairs(info.fields) do t[#t+1] = k .. "=" .. v end
        return t
    end)(), ", ")))
    dprint(string.format("  Regions: %d", #info.regions))
    for i, r in ipairs(info.regions) do
        dprint(string.format("    [%d] %s: %s %s", i, r.type, r.name or "nil", r.texture or ""))
    end
    dprint(string.format("  Children: %d", #info.children))
    for i, c in ipairs(info.children) do
        dprint(string.format("    [%d] %s: %s", i, c.type, c.name or "nil"))
    end
end

local function ApplyGridLayout(viewer, trackerKey)
    if not viewer or not viewer:IsShown() then return false end
    
    -- Prevent concurrent layout
    if viewer._TUI_applying then return false end
    viewer._TUI_applying = true
    
    -- Get icons
    local icons = GetOrderedIcons(viewer, trackerKey)
    if #icons == 0 then
        viewer._TUI_applying = false
        return false
    end
    
    -- Get settings
    local iconSize = GetSetting(trackerKey, "iconSize") or 36
    local customWidth = GetSetting(trackerKey, "iconWidth")
    local customHeight = GetSetting(trackerKey, "iconHeight")
    local aspectRatio = GetSetting(trackerKey, "aspectRatio") or "1:1"
    
    local columns = GetSetting(trackerKey, "columns") or 8
    local maxRows = GetSetting(trackerKey, "rows") or 0  -- 0 = unlimited
    local customLayout = GetSetting(trackerKey, "customLayout") or ""
    local spacingH = GetSetting(trackerKey, "spacingH") or 2
    local spacingV = GetSetting(trackerKey, "spacingV") or 2
    
    local growDir = GetSetting(trackerKey, "growDirection") or "RIGHT"
    local growSec = GetSetting(trackerKey, "growSecondary") or "DOWN"
    local alignment = GetSetting(trackerKey, "alignment") or "LEFT"
    local reverseOrder = GetSetting(trackerKey, "reverseOrder") or false
    
    local zoom = GetSetting(trackerKey, "zoom") or 0.08
    local iconOpacity = GetSetting(trackerKey, "iconOpacity") or 1.0
    local borderAlpha = GetSetting(trackerKey, "borderAlpha") or 1.0
    
    local cooldownTextScale = GetSetting(trackerKey, "cooldownTextScale") or 1.0
    local countTextScale = GetSetting(trackerKey, "countTextScale") or 1.0
    
    -- Reverse order if needed
    if reverseOrder then
        local reversed = {}
        for i = #icons, 1, -1 do
            reversed[#reversed + 1] = icons[i]
        end
        icons = reversed
    end
    
    -- Calculate icon dimensions
    local iconWidth, iconHeight
    
    if customWidth and customHeight and customWidth > 0 and customHeight > 0 then
        -- Custom pixel dimensions override everything
        iconWidth = customWidth
        iconHeight = customHeight
    elseif aspectRatio == "custom" and customWidth and customHeight then
        -- Custom mode but values set
        iconWidth = customWidth > 0 and customWidth or iconSize
        iconHeight = customHeight > 0 and customHeight or iconSize
    elseif aspectRatio and aspectRatio ~= "1:1" and aspectRatio ~= "custom" then
        -- Aspect ratio preset
        local w, h = aspectRatio:match("(%d+):(%d+)")
        w, h = tonumber(w), tonumber(h)
        if w and h and w > 0 and h > 0 then
            -- Base size is the larger dimension
            if w >= h then
                iconWidth = iconSize
                iconHeight = iconSize * h / w
            else
                iconHeight = iconSize
                iconWidth = iconSize * w / h
            end
        else
            iconWidth, iconHeight = iconSize, iconSize
        end
    else
        -- 1:1 square
        iconWidth, iconHeight = iconSize, iconSize
    end
    
    -- Parse custom layout pattern (e.g., "4,4,2" = 4 icons in row 1, 4 in row 2, 2 in row 3)
    local customRowSizes = {}
    local useCustomLayout = false
    if customLayout and customLayout ~= "" then
        for num in customLayout:gmatch("(%d+)") do
            local n = tonumber(num)
            if n and n > 0 then
                table.insert(customRowSizes, n)
                useCustomLayout = true
            end
        end
    end
    
    -- Build cumulative index to row/col mapping for custom layout
    local customMapping = {}  -- [iconIndex] = { row = n, col = n }
    if useCustomLayout then
        local iconIdx = 1
        for row, rowSize in ipairs(customRowSizes) do
            for col = 1, rowSize do
                customMapping[iconIdx] = { row = row - 1, col = col - 1 }
                iconIdx = iconIdx + 1
            end
        end
    end
    
    dprint(string.format("ApplyGridLayout [%s]: %d icons, size=%.0fx%.0f, cols=%d, spacingH=%d, spacingV=%d, grow=%s/%s%s", 
        trackerKey, #icons, iconWidth, iconHeight, columns, spacingH, spacingV, growDir, growSec,
        useCustomLayout and string.format(", custom=%s", customLayout) or ""))
    
    -- Determine if primary direction is horizontal or vertical
    local primaryIsHorizontal = (growDir == "LEFT" or growDir == "RIGHT")
    
    -- For vertical primary, we need to know how many rows to use
    local numRows = maxRows
    if not primaryIsHorizontal and numRows == 0 then
        -- Calculate rows needed based on columns and icon count
        numRows = math.ceil(#icons / columns)
    end
    
    -- Position each icon in grid
    local iconCount = 0
    for i, icon in ipairs(icons) do
        local col, row
        
        if useCustomLayout and customMapping[i] then
            -- Use custom layout mapping
            col = customMapping[i].col
            row = customMapping[i].row
        else
            -- Standard grid layout
            local idx = i - 1
            
            if primaryIsHorizontal then
                -- Horizontal primary (LEFT/RIGHT): fill rows first, then wrap to next row
                -- Row 1: 1,2,3 | Row 2: 4,5,6 | Row 3: 7,8,9
                col = idx % columns
                row = math.floor(idx / columns)
            else
                -- Vertical primary (UP/DOWN): fill columns first, then wrap to next column
                -- Col 1: 1,4,7 | Col 2: 2,5,8 | Col 3: 3,6,9
                local effectiveRows = numRows > 0 and numRows or math.ceil(#icons / columns)
                row = idx % effectiveRows
                col = math.floor(idx / effectiveRows)
            end
        end
        
        -- Check row limit (0 = unlimited)
        if maxRows > 0 and row >= maxRows then
            -- Hide icons beyond row limit
            icon:Hide()
        else
            iconCount = iconCount + 1
            icon:Show()
            
            -- Calculate offset based on grow direction
            local xOffset, yOffset
            
            -- Primary direction determines the "fast" axis
            -- Secondary direction determines the "slow" axis (wrap direction)
            if growDir == "RIGHT" then
                xOffset = col * (iconWidth + spacingH)
            elseif growDir == "LEFT" then
                xOffset = -col * (iconWidth + spacingH)
            elseif growDir == "DOWN" then
                -- Vertical primary: col determines horizontal offset
                if growSec == "RIGHT" then
                    xOffset = col * (iconWidth + spacingH)
                else  -- LEFT
                    xOffset = -col * (iconWidth + spacingH)
                end
            elseif growDir == "UP" then
                -- Vertical primary: col determines horizontal offset
                if growSec == "RIGHT" then
                    xOffset = col * (iconWidth + spacingH)
                else  -- LEFT
                    xOffset = -col * (iconWidth + spacingH)
                end
            else
                xOffset = col * (iconWidth + spacingH)
            end
            
            if growDir == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growDir == "UP" then
                yOffset = row * (iconHeight + spacingV)
            elseif growSec == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growSec == "UP" then
                yOffset = row * (iconHeight + spacingV)
            else
                yOffset = -row * (iconHeight + spacingV)
            end
            
            -- Calculate alignment offset
            local alignOffset = 0
            if alignment == "CENTER" then
                -- For center, we need to know the total row width
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[row + 1] then
                    iconsInThisRow = customRowSizes[row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                local viewerWidth = viewer:GetWidth() or rowWidth
                alignOffset = (viewerWidth - rowWidth) / 2
            elseif alignment == "RIGHT" then
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[row + 1] then
                    iconsInThisRow = customRowSizes[row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                local viewerWidth = viewer:GetWidth() or rowWidth
                alignOffset = viewerWidth - rowWidth
            end
            
            -- Apply position relative to viewer with alignment
            icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT", viewer, "TOPLEFT", xOffset + alignOffset, yOffset)
            
            -- Apply size
            icon:SetSize(iconWidth, iconHeight)
            
            -- Apply opacity (but don't override buff state tracking)
            if trackerKey ~= "buffs" or not GetSetting("buffs", "greyscaleInactive") then
                icon:SetAlpha(iconOpacity)
            end
            
            -- Apply border alpha using helper function
            ApplyBorderAlpha(icon, borderAlpha)
            
            -- Apply zoom and aspect ratio cropping to icon texture
            -- Aspect ratio cropping: crop the texture to match the icon's aspect ratio
            -- Zoom: additional uniform inset (0 = no zoom, 0.1 = 10% inset)
            pcall(function()
                local textureObj = icon.Icon or icon.icon
                if textureObj and textureObj.SetTexCoord then
                    -- Start with zoom inset
                    local left = zoom
                    local right = 1 - zoom
                    local top = zoom
                    local bottom = 1 - zoom
                    
                    -- Calculate aspect ratio cropping
                    -- Textures are assumed square, so we crop to match icon dimensions
                    if iconWidth > iconHeight then
                        -- Wide icon: crop top and bottom
                        local cropAmount = (1 - iconHeight / iconWidth) / 2
                        top = top + cropAmount * (1 - 2 * zoom)
                        bottom = bottom - cropAmount * (1 - 2 * zoom)
                    elseif iconHeight > iconWidth then
                        -- Tall icon: crop left and right
                        local cropAmount = (1 - iconWidth / iconHeight) / 2
                        left = left + cropAmount * (1 - 2 * zoom)
                        right = right - cropAmount * (1 - 2 * zoom)
                    end
                    
                    textureObj:SetTexCoord(left, right, top, bottom)
                end
            end)
            
            -- Apply cooldown text scale using helper function
            ApplyCooldownTextScale(icon, cooldownTextScale)
            
            -- Apply count text scale using helper function
            ApplyCountTextScale(icon, countTextScale)
            
            -- Debug: dump first icon structure when debug mode enabled
            if iconCount == 1 and GetSetting("global", "debugMode") then
                DumpIconStructure(icon, trackerKey)
            end
        end
    end
    
    -- Calculate total layout dimensions for Edit Mode frame sizing
    local totalCols, totalRows
    if useCustomLayout and #customRowSizes > 0 then
        -- Custom layout: find max columns and count rows
        totalCols = 0
        for _, rowSize in ipairs(customRowSizes) do
            totalCols = math.max(totalCols, rowSize)
        end
        totalRows = #customRowSizes
    elseif primaryIsHorizontal then
        -- Horizontal primary (LEFT/RIGHT): fills rows first
        totalCols = math.min(#icons, columns)
        totalRows = math.ceil(#icons / columns)
        if maxRows > 0 then
            totalRows = math.min(totalRows, maxRows)
        end
    else
        -- Vertical primary (UP/DOWN): fills columns first
        local effectiveRows = numRows > 0 and numRows or math.ceil(#icons / columns)
        totalRows = math.min(#icons, effectiveRows)
        totalCols = math.ceil(#icons / effectiveRows)
    end
    
    -- Calculate total dimensions
    local totalWidth = totalCols * iconWidth + math.max(0, totalCols - 1) * spacingH
    local totalHeight = totalRows * iconHeight + math.max(0, totalRows - 1) * spacingV
    
    -- NOTE: We don't set size on Blizzard's tracker frames (essential, utility, buffs)
    -- as that interferes with their Edit Mode positioning. Blizzard handles their own
    -- frame sizing and selection boxes. We only position icons within the frame.
    
    viewer._TUI_applying = false
    dprint(string.format("ApplyGridLayout [%s]: Complete (%d visible)", trackerKey, iconCount))
    return true
end

-- ============================================================================
-- BUFF STATE TRACKING (Buffs tracker only)
-- ============================================================================
-- Detects active vs inactive buffs and applies visual styling
-- Inactive buffs are desaturated and faded for better awareness
--
-- CRITICAL INSIGHT from CMT:
-- The icon's auraInstanceID tells us if the buff is active!
-- - auraInstanceID ~= nil means buff is ACTIVE
-- - auraInstanceID == nil means buff is INACTIVE
-- No need to query C_UnitAuras at all!

local buffStateCache = {}  -- [icon] = lastActiveState (boolean)
local buffUpdateTicker = nil
local BUFF_UPDATE_INTERVAL = 0.1  -- Check buff states 10 times per second

-- Check if a buff icon is currently active
-- Simple check: if icon has auraInstanceID, buff is active
local function IsIconBuffActive(icon)
    if not icon then return true end  -- Default to active if we can't check
    
    -- The magic: auraInstanceID is set when buff is active, nil when inactive
    return (icon.auraInstanceID ~= nil)
end

-- Apply visual state to a buff icon based on active/inactive
-- Now supports comprehensive per-icon overrides including size, offset, aspect ratio
local function ApplyBuffVisualState(icon, isActive, trackerKey)
    if not icon then return end
    trackerKey = trackerKey or "buffs"
    
    -- Get settings
    local greyscaleInactive = GetSetting(trackerKey, "greyscaleInactive")
    local inactiveAlpha = GetSetting(trackerKey, "inactiveAlpha") or 0.5
    local baseOpacity = GetSetting(trackerKey, "iconOpacity") or 1.0
    
    -- Skip if greyscale feature is disabled
    if not greyscaleInactive then
        pcall(function()
            local textureObj = icon.Icon or icon.icon
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(false)
            end
            icon:SetAlpha(baseOpacity)
        end)
        return
    end
    
    -- Check if state changed (avoid unnecessary updates)
    if buffStateCache[icon] == isActive then
        return  -- No change
    end
    
    buffStateCache[icon] = isActive
    dprint(string.format("Buff state: %s (auraInstanceID: %s)", 
        isActive and "ACTIVE" or "INACTIVE",
        tostring(icon.auraInstanceID)))
    
    -- Apply visual changes
    pcall(function()
        local textureObj = icon.Icon or icon.icon
        if isActive then
            -- Active buff - normal appearance
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(false)
            end
            icon:SetAlpha(baseOpacity)
        else
            -- Inactive buff - desaturate and fade
            if textureObj and textureObj.SetDesaturated then
                textureObj:SetDesaturated(true)
            end
            icon:SetAlpha(inactiveAlpha)
        end
    end)
end

-- Update all buff icons' visual states
local function UpdateBuffVisualStates()
    local viewer = _G["BuffIconCooldownViewer"]
    if not viewer or not viewer:IsShown() then return end
    
    -- Get all icons
    local icons = CollectIcons(viewer)
    
    local activeCount, inactiveCount = 0, 0
    for _, icon in ipairs(icons) do
        if icon:IsShown() then
            local isActive = IsIconBuffActive(icon)
            if isActive then
                activeCount = activeCount + 1
            else
                inactiveCount = inactiveCount + 1
            end
            ApplyBuffVisualState(icon, isActive)
        end
    end
    
    dprint(string.format("Buff icons: %d active, %d inactive", activeCount, inactiveCount))
end

-- Start the buff state update ticker
local function StartBuffStateTracking()
    if buffUpdateTicker then return end  -- Already running
    
    buffUpdateTicker = C_Timer.NewTicker(BUFF_UPDATE_INTERVAL, function()
        -- Only run if greyscale feature is enabled
        if GetSetting("buffs", "greyscaleInactive") then
            pcall(UpdateBuffVisualStates)
        end
    end)
    
    dprint("Buff state tracking started")
end

-- Stop the buff state update ticker
local function StopBuffStateTracking()
    if buffUpdateTicker then
        buffUpdateTicker:Cancel()
        buffUpdateTicker = nil
        dprint("Buff state tracking stopped")
    end
end

-- ============================================================================
-- CUSTOM TRACKER SYSTEM
-- ============================================================================
-- Allows users to track custom spells/items and equipped on-use items
-- All entries stored in unified array for reordering

-- Entry types:
-- { type = "spell", id = spellID }
-- { type = "item", id = itemID }
-- { type = "equipped", id = slotID }  -- Tracks whatever is in that slot

-- Initialize per-character custom tracker data
local function InitializeCustomTrackerData()
    if not TweaksUI_CharDB then
        TweaksUI_CharDB = {}
    end
    
    TweaksUI_CharDB.cooldowns = TweaksUI_CharDB.cooldowns or {}
    TweaksUI_CharDB.cooldowns.customEntries = TweaksUI_CharDB.cooldowns.customEntries or {}
    TweaksUI_CharDB.cooldowns.trackerCache = TweaksUI_CharDB.cooldowns.trackerCache or {}
end

-- Get current spec ID
local function GetCurrentSpecID()
    local specIndex = GetSpecialization()
    if not specIndex then return nil end
    local specID = GetSpecializationInfo(specIndex)
    return specID
end

-- Get custom entries for current spec (unified list)
local function GetCurrentSpecEntries()
    InitializeCustomTrackerData()
    
    local specID = GetCurrentSpecID()
    if not specID then return {} end
    
    TweaksUI_CharDB.cooldowns.customEntries[specID] = TweaksUI_CharDB.cooldowns.customEntries[specID] or {}
    return TweaksUI_CharDB.cooldowns.customEntries[specID]
end

-- Check if an entry already exists
local function EntryExists(entryType, entryID)
    local entries = GetCurrentSpecEntries()
    for _, entry in ipairs(entries) do
        if entry.type == entryType and entry.id == entryID then
            return true
        end
    end
    return false
end

-- Add a custom entry (spell, item, or equipped slot)
local function AddCustomEntry(entryType, idOrName)
    InitializeCustomTrackerData()
    
    local specID = GetCurrentSpecID()
    if not specID then
        return false, "Could not determine current spec"
    end
    
    TweaksUI_CharDB.cooldowns.customEntries[specID] = TweaksUI_CharDB.cooldowns.customEntries[specID] or {}
    local entries = TweaksUI_CharDB.cooldowns.customEntries[specID]
    
    local entryID
    local entryName, entryTexture
    
    if entryType == "spell" then
        -- Try to parse as ID first
        local numID = tonumber(idOrName)
        if numID then
            local spellInfo = C_Spell.GetSpellInfo(numID)
            if spellInfo then
                entryID = numID
                entryName = spellInfo.name
                entryTexture = C_Spell.GetSpellTexture(numID)
            else
                return false, "Spell ID not found: " .. numID
            end
        else
            -- Try to find by name
            local spellInfo = C_Spell.GetSpellInfo(idOrName)
            if spellInfo then
                entryID = spellInfo.spellID
                entryName = spellInfo.name
                entryTexture = C_Spell.GetSpellTexture(entryID)
            else
                return false, "Spell not found: " .. idOrName
            end
        end
        
    elseif entryType == "item" then
        -- Try to parse as ID first
        local numID = tonumber(idOrName)
        if numID then
            local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(numID)
            if itemName then
                entryID = numID
                entryName = itemName
                entryTexture = itemTexture
            else
                -- Item not cached, try to load it
                C_Item.RequestLoadItemDataByID(numID)
                entryID = numID
                entryName = "Loading..."
                entryTexture = nil
            end
        else
            -- Try to find by name - this is tricky without ID
            local itemID = C_Item.GetItemIDForItemInfo(idOrName)
            if itemID then
                entryID = itemID
                local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(itemID)
                entryName = itemName or "Loading..."
                entryTexture = itemTexture
            else
                return false, "Item not found: " .. idOrName
            end
        end
        
    elseif entryType == "equipped" then
        -- For equipped slots, idOrName should be the slot ID
        local slotID = tonumber(idOrName)
        if not slotID then
            return false, "Invalid slot ID"
        end
        if not TRACKABLE_EQUIPMENT_SLOTS[slotID] then
            return false, "Invalid equipment slot: " .. slotID
        end
        entryID = slotID
        entryName = TRACKABLE_EQUIPMENT_SLOTS[slotID]
        
    else
        return false, "Invalid entry type: " .. tostring(entryType)
    end
    
    -- Check for duplicates
    if EntryExists(entryType, entryID) then
        return false, "Already tracking this " .. entryType
    end
    
    -- Add entry with enabled flag
    table.insert(entries, {
        type = entryType,
        id = entryID,
        enabled = true,  -- Default to enabled
    })
    
    -- Cache info for spells/items
    if entryType == "spell" or entryType == "item" then
        local cacheKey = entryType .. "_" .. entryID
        TweaksUI_CharDB.cooldowns.trackerCache[cacheKey] = {
            name = entryName,
            texture = entryTexture,
        }
    end
    
    dprint(string.format("Added custom entry: %s %d (%s)", entryType, entryID, entryName or "unknown"))
    return true, "Added: " .. (entryName or entryType .. " " .. entryID)
end

-- Remove a custom entry by index
local function RemoveCustomEntry(index)
    local entries = GetCurrentSpecEntries()
    if index < 1 or index > #entries then return false end
    
    local removed = table.remove(entries, index)
    if removed then
        dprint(string.format("Removed custom entry: %s %d", removed.type, removed.id))
        return true
    end
    return false
end

-- Toggle entry enabled state
local function ToggleCustomEntry(index)
    local entries = GetCurrentSpecEntries()
    if index < 1 or index > #entries then return false end
    
    local entry = entries[index]
    entry.enabled = not entry.enabled
    dprint(string.format("Toggled entry %d enabled: %s", index, tostring(entry.enabled)))
    return true
end

-- Set entry enabled state
local function SetCustomEntryEnabled(index, enabled)
    local entries = GetCurrentSpecEntries()
    if index < 1 or index > #entries then return false end
    
    entries[index].enabled = enabled
    return true
end

-- Move entry from one position to another
local function MoveCustomEntry(fromIndex, toIndex)
    local entries = GetCurrentSpecEntries()
    if fromIndex < 1 or fromIndex > #entries then return false end
    if toIndex < 1 or toIndex > #entries then return false end
    if fromIndex == toIndex then return false end
    
    local entry = table.remove(entries, fromIndex)
    table.insert(entries, toIndex, entry)
    
    dprint(string.format("Moved entry from %d to %d", fromIndex, toIndex))
    return true
end

-- Check if an item has an on-use ability
local function HasOnUseAbility(itemID)
    if not itemID then return false end
    local spellName, spellID = GetItemSpell(itemID)
    return spellName ~= nil, spellID, spellName
end

-- Scan equipped items for on-use abilities
local function ScanEquippedOnUseItems()
    local items = {}
    
    for slotID, slotName in pairs(TRACKABLE_EQUIPMENT_SLOTS) do
        local itemID = GetInventoryItemID("player", slotID)
        if itemID then
            local hasOnUse, spellID, spellName = HasOnUseAbility(itemID)
            if hasOnUse then
                local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(itemID)
                items[slotID] = {
                    itemID = itemID,
                    spellID = spellID,
                    spellName = spellName,
                    itemName = itemName or "Loading...",
                    texture = itemTexture,
                    slotName = slotName,
                }
            end
        end
    end
    
    return items
end

-- Add equipped slot as tracked entry if it has on-use and isn't already tracked
local function AddEquippedSlotIfNeeded(slotID)
    local itemID = GetInventoryItemID("player", slotID)
    if not itemID then return false end
    
    local hasOnUse = HasOnUseAbility(itemID)
    if not hasOnUse then return false end
    
    -- Check if this slot is already tracked
    if EntryExists("equipped", slotID) then return false end
    
    -- Add as equipped entry
    return AddCustomEntry("equipped", slotID)
end

-- Get info for an entry (handles all types)
local function GetEntryDisplayInfo(entry)
    if entry.type == "spell" then
        local cacheKey = "spell_" .. entry.id
        local cached = TweaksUI_CharDB and TweaksUI_CharDB.cooldowns and TweaksUI_CharDB.cooldowns.trackerCache and TweaksUI_CharDB.cooldowns.trackerCache[cacheKey]
        
        if cached and cached.name and cached.texture then
            return cached.name, cached.texture, entry.id
        end
        
        local spellInfo = C_Spell.GetSpellInfo(entry.id)
        local texture = C_Spell.GetSpellTexture(entry.id)
        local name = spellInfo and spellInfo.name or "Unknown Spell"
        
        -- Update cache
        if TweaksUI_CharDB and TweaksUI_CharDB.cooldowns then
            TweaksUI_CharDB.cooldowns.trackerCache = TweaksUI_CharDB.cooldowns.trackerCache or {}
            TweaksUI_CharDB.cooldowns.trackerCache[cacheKey] = { name = name, texture = texture }
        end
        
        return name, texture, entry.id
        
    elseif entry.type == "item" then
        local cacheKey = "item_" .. entry.id
        local cached = TweaksUI_CharDB and TweaksUI_CharDB.cooldowns and TweaksUI_CharDB.cooldowns.trackerCache and TweaksUI_CharDB.cooldowns.trackerCache[cacheKey]
        
        if cached and cached.name and cached.texture then
            return cached.name, cached.texture, entry.id
        end
        
        local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(entry.id)
        
        if itemName and itemTexture then
            -- Update cache
            if TweaksUI_CharDB and TweaksUI_CharDB.cooldowns then
                TweaksUI_CharDB.cooldowns.trackerCache = TweaksUI_CharDB.cooldowns.trackerCache or {}
                TweaksUI_CharDB.cooldowns.trackerCache[cacheKey] = { name = itemName, texture = itemTexture }
            end
            return itemName, itemTexture, entry.id
        end
        
        -- Request load
        C_Item.RequestLoadItemDataByID(entry.id)
        return "Loading...", nil, entry.id
        
    elseif entry.type == "equipped" then
        local slotID = entry.id
        local slotName = TRACKABLE_EQUIPMENT_SLOTS[slotID] or "Slot " .. slotID
        
        -- Get current item in slot
        local itemID = GetInventoryItemID("player", slotID)
        if itemID then
            local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(itemID)
            local hasOnUse = HasOnUseAbility(itemID)
            
            if itemName then
                if hasOnUse then
                    return string.format("%s (%s)", itemName, slotName), itemTexture, itemID
                else
                    -- Item exists but has no on-use ability
                    return string.format("%s (%s) - No on-use", itemName, slotName), itemTexture, itemID, false
                end
            else
                C_Item.RequestLoadItemDataByID(itemID)
                return string.format("Loading... (%s)", slotName), nil, itemID
            end
        else
            return string.format("Empty (%s)", slotName), "Interface\\PaperDoll\\UI-Backpack-EmptySlot", nil
        end
    end
    
    return "Unknown", nil, nil
end

-- Get the actual item/spell ID to use for cooldown tracking
local function GetEntryTrackingID(entry)
    if entry.type == "spell" then
        return "spell", entry.id
    elseif entry.type == "item" then
        return "item", entry.id
    elseif entry.type == "equipped" then
        local itemID = GetInventoryItemID("player", entry.id)
        if itemID then
            return "item", itemID
        end
        return nil, nil
    end
    return nil, nil
end

-- Create a custom tracker icon from an entry
local function CreateCustomTrackerIcon(entry, parent)
    -- Get display info based on entry type
    local displayName, displayTexture, trackingID = GetEntryDisplayInfo(entry)
    
    if not displayTexture then
        dprint(string.format("CreateCustomTrackerIcon: No texture for %s %d", entry.type, entry.id))
        return nil
    end
    
    -- For tracking purposes, get the actual ID to track cooldowns
    local trackType, trackID = GetEntryTrackingID(entry)
    
    -- Generate unique key
    local entryKey = entry.type .. "_" .. entry.id
    
    -- Create button frame
    local frame = CreateFrame("Button", "TweaksUI_CustomTracker_" .. entryKey, parent)
    frame:SetSize(36, 36)
    
    -- Create icon texture
    local icon = frame:CreateTexture(nil, "BACKGROUND")
    icon:SetAllPoints(frame)
    icon:SetTexture(displayTexture)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    
    -- Create cooldown frame overlay
    local cd = CreateFrame("Cooldown", nil, frame, "CooldownFrameTemplate")
    cd:SetAllPoints(frame)
    cd:SetDrawEdge(true)
    cd:SetDrawSwipe(true)
    cd:SetSwipeColor(0, 0, 0, 0.8)
    cd:SetHideCountdownNumbers(false)
    
    -- Count text (for items with stacks or spell charges)
    local countText = frame:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    countText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    countText:SetJustifyH("RIGHT")
    countText:SetTextColor(1, 1, 1, 1)
    countText:SetShadowOffset(1, -1)
    countText:SetShadowColor(0, 0, 0, 1)
    countText:SetDrawLayer("OVERLAY", 7)
    countText:Hide()
    
    -- Store references
    frame.icon = icon
    frame.Icon = icon
    frame.cooldown = cd
    frame.Cooldown = cd
    frame.count = countText
    frame.entry = entry           -- Store the full entry
    frame.entryType = entry.type  -- For backwards compat
    frame.entryID = entry.id
    frame.entryKey = entryKey
    frame.entryName = displayName
    frame.trackType = trackType   -- Actual type for cooldown tracking
    frame.trackID = trackID       -- Actual ID for cooldown tracking
    
    -- Enable mouse for tooltips
    frame:EnableMouse(true)
    
    -- Tooltips - use simple tooltips to avoid taint from vendor price MoneyFrame
    frame:SetScript("OnEnter", function(self)
        if InCombatLockdown() then return end
        
        pcall(function()
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            local tType, tID = GetEntryTrackingID(self.entry)
            if tType == "item" and tID then
                -- Use SetHyperlink which is safer than SetItemByID for taint
                local itemLink = select(2, GetItemInfo(tID))
                if itemLink then
                    GameTooltip:SetHyperlink(itemLink)
                else
                    -- Fallback to simple display
                    local itemName = GetItemInfo(tID)
                    GameTooltip:AddLine(itemName or self.entryName or "Item", 1, 1, 1)
                    GameTooltip:AddLine("Item ID: " .. tID, 0.7, 0.7, 0.7)
                end
            elseif tType == "spell" and tID then
                GameTooltip:SetSpellByID(tID)
            else
                GameTooltip:AddLine(self.entryName or "Unknown")
            end
            GameTooltip:Show()
        end)
    end)
    
    frame:SetScript("OnLeave", function()
        if not InCombatLockdown() then
            GameTooltip:Hide()
        end
    end)
    
    dprint(string.format("Created custom tracker icon: %s %d (%s)", entry.type, entry.id, displayName or "?"))
    
    return frame
end

-- Update cooldown for a custom tracker icon
local function UpdateCustomTrackerCooldown(iconFrame)
    if not iconFrame or not iconFrame.cooldown then return end
    
    -- Get tracking info (may change for equipped slots)
    local trackType, trackID = GetEntryTrackingID(iconFrame.entry)
    
    -- Update icon texture if equipped item changed
    if iconFrame.entry.type == "equipped" then
        local displayName, displayTexture, newTrackID = GetEntryDisplayInfo(iconFrame.entry)
        if displayTexture and iconFrame.icon then
            iconFrame.icon:SetTexture(displayTexture)
        end
        iconFrame.trackID = newTrackID
        trackID = newTrackID
    end
    
    if not trackType or not trackID then
        iconFrame.cooldown:Clear()
        iconFrame.count:Hide()
        return
    end
    
    if trackType == "item" then
        local start, duration, enable = GetItemCooldown(trackID)
        if start and duration and duration > 0 then
            iconFrame.cooldown:SetCooldown(start, duration)
        else
            iconFrame.cooldown:Clear()
        end
        
        -- Update count
        pcall(function()
            local count = C_Item.GetItemCount(trackID, false, false, false)
            if count and count > 1 then
                iconFrame.count:SetText(count)
                iconFrame.count:Show()
            else
                iconFrame.count:Hide()
            end
        end)
        
    elseif trackType == "spell" then
        local info = C_Spell.GetSpellCooldown(trackID)
        if info and info.duration and info.duration > 0 then
            iconFrame.cooldown:SetCooldown(info.startTime, info.duration)
        else
            iconFrame.cooldown:Clear()
        end
        
        -- Update charges
        pcall(function()
            local charges = C_Spell.GetSpellCharges(trackID)
            if charges and charges.currentCharges then
                if charges.maxCharges > 1 then
                    iconFrame.count:SetText(charges.currentCharges)
                    iconFrame.count:Show()
                else
                    iconFrame.count:Hide()
                end
            else
                iconFrame.count:Hide()
            end
        end)
    end
end

-- Create the custom tracker display frame
local function CreateCustomTrackerFrame()
    if customTrackerFrame then return customTrackerFrame end
    
    -- Load saved position
    local trackerKey = "customTrackers"
    local savedPoint = GetSetting(trackerKey, "point") or "CENTER"
    local savedX = GetSetting(trackerKey, "x") or 0
    local savedY = GetSetting(trackerKey, "y") or -200
    
    local frame = CreateFrame("Frame", "TweaksUI_CustomTrackerFrame", UIParent)
    frame:SetSize(200, 50)
    frame:SetPoint(savedPoint, savedX, savedY)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    
    -- Container for icons
    frame.icons = {}
    
    -- Register with Edit Mode
    if TweaksUI.EditMode then
        local trackerKey = "customTrackers"
        
        -- Callback to save position when moved
        -- NOTE: TweaksUI.EditMode strips layoutName, so we receive (frame, point, x, y)
        local function OnPositionChanged(movedFrame, point, x, y)
            SetSetting(trackerKey, "point", point)
            SetSetting(trackerKey, "x", x)
            SetSetting(trackerKey, "y", y)
            dprint(string.format("Custom tracker moved to %s, %.1f, %.1f", point, x, y))
        end
        
        -- Load saved position or use defaults
        local savedPoint = GetSetting(trackerKey, "point") or "CENTER"
        local savedX = GetSetting(trackerKey, "x") or 0
        local savedY = GetSetting(trackerKey, "y") or -200
        
        TweaksUI.EditMode:RegisterFrame(frame, {
            name = "TweaksUI: Custom Cooldowns",
            onPositionChanged = OnPositionChanged,
            default = {
                point = savedPoint,
                x = savedX,
                y = savedY,
            },
        })
    end
    
    customTrackerFrame = frame
    dprint("Created custom tracker frame")
    
    return frame
end

-- ========================================
-- VISIBILITY SYSTEM FOR CUSTOM TRACKERS
-- ========================================

local customTrackerVisibilityState = {
    shouldShow = true,
    isFaded = false,
    lastActivityTime = 0,
}

-- Check if custom tracker frame should be visible based on conditions
local function ShouldShowCustomTrackers()
    -- Always show in Edit Mode for positioning
    if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
        return true
    end
    
    local trackerKey = "customTrackers"
    
    -- Check if visibility conditions are enabled
    if not GetSetting(trackerKey, "visibilityEnabled") then
        return true  -- Always show if conditions not enabled
    end
    
    local shouldShow = false
    
    -- Combat state
    local inCombat = UnitAffectingCombat("player")
    if inCombat and GetSetting(trackerKey, "showInCombat") then
        shouldShow = true
    end
    if not inCombat and GetSetting(trackerKey, "showOutOfCombat") then
        shouldShow = true
    end
    
    -- Group state
    local inRaid = IsInRaid()
    local inParty = IsInGroup() and not inRaid
    local solo = not IsInGroup()
    
    if solo and GetSetting(trackerKey, "showSolo") then
        shouldShow = true
    end
    if inParty and GetSetting(trackerKey, "showInParty") then
        shouldShow = true
    end
    if inRaid and GetSetting(trackerKey, "showInRaid") then
        shouldShow = true
    end
    
    -- Instance type
    local _, instanceType = IsInInstance()
    if instanceType == "party" and GetSetting(trackerKey, "showInInstance") then
        shouldShow = true
    end
    if instanceType == "arena" and GetSetting(trackerKey, "showInArena") then
        shouldShow = true
    end
    if instanceType == "pvp" and GetSetting(trackerKey, "showInBattleground") then
        shouldShow = true
    end
    
    -- Target state
    local hasTarget = UnitExists("target")
    if hasTarget and GetSetting(trackerKey, "showHasTarget") then
        shouldShow = true
    end
    if not hasTarget and GetSetting(trackerKey, "showNoTarget") then
        shouldShow = true
    end
    
    return shouldShow
end

-- Update custom tracker visibility
local function UpdateCustomTrackerVisibility()
    if not customTrackerFrame then return end
    
    -- Always show in Edit Mode for positioning
    if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
        customTrackerFrame:Show()
        customTrackerFrame:SetAlpha(1.0)
        return
    end
    
    -- Check if enabled at all
    if not GetSetting("customTrackers", "enabled") then
        customTrackerFrame:Hide()
        return
    end
    
    local shouldShow = ShouldShowCustomTrackers()
    local trackerKey = "customTrackers"
    
    if shouldShow then
        customTrackerFrame:Show()
        
        -- Handle fade
        if GetSetting(trackerKey, "fadeEnabled") then
            local fadeDelay = GetSetting(trackerKey, "fadeDelay") or 3.0
            local fadeAlpha = GetSetting(trackerKey, "fadeAlpha") or 0.3
            local normalAlpha = GetSetting(trackerKey, "iconOpacity") or 1.0
            
            local now = GetTime()
            local timeSinceActivity = now - customTrackerVisibilityState.lastActivityTime
            
            if timeSinceActivity > fadeDelay then
                if not customTrackerVisibilityState.isFaded then
                    customTrackerVisibilityState.isFaded = true
                    customTrackerFrame:SetAlpha(fadeAlpha)
                end
            else
                if customTrackerVisibilityState.isFaded then
                    customTrackerVisibilityState.isFaded = false
                    customTrackerFrame:SetAlpha(normalAlpha)
                end
            end
        else
            customTrackerFrame:SetAlpha(GetSetting(trackerKey, "iconOpacity") or 1.0)
        end
    else
        customTrackerFrame:Hide()
    end
end

-- Mark activity (for fade system)
local function MarkCustomTrackerActivity()
    customTrackerVisibilityState.lastActivityTime = GetTime()
    if customTrackerVisibilityState.isFaded and customTrackerFrame then
        customTrackerVisibilityState.isFaded = false
        customTrackerFrame:SetAlpha(GetSetting("customTrackers", "iconOpacity") or 1.0)
    end
end

-- Helper to count table entries
local function CountTableEntries(t)
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    return count
end

-- Layout custom tracker icons in grid (same logic as ApplyGridLayout)
local function LayoutCustomTrackerIcons()
    if not customTrackerFrame then return end
    
    -- Collect visible icons and sort by listIndex to maintain order
    local icons = {}
    for key, iconFrame in pairs(customTrackerIcons) do
        icons[#icons + 1] = iconFrame
    end
    
    -- Sort by listIndex to maintain user-defined order
    table.sort(icons, function(a, b)
        return (a.listIndex or 0) < (b.listIndex or 0)
    end)
    
    if #icons == 0 then
        -- Only show placeholder during Edit Mode
        if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
            -- Create or show placeholder for empty frame (for Edit Mode visibility)
            if not customTrackerFrame.placeholder then
                local placeholder = customTrackerFrame:CreateTexture(nil, "BACKGROUND")
                placeholder:SetAllPoints()
                placeholder:SetColorTexture(0.2, 0.2, 0.2, 0.3)
                customTrackerFrame.placeholder = placeholder
                
                local placeholderText = customTrackerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                placeholderText:SetPoint("CENTER")
                placeholderText:SetText("|cff888888Custom\nTrackers|r")
                placeholderText:SetJustifyH("CENTER")
                customTrackerFrame.placeholderText = placeholderText
            end
            customTrackerFrame.placeholder:Show()
            customTrackerFrame.placeholderText:Show()
            customTrackerFrame:SetSize(50, 50)  -- Minimum size for Edit Mode visibility
            customTrackerFrame:Show()
        else
            -- Hide placeholder outside Edit Mode
            if customTrackerFrame.placeholder then
                customTrackerFrame.placeholder:Hide()
                customTrackerFrame.placeholderText:Hide()
            end
        end
        return
    else
        -- Hide placeholder when we have icons
        if customTrackerFrame.placeholder then
            customTrackerFrame.placeholder:Hide()
            customTrackerFrame.placeholderText:Hide()
        end
    end
    
    -- Get settings (same as other trackers)
    local trackerKey = "customTrackers"
    local iconSize = GetSetting(trackerKey, "iconSize") or 36
    local customWidth = GetSetting(trackerKey, "iconWidth")
    local customHeight = GetSetting(trackerKey, "iconHeight")
    local aspectRatio = GetSetting(trackerKey, "aspectRatio") or "1:1"
    
    local columns = GetSetting(trackerKey, "columns") or 4
    local maxRows = GetSetting(trackerKey, "rows") or 0
    local customLayout = GetSetting(trackerKey, "customLayout") or ""
    local spacingH = GetSetting(trackerKey, "spacingH") or 2
    local spacingV = GetSetting(trackerKey, "spacingV") or 2
    
    local growDir = GetSetting(trackerKey, "growDirection") or "RIGHT"
    local growSec = GetSetting(trackerKey, "growSecondary") or "DOWN"
    local alignment = GetSetting(trackerKey, "alignment") or "LEFT"
    local reverseOrder = GetSetting(trackerKey, "reverseOrder") or false
    
    local zoom = GetSetting(trackerKey, "zoom") or 0.08
    local iconOpacity = GetSetting(trackerKey, "iconOpacity") or 1.0
    local borderAlpha = GetSetting(trackerKey, "borderAlpha") or 1.0
    local cooldownTextScale = GetSetting(trackerKey, "cooldownTextScale") or 1.0
    local countTextScale = GetSetting(trackerKey, "countTextScale") or 1.0
    
    -- Reverse order if needed
    if reverseOrder then
        local reversed = {}
        for i = #icons, 1, -1 do
            reversed[#reversed + 1] = icons[i]
        end
        icons = reversed
    end
    
    -- Calculate icon dimensions
    local iconWidth, iconHeight
    
    if customWidth and customHeight and customWidth > 0 and customHeight > 0 then
        iconWidth = customWidth
        iconHeight = customHeight
    elseif aspectRatio == "custom" and customWidth and customHeight then
        iconWidth = customWidth > 0 and customWidth or iconSize
        iconHeight = customHeight > 0 and customHeight or iconSize
    elseif aspectRatio and aspectRatio ~= "1:1" and aspectRatio ~= "custom" then
        local w, h = aspectRatio:match("(%d+):(%d+)")
        w, h = tonumber(w), tonumber(h)
        if w and h and w > 0 and h > 0 then
            if w >= h then
                iconWidth = iconSize
                iconHeight = iconSize * h / w
            else
                iconHeight = iconSize
                iconWidth = iconSize * w / h
            end
        else
            iconWidth, iconHeight = iconSize, iconSize
        end
    else
        iconWidth, iconHeight = iconSize, iconSize
    end
    
    -- Parse custom layout pattern
    local customRowSizes = {}
    local useCustomLayout = false
    if customLayout and customLayout ~= "" then
        for num in customLayout:gmatch("(%d+)") do
            local n = tonumber(num)
            if n and n > 0 then
                table.insert(customRowSizes, n)
                useCustomLayout = true
            end
        end
    end
    
    -- Build cumulative index to row/col mapping for custom layout
    local customMapping = {}
    if useCustomLayout then
        local iconIdx = 1
        for row, rowSize in ipairs(customRowSizes) do
            for col = 1, rowSize do
                customMapping[iconIdx] = { row = row - 1, col = col - 1 }
                iconIdx = iconIdx + 1
            end
        end
    end
    
    -- Determine if primary direction is horizontal or vertical
    local primaryIsHorizontal = (growDir == "LEFT" or growDir == "RIGHT")
    
    local numRows = maxRows
    if not primaryIsHorizontal and numRows == 0 then
        numRows = math.ceil(#icons / columns)
    end
    
    -- First pass: calculate all icon positions and track bounds
    local iconPositions = {}
    local iconCount = 0
    
    -- Track bounds for all visible icons
    local boundsMinX, boundsMaxX = math.huge, -math.huge
    local boundsMinY, boundsMaxY = math.huge, -math.huge
    
    for i, icon in ipairs(icons) do
        local col, row
        
        if useCustomLayout and customMapping[i] then
            col = customMapping[i].col
            row = customMapping[i].row
        else
            local idx = i - 1
            
            if primaryIsHorizontal then
                col = idx % columns
                row = math.floor(idx / columns)
            else
                local effectiveRows = numRows > 0 and numRows or math.ceil(#icons / columns)
                row = idx % effectiveRows
                col = math.floor(idx / effectiveRows)
            end
        end
        
        -- Check row limit
        if maxRows > 0 and row >= maxRows then
            iconPositions[i] = { hidden = true }
        else
            iconCount = iconCount + 1
            
            -- Calculate offset based on grow direction
            local xOffset, yOffset
            
            if growDir == "RIGHT" then
                xOffset = col * (iconWidth + spacingH)
            elseif growDir == "LEFT" then
                xOffset = -col * (iconWidth + spacingH)
            elseif growDir == "DOWN" or growDir == "UP" then
                if growSec == "RIGHT" then
                    xOffset = col * (iconWidth + spacingH)
                else
                    xOffset = -col * (iconWidth + spacingH)
                end
            else
                xOffset = col * (iconWidth + spacingH)
            end
            
            if growDir == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growDir == "UP" then
                yOffset = row * (iconHeight + spacingV)
            elseif growSec == "DOWN" then
                yOffset = -row * (iconHeight + spacingV)
            elseif growSec == "UP" then
                yOffset = row * (iconHeight + spacingV)
            else
                yOffset = -row * (iconHeight + spacingV)
            end
            
            iconPositions[i] = { x = xOffset, y = yOffset, row = row }
            
            -- Track bounds: x goes from xOffset to xOffset+iconWidth
            -- y goes from yOffset (top) to yOffset-iconHeight (bottom, since negative is down)
            boundsMinX = math.min(boundsMinX, xOffset)
            boundsMaxX = math.max(boundsMaxX, xOffset + iconWidth)
            boundsMinY = math.min(boundsMinY, yOffset - iconHeight)  -- Bottom of icon
            boundsMaxY = math.max(boundsMaxY, yOffset)               -- Top of icon
        end
    end
    
    -- Handle empty case
    if iconCount == 0 then
        boundsMinX, boundsMaxX = 0, 1
        boundsMinY, boundsMaxY = -1, 0
    end
    
    -- Calculate frame dimensions from bounds
    local totalWidth = boundsMaxX - boundsMinX
    local totalHeight = boundsMaxY - boundsMinY
    
    -- Calculate shift to normalize all positions to positive coordinates
    -- Shift X so left edge is at 0
    local shiftX = -boundsMinX
    -- Shift Y so top edge is at 0 (boundsMaxY becomes 0)
    local shiftY = -boundsMaxY
    
    -- Second pass: position icons with normalized coordinates
    for i, icon in ipairs(icons) do
        local pos = iconPositions[i]
        if not pos then
            icon:Hide()
        elseif pos.hidden then
            icon:Hide()
        else
            icon:Show()
            
            -- Apply normalized position (all icons now in positive coordinate space)
            local finalX = pos.x + shiftX
            local finalY = pos.y + shiftY
            
            -- Calculate alignment offset based on total width
            local alignOffset = 0
            if alignment == "CENTER" then
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[pos.row + 1] then
                    iconsInThisRow = customRowSizes[pos.row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                alignOffset = (totalWidth - rowWidth) / 2
            elseif alignment == "RIGHT" then
                local iconsInThisRow = columns
                if useCustomLayout and customRowSizes[pos.row + 1] then
                    iconsInThisRow = customRowSizes[pos.row + 1]
                end
                local rowWidth = iconsInThisRow * iconWidth + (iconsInThisRow - 1) * spacingH
                alignOffset = totalWidth - rowWidth
            end
            
            finalX = finalX + alignOffset
            
            icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT", customTrackerFrame, "TOPLEFT", finalX, finalY)
            icon:SetSize(iconWidth, iconHeight)
            icon:SetAlpha(iconOpacity)
            
            -- Apply border alpha
            ApplyBorderAlpha(icon, borderAlpha)
            
            -- Apply zoom and aspect ratio cropping
            pcall(function()
                local textureObj = icon.Icon or icon.icon
                if textureObj and textureObj.SetTexCoord then
                    local left = zoom
                    local right = 1 - zoom
                    local top = zoom
                    local bottom = 1 - zoom
                    
                    if iconWidth > iconHeight then
                        local cropAmount = (1 - iconHeight / iconWidth) / 2
                        top = top + cropAmount * (1 - 2 * zoom)
                        bottom = bottom - cropAmount * (1 - 2 * zoom)
                    elseif iconHeight > iconWidth then
                        local cropAmount = (1 - iconWidth / iconHeight) / 2
                        left = left + cropAmount * (1 - 2 * zoom)
                        right = right - cropAmount * (1 - 2 * zoom)
                    end
                    
                    textureObj:SetTexCoord(left, right, top, bottom)
                end
            end)
            
            -- Apply cooldown text scale
            ApplyCooldownTextScale(icon, cooldownTextScale)
            
            -- Apply count text scale
            ApplyCountTextScale(icon, countTextScale)
        end
    end
    
    -- Set frame size only in Edit Mode (for selection box)
    -- During normal play, skip resize to prevent position shifting
    totalWidth = math.max(totalWidth, 1)
    totalHeight = math.max(totalHeight, 1)
    if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
        customTrackerFrame:SetSize(totalWidth, totalHeight)
    end
    
    customTrackerFrame:Show()
    
    dprint(string.format("LayoutCustomTrackerIcons: %d visible icons (of %d total), %.0fx%.0f size", 
        iconCount, #icons, totalWidth, totalHeight))
end

-- Rebuild all custom tracker icons
local function RebuildCustomTrackerIcons()
    if not customTrackerFrame then
        CreateCustomTrackerFrame()
    end
    
    -- Hide and release all existing icons
    for key, iconFrame in pairs(customTrackerIcons) do
        iconFrame:Hide()
        iconFrame:SetParent(nil)
    end
    customTrackerIcons = {}
    
    -- Check if custom trackers are enabled
    if not GetSetting("customTrackers", "enabled") then
        customTrackerFrame:Hide()
        return
    end
    
    -- Get all entries for current spec (unified list includes spell, item, and equipped types)
    local entries = GetCurrentSpecEntries()
    
    -- Create icons for enabled entries, tracking display order
    local displayIndex = 0
    for i, entry in ipairs(entries) do
        -- Check if entry is enabled (default to true for backwards compatibility)
        local isEnabled = entry.enabled ~= false
        
        if isEnabled then
            local entryKey = entry.type .. "_" .. entry.id
            
            -- For equipped entries, check if slot has an item with on-use ability
            if entry.type == "equipped" then
                local itemID = GetInventoryItemID("player", entry.id)
                if itemID then
                    -- Verify the item has an on-use ability
                    local hasOnUse = HasOnUseAbility(itemID)
                    if hasOnUse then
                        local iconFrame = CreateCustomTrackerIcon(entry, customTrackerFrame)
                        if iconFrame then
                            displayIndex = displayIndex + 1
                            iconFrame.listIndex = displayIndex
                            iconFrame.entryIndex = i  -- Store actual index in entries list
                            customTrackerIcons[entryKey] = iconFrame
                        end
                    else
                        dprint(string.format("Equipped slot %d: item %d has no on-use, skipping display", entry.id, itemID))
                    end
                end
                -- Empty slots or non-on-use items are skipped but entry stays in the list
            else
                local iconFrame = CreateCustomTrackerIcon(entry, customTrackerFrame)
                if iconFrame then
                    displayIndex = displayIndex + 1
                    iconFrame.listIndex = displayIndex
                    iconFrame.entryIndex = i  -- Store actual index in entries list
                    customTrackerIcons[entryKey] = iconFrame
                end
            end
        end
    end
    
    -- Layout the icons
    LayoutCustomTrackerIcons()
    
    dprint(string.format("Rebuilt custom tracker icons: %d visible of %d total entries", displayIndex, #entries))
end

-- Update all custom tracker cooldowns
local function UpdateAllCustomTrackerCooldowns()
    for _, iconFrame in pairs(customTrackerIcons) do
        UpdateCustomTrackerCooldown(iconFrame)
    end
end

-- Start custom tracker update ticker
local function StartCustomTrackerUpdates()
    if customTrackerUpdateTicker then return end
    
    customTrackerUpdateTicker = C_Timer.NewTicker(CUSTOM_TRACKER_UPDATE_INTERVAL, function()
        if GetSetting("customTrackers", "enabled") then
            pcall(UpdateAllCustomTrackerCooldowns)
            pcall(UpdateCustomTrackerVisibility)
        end
    end)
    
    dprint("Custom tracker updates started")
end

-- Stop custom tracker update ticker
local function StopCustomTrackerUpdates()
    if customTrackerUpdateTicker then
        customTrackerUpdateTicker:Cancel()
        customTrackerUpdateTicker = nil
        dprint("Custom tracker updates stopped")
    end
end

-- Handle equipment changes
local function OnEquipmentChanged(slotID, hasItem)
    if not GetSetting("customTrackers", "enabled") then return end
    
    -- Check if we have any equipped slot entries that might be affected
    local entries = GetCurrentSpecEntries()
    local hasEquippedEntries = false
    for _, entry in ipairs(entries) do
        if entry.type == "equipped" then
            hasEquippedEntries = true
            break
        end
    end
    
    if hasEquippedEntries then
        dprint(string.format("Equipment changed: slot %d, hasItem=%s - rebuilding", slotID, tostring(hasItem)))
        RebuildCustomTrackerIcons()
    end
end

-- Handle spec changes
local function OnSpecChanged()
    dprint("Spec changed, rebuilding custom tracker icons")
    RebuildCustomTrackerIcons()
end

-- ============================================================================
-- VISIBILITY SYSTEM
-- ============================================================================
-- Handles show/hide based on combat, group, instance conditions
-- Also handles fade in/out animations

local visibilityState = {}  -- [trackerKey] = { visible = bool, faded = bool, lastActivity = time }
local fadeTimers = {}       -- [trackerKey] = ticker

-- Get current player state for visibility checks
local function GetPlayerState()
    local state = {
        inCombat = InCombatLockdown() or UnitAffectingCombat("player"),
        inGroup = IsInGroup(),
        inRaid = IsInRaid(),
        inInstance = false,
        inArena = false,
        inBattleground = false,
        isSolo = not IsInGroup(),
        hasTarget = UnitExists("target"),
    }
    
    -- Check instance type
    local _, instanceType = IsInInstance()
    if instanceType == "party" or instanceType == "raid" then
        state.inInstance = true
    elseif instanceType == "arena" then
        state.inArena = true
    elseif instanceType == "pvp" then
        state.inBattleground = true
    end
    
    return state
end

-- Check if viewer should be visible based on conditions
local function ShouldBeVisible(trackerKey)
    -- Always show in Edit Mode for positioning
    if EditModeManagerFrame and EditModeManagerFrame:IsShown() then
        return true
    end
    
    local enabled = GetSetting(trackerKey, "visibilityEnabled")
    if not enabled then
        return true  -- Visibility system disabled = always show
    end
    
    local state = GetPlayerState()
    
    -- OR logic: if ANY checked condition is true, show the tracker
    if state.inCombat and GetSetting(trackerKey, "showInCombat") then return true end
    if not state.inCombat and GetSetting(trackerKey, "showOutOfCombat") then return true end
    if state.isSolo and GetSetting(trackerKey, "showSolo") then return true end
    if state.inGroup and not state.inRaid and GetSetting(trackerKey, "showInParty") then return true end
    if state.inRaid and GetSetting(trackerKey, "showInRaid") then return true end
    if state.inInstance and GetSetting(trackerKey, "showInInstance") then return true end
    if state.inArena and GetSetting(trackerKey, "showInArena") then return true end
    if state.inBattleground and GetSetting(trackerKey, "showInBattleground") then return true end
    if state.hasTarget and GetSetting(trackerKey, "showHasTarget") then return true end
    if not state.hasTarget and GetSetting(trackerKey, "showNoTarget") then return true end
    
    -- No conditions matched
    return false
end

-- Apply fade to a viewer
local function ApplyFade(viewer, trackerKey, targetAlpha, duration)
    if not viewer then return end
    
    local currentAlpha = viewer:GetAlpha()
    if math.abs(currentAlpha - targetAlpha) < 0.01 then return end
    
    -- Use UIFrameFadeOut/In for smooth animation
    if targetAlpha < currentAlpha then
        UIFrameFadeOut(viewer, duration or 0.3, currentAlpha, targetAlpha)
    else
        UIFrameFadeIn(viewer, duration or 0.3, currentAlpha, targetAlpha)
    end
end

-- Update visibility for a single tracker
local function UpdateTrackerVisibility(trackerKey)
    local trackerInfo = GetTrackerInfo(trackerKey)
    if not trackerInfo then return end
    
    local viewer = _G[trackerInfo.name]
    if not viewer then return end
    
    local shouldShow = ShouldBeVisible(trackerKey)
    local fadeEnabled = GetSetting(trackerKey, "fadeEnabled")
    local fadeDelay = GetSetting(trackerKey, "fadeDelay") or 3.0
    local fadeAlpha = GetSetting(trackerKey, "fadeAlpha") or 0.3
    local fadeDuration = GetSetting(trackerKey, "fadeDuration") or 0.3
    
    -- Initialize state if needed
    if not visibilityState[trackerKey] then
        visibilityState[trackerKey] = { visible = true, faded = false, lastActivity = GetTime() }
    end
    
    local state = visibilityState[trackerKey]
    
    if shouldShow then
        -- Should be visible - ensure frame is shown and at proper alpha
        -- We need to call Show() because Blizzard doesn't always show these frames
        if not state.visible then
            viewer:Show()
            viewer:SetAlpha(1.0)
            state.visible = true
            state.faded = false
            -- Immediately apply layout to prevent flash of default layout
            ApplyGridLayout(viewer, trackerKey)
            dprint(string.format("[%s] Showing (visibility condition met)", trackerKey))
        end
        
        -- Handle fading based on activity
        if fadeEnabled then
            local timeSinceActivity = GetTime() - state.lastActivity
            if timeSinceActivity >= fadeDelay and not state.faded then
                ApplyFade(viewer, trackerKey, fadeAlpha, fadeDuration)
                state.faded = true
                dprint(string.format("[%s] Fading out (inactive for %.1fs)", trackerKey, timeSinceActivity))
            end
        else
            -- Fade disabled - ensure full opacity
            if viewer:GetAlpha() < 1.0 then
                viewer:SetAlpha(1.0)
                state.faded = false
            end
        end
    else
        -- Should be hidden - fade to invisible instead of calling Hide()
        -- This avoids position reset issues with Blizzard's frames
        if state.visible then
            ApplyFade(viewer, trackerKey, 0.0, fadeDuration)
            state.faded = true
            state.visible = false
            dprint(string.format("[%s] Fading to invisible (no visibility conditions met)", trackerKey))
        end
    end
end

-- Mark activity on a tracker (resets fade timer)
local function MarkTrackerActivity(trackerKey)
    if not visibilityState[trackerKey] then
        visibilityState[trackerKey] = { visible = true, faded = false, lastActivity = GetTime() }
    end
    
    local state = visibilityState[trackerKey]
    state.lastActivity = GetTime()
    
    -- If currently faded, unfade
    if state.faded then
        local trackerInfo = GetTrackerInfo(trackerKey)
        if trackerInfo then
            local viewer = _G[trackerInfo.name]
            if viewer then
                ApplyFade(viewer, trackerKey, 1.0, 0.2)
                state.faded = false
            end
        end
    end
end

-- Update visibility for all trackers
local function UpdateAllVisibility()
    for _, tracker in ipairs(TRACKERS) do
        UpdateTrackerVisibility(tracker.key)
    end
end

-- Start visibility update ticker (checks fade timers)
local visibilityTicker = nil
local function StartVisibilitySystem()
    if visibilityTicker then return end
    
    visibilityTicker = C_Timer.NewTicker(0.5, function()
        for _, tracker in ipairs(TRACKERS) do
            if GetSetting(tracker.key, "visibilityEnabled") or GetSetting(tracker.key, "fadeEnabled") then
                UpdateTrackerVisibility(tracker.key)
            end
        end
    end)
    
    dprint("Visibility system started")
end

local function StopVisibilitySystem()
    if visibilityTicker then
        visibilityTicker:Cancel()
        visibilityTicker = nil
        dprint("Visibility system stopped")
    end
end

-- ============================================================================
-- VIEWER HOOKING
-- ============================================================================

local function HookViewer(viewer, trackerKey)
    if not viewer or hookedViewers[viewer] then return end
    
    hookedViewers[viewer] = trackerKey
    viewer._TUI_Key = trackerKey
    
    dprint(string.format("Hooking viewer: %s [%s]", viewer:GetName() or "unnamed", trackerKey))
    
    -- Hook Layout function to intercept Blizzard's layout and apply ours
    if viewer.Layout then
        hooksecurefunc(viewer, "Layout", function(self)
            -- Skip if we're currently applying our layout
            if self._TUI_applying then return end
            
            dprint(string.format("Layout hook fired for [%s]", trackerKey))
            
            if self:IsShown() then
                -- BUFFS ONLY: Capture order from Blizzard positions when Cooldown Manager changes
                if trackerKey == "buffs" then
                    local icons = CollectIcons(self)
                    local shown = {}
                    local hasValidPositions = false
                    
                    for _, icon in ipairs(icons) do
                        if icon:IsShown() then
                            shown[#shown + 1] = icon
                            local t, l = icon:GetTop(), icon:GetLeft()
                            if t and l and (t ~= 0 or l ~= 0) then
                                hasValidPositions = true
                            end
                        end
                    end
                    
                    -- Only capture order if icons have valid positions
                    if hasValidPositions and #shown > 0 then
                        -- Sort by visual position (reading order)
                        table.sort(shown, function(a, b)
                            local at, bt = a:GetTop() or 0, b:GetTop() or 0
                            local al, bl = a:GetLeft() or 0, b:GetLeft() or 0
                            if math.abs(at - bt) > 5 then return at > bt end
                            return al < bl
                        end)
                        
                        -- Build new order from texture IDs
                        local newOrder = {}
                        for i, icon in ipairs(shown) do
                            newOrder[i] = GetIconTextureID(icon)
                        end
                        
                        -- Compare to saved order
                        local savedOrder = GetSetting(trackerKey, "savedIconOrder") or {}
                        local orderChanged = #newOrder ~= #savedOrder
                        if not orderChanged then
                            for i, id in ipairs(newOrder) do
                                if savedOrder[i] ~= id then
                                    orderChanged = true
                                    break
                                end
                            end
                        end
                        
                        -- Save new order if it changed (player used Cooldown Manager)
                        if orderChanged then
                            SetSetting(trackerKey, "savedIconOrder", newOrder)
                            dprint(string.format("Layout hook [%s]: Order changed, saved new order: %s", 
                                trackerKey, table.concat(newOrder, ",")))
                        end
                    end
                end
                
                -- Apply our layout
                pcall(ApplyGridLayout, self, trackerKey)
            end
        end)
    end
    
    -- Hook Show to catch when viewer becomes visible
    hooksecurefunc(viewer, "Show", function(self)
        dprint(string.format("Show hook fired for [%s]", trackerKey))
        -- Apply immediately
        if self:IsShown() then
            pcall(ApplyGridLayout, self, trackerKey)
        end
    end)
    
    -- Initial layout if already visible
    if viewer:IsShown() then
        pcall(ApplyGridLayout, viewer, trackerKey)
    end
end

local function HookAllViewers()
    for _, tracker in ipairs(TRACKERS) do
        local viewer = _G[tracker.name]
        if viewer then
            HookViewer(viewer, tracker.key)
        else
            dprint(string.format("Viewer not found: %s", tracker.name))
        end
    end
end

-- ============================================================================
-- EVENT HANDLING
-- ============================================================================

local eventFrame = CreateFrame("Frame")
local updateTimer = 0
local UPDATE_THROTTLE = 0.1
local layoutEnforceTimer = 0
local LAYOUT_ENFORCE_INTERVAL = 0.2  -- Check layout 5x per second (like CMT)

local function OnEvent(self, event, arg1, ...)
    if event == "ADDON_LOADED" then
        -- Try to hook viewers as they become available
        C_Timer.After(0.5, HookAllViewers)
        
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Hook viewers and apply initial layout
        C_Timer.After(0.5, function()
            HookAllViewers()
            -- Apply layout to all visible viewers
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
            -- Update visibility
            UpdateAllVisibility()
        end)
        
        -- DELAYED CACHE RESET: Clear session caches and recapture after positions are stable
        -- This fixes order issues where positions aren't valid at initial capture
        C_Timer.After(2.0, function()
            dprint("Delayed reset - clearing session caches and recapturing with stable positions")
            -- Clear session caches only (not persistent savedIconOrder for buffs)
            iconOrderCache = {}
            -- Re-apply layout to all visible viewers
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
        end)
        
        -- Force Edit Mode to re-apply positions multiple times after load
        -- This fixes position issues after reload
        local function RefreshEditModePositions()
            if EditModeManagerFrame and not InCombatLockdown() then
                pcall(function()
                    -- Trigger layout update on each cooldown viewer
                    for _, tracker in ipairs(TRACKERS) do
                        local viewer = _G[tracker.name]
                        if viewer then
                            -- Try calling SetHasActiveChanges to trigger position refresh
                            if viewer.SetHasActiveChanges then
                                viewer:SetHasActiveChanges(false)
                            end
                            -- Try ApplySystemAnchor if available
                            if viewer.ApplySystemAnchor then
                                viewer:ApplySystemAnchor()
                            end
                        end
                    end
                end)
            end
        end
        
        -- Try at multiple intervals to ensure position is correct
        C_Timer.After(1.0, RefreshEditModePositions)
        C_Timer.After(2.0, RefreshEditModePositions)
        C_Timer.After(4.0, RefreshEditModePositions)
        
    elseif event == "SPELL_UPDATE_COOLDOWN" or event == "ACTIONBAR_UPDATE_COOLDOWN" then
        -- Icons might have changed, schedule layout update
        for key in pairs(needsLayoutUpdate) do
            needsLayoutUpdate[key] = true
        end
        -- Mark activity for fade system
        MarkTrackerActivity("essential")
        MarkTrackerActivity("utility")
        
    elseif event == "PLAYER_REGEN_ENABLED" then
        -- Left combat - safe to do UI updates
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        -- Update visibility (combat state changed)
        UpdateAllVisibility()
        
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- Entered combat - update visibility
        UpdateAllVisibility()
        -- Mark activity on all trackers
        for _, tracker in ipairs(TRACKERS) do
            MarkTrackerActivity(tracker.key)
        end
        
    elseif event == "GROUP_ROSTER_UPDATE" then
        -- Group composition changed - update visibility
        UpdateAllVisibility()
        
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        -- Instance type might have changed - update visibility
        C_Timer.After(0.5, UpdateAllVisibility)
        
    elseif event == "UNIT_AURA" and arg1 == "player" then
        -- Player aura changed - mark activity for buffs tracker
        MarkTrackerActivity("buffs")
        
    elseif event == "PLAYER_TARGET_CHANGED" then
        -- Target changed - update visibility
        UpdateAllVisibility()
        -- Mark activity on all trackers
        for _, tracker in ipairs(TRACKERS) do
            MarkTrackerActivity(tracker.key)
        end
        
    elseif event == "EDIT_MODE_LAYOUTS_UPDATED" then
        -- Edit Mode has applied positions - now apply our grid layouts
        dprint("EDIT_MODE_LAYOUTS_UPDATED fired")
        C_Timer.After(0.1, function()
            HookAllViewers()
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
        end)
        
    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        -- Gear changed - update equipped items tracker
        local slotID = arg1
        local hasItem = ...
        OnEquipmentChanged(slotID, hasItem)
        
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        -- Spec changed - rebuild custom trackers for new spec
        C_Timer.After(0.5, OnSpecChanged)
    end
end

local function OnUpdate(self, elapsed)
    updateTimer = updateTimer + elapsed
    layoutEnforceTimer = layoutEnforceTimer + elapsed
    
    -- Process pending layout updates (throttled)
    if updateTimer >= UPDATE_THROTTLE then
        updateTimer = 0
        for key, needed in pairs(needsLayoutUpdate) do
            if needed then
                needsLayoutUpdate[key] = false
                local info = GetTrackerInfo(key)
                if info then
                    local viewer = _G[info.name]
                    if viewer and viewer:IsShown() and not viewer._TUI_applying then
                        pcall(ApplyGridLayout, viewer, key)
                    end
                end
            end
        end
    end
    
    -- Aggressive layout enforcement (5x per second like CMT)
    -- This catches Blizzard resetting layouts during combat
    if layoutEnforceTimer >= LAYOUT_ENFORCE_INTERVAL then
        layoutEnforceTimer = 0
        -- Always enforce layout on visible trackers
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() and not viewer._TUI_applying then
                local trackerSettings = settings[tracker.key]
                if trackerSettings and trackerSettings.customLayout then
                    pcall(ApplyGridLayout, viewer, tracker.key)
                end
            end
        end
    end
end

-- ============================================================================
-- EXPORT / IMPORT
-- ============================================================================

local function SerializeCooldownSettings()
    -- Simple serialization for settings
    local serialized = "TweaksUI_Cooldowns:"
    
    -- Recursive function to serialize table
    local function serializeTable(tbl, prefix)
        local result = ""
        for k, v in pairs(tbl) do
            local key = prefix and (prefix .. "." .. k) or k
            if type(v) == "table" then
                result = result .. serializeTable(v, key)
            elseif type(v) == "boolean" then
                result = result .. key .. "=" .. (v and "true" or "false") .. ";"
            elseif type(v) == "number" then
                result = result .. key .. "=" .. tostring(v) .. ";"
            elseif type(v) == "string" then
                result = result .. key .. "=" .. v .. ";"
            end
        end
        return result
    end
    
    serialized = serialized .. serializeTable(settings, nil)
    return serialized
end

local function DeserializeCooldownSettings(str)
    if not str or not str:find("^TweaksUI_Cooldowns:") then
        return nil, "Invalid import string"
    end
    
    str = str:gsub("^TweaksUI_Cooldowns:", "")
    
    local newSettings = DeepCopy(DEFAULTS)
    
    for pair in str:gmatch("([^;]+)") do
        local key, value = pair:match("(.+)=(.+)")
        if key and value then
            -- Parse the key path
            local parts = {}
            for part in key:gmatch("[^%.]+") do
                table.insert(parts, part)
            end
            
            -- Navigate to the setting location
            local current = newSettings
            for i = 1, #parts - 1 do
                if current[parts[i]] then
                    current = current[parts[i]]
                end
            end
            
            -- Set the value
            local finalKey = parts[#parts]
            if value == "true" then
                current[finalKey] = true
            elseif value == "false" then
                current[finalKey] = false
            elseif tonumber(value) then
                current[finalKey] = tonumber(value)
            else
                current[finalKey] = value
            end
        end
    end
    
    return newSettings
end

function Cooldowns:ShowExportDialog()
    local dialog = CreateFrame("Frame", "TweaksUI_Cooldowns_ExportDialog", UIParent, "BackdropTemplate")
    dialog:SetSize(450, 350)
    dialog:SetPoint("CENTER")
    dialog:SetBackdrop(darkBackdrop)
    dialog:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    dialog:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    dialog:SetFrameStrata("FULLSCREEN_DIALOG")
    dialog:EnableMouse(true)
    
    local title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Export Cooldown Tracker Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, dialog, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, dialog, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 15, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 50)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(390)
    editBox:SetAutoFocus(false)
    editBox:SetText(SerializeCooldownSettings())
    editBox:HighlightText()
    scrollFrame:SetScrollChild(editBox)
    
    local copyLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    copyLabel:SetPoint("BOTTOM", 0, 30)
    copyLabel:SetText("Press Ctrl+C to copy")
    copyLabel:SetTextColor(0.8, 0.8, 0.8)
    
    local closeButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    closeButton:SetPoint("BOTTOM", 0, 10)
    closeButton:SetSize(100, 24)
    closeButton:SetText("Close")
    closeButton:SetScript("OnClick", function() dialog:Hide() end)
end

function Cooldowns:ShowImportDialog()
    local dialog = CreateFrame("Frame", "TweaksUI_Cooldowns_ImportDialog", UIParent, "BackdropTemplate")
    dialog:SetSize(450, 350)
    dialog:SetPoint("CENTER")
    dialog:SetBackdrop(darkBackdrop)
    dialog:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    dialog:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    dialog:SetFrameStrata("FULLSCREEN_DIALOG")
    dialog:EnableMouse(true)
    
    local title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Import Cooldown Tracker Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, dialog, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, dialog, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 15, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 80)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(390)
    editBox:SetAutoFocus(true)
    editBox:SetText("")
    scrollFrame:SetScrollChild(editBox)
    
    local pasteLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    pasteLabel:SetPoint("BOTTOM", 0, 58)
    pasteLabel:SetText("Paste import string above (Ctrl+V)")
    pasteLabel:SetTextColor(0.8, 0.8, 0.8)
    
    local module = self
    
    local importButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    importButton:SetPoint("BOTTOMLEFT", 50, 20)
    importButton:SetSize(100, 24)
    importButton:SetText("Import")
    importButton:SetScript("OnClick", function()
        local str = editBox:GetText()
        local newSettings, err = DeserializeCooldownSettings(str)
        if newSettings then
            -- Apply new settings
            for k, v in pairs(newSettings) do
                settings[k] = v
            end
            -- Refresh all layouts
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer and viewer:IsShown() then
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
            TweaksUI:Print("Cooldown Tracker settings imported successfully!")
            dialog:Hide()
        else
            TweaksUI:Print("|cffff0000Import failed:|r " .. (err or "Unknown error"))
        end
    end)
    
    local cancelButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    cancelButton:SetPoint("BOTTOMRIGHT", -50, 20)
    cancelButton:SetSize(100, 24)
    cancelButton:SetText("Cancel")
    cancelButton:SetScript("OnClick", function() dialog:Hide() end)
end

-- ============================================================================
-- SETTINGS HUB
-- ============================================================================

function Cooldowns:CreateHub(parent)
    if cooldownHub then return cooldownHub end
    
    local hub = CreateFrame("Frame", "TweaksUI_Cooldowns_Hub", parent or UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, HUB_HEIGHT)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    hub:Hide()
    
    -- Title
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Cooldown Trackers")
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        hub:Hide()
        self:HideAllPanels()
    end)
    
    local yOffset = -42
    
    -- Section label
    local sectionLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sectionLabel:SetPoint("TOP", 0, yOffset)
    sectionLabel:SetText("|cff888888Blizzard Trackers|r")
    yOffset = yOffset - 16
    
    -- Create button for each tracker
    for _, tracker in ipairs(TRACKERS) do
        local btn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
        btn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
        btn:SetPoint("TOP", 0, yOffset)
        btn:SetText(tracker.displayName)
        btn:SetScript("OnClick", function()
            self:TogglePanel(tracker.key)
        end)
        yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    end
    
    yOffset = yOffset - 6
    
    -- Custom Trackers section label
    local customLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    customLabel:SetPoint("TOP", 0, yOffset)
    customLabel:SetText("|cff888888Custom Trackers|r")
    yOffset = yOffset - 16
    
    -- Custom Trackers button
    local customBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    customBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    customBtn:SetPoint("TOP", 0, yOffset)
    customBtn:SetText("Custom Trackers")
    customBtn:SetScript("OnClick", function()
        self:TogglePanel("customTrackers")
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    yOffset = yOffset - 4
    
    -- Blizzard Cooldown Settings button
    local blizzSettingsBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    blizzSettingsBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    blizzSettingsBtn:SetPoint("TOP", 0, yOffset)
    blizzSettingsBtn:SetText("Blizzard Settings")
    blizzSettingsBtn:SetScript("OnClick", function()
        -- CooldownViewerSettings is Blizzard's Cooldown Settings frame
        local cooldownFrame = _G["CooldownViewerSettings"]
        
        if cooldownFrame then
            if cooldownFrame:IsShown() then
                cooldownFrame:Hide()
            else
                cooldownFrame:Show()
            end
        else
            print("|cff00ff00TweaksUI:|r Cooldown Settings not available.")
        end
    end)
    blizzSettingsBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Blizzard Cooldown Settings", 1, 1, 1)
        GameTooltip:AddLine("Opens WoW's built-in cooldown manager", 0.7, 0.7, 0.7, true)
        GameTooltip:AddLine("Also accessible via /cdm", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    blizzSettingsBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Separator
    local sep = hub:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOP", 0, yOffset)
    sep:SetSize(HUB_WIDTH - 20, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 12
    
    -- Import/Export section label
    local ieLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ieLabel:SetPoint("TOP", 0, yOffset)
    ieLabel:SetText("|cff888888Import / Export|r")
    yOffset = yOffset - 20
    
    -- Export button
    local exportBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    exportBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    exportBtn:SetPoint("TOP", 0, yOffset)
    exportBtn:SetText("Export All")
    exportBtn:SetScript("OnClick", function()
        self:ShowExportDialog()
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    -- Import button
    local importBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    importBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    importBtn:SetPoint("TOP", 0, yOffset)
    importBtn:SetText("Import")
    importBtn:SetScript("OnClick", function()
        self:ShowImportDialog()
    end)
    
    -- Refresh All button at bottom
    local refreshBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    refreshBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    refreshBtn:SetPoint("BOTTOM", 0, 10)
    refreshBtn:SetText("Refresh All Layouts")
    refreshBtn:SetScript("OnClick", function()
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        TweaksUI:Print("Refreshed all tracker layouts")
    end)
    
    cooldownHub = hub
    return hub
end

function Cooldowns:ShowHub(parent)
    if not cooldownHub then
        self:CreateHub(parent)
    end
    
    if parent then
        cooldownHub:ClearAllPoints()
        cooldownHub:SetPoint("TOPLEFT", parent, "TOPRIGHT", 0, 0)
    end
    
    cooldownHub:Show()
end

function Cooldowns:HideAllPanels()
    for _, panel in pairs(settingsPanels) do
        if panel then panel:Hide() end
    end
    if cooldownHub then cooldownHub:Hide() end
    currentOpenPanel = nil
end

function Cooldowns:TogglePanel(trackerKey)
    -- Hide other panels
    for key, panel in pairs(settingsPanels) do
        if panel and key ~= trackerKey then
            panel:Hide()
        end
    end
    
    if settingsPanels[trackerKey] then
        if settingsPanels[trackerKey]:IsShown() then
            settingsPanels[trackerKey]:Hide()
            currentOpenPanel = nil
        else
            settingsPanels[trackerKey]:Show()
            currentOpenPanel = trackerKey
        end
    else
        -- Create the appropriate panel
        if trackerKey == "customTrackers" then
            self:CreateCustomTrackersPanel()
        else
            self:CreateTrackerPanel(trackerKey)
        end
        if settingsPanels[trackerKey] then
            settingsPanels[trackerKey]:Show()
            currentOpenPanel = trackerKey
        end
    end
end

-- ============================================================================
-- TRACKER SETTINGS PANEL
-- ============================================================================

function Cooldowns:CreateTrackerPanel(trackerKey)
    local trackerInfo = GetTrackerInfo(trackerKey)
    if not trackerInfo then return end
    
    local panel = CreateFrame("Frame", "TweaksUI_Cooldowns_" .. trackerKey .. "_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetPoint("TOPLEFT", cooldownHub, "TOPRIGHT", 0, 0)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    
    settingsPanels[trackerKey] = panel
    
    -- Title
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText(trackerInfo.displayName)
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
    end)
    
    -- Handle panel hide
    panel:SetScript("OnHide", function()
        currentOpenPanel = nil
    end)
    
    -- Tab buttons container
    local tabContainer = CreateFrame("Frame", nil, panel)
    tabContainer:SetPoint("TOPLEFT", 10, -40)
    tabContainer:SetPoint("TOPRIGHT", -10, -40)
    tabContainer:SetHeight(28)
    
    -- Content frames (one per tab)
    local contentFrames = {}
    local tabButtons = {}
    local currentTab = 1
    
    -- Tab definitions
    local tabs = {
        { name = "Layout", key = "layout" },
        { name = "Appearance", key = "appearance" },
        { name = "Text", key = "text" },
        { name = "Visibility", key = "visibility" },
    }
    
    -- Add buff-specific tab
    if trackerKey == "buffs" then
        table.insert(tabs, { name = "Buff Display", key = "buffdisplay" })
    end
    
    -- Helper function to refresh layout
    local function RefreshLayout()
        local viewer = _G[trackerInfo.name]
        if viewer and viewer:IsShown() then
            ApplyGridLayout(viewer, trackerKey)
        end
    end
    
    -- Create tab content frame
    local function CreateTabContent()
        local content = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
        content:SetPoint("TOPLEFT", 10, -72)
        content:SetPoint("BOTTOMRIGHT", -28, 10)
        
        local scrollChild = CreateFrame("Frame", nil, content)
        scrollChild:SetSize(PANEL_WIDTH - 50, 800)
        content:SetScrollChild(scrollChild)
        
        content.scrollChild = scrollChild
        content:Hide()
        return content
    end
    
    -- UI Element Helpers
    local function CreateHeader(parent, yOffset, text)
        yOffset = yOffset - 8
        local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        header:SetPoint("TOPLEFT", 5, yOffset)
        header:SetText(text)
        header:SetTextColor(1, 0.82, 0)
        return yOffset - 20
    end
    
    local function CreateSlider(parent, yOffset, labelText, min, max, step, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        yOffset = yOffset - 16
        
        local slider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
        slider:SetPoint("TOPLEFT", 10, yOffset)
        slider:SetSize(PANEL_WIDTH - 90, 17)
        slider:SetMinMaxValues(min, max)
        slider:SetValueStep(step)
        slider:SetObeyStepOnDrag(true)
        slider:SetValue(getValue())
        
        slider.Low:SetText(min)
        slider.High:SetText(max)
        slider.Text:SetText(string.format(step < 1 and "%.2f" or "%d", getValue()))
        
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.floor(value / step + 0.5) * step
            setValue(value)
            self.Text:SetText(string.format(step < 1 and "%.2f" or "%d", value))
            RefreshLayout()
        end)
        
        return yOffset - 30
    end
    
    local function CreateCheckbox(parent, yOffset, labelText, getValue, setValue)
        local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 5, yOffset)
        cb:SetSize(24, 24)
        cb:SetChecked(getValue())
        cb:SetScript("OnClick", function(self)
            setValue(self:GetChecked())
            RefreshLayout()
        end)
        
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        return yOffset - 26
    end
    
    local function CreateDropdown(parent, yOffset, labelText, options, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        yOffset = yOffset - 18
        
        local dropdown = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate")
        dropdown:SetPoint("TOPLEFT", -5, yOffset)
        UIDropDownMenu_SetWidth(dropdown, PANEL_WIDTH - 110)
        
        local function OnSelect(self, value)
            setValue(value)
            UIDropDownMenu_SetText(dropdown, self:GetText())
            RefreshLayout()
        end
        
        UIDropDownMenu_Initialize(dropdown, function(self, level)
            for _, opt in ipairs(options) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = opt.label
                info.value = opt.value
                info.func = OnSelect
                info.arg1 = opt.value
                info.checked = (getValue() == opt.value)
                UIDropDownMenu_AddButton(info, level)
            end
        end)
        
        local currentVal = getValue()
        for _, opt in ipairs(options) do
            if opt.value == currentVal then
                UIDropDownMenu_SetText(dropdown, opt.label)
                break
            end
        end
        
        return yOffset - 30
    end
    
    local function CreateEditBox(parent, yOffset, labelText, getValue, setValue, width)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        box:SetPoint("LEFT", label, "RIGHT", 8, 0)
        box:SetSize(width or 60, 20)
        box:SetAutoFocus(false)
        box:SetText(getValue() or "")
        box:SetScript("OnEnterPressed", function(self)
            setValue(self:GetText())
            RefreshLayout()
            self:ClearFocus()
        end)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        
        return yOffset - 26, box
    end
    
    local function CreateButton(parent, yOffset, text, width, onClick)
        local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        btn:SetPoint("TOPLEFT", 10, yOffset)
        btn:SetSize(width, 22)
        btn:SetText(text)
        btn:SetScript("OnClick", function()
            onClick()
            RefreshLayout()
        end)
        return yOffset - 28
    end
    
    -- ========================================
    -- TAB 1: Layout
    -- ========================================
    local function BuildLayoutTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Icon Size")
        y = CreateSlider(parent, y, "Base Size", 16, 80, 1,
            function() return GetSetting(trackerKey, "iconSize") or 36 end,
            function(v) SetSetting(trackerKey, "iconSize", v) end)
        
        y = CreateDropdown(parent, y, "Aspect Ratio", ASPECT_PRESETS,
            function() return GetSetting(trackerKey, "aspectRatio") or "1:1" end,
            function(v) 
                SetSetting(trackerKey, "aspectRatio", v)
                if v ~= "custom" then
                    SetSetting(trackerKey, "iconWidth", nil)
                    SetSetting(trackerKey, "iconHeight", nil)
                end
            end)
        
        -- Custom dimensions
        local customLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        customLabel:SetPoint("TOPLEFT", 10, y)
        customLabel:SetText("Custom: Width")
        customLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local widthBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        widthBox:SetPoint("LEFT", customLabel, "RIGHT", 5, 0)
        widthBox:SetSize(40, 20)
        widthBox:SetAutoFocus(false)
        widthBox:SetNumeric(true)
        widthBox:SetNumber(GetSetting(trackerKey, "iconWidth") or 36)
        widthBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconWidth", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        
        local heightLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        heightLabel:SetPoint("LEFT", widthBox, "RIGHT", 10, 0)
        heightLabel:SetText("Height")
        heightLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local heightBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        heightBox:SetPoint("LEFT", heightLabel, "RIGHT", 5, 0)
        heightBox:SetSize(40, 20)
        heightBox:SetAutoFocus(false)
        heightBox:SetNumeric(true)
        heightBox:SetNumber(GetSetting(trackerKey, "iconHeight") or 36)
        heightBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconHeight", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        y = y - 28
        
        y = CreateHeader(parent, y, "Grid Layout")
        y = CreateSlider(parent, y, "Columns", 1, 20, 1,
            function() return GetSetting(trackerKey, "columns") or 8 end,
            function(v) SetSetting(trackerKey, "columns", v) end)
        
        y = CreateSlider(parent, y, "Max Rows (0=unlimited)", 0, 10, 1,
            function() return GetSetting(trackerKey, "rows") or 0 end,
            function(v) SetSetting(trackerKey, "rows", v) end)
        
        -- Custom layout pattern
        y, _ = CreateEditBox(parent, y, "Custom Pattern (e.g. 4,4,2):",
            function() return GetSetting(trackerKey, "customLayout") or "" end,
            function(v) SetSetting(trackerKey, "customLayout", v) end, 100)
        
        y = CreateHeader(parent, y, "Spacing")
        
        -- Horizontal spacing with edit box for custom values
        local hLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hLabel:SetPoint("TOPLEFT", 10, y)
        hLabel:SetText("Horizontal:")
        hLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local hBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        hBox:SetPoint("LEFT", hLabel, "RIGHT", 8, 0)
        hBox:SetSize(60, 20)
        hBox:SetAutoFocus(false)
        hBox:SetNumeric(false)  -- Allow negative too
        hBox:SetText(tostring(GetSetting(trackerKey, "spacingH") or 2))
        hBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingH", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        hBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        -- Vertical spacing with edit box for custom values
        local vLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        vLabel:SetPoint("TOPLEFT", 10, y)
        vLabel:SetText("Vertical:")
        vLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local vBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        vBox:SetPoint("LEFT", vLabel, "RIGHT", 8, 0)
        vBox:SetSize(60, 20)
        vBox:SetAutoFocus(false)
        vBox:SetNumeric(false)
        vBox:SetText(tostring(GetSetting(trackerKey, "spacingV") or 2))
        vBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingV", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        vBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        y = CreateButton(parent, y, "Compress (0 spacing)", 140, function()
            SetSetting(trackerKey, "spacingH", 0)
            SetSetting(trackerKey, "spacingV", 0)
            hBox:SetText("0")
            vBox:SetText("0")
        end)
        
        y = CreateHeader(parent, y, "Direction & Alignment")
        -- Primary direction: which way icons fill first
        -- Horizontal (Left/Right) = row mode: 1,2,3 / 4,5,6
        -- Vertical (Up/Down) = column mode: 1,4,7 / 2,5,8
        local growOpts = {
            { label = "Right (Row Mode)", value = "RIGHT" }, 
            { label = "Left (Row Mode)", value = "LEFT" },
            { label = "Down (Column Mode)", value = "DOWN" },
            { label = "Up (Column Mode)", value = "UP" },
        }
        y = CreateDropdown(parent, y, "Primary", growOpts,
            function() return GetSetting(trackerKey, "growDirection") or "RIGHT" end,
            function(v) SetSetting(trackerKey, "growDirection", v) end)
        
        -- Secondary direction: which way to wrap after filling primary
        local growSecOpts = {
            { label = "Down", value = "DOWN" }, 
            { label = "Up", value = "UP" },
            { label = "Right", value = "RIGHT" },
            { label = "Left", value = "LEFT" },
        }
        y = CreateDropdown(parent, y, "Secondary", growSecOpts,
            function() return GetSetting(trackerKey, "growSecondary") or "DOWN" end,
            function(v) SetSetting(trackerKey, "growSecondary", v) end)
        
        local alignOpts = {{ label = "Left", value = "LEFT" }, { label = "Center", value = "CENTER" }, { label = "Right", value = "RIGHT" }}
        y = CreateDropdown(parent, y, "Alignment", alignOpts,
            function() return GetSetting(trackerKey, "alignment") or "LEFT" end,
            function(v) SetSetting(trackerKey, "alignment", v) end)
        
        y = CreateCheckbox(parent, y, "Reverse Icon Order",
            function() return GetSetting(trackerKey, "reverseOrder") or false end,
            function(v) SetSetting(trackerKey, "reverseOrder", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 2: Appearance
    -- ========================================
    local function BuildAppearanceTab(parent)
        local y = -10
        
        y = CreateSlider(parent, y, "Icon Opacity", 0.1, 1.0, 0.05,
            function() return GetSetting(trackerKey, "iconOpacity") or 1.0 end,
            function(v) SetSetting(trackerKey, "iconOpacity", v) end)
        
        y = CreateSlider(parent, y, "Border Alpha", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "borderAlpha") or 1.0 end,
            function(v) SetSetting(trackerKey, "borderAlpha", v) end)
        
        y = CreateSlider(parent, y, "Zoom (texture crop)", 0, 0.2, 0.01,
            function() return GetSetting(trackerKey, "zoom") or 0.08 end,
            function(v) SetSetting(trackerKey, "zoom", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 3: Text
    -- ========================================
    local function BuildTextTab(parent)
        local y = -10
        
        y = CreateSlider(parent, y, "Cooldown Text Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "cooldownTextScale") or 1.0 end,
            function(v) 
                SetSetting(trackerKey, "cooldownTextScale", v) 
                -- Force immediate layout update
                local viewer = _G[GetTrackerInfo(trackerKey).name]
                if viewer then ApplyGridLayout(viewer, trackerKey) end
            end)
        
        y = CreateSlider(parent, y, "Count/Charge Text Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "countTextScale") or 1.0 end,
            function(v) 
                SetSetting(trackerKey, "countTextScale", v)
                -- Force immediate layout update
                local viewer = _G[GetTrackerInfo(trackerKey).name]
                if viewer then ApplyGridLayout(viewer, trackerKey) end
            end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 4: Visibility
    -- ========================================
    local function BuildVisibilityTab(parent)
        local y = -10
        
        y = CreateCheckbox(parent, y, "Enable Visibility Conditions",
            function() return GetSetting(trackerKey, "visibilityEnabled") or false end,
            function(v) SetSetting(trackerKey, "visibilityEnabled", v) end)
        
        y = CreateHeader(parent, y, "Show When (OR logic)")
        
        y = CreateCheckbox(parent, y, "In Combat",
            function() return GetSetting(trackerKey, "showInCombat") end,
            function(v) SetSetting(trackerKey, "showInCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Out of Combat",
            function() return GetSetting(trackerKey, "showOutOfCombat") end,
            function(v) SetSetting(trackerKey, "showOutOfCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Solo",
            function() return GetSetting(trackerKey, "showSolo") end,
            function(v) SetSetting(trackerKey, "showSolo", v) end)
        
        y = CreateCheckbox(parent, y, "In Party",
            function() return GetSetting(trackerKey, "showInParty") end,
            function(v) SetSetting(trackerKey, "showInParty", v) end)
        
        y = CreateCheckbox(parent, y, "In Raid",
            function() return GetSetting(trackerKey, "showInRaid") end,
            function(v) SetSetting(trackerKey, "showInRaid", v) end)
        
        y = CreateCheckbox(parent, y, "In Instance (Dungeon)",
            function() return GetSetting(trackerKey, "showInInstance") end,
            function(v) SetSetting(trackerKey, "showInInstance", v) end)
        
        y = CreateCheckbox(parent, y, "In Arena",
            function() return GetSetting(trackerKey, "showInArena") end,
            function(v) SetSetting(trackerKey, "showInArena", v) end)
        
        y = CreateCheckbox(parent, y, "In Battleground",
            function() return GetSetting(trackerKey, "showInBattleground") end,
            function(v) SetSetting(trackerKey, "showInBattleground", v) end)
        
        y = CreateCheckbox(parent, y, "Has Target",
            function() return GetSetting(trackerKey, "showHasTarget") end,
            function(v) SetSetting(trackerKey, "showHasTarget", v) end)
        
        y = CreateCheckbox(parent, y, "No Target",
            function() return GetSetting(trackerKey, "showNoTarget") end,
            function(v) SetSetting(trackerKey, "showNoTarget", v) end)
        
        y = CreateHeader(parent, y, "Fade Settings")
        
        y = CreateCheckbox(parent, y, "Enable Fade",
            function() return GetSetting(trackerKey, "fadeEnabled") or false end,
            function(v) SetSetting(trackerKey, "fadeEnabled", v) end)
        
        y = CreateSlider(parent, y, "Fade Delay (seconds)", 0, 10, 0.5,
            function() return GetSetting(trackerKey, "fadeDelay") or 3.0 end,
            function(v) SetSetting(trackerKey, "fadeDelay", v) end)
        
        y = CreateSlider(parent, y, "Fade Alpha", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "fadeAlpha") or 0.3 end,
            function(v) SetSetting(trackerKey, "fadeAlpha", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 5: Buff Display (buffs only)
    -- ========================================
    local function BuildBuffDisplayTab(parent)
        local y = -10
        
        y = CreateCheckbox(parent, y, "Greyscale Inactive Buffs",
            function() return GetSetting(trackerKey, "greyscaleInactive") end,
            function(v) 
                SetSetting(trackerKey, "greyscaleInactive", v)
                if v then
                    pcall(UpdateBuffVisualStates)
                else
                    local viewer = _G["BuffIconCooldownViewer"]
                    if viewer then
                        local icons = CollectIcons(viewer)
                        for _, icon in ipairs(icons) do
                            pcall(function()
                                local textureObj = icon.Icon or icon.icon
                                if textureObj and textureObj.SetDesaturated then
                                    textureObj:SetDesaturated(false)
                                end
                                icon:SetAlpha(GetSetting("buffs", "iconOpacity") or 1.0)
                            end)
                        end
                    end
                    wipe(buffStateCache)
                end
            end)
        
        y = CreateSlider(parent, y, "Inactive Buff Opacity", 0.1, 1.0, 0.05,
            function() return GetSetting(trackerKey, "inactiveAlpha") or 0.5 end,
            function(v) 
                SetSetting(trackerKey, "inactiveAlpha", v)
                -- Force update all buff visuals with new opacity
                wipe(buffStateCache)
                pcall(UpdateBuffVisualStates)
            end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- Build tab content builders
    local tabBuilders = {
        layout = BuildLayoutTab,
        appearance = BuildAppearanceTab,
        text = BuildTextTab,
        visibility = BuildVisibilityTab,
        buffdisplay = BuildBuffDisplayTab,
    }
    
    -- Create content frames and tab buttons
    local tabWidth = (PANEL_WIDTH - 20) / #tabs
    local scrollChildren = {}  -- Store scroll children for refresh
    
    for i, tab in ipairs(tabs) do
        -- Create content frame
        local content = CreateTabContent()
        contentFrames[tab.key] = content
        scrollChildren[tab.key] = content.scrollChild
        
        -- Build content
        if tabBuilders[tab.key] then
            tabBuilders[tab.key](content.scrollChild)
        end
        
        -- Create tab button
        local tabBtn = CreateFrame("Button", nil, tabContainer)
        tabBtn:SetSize(tabWidth - 2, 26)
        tabBtn:SetPoint("LEFT", (i - 1) * tabWidth, 0)
        
        tabBtn.bg = tabBtn:CreateTexture(nil, "BACKGROUND")
        tabBtn.bg:SetAllPoints()
        tabBtn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
        
        tabBtn.text = tabBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        tabBtn.text:SetPoint("CENTER")
        tabBtn.text:SetText(tab.name)
        
        tabBtn:SetScript("OnClick", function()
            -- Hide all content
            for _, cf in pairs(contentFrames) do
                cf:Hide()
            end
            -- Show selected
            contentFrames[tab.key]:Show()
            -- Update button visuals
            for _, btn in ipairs(tabButtons) do
                btn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
                btn.text:SetTextColor(0.7, 0.7, 0.7)
            end
            tabBtn.bg:SetColorTexture(0.3, 0.3, 0.5, 1)
            tabBtn.text:SetTextColor(1, 1, 1)
            currentTab = i
        end)
        
        tabBtn:SetScript("OnEnter", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.25, 0.25, 0.35, 0.9)
            end
        end)
        
        tabBtn:SetScript("OnLeave", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
            end
        end)
        
        tabButtons[i] = tabBtn
    end
    
    -- Show first tab
    contentFrames[tabs[1].key]:Show()
    tabButtons[1].bg:SetColorTexture(0.3, 0.3, 0.5, 1)
    tabButtons[1].text:SetTextColor(1, 1, 1)
    
    panel:Show()
end

-- ============================================================================
-- CUSTOM TRACKERS SETTINGS PANEL
-- ============================================================================

function Cooldowns:CreateCustomTrackersPanel()
    local panel = CreateFrame("Frame", "TweaksUI_Cooldowns_customTrackers_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT + 50)
    panel:SetPoint("TOPLEFT", cooldownHub, "TOPRIGHT", 0, 0)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    
    settingsPanels["customTrackers"] = panel
    local trackerKey = "customTrackers"
    
    -- Title
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Custom Trackers")
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() panel:Hide() end)
    
    -- Tab system
    local tabs = {
        { name = "Entries", key = "entries" },
        { name = "Layout", key = "layout" },
        { name = "Appearance", key = "appearance" },
        { name = "Text", key = "text" },
        { name = "Visibility", key = "visibility" },
    }
    
    local tabContainer = CreateFrame("Frame", nil, panel)
    tabContainer:SetPoint("TOPLEFT", 10, -40)
    tabContainer:SetPoint("TOPRIGHT", -10, -40)
    tabContainer:SetHeight(28)
    
    local contentContainer = CreateFrame("Frame", nil, panel)
    contentContainer:SetPoint("TOPLEFT", tabContainer, "BOTTOMLEFT", 0, -4)
    contentContainer:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -10, 10)
    
    local contentFrames = {}
    local tabButtons = {}
    local currentTab = 1
    
    -- Helper to create tab content with scroll
    local function CreateTabContent()
        local content = CreateFrame("ScrollFrame", nil, contentContainer, "UIPanelScrollFrameTemplate")
        content:SetAllPoints()
        content:Hide()
        
        local scrollChild = CreateFrame("Frame", nil, content)
        scrollChild:SetSize(PANEL_WIDTH - 50, 800)
        content:SetScrollChild(scrollChild)
        content.scrollChild = scrollChild
        
        return content
    end
    
    -- Refresh layout function
    local function RefreshLayout()
        LayoutCustomTrackerIcons()
    end
    
    -- ========================================
    -- SHARED HELPER FUNCTIONS
    -- ========================================
    
    local function CreateHeader(parent, yOffset, text)
        yOffset = yOffset - 8
        local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        header:SetPoint("TOPLEFT", 5, yOffset)
        header:SetText(text)
        header:SetTextColor(1, 0.82, 0)
        return yOffset - 18
    end
    
    local function CreateCheckbox(parent, yOffset, text, getValue, setValue)
        local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 10, yOffset)
        cb:SetSize(24, 24)
        cb:SetChecked(getValue() or false)
        cb:SetScript("OnClick", function(self)
            setValue(self:GetChecked())
            RefreshLayout()
        end)
        
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        label:SetText(text)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        return yOffset - 26, cb
    end
    
    local function CreateSlider(parent, yOffset, labelText, min, max, step, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        yOffset = yOffset - 14
        
        local slider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
        slider:SetPoint("TOPLEFT", 15, yOffset)
        slider:SetSize(PANEL_WIDTH - 100, 17)
        slider:SetMinMaxValues(min, max)
        slider:SetValueStep(step)
        slider:SetObeyStepOnDrag(true)
        slider:SetValue(getValue() or min)
        
        slider.Low:SetText(min)
        slider.High:SetText(max)
        slider.Text:SetText(string.format(step < 1 and "%.2f" or "%d", getValue() or min))
        
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.floor(value / step + 0.5) * step
            setValue(value)
            self.Text:SetText(string.format(step < 1 and "%.2f" or "%d", value))
            RefreshLayout()
        end)
        
        return yOffset - 26
    end
    
    local function CreateDropdown(parent, yOffset, labelText, options, getValue, setValue)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        local dropdown = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate")
        dropdown:SetPoint("LEFT", label, "RIGHT", -5, -2)
        UIDropDownMenu_SetWidth(dropdown, 120)
        
        local function OnSelect(self, arg1)
            setValue(arg1)
            UIDropDownMenu_SetText(dropdown, self:GetText())
            RefreshLayout()
        end
        
        UIDropDownMenu_Initialize(dropdown, function(self, level)
            for _, opt in ipairs(options) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = opt.label
                info.value = opt.value
                info.func = OnSelect
                info.arg1 = opt.value
                info.checked = (getValue() == opt.value)
                UIDropDownMenu_AddButton(info, level)
            end
        end)
        
        local currentVal = getValue()
        for _, opt in ipairs(options) do
            if opt.value == currentVal then
                UIDropDownMenu_SetText(dropdown, opt.label)
                break
            end
        end
        
        return yOffset - 30
    end
    
    local function CreateEditBox(parent, yOffset, labelText, getValue, setValue, width)
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", 10, yOffset)
        label:SetText(labelText)
        label:SetTextColor(0.8, 0.8, 0.8)
        
        local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        box:SetPoint("LEFT", label, "RIGHT", 8, 0)
        box:SetSize(width or 60, 20)
        box:SetAutoFocus(false)
        box:SetText(getValue() or "")
        box:SetScript("OnEnterPressed", function(self)
            setValue(self:GetText())
            RefreshLayout()
            self:ClearFocus()
        end)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        
        return yOffset - 26, box
    end
    
    -- ========================================
    -- TAB 1: ENTRIES (Add/Remove Spells/Items)
    -- ========================================
    local function BuildEntriesTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Master Enable")
        y = CreateCheckbox(parent, y, "Enable Custom Trackers",
            function() return GetSetting(trackerKey, "enabled") end,
            function(v) 
                SetSetting(trackerKey, "enabled", v)
                RebuildCustomTrackerIcons()
            end)
        
        -- ========================================
        -- DRAG & DROP ZONE
        -- ========================================
        y = y - 10
        y = CreateHeader(parent, y, "Add Entry")
        
        -- Create drop zone frame
        local dropZone = CreateFrame("Button", nil, parent, "BackdropTemplate")
        dropZone:SetPoint("TOPLEFT", 10, y)
        dropZone:SetSize(PANEL_WIDTH - 60, 45)
        dropZone:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12,
            insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        dropZone:SetBackdropColor(0.1, 0.1, 0.1, 0.8)
        dropZone:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
        
        local dropText = dropZone:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        dropText:SetPoint("CENTER")
        dropText:SetText("|cff888888Drop spell or item here|r")
        
        -- Drop zone handlers
        local function ProcessPanelDrop()
            local cursorType, id, subType, spellID = GetCursorInfo()
            
            if cursorType == "spell" then
                local actualSpellID = spellID or id
                if actualSpellID then
                    local success, msg = AddCustomEntry("spell", actualSpellID)
                    ClearCursor()
                    if success then
                        RebuildCustomTrackerIcons()
                        if panel.RefreshEntriesList then
                            panel:RefreshEntriesList()
                        end
                        dropText:SetText("|cff00ff00Added!|r")
                        C_Timer.After(1.5, function()
                            dropText:SetText("|cff888888Drop spell or item here|r")
                        end)
                    end
                    return true
                end
            elseif cursorType == "item" then
                local itemID = id
                if itemID then
                    local success, msg = AddCustomEntry("item", itemID)
                    ClearCursor()
                    if success then
                        RebuildCustomTrackerIcons()
                        if panel.RefreshEntriesList then
                            panel:RefreshEntriesList()
                        end
                        dropText:SetText("|cff00ff00Added!|r")
                        C_Timer.After(1.5, function()
                            dropText:SetText("|cff888888Drop spell or item here|r")
                        end)
                    end
                    return true
                end
            end
            ClearCursor()
            return false
        end
        
        dropZone:SetScript("OnReceiveDrag", ProcessPanelDrop)
        dropZone:SetScript("OnMouseDown", function(self, button)
            if button == "LeftButton" and GetCursorInfo() then
                ProcessPanelDrop()
            end
        end)
        
        dropZone:SetScript("OnEnter", function(self)
            if GetCursorInfo() then
                self:SetBackdropBorderColor(0.2, 0.8, 0.2, 1)
                dropText:SetText("|cff00ff00Release to add!|r")
            else
                self:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
            end
        end)
        
        dropZone:SetScript("OnLeave", function(self)
            self:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
            dropText:SetText("|cff888888Drop spell or item here|r")
        end)
        
        y = y - 55
        
        -- Manual entry row
        local typeLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        typeLabel:SetPoint("TOPLEFT", 10, y)
        typeLabel:SetText("Manual:")
        typeLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local typeDropdown = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate")
        typeDropdown:SetPoint("LEFT", typeLabel, "RIGHT", -10, -2)
        UIDropDownMenu_SetWidth(typeDropdown, 65)
        
        local selectedType = "spell"
        UIDropDownMenu_Initialize(typeDropdown, function(self, level)
            local info = UIDropDownMenu_CreateInfo()
            info.text = "Spell"
            info.value = "spell"
            info.func = function() selectedType = "spell"; UIDropDownMenu_SetText(typeDropdown, "Spell") end
            info.checked = (selectedType == "spell")
            UIDropDownMenu_AddButton(info, level)
            
            info = UIDropDownMenu_CreateInfo()
            info.text = "Item"
            info.value = "item"
            info.func = function() selectedType = "item"; UIDropDownMenu_SetText(typeDropdown, "Item") end
            info.checked = (selectedType == "item")
            UIDropDownMenu_AddButton(info, level)
        end)
        UIDropDownMenu_SetText(typeDropdown, "Spell")
        
        local idInput = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        idInput:SetPoint("LEFT", typeDropdown, "RIGHT", 0, 2)
        idInput:SetSize(70, 20)
        idInput:SetAutoFocus(false)
        idInput:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        
        local addBtn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        addBtn:SetPoint("LEFT", idInput, "RIGHT", 3, 0)
        addBtn:SetSize(45, 20)
        addBtn:SetText("Add")
        
        addBtn:SetScript("OnClick", function()
            local input = idInput:GetText():trim()
            if input == "" then return end
            
            local success, msg = AddCustomEntry(selectedType, input)
            if success then
                idInput:SetText("")
                RebuildCustomTrackerIcons()
                if panel.RefreshEntriesList then
                    panel:RefreshEntriesList()
                end
            end
        end)
        
        idInput:SetScript("OnEnterPressed", function(self)
            addBtn:Click()
            self:ClearFocus()
        end)
        y = y - 30
        
        -- ========================================
        -- ADD EQUIPPED SLOTS
        -- ========================================
        y = y - 5
        y = CreateHeader(parent, y, "Add Equipped Slot")
        
        local equipHelp = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        equipHelp:SetPoint("TOPLEFT", 10, y)
        equipHelp:SetText("|cff888888Click + to track on-use equipment:|r")
        y = y - 14
        
        local equipContainer = CreateFrame("Frame", nil, parent)
        equipContainer:SetPoint("TOPLEFT", 10, y)
        equipContainer:SetSize(PANEL_WIDTH - 50, 80)
        panel.equipContainer = equipContainer
        
        local equipElements = {}
        
        -- Refresh available equipped items to add
        function panel:RefreshEquipmentList()
            for _, elem in ipairs(equipElements) do
                if elem.Hide then elem:Hide() end
                if elem.SetParent then elem:SetParent(nil) end
            end
            wipe(equipElements)
            
            local eqY = 0
            local currentEquipped = ScanEquippedOnUseItems()
            local entries = GetCurrentSpecEntries()
            
            -- Check which slots are already tracked
            local trackedSlots = {}
            for _, entry in ipairs(entries) do
                if entry.type == "equipped" then
                    trackedSlots[entry.id] = true
                end
            end
            
            local hasAny = false
            for slotID, itemInfo in pairs(currentEquipped) do
                if not trackedSlots[slotID] then
                    hasAny = true
                    local row = CreateFrame("Frame", nil, equipContainer)
                    row:SetPoint("TOPLEFT", 0, eqY)
                    row:SetSize(PANEL_WIDTH - 70, 20)
                    table.insert(equipElements, row)
                    
                    local icon = row:CreateTexture(nil, "ARTWORK")
                    icon:SetPoint("LEFT", 0, 0)
                    icon:SetSize(18, 18)
                    icon:SetTexture(itemInfo.texture)
                    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                    
                    local slotName = itemInfo.slotName or TRACKABLE_EQUIPMENT_SLOTS[slotID] or "Slot " .. slotID
                    local itemName = itemInfo.itemName or "Unknown"
                    
                    local label = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    label:SetPoint("LEFT", icon, "RIGHT", 4, 0)
                    label:SetPoint("RIGHT", row, "RIGHT", -40, 0)
                    label:SetJustifyH("LEFT")
                    label:SetText(string.format("|cff888888[%s]|r %s", slotName, itemName))
                    label:SetWordWrap(false)
                    
                    local addSlotBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                    addSlotBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
                    addSlotBtn:SetSize(30, 18)
                    addSlotBtn:SetText("+")
                    addSlotBtn:SetScript("OnClick", function()
                        AddCustomEntry("equipped", slotID)
                        RebuildCustomTrackerIcons()
                        panel:RefreshEquipmentList()
                        panel:RefreshEntriesList()
                    end)
                    
                    eqY = eqY - 22
                end
            end
            
            if not hasAny then
                local noNew = equipContainer:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                noNew:SetPoint("TOPLEFT", 0, 0)
                if CountTableEntries(currentEquipped) == 0 then
                    noNew:SetText("|cff666666No on-use equipment currently equipped|r")
                else
                    noNew:SetText("|cff666666All on-use equipment already tracked|r")
                end
                table.insert(equipElements, noNew)
            end
        end
        
        y = y - 70
        
        -- ========================================
        -- UNIFIED ENTRIES LIST
        -- ========================================
        y = y - 10
        y = CreateHeader(parent, y, "Tracked Entries (This Spec)")
        
        local reorderHelp = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        reorderHelp:SetPoint("TOPLEFT", 10, y)
        reorderHelp:SetText("|cff888888Arrows to reorder, X to remove|r")
        y = y - 14
        
        local entriesContainer = CreateFrame("Frame", nil, parent)
        entriesContainer:SetPoint("TOPLEFT", 10, y)
        entriesContainer:SetSize(PANEL_WIDTH - 50, 250)
        panel.entriesContainer = entriesContainer
        
        local entryElements = {}
        
        -- Refresh unified entries list
        function panel:RefreshEntriesList()
            for _, elem in ipairs(entryElements) do
                if elem.Hide then elem:Hide() end
                if elem.SetParent then elem:SetParent(nil) end
            end
            wipe(entryElements)
            
            local entryY = 0
            local entries = GetCurrentSpecEntries()
            
            for i, entry in ipairs(entries) do
                local displayName, displayTexture, trackID = GetEntryDisplayInfo(entry)
                local isEnabled = entry.enabled ~= false
                
                -- Check if equipped slot has on-use ability
                local hasOnUse = true
                local isEmptySlot = false
                if entry.type == "equipped" then
                    local itemID = GetInventoryItemID("player", entry.id)
                    if itemID then
                        hasOnUse = HasOnUseAbility(itemID)
                    else
                        isEmptySlot = true
                    end
                end
                
                -- Determine if entry will actually display
                local willDisplay = isEnabled and hasOnUse and not isEmptySlot
                
                local row = CreateFrame("Frame", nil, entriesContainer)
                row:SetPoint("TOPLEFT", 0, entryY)
                row:SetSize(PANEL_WIDTH - 50, 24)
                table.insert(entryElements, row)
                
                -- Enable checkbox
                local enableCB = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
                enableCB:SetPoint("LEFT", 0, 0)
                enableCB:SetSize(18, 18)
                enableCB:SetChecked(isEnabled)
                enableCB:SetScript("OnClick", function(self)
                    SetCustomEntryEnabled(i, self:GetChecked())
                    RebuildCustomTrackerIcons()
                end)
                enableCB:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:SetText("Enable/Disable")
                    GameTooltip:AddLine("Uncheck to hide without removing", 0.8, 0.8, 0.8, true)
                    GameTooltip:Show()
                end)
                enableCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
                
                -- Move up button
                local upBtn = CreateFrame("Button", nil, row)
                upBtn:SetPoint("LEFT", enableCB, "RIGHT", 0, 0)
                upBtn:SetSize(14, 14)
                upBtn:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up")
                upBtn:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down")
                upBtn:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Highlight")
                upBtn:SetEnabled(i > 1)
                upBtn:SetScript("OnClick", function()
                    MoveCustomEntry(i, i - 1)
                    RebuildCustomTrackerIcons()
                    panel:RefreshEntriesList()
                end)
                if i == 1 then upBtn:SetAlpha(0.3) end
                
                -- Move down button
                local downBtn = CreateFrame("Button", nil, row)
                downBtn:SetPoint("LEFT", upBtn, "RIGHT", 0, 0)
                downBtn:SetSize(14, 14)
                downBtn:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
                downBtn:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down")
                downBtn:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Highlight")
                downBtn:SetEnabled(i < #entries)
                downBtn:SetScript("OnClick", function()
                    MoveCustomEntry(i, i + 1)
                    RebuildCustomTrackerIcons()
                    panel:RefreshEntriesList()
                end)
                if i == #entries then downBtn:SetAlpha(0.3) end
                
                -- Icon
                local icon = row:CreateTexture(nil, "ARTWORK")
                icon:SetPoint("LEFT", downBtn, "RIGHT", 3, 0)
                icon:SetSize(18, 18)
                icon:SetTexture(displayTexture or "Interface\\Icons\\INV_Misc_QuestionMark")
                icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                if not willDisplay then
                    icon:SetDesaturated(true)
                    icon:SetAlpha(0.5)
                end
                
                -- Type indicator and name
                local typeChar
                if entry.type == "spell" then
                    typeChar = "|cff71d5ffS|r"  -- Blue for spell
                elseif entry.type == "item" then
                    typeChar = "|cffa335eeI|r"  -- Purple for item
                elseif entry.type == "equipped" then
                    typeChar = "|cff00ff00E|r"  -- Green for equipped
                end
                
                -- Build label with status indicators
                local labelText = displayName or "Loading..."
                if not isEnabled then
                    labelText = "|cff666666[" .. typeChar .. "] " .. labelText .. "|r"
                elseif isEmptySlot then
                    labelText = "|cff666666[" .. typeChar .. "] " .. labelText .. " |cffff6600(empty)|r|r"
                elseif not hasOnUse then
                    labelText = "|cff666666[" .. typeChar .. "] " .. labelText .. "|r"
                else
                    labelText = "[" .. typeChar .. "] " .. labelText
                end
                
                local label = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                label:SetPoint("LEFT", icon, "RIGHT", 3, 0)
                label:SetPoint("RIGHT", row, "RIGHT", -22, 0)
                label:SetJustifyH("LEFT")
                label:SetText(labelText)
                label:SetWordWrap(false)
                
                -- Remove button
                local removeBtn = CreateFrame("Button", nil, row)
                removeBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
                removeBtn:SetSize(16, 16)
                removeBtn:SetNormalTexture("Interface\\Buttons\\UI-StopButton")
                removeBtn:SetHighlightTexture("Interface\\Buttons\\UI-StopButton")
                removeBtn:GetHighlightTexture():SetVertexColor(1, 0.3, 0.3)
                removeBtn:SetScript("OnClick", function()
                    RemoveCustomEntry(i)
                    RebuildCustomTrackerIcons()
                    panel:RefreshEntriesList()
                    panel:RefreshEquipmentList()
                end)
                removeBtn:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:SetText("Remove")
                    GameTooltip:Show()
                end)
                removeBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                
                entryY = entryY - 26
            end
            
            if #entries == 0 then
                local noEntries = entriesContainer:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                noEntries:SetPoint("TOPLEFT", 0, 0)
                noEntries:SetText("|cff888888No entries - drop spells/items above to add|r")
                table.insert(entryElements, noEntries)
            end
        end
        
        -- Backwards compat aliases
        panel.RefreshCustomEntriesList = panel.RefreshEntriesList
        panel.RefreshEquippedItemsList = panel.RefreshEquipmentList
        
        parent:SetHeight(math.abs(y) + 300)
    end
    
    -- ========================================
    -- TAB 2: LAYOUT
    -- ========================================
    local function BuildLayoutTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Icon Size")
        y = CreateSlider(parent, y, "Base Size", 16, 80, 1,
            function() return GetSetting(trackerKey, "iconSize") or 36 end,
            function(v) SetSetting(trackerKey, "iconSize", v) end)
        
        y = CreateDropdown(parent, y, "Aspect Ratio", ASPECT_PRESETS,
            function() return GetSetting(trackerKey, "aspectRatio") or "1:1" end,
            function(v) 
                SetSetting(trackerKey, "aspectRatio", v)
                if v ~= "custom" then
                    SetSetting(trackerKey, "iconWidth", nil)
                    SetSetting(trackerKey, "iconHeight", nil)
                end
            end)
        
        -- Custom dimensions
        local customLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        customLabel:SetPoint("TOPLEFT", 10, y)
        customLabel:SetText("Custom: Width")
        customLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local widthBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        widthBox:SetPoint("LEFT", customLabel, "RIGHT", 5, 0)
        widthBox:SetSize(40, 20)
        widthBox:SetAutoFocus(false)
        widthBox:SetNumeric(true)
        widthBox:SetNumber(GetSetting(trackerKey, "iconWidth") or 36)
        widthBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconWidth", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        
        local heightLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        heightLabel:SetPoint("LEFT", widthBox, "RIGHT", 10, 0)
        heightLabel:SetText("Height")
        heightLabel:SetTextColor(0.6, 0.6, 0.6)
        
        local heightBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        heightBox:SetPoint("LEFT", heightLabel, "RIGHT", 5, 0)
        heightBox:SetSize(40, 20)
        heightBox:SetAutoFocus(false)
        heightBox:SetNumeric(true)
        heightBox:SetNumber(GetSetting(trackerKey, "iconHeight") or 36)
        heightBox:SetScript("OnEnterPressed", function(self)
            SetSetting(trackerKey, "iconHeight", self:GetNumber())
            SetSetting(trackerKey, "aspectRatio", "custom")
            RefreshLayout()
            self:ClearFocus()
        end)
        y = y - 28
        
        y = CreateHeader(parent, y, "Grid Layout")
        y = CreateSlider(parent, y, "Columns", 1, 20, 1,
            function() return GetSetting(trackerKey, "columns") or 4 end,
            function(v) SetSetting(trackerKey, "columns", v) end)
        
        y = CreateSlider(parent, y, "Max Rows (0=unlimited)", 0, 10, 1,
            function() return GetSetting(trackerKey, "rows") or 0 end,
            function(v) SetSetting(trackerKey, "rows", v) end)
        
        -- Custom layout pattern
        y, _ = CreateEditBox(parent, y, "Custom Pattern (e.g. 4,4,2):",
            function() return GetSetting(trackerKey, "customLayout") or "" end,
            function(v) SetSetting(trackerKey, "customLayout", v) end, 100)
        
        y = CreateHeader(parent, y, "Spacing")
        
        -- Horizontal spacing
        local hLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hLabel:SetPoint("TOPLEFT", 10, y)
        hLabel:SetText("Horizontal:")
        hLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local hBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        hBox:SetPoint("LEFT", hLabel, "RIGHT", 8, 0)
        hBox:SetSize(60, 20)
        hBox:SetAutoFocus(false)
        hBox:SetText(tostring(GetSetting(trackerKey, "spacingH") or 2))
        hBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingH", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        hBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        -- Vertical spacing
        local vLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        vLabel:SetPoint("TOPLEFT", 10, y)
        vLabel:SetText("Vertical:")
        vLabel:SetTextColor(0.8, 0.8, 0.8)
        
        local vBox = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        vBox:SetPoint("LEFT", vLabel, "RIGHT", 8, 0)
        vBox:SetSize(60, 20)
        vBox:SetAutoFocus(false)
        vBox:SetText(tostring(GetSetting(trackerKey, "spacingV") or 2))
        vBox:SetScript("OnEnterPressed", function(self)
            local val = tonumber(self:GetText()) or 2
            SetSetting(trackerKey, "spacingV", val)
            RefreshLayout()
            self:ClearFocus()
        end)
        vBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        y = y - 26
        
        y = CreateHeader(parent, y, "Growth Direction")
        
        local growOptions = {
            { label = "Right", value = "RIGHT" },
            { label = "Left", value = "LEFT" },
            { label = "Down", value = "DOWN" },
            { label = "Up", value = "UP" },
        }
        
        y = CreateDropdown(parent, y, "Primary:", growOptions,
            function() return GetSetting(trackerKey, "growDirection") or "RIGHT" end,
            function(v) SetSetting(trackerKey, "growDirection", v) end)
        
        y = CreateDropdown(parent, y, "Secondary:", growOptions,
            function() return GetSetting(trackerKey, "growSecondary") or "DOWN" end,
            function(v) SetSetting(trackerKey, "growSecondary", v) end)
        
        local alignOptions = {
            { label = "Left", value = "LEFT" },
            { label = "Center", value = "CENTER" },
            { label = "Right", value = "RIGHT" },
        }
        
        y = CreateDropdown(parent, y, "Alignment:", alignOptions,
            function() return GetSetting(trackerKey, "alignment") or "LEFT" end,
            function(v) SetSetting(trackerKey, "alignment", v) end)
        
        y = CreateCheckbox(parent, y, "Reverse Icon Order",
            function() return GetSetting(trackerKey, "reverseOrder") end,
            function(v) SetSetting(trackerKey, "reverseOrder", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 3: APPEARANCE
    -- ========================================
    local function BuildAppearanceTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Icon Appearance")
        
        y = CreateSlider(parent, y, "Zoom (texture crop)", 0, 0.15, 0.01,
            function() return GetSetting(trackerKey, "zoom") or 0.08 end,
            function(v) SetSetting(trackerKey, "zoom", v) end)
        
        y = CreateSlider(parent, y, "Icon Opacity", 0.1, 1.0, 0.05,
            function() return GetSetting(trackerKey, "iconOpacity") or 1.0 end,
            function(v) SetSetting(trackerKey, "iconOpacity", v) end)
        
        y = CreateSlider(parent, y, "Border Opacity", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "borderAlpha") or 1.0 end,
            function(v) SetSetting(trackerKey, "borderAlpha", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 4: TEXT
    -- ========================================
    local function BuildTextTab(parent)
        local y = -10
        
        y = CreateHeader(parent, y, "Text Scaling")
        
        y = CreateSlider(parent, y, "Cooldown Text Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "cooldownTextScale") or 1.0 end,
            function(v) SetSetting(trackerKey, "cooldownTextScale", v) end)
        
        y = CreateSlider(parent, y, "Stack Count Scale", 0.5, 2.0, 0.1,
            function() return GetSetting(trackerKey, "countTextScale") or 1.0 end,
            function(v) SetSetting(trackerKey, "countTextScale", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- ========================================
    -- TAB 5: VISIBILITY
    -- ========================================
    local function BuildVisibilityTab(parent)
        local y = -10
        
        y = CreateCheckbox(parent, y, "Enable Visibility Conditions",
            function() return GetSetting(trackerKey, "visibilityEnabled") or false end,
            function(v) SetSetting(trackerKey, "visibilityEnabled", v) end)
        
        y = CreateHeader(parent, y, "Show When (OR logic)")
        
        y = CreateCheckbox(parent, y, "In Combat",
            function() return GetSetting(trackerKey, "showInCombat") end,
            function(v) SetSetting(trackerKey, "showInCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Out of Combat",
            function() return GetSetting(trackerKey, "showOutOfCombat") end,
            function(v) SetSetting(trackerKey, "showOutOfCombat", v) end)
        
        y = CreateCheckbox(parent, y, "Solo",
            function() return GetSetting(trackerKey, "showSolo") end,
            function(v) SetSetting(trackerKey, "showSolo", v) end)
        
        y = CreateCheckbox(parent, y, "In Party",
            function() return GetSetting(trackerKey, "showInParty") end,
            function(v) SetSetting(trackerKey, "showInParty", v) end)
        
        y = CreateCheckbox(parent, y, "In Raid",
            function() return GetSetting(trackerKey, "showInRaid") end,
            function(v) SetSetting(trackerKey, "showInRaid", v) end)
        
        y = CreateCheckbox(parent, y, "In Instance (Dungeon)",
            function() return GetSetting(trackerKey, "showInInstance") end,
            function(v) SetSetting(trackerKey, "showInInstance", v) end)
        
        y = CreateCheckbox(parent, y, "In Arena",
            function() return GetSetting(trackerKey, "showInArena") end,
            function(v) SetSetting(trackerKey, "showInArena", v) end)
        
        y = CreateCheckbox(parent, y, "In Battleground",
            function() return GetSetting(trackerKey, "showInBattleground") end,
            function(v) SetSetting(trackerKey, "showInBattleground", v) end)
        
        y = CreateCheckbox(parent, y, "Has Target",
            function() return GetSetting(trackerKey, "showHasTarget") end,
            function(v) SetSetting(trackerKey, "showHasTarget", v) end)
        
        y = CreateCheckbox(parent, y, "No Target",
            function() return GetSetting(trackerKey, "showNoTarget") end,
            function(v) SetSetting(trackerKey, "showNoTarget", v) end)
        
        y = CreateHeader(parent, y, "Fade Settings")
        
        y = CreateCheckbox(parent, y, "Enable Fade",
            function() return GetSetting(trackerKey, "fadeEnabled") or false end,
            function(v) SetSetting(trackerKey, "fadeEnabled", v) end)
        
        y = CreateSlider(parent, y, "Fade Delay (seconds)", 0, 10, 0.5,
            function() return GetSetting(trackerKey, "fadeDelay") or 3.0 end,
            function(v) SetSetting(trackerKey, "fadeDelay", v) end)
        
        y = CreateSlider(parent, y, "Fade Alpha", 0, 1.0, 0.05,
            function() return GetSetting(trackerKey, "fadeAlpha") or 0.3 end,
            function(v) SetSetting(trackerKey, "fadeAlpha", v) end)
        
        parent:SetHeight(math.abs(y) + 20)
    end
    
    -- Build tab content builders
    local tabBuilders = {
        entries = BuildEntriesTab,
        layout = BuildLayoutTab,
        appearance = BuildAppearanceTab,
        text = BuildTextTab,
        visibility = BuildVisibilityTab,
    }
    
    -- Create content frames and tab buttons
    local tabWidth = (PANEL_WIDTH - 20) / #tabs
    
    for i, tab in ipairs(tabs) do
        -- Create content frame
        local content = CreateTabContent()
        contentFrames[tab.key] = content
        
        -- Build content
        if tabBuilders[tab.key] then
            tabBuilders[tab.key](content.scrollChild)
        end
        
        -- Create tab button
        local tabBtn = CreateFrame("Button", nil, tabContainer)
        tabBtn:SetSize(tabWidth - 2, 26)
        tabBtn:SetPoint("LEFT", (i - 1) * tabWidth, 0)
        
        tabBtn.bg = tabBtn:CreateTexture(nil, "BACKGROUND")
        tabBtn.bg:SetAllPoints()
        tabBtn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
        
        tabBtn.text = tabBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        tabBtn.text:SetPoint("CENTER")
        tabBtn.text:SetText(tab.name)
        
        tabBtn:SetScript("OnClick", function()
            -- Hide all content
            for _, cf in pairs(contentFrames) do
                cf:Hide()
            end
            -- Show selected
            contentFrames[tab.key]:Show()
            -- Update button visuals
            for _, btn in ipairs(tabButtons) do
                btn.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
                btn.text:SetTextColor(0.7, 0.7, 0.7)
            end
            tabBtn.bg:SetColorTexture(0.3, 0.3, 0.5, 1)
            tabBtn.text:SetTextColor(1, 1, 1)
            currentTab = i
            
            -- Refresh entries tab when shown
            if tab.key == "entries" then
                if panel.RefreshEquipmentList then panel:RefreshEquipmentList() end
                if panel.RefreshCustomEntriesList then panel:RefreshCustomEntriesList() end
            end
        end)
        
        tabBtn:SetScript("OnEnter", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.25, 0.25, 0.35, 0.9)
            end
        end)
        
        tabBtn:SetScript("OnLeave", function(self)
            if currentTab ~= i then
                self.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
            end
        end)
        
        tabButtons[i] = tabBtn
    end
    
    -- Show first tab
    if tabButtons[1] then
        tabButtons[1]:Click()
    end
    
    -- Initial refresh
    C_Timer.After(0.1, function()
        if panel.RefreshEquippedItemsList then panel:RefreshEquippedItemsList() end
        if panel.RefreshCustomEntriesList then panel:RefreshCustomEntriesList() end
    end)
    
    panel:Show()
end



-- ============================================================================
-- MODULE LIFECYCLE
-- ============================================================================

function Cooldowns:OnInitialize()
    -- Load settings from database
    local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
    
    -- Start with defaults
    settings = DeepCopy(DEFAULTS)
    
    -- Merge saved settings
    if dbSettings then
        for key, trackerSettings in pairs(dbSettings) do
            if settings[key] and type(trackerSettings) == "table" then
                for k, v in pairs(trackerSettings) do
                    -- Migration: old "spacing" -> "spacingH" and "spacingV"
                    if k == "spacing" then
                        settings[key]["spacingH"] = v
                        settings[key]["spacingV"] = v
                    else
                        settings[key][k] = v
                    end
                end
            elseif key == "global" and type(trackerSettings) == "table" then
                for k, v in pairs(trackerSettings) do
                    settings.global[k] = v
                end
            end
        end
    end
    
    -- Initialize layout update flags
    for _, tracker in ipairs(TRACKERS) do
        needsLayoutUpdate[tracker.key] = false
    end
    needsLayoutUpdate["customTrackers"] = false
    
    dprint("Cooldowns module initialized")
    if dbSettings then
        dprint("Loaded saved settings")
    else
        dprint("No saved settings found, using defaults")
    end
end


function Cooldowns:OnEnable()
    -- Register events
    eventFrame:RegisterEvent("ADDON_LOADED")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("SPELL_UPDATE_COOLDOWN")
    eventFrame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")  -- Combat start
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")     -- Party/raid changes
    eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")   -- Instance changes
    eventFrame:RegisterEvent("UNIT_AURA")               -- Buff changes (for activity)
    eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")   -- Target changes
    eventFrame:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")  -- Edit Mode positions applied
    eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")  -- Gear changes for equipped items tracker
    eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")  -- Spec changes for per-spec entries
    
    eventFrame:SetScript("OnEvent", OnEvent)
    eventFrame:SetScript("OnUpdate", OnUpdate)
    
    -- Hook Edit Mode for tracker visibility
    if EditModeManagerFrame then
        EditModeManagerFrame:HookScript("OnShow", function()
            dprint("Edit Mode opened")
            
            -- Force show all Blizzard trackers for Edit Mode positioning
            for _, tracker in ipairs(TRACKERS) do
                local viewer = _G[tracker.name]
                if viewer then
                    viewer:Show()
                    viewer:SetAlpha(1.0)
                    ApplyGridLayout(viewer, tracker.key)
                end
            end
            
            -- Force show custom tracker for Edit Mode
            if customTrackerFrame then
                customTrackerFrame:Show()
                
                -- Disable mouse on icons so LibEditMode selection can be clicked
                for _, iconFrame in pairs(customTrackerIcons) do
                    iconFrame:EnableMouse(false)
                end
                
                LayoutCustomTrackerIcons()
            end
        end)
        
        -- Hook Edit Mode exit to restore visibility rules
        EditModeManagerFrame:HookScript("OnHide", function()
            dprint("Edit Mode closed")
            
            -- Re-apply visibility rules for all Blizzard trackers
            for _, tracker in ipairs(TRACKERS) do
                UpdateTrackerVisibility(tracker.key)
            end
            
            -- Handle custom tracker
            if customTrackerFrame then
                -- Re-enable mouse on icons for tooltips
                for _, iconFrame in pairs(customTrackerIcons) do
                    iconFrame:EnableMouse(true)
                end
                
                -- Re-apply saved position to ensure it's correct after Edit Mode
                local savedPoint = GetSetting("customTrackers", "point") or "CENTER"
                local savedX = GetSetting("customTrackers", "x") or 0
                local savedY = GetSetting("customTrackers", "y") or -200
                
                dprint(string.format("Restoring custom tracker pos: %s, %.1f, %.1f", savedPoint, savedX, savedY))
                
                customTrackerFrame:ClearAllPoints()
                customTrackerFrame:SetPoint(savedPoint, savedX, savedY)
                
                -- Re-apply visibility rules now that Edit Mode is closed
                UpdateCustomTrackerVisibility()
            end
        end)
    end
    
    -- Hook viewers immediately (they might already exist)
    HookAllViewers()
    
    -- Schedule additional hook attempt
    C_Timer.After(1.0, HookAllViewers)
    C_Timer.After(3.0, HookAllViewers)
    
    -- Start buff state tracking
    StartBuffStateTracking()
    
    -- Start visibility system
    StartVisibilitySystem()
    
    -- Initialize custom tracker system
    InitializeCustomTrackerData()
    CreateCustomTrackerFrame()
    StartCustomTrackerUpdates()
    
    -- Delay custom tracker rebuild to ensure data is loaded
    C_Timer.After(1.0, RebuildCustomTrackerIcons)
    
    dprint("Cooldowns module enabled")
end

function Cooldowns:OnDisable()
    eventFrame:UnregisterAllEvents()
    eventFrame:SetScript("OnEvent", nil)
    eventFrame:SetScript("OnUpdate", nil)
    
    -- Stop buff state tracking
    StopBuffStateTracking()
    
    -- Stop visibility system
    StopVisibilitySystem()
    
    -- Stop custom tracker updates
    StopCustomTrackerUpdates()
    
    if cooldownHub then
        cooldownHub:Hide()
    end
    self:HideAllPanels()
    
    dprint("Cooldowns module disabled")
end

-- Save settings on logout
local saveFrame = CreateFrame("Frame")
saveFrame:RegisterEvent("PLAYER_LOGOUT")
saveFrame:SetScript("OnEvent", function()
    if settings then
        TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS, settings)
    end
end)

-- Debug slash command
SLASH_TUICD1 = "/tuicd"
SlashCmdList["TUICD"] = function(msg)
    msg = msg:lower():trim()
    
    if msg == "debug" then
        -- Toggle debug mode
        if settings and settings.global then
            settings.global.debugMode = not settings.global.debugMode
            print("|cff00ff00[TweaksUI CD]|r Debug mode:", settings.global.debugMode and "ON" or "OFF")
        end
        
    elseif msg == "dump" then
        -- Dump icon structure
        print("|cff00ff00[TweaksUI CD]|r Dumping icon structures...")
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                print("  " .. tracker.key .. ":")
                local icons = CollectIcons(viewer)
                for i, icon in ipairs(icons) do
                    if i <= 2 and icon:IsShown() then  -- Only first 2 shown icons
                        local name = icon:GetName() or "unnamed"
                        print("    Icon " .. i .. ": " .. name)
                        -- Check for fields
                        local fields = {}
                        if icon.Border then table.insert(fields, "Border") end
                        if icon.border then table.insert(fields, "border") end
                        if icon.IconBorder then table.insert(fields, "IconBorder") end
                        if icon.Icon then table.insert(fields, "Icon") end
                        if icon.icon then table.insert(fields, "icon") end
                        if icon.Cooldown then table.insert(fields, "Cooldown") end
                        if icon.cooldown then table.insert(fields, "cooldown") end
                        if icon.Count then table.insert(fields, "Count") end
                        if icon.count then table.insert(fields, "count") end
                        if icon.GetNormalTexture and icon:GetNormalTexture() then table.insert(fields, "NormalTexture") end
                        print("      Fields: " .. table.concat(fields, ", "))
                        
                        -- Check regions for FontStrings
                        if icon.GetRegions then
                            local fontStrings = {}
                            for _, region in ipairs({icon:GetRegions()}) do
                                if region:GetObjectType() == "FontString" then
                                    local fsName = region:GetName() or "unnamed"
                                    local fsText = region:GetText() or ""
                                    table.insert(fontStrings, fsName .. "='" .. fsText .. "'")
                                end
                            end
                            if #fontStrings > 0 then
                                print("      FontStrings: " .. table.concat(fontStrings, ", "))
                            end
                        end
                        
                        -- Check children
                        if icon.GetChildren then
                            for _, child in ipairs({icon:GetChildren()}) do
                                local childName = child:GetName() or child:GetObjectType()
                                print("      Child: " .. childName)
                                
                                -- Check child for FontStrings
                                if child.GetRegions then
                                    for _, region in ipairs({child:GetRegions()}) do
                                        if region:GetObjectType() == "FontString" then
                                            local fsName = region:GetName() or "unnamed"
                                            local fsText = region:GetText() or ""
                                            print("        FontString: " .. fsName .. " = '" .. fsText .. "'")
                                        end
                                    end
                                end
                                
                                -- Check grandchildren
                                if child.GetChildren then
                                    for _, grandchild in ipairs({child:GetChildren()}) do
                                        local gcName = grandchild:GetName() or grandchild:GetObjectType()
                                        if grandchild.GetRegions then
                                            for _, region in ipairs({grandchild:GetRegions()}) do
                                                if region:GetObjectType() == "FontString" then
                                                    local fsName = region:GetName() or "unnamed"
                                                    local fsText = region:GetText() or ""
                                                    print("          " .. gcName .. " FontString: " .. fsName .. " = '" .. fsText .. "'")
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        
    elseif msg == "test" then
        -- Test settings persistence
        print("|cff00ff00[TweaksUI CD]|r Testing settings...")
        print("  settings table exists:", settings ~= nil)
        if settings then
            print("  settings.essential:", settings.essential ~= nil)
            if settings.essential then
                print("    iconSize:", settings.essential.iconSize)
                print("    columns:", settings.essential.columns)
            end
        end
        -- Check database
        local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.COOLDOWNS)
        print("  DB settings exists:", dbSettings ~= nil)
        if dbSettings and dbSettings.essential then
            print("    DB iconSize:", dbSettings.essential.iconSize)
        end
        
    elseif msg == "reset" then
        -- Clear saved order and recapture all trackers
        print("|cff00ff00[TweaksUI CD]|r Clearing saved icon order and recapturing...")
        ClearIconOrderCache()
        for _, tracker in ipairs(TRACKERS) do
            local viewer = _G[tracker.name]
            if viewer and viewer:IsShown() then
                ApplyGridLayout(viewer, tracker.key)
            end
        end
        print("|cff00ff00[TweaksUI CD]|r Reset complete. Icon order saved from current positions.")
    
    elseif msg == "resetbuffs" then
        -- Clear saved order for just buffs tracker
        print("|cff00ff00[TweaksUI CD]|r Clearing buffs icon order and recapturing...")
        ClearIconOrderCache("buffs")
        local viewer = _G["BuffIconCooldownViewer"]
        if viewer and viewer:IsShown() then
            ApplyGridLayout(viewer, "buffs")
            print("|cff00ff00[TweaksUI CD]|r Buffs tracker reset complete.")
        else
            print("|cff00ff00[TweaksUI CD]|r Buffs tracker not visible - show it first.")
        end
    
    elseif msg == "order" then
        -- Show current saved order for all trackers
        print("|cff00ff00[TweaksUI CD]|r Saved icon order:")
        for _, tracker in ipairs(TRACKERS) do
            local savedOrder = GetSetting(tracker.key, "savedIconOrder")
            if savedOrder and #savedOrder > 0 then
                print(string.format("  [%s]: %d icons - %s", tracker.key, #savedOrder, table.concat(savedOrder, ", ")))
            else
                print(string.format("  [%s]: (no saved order)", tracker.key))
            end
        end
        
    elseif msg == "custom" then
        -- Rebuild custom trackers
        print("|cff00ff00[TweaksUI CD]|r Rebuilding custom trackers...")
        RebuildCustomTrackerIcons()
        print("|cff00ff00[TweaksUI CD]|r Custom trackers rebuilt.")
        
    elseif msg == "equipped" then
        -- Show equipped on-use items
        print("|cff00ff00[TweaksUI CD]|r Scanning equipped on-use items...")
        local items = ScanEquippedOnUseItems()
        local count = 0
        for slotID, info in pairs(items) do
            count = count + 1
            print(string.format("  Slot %d (%s): %s", slotID, info.slotName, info.itemName or "Loading..."))
        end
        if count == 0 then
            print("  No equipped items with on-use abilities found.")
        end
        
    else
        print("|cff00ff00[TweaksUI CD]|r Commands:")
        print("  /tuicd debug - Toggle debug mode")
        print("  /tuicd dump - Dump icon structure info")
        print("  /tuicd test - Test settings persistence")
        print("  /tuicd reset - Clear and recapture ALL tracker icon order")
        print("  /tuicd resetbuffs - Clear and recapture buffs tracker order")
        print("  /tuicd order - Show saved icon order (texture fileIDs)")
        print("  /tuicd custom - Rebuild custom trackers")
        print("  /tuicd equipped - Show equipped on-use items")
    end
end
