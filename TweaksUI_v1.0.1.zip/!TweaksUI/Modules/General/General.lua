-- TweaksUI General Module
-- Provides UI visibility toggles and AFK Mode functionality
-- This is NOT a standard enable/disable module - it's always active

local ADDON_NAME, TweaksUI = ...

local General = {}
TweaksUI.General = General

-- ============================================================================
-- CONSTANTS
-- ============================================================================

local HUB_WIDTH = 180
local HUB_HEIGHT = 180
local PANEL_WIDTH = 420
local PANEL_HEIGHT = 600
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 6
local TAB_HEIGHT = 26
local CHECKBOX_SPACING = 28

local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- ============================================================================
-- FRAME VISIBILITY CONFIGURATION
-- ============================================================================

-- Frame definitions with categories
local VISIBILITY_FRAMES = {
    -- Combat category
    buffs = {
        frames = {"BuffFrame"},
        label = "Buffs",
        category = "combat",
        description = "Player buff icons",
    },
    debuffs = {
        frames = {"DebuffFrame"},
        label = "Debuffs",
        category = "combat",
        description = "Player debuff icons",
    },
    extraAction = {
        frames = {"ExtraActionBarFrame", "ZoneAbilityFrame"},
        label = "Extra Action",
        category = "combat",
        description = "Special ability buttons",
    },
    -- Information category
    questTracker = {
        frames = {"ObjectiveTrackerFrame"},
        label = "Quest Tracker",
        category = "information",
        description = "Quest/objective tracker",
    },
    zoneText = {
        frames = {"ZoneTextFrame", "SubZoneTextFrame"},
        label = "Zone Text",
        category = "information",
        description = "Zone name display on area change",
    },
    errorText = {
        frames = {"UIErrorsFrame"},
        label = "Errors",
        category = "information",
        description = "Red error text messages",
    },
    -- Navigation category
    minimap = {
        frames = {"MinimapCluster"},
        label = "Minimap",
        category = "navigation",
        description = "Minimap and surrounding elements",
    },
    bagsBar = {
        frames = {"BagsBar"},
        label = "Bags Bar",
        category = "navigation",
        description = "Bag slot buttons",
    },
    menuBar = {
        frames = {"MicroMenuContainer"},
        label = "Menu Bar",
        category = "navigation",
        description = "Character, spellbook, and other menu buttons",
    },
    -- Indicators category
    durability = {
        frames = {"DurabilityFrame"},
        label = "Durability",
        category = "indicators",
        description = "Armor damage indicator",
    },
    vehicleSeat = {
        frames = {"VehicleSeatIndicator"},
        label = "Vehicle Seat",
        category = "indicators",
        description = "Vehicle seat switcher",
    },
    orderHall = {
        frames = {"OrderHallCommandBar"},
        label = "Order Hall",
        category = "indicators",
        description = "Legion class hall command bar",
    },
    statusBars = {
        frames = {"StatusTrackingBarManager"},
        label = "XP/Rep Bars",
        category = "indicators",
        description = "Experience, reputation, and honor bars",
    },
    -- Popups category
    alerts = {
        frames = {"AlertFrame"},
        label = "Alerts",
        category = "popups",
        description = "Achievement and loot alert popups",
    },
    talkingHead = {
        frames = {"TalkingHeadFrame"},
        label = "Talking Head",
        category = "popups",
        description = "NPC dialogue popups",
    },
    tutorials = {
        frames = {"TutorialFrame", "HelpPlate", "HelpPlateTooltip"},
        label = "Tutorials",
        category = "popups",
        description = "Tutorial hints and highlights",
    },
}

-- Category display order
local CATEGORIES = {
    { key = "combat", label = "Combat" },
    { key = "information", label = "Information" },
    { key = "navigation", label = "Navigation" },
    { key = "indicators", label = "Indicators" },
    { key = "popups", label = "Popups" },
}

-- Default visibility settings for each frame
local function GetDefaultVisibilitySettings()
    return {
        hide = false,                -- Master hide toggle
        visibilityEnabled = false,   -- Use visibility conditions
        inCombat = true,
        outOfCombat = true,
        hasTarget = true,
        noTarget = true,
        solo = true,
        inParty = true,
        inRaid = true,
        inInstance = true,
        onMouseover = false,         -- Show on mouseover (always interactable)
        -- Fade settings
        fadeEnabled = false,
        fadeDelay = 3,
        fadeAlpha = 0.5,
    }
end

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

local DEFAULTS = {
    -- General Settings (QoL)
    autoRepair = false,
    autoRepairGuild = false,  -- Use guild funds first when available
    autoSellJunk = false,
    hideMinimapButton = false,
    
    -- Visibility settings per frame (populated dynamically)
    visibility = {},
    
    -- AFK Mode
    afkModeEnabled = false,
    afkFadeAnimation = true,
    afkFadeDuration = 0.5,
    afkKeepMinimap = false,
    afkKeepChat = false,
    afkCameraSpin = false,
    afkCameraSpinSpeed = 0.05,
    afkHideNameplates = true,
    
    -- Minimap Customization
    minimapSettings = {
        squareShape = false,
        scale = 1.0,
        -- Custom border for square minimap
        customBorder = {
            color = { r = 0.4, g = 0.4, b = 0.4 },  -- Grey default
            width = 2,
        },
        -- Button collector
        buttonCollector = {
            enabled = false,
        },
        hide = {
            zoomButtons = false,
            border = false,
            calendar = false,
            tracking = false,
            mail = false,
            craftingOrder = false,
            instanceDifficulty = false,
            clock = false,
            expansionButton = false,
            zoneText = false,
            zoneTextBackground = false,
        },
    },
}

-- Initialize default visibility settings for each frame
for key, _ in pairs(VISIBILITY_FRAMES) do
    DEFAULTS.visibility[key] = GetDefaultVisibilitySettings()
end

-- ============================================================================
-- STATE
-- ============================================================================

local settings = nil
local generalHub = nil
local generalPanel = nil
local visibilityPanel = nil
local visibilityCategoryPanels = {}  -- Store category panels (combat, information, interface)
local afkPanel = nil
local minimapPanel = nil  -- Minimap customization panel
local currentVisibilityItemPanel = nil
local minimapButton = nil
local isInAFKMode = false
local isTestingAFK = false
local storedFrameStates = {}
local storedModuleFrameStates = {}  -- Track module-managed frames separately
local pendingVisibilityChanges = {}
local storedNameplateStates = {}
local storedActionBarStates = {}
local visibilityUpdateFrame = nil
local fadeTimers = {}
local storedOnShowScripts = {}  -- Store original OnShow scripts during AFK

-- Track which frames WE have hidden and their current visibility state
local hiddenByUs = {}
local currentVisibilityState = {}  -- true = visible, false = hidden

-- Mouseover detection
local mouseoverHitFrames = {}      -- Hit test frames for mouseover detection
local mouseoverState = {}          -- Track which frames are currently moused over

-- Leatrix Plus conflict tracking
local leatrixConflicts = nil

-- Custom minimap border frame
local customMinimapBorder = nil

-- Button collector state
local buttonDrawer = nil
local collectedButtons = {}
local originalButtonPositions = {}

-- ============================================================================
-- LEATRIX PLUS DETECTION
-- ============================================================================

-- Check if Leatrix Plus is loaded
local function IsLeatrixPlusLoaded()
    return C_AddOns.IsAddOnLoaded("Leatrix_Plus")
end

-- Check for Leatrix Plus feature conflicts
function General:CheckLeatrixConflicts()
    leatrixConflicts = nil
    
    if not IsLeatrixPlusLoaded() then
        return nil
    end
    
    local db = LeaPlusDB
    if not db then return nil end
    
    local conflicts = {}
    
    -- QoL features
    if db["AutoRepairGear"] == "On" then
        conflicts.autoRepair = true
    end
    if db["AutoSellJunk"] == "On" then
        conflicts.autoSellJunk = true
    end
    
    -- Minimap features
    if db["SquareMinimap"] == "On" then
        conflicts.squareMinimap = true
    end
    if db["MinimapModder"] == "On" then
        conflicts.minimapModder = true  -- General minimap modifications
        conflicts.decorations = true     -- Decorations are part of MinimapModder
    end
    if db["HideMiniAddonMenu"] == "On" then
        conflicts.buttonCollector = true
    end
    if db["MinimapNoScale"] == "On" then
        conflicts.minimapScale = true
    end
    
    -- Only store if we found conflicts
    if next(conflicts) then
        leatrixConflicts = conflicts
        TweaksUI:PrintDebug("General: Leatrix Plus conflicts detected:", conflicts)
    end
    
    return conflicts
end

-- Check if Leatrix is managing a specific feature
function General:IsLeatrixManaging(feature)
    if not leatrixConflicts then return false end
    return leatrixConflicts[feature] == true
end

-- Get all current Leatrix conflicts (for UI display)
function General:GetLeatrixConflicts()
    return leatrixConflicts
end

-- Check if Leatrix Plus is loaded (public accessor)
function General:IsLeatrixPlusLoaded()
    return IsLeatrixPlusLoaded()
end

-- ============================================================================
-- SETTINGS ACCESS
-- ============================================================================

function General:GetSettings()
    return settings
end

function General:GetSetting(key)
    if settings and settings[key] ~= nil then
        return settings[key]
    end
    return DEFAULTS[key]
end

function General:SetSetting(key, value)
    if settings then
        settings[key] = value
    end
end

function General:GetVisibilitySetting(frameKey, settingKey)
    if settings and settings.visibility and settings.visibility[frameKey] then
        local val = settings.visibility[frameKey][settingKey]
        if val ~= nil then return val end
    end
    if DEFAULTS.visibility[frameKey] then
        return DEFAULTS.visibility[frameKey][settingKey]
    end
    return nil
end

function General:SetVisibilitySetting(frameKey, settingKey, value)
    if settings then
        settings.visibility = settings.visibility or {}
        settings.visibility[frameKey] = settings.visibility[frameKey] or GetDefaultVisibilitySettings()
        settings.visibility[frameKey][settingKey] = value
    end
end

-- ============================================================================
-- VISIBILITY CONDITION CHECKER
-- ============================================================================

local function ShouldFrameBeVisible(frameKey)
    local vs = settings and settings.visibility and settings.visibility[frameKey]
    if not vs then return true end  -- No settings = visible
    
    -- Master hide toggle
    if vs.hide then return false end
    
    -- If visibility conditions not enabled, frame is visible
    if not vs.visibilityEnabled then return true end
    
    -- Check if currently moused over (always show if mouseover enabled and hovering)
    if vs.onMouseover and mouseoverState[frameKey] then
        return true
    end
    
    -- Check all conditions (OR logic - any true condition shows the frame)
    local shouldShow = false
    
    -- Combat conditions
    local inCombat = UnitAffectingCombat("player")
    if vs.inCombat and inCombat then shouldShow = true end
    if vs.outOfCombat and not inCombat then shouldShow = true end
    
    -- Target conditions
    local hasTarget = UnitExists("target")
    if vs.hasTarget and hasTarget then shouldShow = true end
    if vs.noTarget and not hasTarget then shouldShow = true end
    
    -- Group conditions
    local inGroup = IsInGroup()
    local inRaid = IsInRaid()
    local inInstance, instanceType = IsInInstance()
    local inDungeon = inInstance and (instanceType == "party" or instanceType == "raid")
    
    if vs.solo and not inGroup then shouldShow = true end
    if vs.inParty and inGroup and not inRaid then shouldShow = true end
    if vs.inRaid and inRaid then shouldShow = true end
    if vs.inInstance and inDungeon then shouldShow = true end
    
    return shouldShow
end

-- ============================================================================
-- FRAME HIDING/SHOWING METHODS
-- ============================================================================

local function SafeHideFrame(frame)
    if not frame then return false end
    
    -- Check if it's actually a frame with required methods
    if type(frame.IsProtected) ~= "function" then return false end
    
    local success = pcall(function()
        if frame:IsProtected() and InCombatLockdown() then
            pendingVisibilityChanges[frame] = "hide"
            return
        end
        frame:Hide()
    end)
    
    if not success then
        pcall(function()
            frame:SetAlpha(0)
        end)
    end
    
    return success
end

-- Frames that should never be shown by us (Blizzard bugs or managed internally)
local SHOW_BLACKLIST = {
    ["TutorialFrame"] = true,
    ["HelpPlate"] = true,
    ["HelpPlateTooltip"] = true,
    ["ZoneTextFrame"] = true,      -- Has own fade system
    ["SubZoneTextFrame"] = true,   -- Has own fade system
}

local function SafeShowFrame(frame)
    if not frame then return false end
    
    -- Check if it's actually a frame with GetName method
    if type(frame.GetName) ~= "function" then return false end
    
    -- Check blacklist
    local frameName = frame:GetName()
    if frameName and SHOW_BLACKLIST[frameName] then
        return false  -- Never show these frames
    end
    
    local success = pcall(function()
        if frame:IsProtected() and InCombatLockdown() then
            pendingVisibilityChanges[frame] = "show"
            return
        end
        frame:Show()
        frame:SetAlpha(1)
    end)
    
    return success
end

local function SetFrameAlpha(frame, alpha)
    if not frame then return end
    pcall(function()
        frame:SetAlpha(alpha)
    end)
end

-- ============================================================================
-- VISIBILITY CONTROL
-- ============================================================================

function General:ApplyFrameVisibility(frameKey, instant)
    -- Don't apply visibility during AFK mode - AFK overrides everything
    if isInAFKMode then return end
    
    local info = VISIBILITY_FRAMES[frameKey]
    if not info then return end
    
    local shouldShow = ShouldFrameBeVisible(frameKey)
    local vs = settings and settings.visibility and settings.visibility[frameKey]
    
    -- Track state change
    local wasVisible = currentVisibilityState[frameKey]
    currentVisibilityState[frameKey] = shouldShow
    
    for _, frameName in ipairs(info.frames) do
        local frame = _G[frameName]
        if frame then
            if shouldShow then
                -- Cancel any pending fade
                if fadeTimers[frameKey] then
                    fadeTimers[frameKey]:Cancel()
                    fadeTimers[frameKey] = nil
                end
                
                SafeShowFrame(frame)
                hiddenByUs[frameName] = nil
            else
                SafeHideFrame(frame)
                hiddenByUs[frameName] = true
            end
        end
    end
    
    -- Handle fade if enabled and frame is visible
    if shouldShow and vs and vs.fadeEnabled and vs.fadeDelay and vs.fadeAlpha then
        self:StartFadeTimer(frameKey, vs.fadeDelay, vs.fadeAlpha)
    end
end

function General:StartFadeTimer(frameKey, delay, targetAlpha)
    -- Cancel existing timer
    if fadeTimers[frameKey] then
        fadeTimers[frameKey]:Cancel()
    end
    
    local info = VISIBILITY_FRAMES[frameKey]
    if not info then return end
    
    fadeTimers[frameKey] = C_Timer.NewTimer(delay, function()
        if isInAFKMode then return end  -- Don't fade during AFK
        
        for _, frameName in ipairs(info.frames) do
            local frame = _G[frameName]
            if frame and frame:IsShown() then
                SetFrameAlpha(frame, targetAlpha)
            end
        end
        fadeTimers[frameKey] = nil
    end)
end

function General:ResetFade(frameKey)
    -- Cancel timer and restore alpha
    if fadeTimers[frameKey] then
        fadeTimers[frameKey]:Cancel()
        fadeTimers[frameKey] = nil
    end
    
    local info = VISIBILITY_FRAMES[frameKey]
    if not info then return end
    
    for _, frameName in ipairs(info.frames) do
        local frame = _G[frameName]
        if frame then
            SetFrameAlpha(frame, 1)
        end
    end
end

function General:ApplyAllVisibility()
    if isInAFKMode then return end
    
    for frameKey, _ in pairs(VISIBILITY_FRAMES) do
        self:ApplyFrameVisibility(frameKey, false)
    end
end

function General:ProcessPendingChanges()
    if InCombatLockdown() then return end
    
    for frame, action in pairs(pendingVisibilityChanges) do
        if action == "hide" then
            SafeHideFrame(frame)
        else
            SafeShowFrame(frame)
        end
    end
    
    pendingVisibilityChanges = {}
end

-- ============================================================================
-- MOUSEOVER HIT FRAME SYSTEM
-- ============================================================================

-- Check if mouse is over a frame or any of its children (recursive)
local function IsMouseOverFrameOrChildren(frame)
    if not frame then return false end
    
    -- Check the frame itself
    if frame:IsMouseOver() then return true end
    
    -- Check all children recursively
    local children = {frame:GetChildren()}
    for _, child in ipairs(children) do
        if child:IsVisible() and IsMouseOverFrameOrChildren(child) then
            return true
        end
    end
    
    return false
end

-- Check if mouse is over any of the frames for a given frameKey
local function IsMouseOverAnyFrame(frameKey)
    local info = VISIBILITY_FRAMES[frameKey]
    if not info then return false end
    
    for _, frameName in ipairs(info.frames) do
        local frame = _G[frameName]
        if frame and frame:IsVisible() and IsMouseOverFrameOrChildren(frame) then
            return true
        end
    end
    
    return false
end

-- Create a transparent hit frame for mouseover detection
local function CreateMouseoverHitFrame(frameKey)
    if mouseoverHitFrames[frameKey] then return end
    
    local info = VISIBILITY_FRAMES[frameKey]
    if not info or not info.frames or #info.frames == 0 then return end
    
    -- Get the first frame as the anchor
    local targetFrame = _G[info.frames[1]]
    if not targetFrame then return end
    
    local hitFrame = CreateFrame("Frame", "TweaksUI_MouseoverHit_" .. frameKey, UIParent)
    hitFrame:SetFrameStrata("BACKGROUND")
    hitFrame:SetFrameLevel(0)
    hitFrame.frameKey = frameKey
    hitFrame.isMouseOverTarget = false  -- Track if mouse is over the actual target
    
    -- Update position to match target frame
    local function UpdateHitFramePosition()
        if not targetFrame:IsShown() and not mouseoverHitFrames[frameKey] then return end
        
        -- Match the target frame's position and size
        hitFrame:ClearAllPoints()
        hitFrame:SetPoint("TOPLEFT", targetFrame, "TOPLEFT", 0, 0)
        hitFrame:SetPoint("BOTTOMRIGHT", targetFrame, "BOTTOMRIGHT", 0, 0)
        
        -- If the frame is hidden, we need a fallback size
        local width, height = targetFrame:GetSize()
        if width < 1 then width = 100 end
        if height < 1 then height = 50 end
        hitFrame:SetSize(width, height)
    end
    
    -- Update position and check for mouseover state
    hitFrame:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        if self.elapsed > 0.05 then  -- Check every 50ms
            self.elapsed = 0
            UpdateHitFramePosition()
            
            -- Check if mouse is over the actual target frame(s) or their children
            local isOverTarget = IsMouseOverAnyFrame(frameKey)
            local isOverHitFrame = self:IsMouseOver()
            local wasOver = mouseoverState[frameKey]
            
            if isOverTarget or isOverHitFrame then
                -- Mouse is over target or hit frame - keep visible
                if not wasOver then
                    mouseoverState[frameKey] = true
                    General:ResetFade(frameKey)
                end
            else
                -- Mouse has left both target and hit frame - trigger hide
                if wasOver then
                    mouseoverState[frameKey] = false
                    General:ApplyFrameVisibility(frameKey, true)
                end
            end
        end
    end)
    
    hitFrame:SetScript("OnEnter", function(self)
        -- Immediate show when entering hit frame
        mouseoverState[frameKey] = true
        General:ApplyFrameVisibility(frameKey, true)
        General:ResetFade(frameKey)
    end)
    
    -- OnLeave is handled by OnUpdate polling - no need for timer here
    hitFrame:SetScript("OnLeave", nil)
    
    hitFrame:EnableMouse(true)
    hitFrame:SetMouseClickEnabled(false)  -- Allow mouseover detection but don't block clicks
    hitFrame:Show()
    
    mouseoverHitFrames[frameKey] = hitFrame
    
    -- Hook the actual frame(s) for immediate response when entering them directly
    for _, frameName in ipairs(info.frames) do
        local frame = _G[frameName]
        if frame and not frame.tweaksMouseoverHooked then
            frame:HookScript("OnEnter", function()
                mouseoverState[frameKey] = true
            end)
            -- OnLeave handled by OnUpdate polling
            frame.tweaksMouseoverHooked = true
        end
    end
end

-- Remove hit frame
local function RemoveMouseoverHitFrame(frameKey)
    if mouseoverHitFrames[frameKey] then
        mouseoverHitFrames[frameKey]:Hide()
        mouseoverHitFrames[frameKey]:SetScript("OnUpdate", nil)
        mouseoverHitFrames[frameKey] = nil
    end
    mouseoverState[frameKey] = nil
end

-- Update mouseover hit frames based on settings
function General:UpdateMouseoverHitFrames()
    for frameKey, info in pairs(VISIBILITY_FRAMES) do
        local vs = settings and settings.visibility and settings.visibility[frameKey]
        if vs and vs.visibilityEnabled and vs.onMouseover then
            CreateMouseoverHitFrame(frameKey)
        else
            RemoveMouseoverHitFrame(frameKey)
        end
    end
end

-- ============================================================================
-- VISIBILITY UPDATE LOOP
-- ============================================================================

function General:SetupVisibilityUpdater()
    if visibilityUpdateFrame then return end
    
    visibilityUpdateFrame = CreateFrame("Frame")
    visibilityUpdateFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    visibilityUpdateFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    visibilityUpdateFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    visibilityUpdateFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    visibilityUpdateFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    visibilityUpdateFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    
    visibilityUpdateFrame:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_REGEN_ENABLED" then
            General:ProcessPendingChanges()
        end
        -- Update all visibility on relevant events
        C_Timer.After(0.1, function()
            General:ApplyAllVisibility()
        end)
    end)
end

-- ============================================================================
-- AFK MODE
-- ============================================================================

local AFK_SAFE_FRAMES = {
    "Boss1TargetFrame", "Boss2TargetFrame", "Boss3TargetFrame",
    "Boss4TargetFrame", "Boss5TargetFrame",
    "BuffFrame", "DebuffFrame",
    "ObjectiveTrackerFrame", "ExtraActionBarFrame", "ZoneAbilityFrame",
    "StatusTrackingBarManager", "UIErrorsFrame", "DurabilityFrame",
    "MicroMenuContainer", "BagsBar",
    -- Note: Cooldown viewers are module-managed, not listed here
}

local AFK_OPTIONAL_FRAMES = {
    minimap = {"MinimapCluster", "Minimap"},
    chat = {"TweaksUIChatFrame"},
}

local function IsModuleEnabled(moduleId)
    if TweaksUI.ModuleManager then
        local module = TweaksUI.ModuleManager:GetModule(moduleId)
        return module and module.enabled
    end
    return false
end

local function StoreActionBarStates()
    storedActionBarStates = {}
    
    local barFrames = {
        "MainMenuBar", "MultiBarBottomLeft", "MultiBarBottomRight",
        "MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6", "MultiBar7",
        "StanceBar", "PossessActionBar", "PetActionBar",
    }
    
    for _, frameName in ipairs(barFrames) do
        local frame = _G[frameName]
        if frame then
            storedActionBarStates[frameName] = {
                shown = frame:IsShown(),
                alpha = frame:GetAlpha(),
            }
        end
    end
end

local function RestoreActionBarStates()
    for frameName, state in pairs(storedActionBarStates) do
        local frame = _G[frameName]
        if frame and state.shown then
            pcall(function()
                frame:Show()
                frame:SetAlpha(state.alpha or 1)
            end)
        end
    end
    
    local actionBars = TweaksUI.ModuleManager and TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.ACTION_BARS)
    if actionBars and actionBars.enabled and actionBars.Refresh then
        pcall(function() actionBars:Refresh() end)
    end
    
    storedActionBarStates = {}
end

function General:EnterAFKMode(isTest)
    if isInAFKMode then return end
    if not isTest and not self:GetSetting("afkModeEnabled") then return end
    
    isInAFKMode = true
    isTestingAFK = isTest or false
    storedFrameStates = {}
    storedModuleFrameStates = {}
    
    -- Cancel all fade timers
    for frameKey, timer in pairs(fadeTimers) do
        timer:Cancel()
        fadeTimers[frameKey] = nil
    end
    
    local fadeDuration = self:GetSetting("afkFadeAnimation") and self:GetSetting("afkFadeDuration") or 0
    
    StoreActionBarStates()
    
    -- Frames managed by modules - store separately, restore only if they were visible
    local MODULE_MANAGED_FRAMES = {
        -- Cooldowns
        ["EssentialCooldownViewer"] = true,
        ["UtilityCooldownViewer"] = true,
        ["BuffIconCooldownViewer"] = true,
        -- ResourceBars
        ["TweaksUI_ResourceBars_PowerBar"] = true,
        ["TweaksUI_ResourceBars_ClassPower"] = true,
        ["TweaksUI_ResourceBars_SoulFragments"] = true,
        -- TweaksUI Unit Frames (actual display frames, not settings panels)
        ["TweaksUI_UF_player"] = true,
        ["TweaksUI_UF_target"] = true,
        ["TweaksUI_UF_focus"] = true,
        ["TweaksUI_UF_pet"] = true,
        ["TweaksUI_UF_targettarget"] = true,
        ["TweaksUI_PartyContainer"] = true,
        ["TweaksUI_TankContainer"] = true,
        ["TweaksUI_BossContainer"] = true,
    }
    
    local function HideFrameForAFK(frame, shouldStore)
        if not frame then return end
        
        -- Check if it's actually a frame
        if type(frame.GetName) ~= "function" then return end
        
        local frameName = frame:GetName()
        
        -- Check if frame is ACTUALLY visible (shown AND has alpha)
        local wasShown = false
        local currentAlpha = 0
        pcall(function()
            currentAlpha = frame:GetAlpha() or 0
            wasShown = frame:IsShown() and (currentAlpha > 0.01)
        end)
        
        -- Store module-managed frames separately
        local isModuleManaged = frameName and MODULE_MANAGED_FRAMES[frameName]
        
        if isModuleManaged and wasShown then
            -- Store in separate table - we'll restore these based on their pre-AFK state
            storedModuleFrameStates[frameName] = {
                shown = true,
                alpha = currentAlpha,
            }
        elseif shouldStore and frameName and wasShown then
            storedFrameStates[frameName] = {
                shown = true,
                alpha = currentAlpha,
            }
        end
        
        -- Skip frames that aren't actually visible
        if not wasShown then return end
        
        -- Skip fade animation for blacklisted frames (UIFrameFadeOut calls Show() internally)
        local skipFade = frameName and SHOW_BLACKLIST[frameName]
        
        if fadeDuration > 0 and not skipFade then
            UIFrameFadeOut(frame, fadeDuration, currentAlpha, 0)
            C_Timer.After(fadeDuration, function()
                if isInAFKMode and frame then
                    pcall(function() frame:Hide() end)
                end
            end)
        else
            pcall(function() frame:Hide() end)
        end
    end
    
    -- Hide all visibility-controlled frames (even if they have "has target" etc.)
    for frameKey, info in pairs(VISIBILITY_FRAMES) do
        for _, frameName in ipairs(info.frames) do
            local frame = _G[frameName]
            if frame then
                HideFrameForAFK(frame, true)
            end
        end
    end
    
    -- Hide safe frames
    for _, frameName in ipairs(AFK_SAFE_FRAMES) do
        local frame = _G[frameName]
        if frame then HideFrameForAFK(frame, true) end
    end
    
    -- Frames that need OnShow hooks to prevent auto-showing during AFK
    -- (These modules have update functions that call Show())
    local hookFrameNames = {
        "EssentialCooldownViewer", "UtilityCooldownViewer", "BuffIconCooldownViewer",
        "TweaksUI_ResourceBars_PowerBar", "TweaksUI_ResourceBars_ClassPower", 
        "TweaksUI_ResourceBars_SoulFragments",
    }
    
    for _, frameName in ipairs(hookFrameNames) do
        local frame = _G[frameName]
        if frame then
            -- Store if visible before hiding
            local wasShown = false
            pcall(function()
                wasShown = frame:IsShown() and (frame:GetAlpha() > 0.01)
            end)
            if wasShown then
                storedModuleFrameStates[frameName] = { shown = true, alpha = frame:GetAlpha() or 1 }
            end
            
            -- Store original OnShow script and hook to prevent showing
            storedOnShowScripts[frameName] = frame:GetScript("OnShow")
            frame:SetScript("OnShow", function(self)
                if isInAFKMode then
                    self:Hide()
                elseif storedOnShowScripts[frameName] then
                    storedOnShowScripts[frameName](self)
                end
            end)
            
            -- Now hide the frame
            HideFrameForAFK(frame, false)
        end
    end
    
    -- TweaksUI Unit Frames use state drivers - we need to override them
    local unitFrameNames = {
        "TweaksUI_UF_player", "TweaksUI_UF_target",
        "TweaksUI_UF_focus", "TweaksUI_UF_pet", "TweaksUI_UF_targettarget",
    }
    for _, frameName in ipairs(unitFrameNames) do
        local frame = _G[frameName]
        if frame then
            -- Store if visible
            local wasShown = false
            pcall(function()
                wasShown = frame:IsShown() and (frame:GetAlpha() > 0.01)
            end)
            if wasShown then
                storedModuleFrameStates[frameName] = { shown = true, alpha = frame:GetAlpha() or 1 }
            end
            -- Override state driver to force hide
            pcall(function()
                RegisterStateDriver(frame, "visibility", "hide")
            end)
        end
    end
    
    -- Group containers don't have state drivers, just hide them
    local groupContainers = { "TweaksUI_PartyContainer", "TweaksUI_TankContainer", "TweaksUI_BossContainer" }
    for _, frameName in ipairs(groupContainers) do
        local frame = _G[frameName]
        if frame then HideFrameForAFK(frame, false) end
    end
    
    -- Always hide Blizzard unit frames during AFK (they may still show through)
    local blizzardUnitFrames = {
        "PlayerFrame", "TargetFrame", "FocusFrame", "PetFrame",
        "TargetFrameToT", "FocusFrameToT",
    }
    for _, frameName in ipairs(blizzardUnitFrames) do
        local frame = _G[frameName]
        if frame then HideFrameForAFK(frame, true) end
    end
    
    -- Hide action bars
    local actionBarFrames = {
        "MainMenuBar", "MultiBarBottomLeft", "MultiBarBottomRight",
        "MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6", "MultiBar7",
        "StanceBar", "PossessActionBar", "PetActionBar",
    }
    for _, frameName in ipairs(actionBarFrames) do
        local frame = _G[frameName]
        if frame then HideFrameForAFK(frame, false) end
    end
    
    -- Hide Blizzard chat frames
    local chatFrames = {"ChatFrame1", "ChatFrame2", "ChatFrame3", "GeneralDockManager"}
    for _, frameName in ipairs(chatFrames) do
        local frame = _G[frameName]
        if frame then HideFrameForAFK(frame, false) end
    end
    
    -- Optional frames
    if not self:GetSetting("afkKeepMinimap") then
        for _, frameName in ipairs(AFK_OPTIONAL_FRAMES.minimap) do
            local frame = _G[frameName]
            if frame then HideFrameForAFK(frame, true) end
        end
    end
    
    if not self:GetSetting("afkKeepChat") then
        for _, frameName in ipairs(AFK_OPTIONAL_FRAMES.chat) do
            local frame = _G[frameName]
            if frame then HideFrameForAFK(frame, false) end  -- Don't store - Chat module restores
        end
    end
    
    -- Camera spin
    if self:GetSetting("afkCameraSpin") then
        local spinSpeed = self:GetSetting("afkCameraSpinSpeed") or 0.05
        MoveViewRightStart(spinSpeed)
    end
    
    -- Hide nameplates
    if self:GetSetting("afkHideNameplates") then
        storedNameplateStates = {
            nameplateShowAll = GetCVar("nameplateShowAll"),
            nameplateShowEnemies = GetCVar("nameplateShowEnemies"),
            nameplateShowFriends = GetCVar("nameplateShowFriends"),
            nameplateShowFriendlyNPCs = GetCVar("nameplateShowFriendlyNPCs"),
        }
        SetCVar("nameplateShowAll", 0)
        SetCVar("nameplateShowEnemies", 0)
        SetCVar("nameplateShowFriends", 0)
        SetCVar("nameplateShowFriendlyNPCs", 0)
    end
    
    TweaksUI:PrintDebug("General: Entered AFK mode" .. (isTest and " (test)" or ""))
end

function General:ExitAFKMode()
    if not isInAFKMode then return end
    
    isInAFKMode = false
    local wasTest = isTestingAFK
    isTestingAFK = false
    
    local fadeDuration = self:GetSetting("afkFadeAnimation") and self:GetSetting("afkFadeDuration") or 0
    
    -- Restore OnShow scripts first (isInAFKMode is now false so hook will pass through)
    for frameName, originalScript in pairs(storedOnShowScripts) do
        local frame = _G[frameName]
        if frame then
            pcall(function()
                frame:SetScript("OnShow", originalScript)
            end)
        end
    end
    storedOnShowScripts = {}
    
    -- Stop camera spin
    MoveViewRightStop()
    MoveViewLeftStop()
    
    -- Restore nameplates
    if storedNameplateStates and next(storedNameplateStates) then
        for cvar, value in pairs(storedNameplateStates) do
            pcall(function() SetCVar(cvar, value) end)
        end
        storedNameplateStates = {}
    end
    
    -- Restore stored frames (skip blacklisted frames)
    for frameName, state in pairs(storedFrameStates) do
        if state.shown and not SHOW_BLACKLIST[frameName] then
            local frame = _G[frameName]
            if frame then
                pcall(function()
                    frame:Show()
                    if fadeDuration > 0 then
                        frame:SetAlpha(0)
                        UIFrameFadeIn(frame, fadeDuration, 0, state.alpha or 1)
                    else
                        frame:SetAlpha(state.alpha or 1)
                    end
                end)
            end
        end
    end
    
    storedFrameStates = {}
    
    -- Re-apply visibility conditions (this will hide/show based on current conditions)
    C_Timer.After(0.1, function()
        General:ApplyAllVisibility()
    end)
    
    -- Restore TweaksUI UnitFrames state drivers and refresh
    C_Timer.After(0.15, function()
        local unitFrames = TweaksUI.ModuleManager and TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.UNIT_FRAMES)
        if unitFrames and unitFrames.enabled then
            -- Re-register state drivers with proper conditions
            local unitStateConditions = {
                ["TweaksUI_UF_player"] = "show",
                ["TweaksUI_UF_target"] = "[@target,exists] show; hide",
                ["TweaksUI_UF_focus"] = "[@focus,exists] show; hide", 
                ["TweaksUI_UF_pet"] = "[@pet,exists] show; hide",
                ["TweaksUI_UF_targettarget"] = "[@target,exists] show; hide",
            }
            for frameName, condition in pairs(unitStateConditions) do
                local frame = _G[frameName]
                if frame then
                    pcall(function()
                        RegisterStateDriver(frame, "visibility", condition)
                    end)
                end
            end
            
            -- Refresh frame data
            if unitFrames.RefreshFrame then
                pcall(function() unitFrames:RefreshFrame("player") end)
                pcall(function() unitFrames:RefreshFrame("target") end)
                pcall(function() unitFrames:RefreshFrame("focus") end)
                pcall(function() unitFrames:RefreshFrame("pet") end)
                pcall(function() unitFrames:RefreshFrame("targettarget") end)
            end
        end
    end)
    
    -- Restore action bars
    C_Timer.After(0.2, function()
        RestoreActionBarStates()
    end)
    
    -- Restore chat
    C_Timer.After(0.25, function()
        local chat = TweaksUI.ModuleManager and TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.CHAT)
        if chat and chat.enabled and TweaksUIChatFrame then
            pcall(function() TweaksUIChatFrame:Show() end)
        end
    end)
    
    -- Notify Cooldowns module to update visibility based on current conditions
    -- Don't force-show module frames - let their visibility systems decide
    C_Timer.After(0.3, function()
        -- Tell Cooldowns module to refresh visibility
        local cooldowns = TweaksUI.ModuleManager and TweaksUI.ModuleManager:GetModule(TweaksUI.MODULE_IDS.COOLDOWNS)
        if cooldowns and cooldowns.UpdateAllVisibility then
            pcall(function() cooldowns:UpdateAllVisibility() end)
        end
        
        storedModuleFrameStates = {}
    end)
    
    -- Re-apply minimap settings (square shape auto-hides border, etc.)
    C_Timer.After(0.35, function()
        General:ApplyAllMinimapSettings()
    end)
    
    TweaksUI:PrintDebug("General: Exited AFK mode" .. (wasTest and " (test)" or ""))
end

function General:IsInAFKMode()
    return isInAFKMode
end

function General:IsTestingAFK()
    return isTestingAFK
end

function General:SetupAFKMode()
    local eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("PLAYER_FLAGS_CHANGED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    
    eventFrame:SetScript("OnEvent", function(self, event, unit)
        if event == "PLAYER_FLAGS_CHANGED" then
            if unit == "player" or unit == nil then
                if UnitIsAFK("player") then
                    General:EnterAFKMode(false)
                else
                    if not isTestingAFK then
                        General:ExitAFKMode()
                    end
                end
            end
        elseif event == "PLAYER_REGEN_ENABLED" then
            General:ProcessPendingChanges()
        end
    end)
end

-- ============================================================================
-- AUTO REPAIR & AUTO SELL JUNK
-- ============================================================================

-- Perform auto repair
function General:DoAutoRepair()
    -- Check if merchant can repair
    if not CanMerchantRepair() then return end
    
    -- Get repair cost
    local repairCost, canRepair = GetRepairAllCost()
    if not canRepair or repairCost <= 0 then return end
    
    -- Check for guild repair option
    local useGuild = self:GetSetting("autoRepairGuild") and IsInGuild() and CanGuildBankRepair()
    
    if useGuild then
        local guildMoney = GetGuildBankWithdrawMoney()
        -- guildMoney == -1 means unlimited withdrawal
        if guildMoney == -1 or guildMoney >= repairCost then
            RepairAllItems(true)  -- true = use guild funds
            TweaksUI:Print(string.format("|cff00ff00Repaired|r (Guild): %s", GetCoinTextureString(repairCost)))
            return
        end
    end
    
    -- Use personal funds
    if GetMoney() >= repairCost then
        RepairAllItems(false)
        TweaksUI:Print(string.format("|cff00ff00Repaired|r: %s", GetCoinTextureString(repairCost)))
    else
        TweaksUI:Print("|cffff6666Not enough gold to repair!|r")
    end
end

-- Perform auto sell junk
function General:DoAutoSellJunk()
    local totalValue = 0
    local itemsSold = 0
    
    for bag = 0, NUM_BAG_SLOTS do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.quality == Enum.ItemQuality.Poor and not info.isLocked then
                -- Get vendor price
                local itemInfo = {GetItemInfo(info.itemID)}
                local vendorPrice = itemInfo[11] or 0
                
                if vendorPrice > 0 then
                    totalValue = totalValue + (vendorPrice * info.stackCount)
                    itemsSold = itemsSold + 1
                    C_Container.UseContainerItem(bag, slot)
                end
            end
        end
    end
    
    if itemsSold > 0 then
        TweaksUI:Print(string.format("|cff00ff00Sold %d junk item(s)|r: %s", itemsSold, GetCoinTextureString(totalValue)))
    end
end

-- Setup merchant event handler
function General:SetupMerchantHandler()
    local frame = CreateFrame("Frame")
    frame:RegisterEvent("MERCHANT_SHOW")
    frame:SetScript("OnEvent", function()
        -- Auto repair first (if enabled and not managed by Leatrix)
        if General:GetSetting("autoRepair") and not General:IsLeatrixManaging("autoRepair") then
            General:DoAutoRepair()
        end
        
        -- Then sell junk with small delay (if enabled and not managed by Leatrix)
        if General:GetSetting("autoSellJunk") and not General:IsLeatrixManaging("autoSellJunk") then
            C_Timer.After(0.3, function()
                General:DoAutoSellJunk()
            end)
        end
    end)
    
    TweaksUI:PrintDebug("General: Merchant handler initialized")
end

-- ============================================================================
-- MINIMAP CUSTOMIZATION
-- ============================================================================

-- Get minimap setting with defaults
function General:GetMinimapSetting(key)
    if settings and settings.minimapSettings and settings.minimapSettings[key] ~= nil then
        return settings.minimapSettings[key]
    end
    return DEFAULTS.minimapSettings[key]
end

-- Get minimap hide setting
function General:GetMinimapHideSetting(key)
    if settings and settings.minimapSettings and settings.minimapSettings.hide and settings.minimapSettings.hide[key] ~= nil then
        return settings.minimapSettings.hide[key]
    end
    return DEFAULTS.minimapSettings.hide[key]
end

-- Set minimap setting
function General:SetMinimapSetting(key, value)
    if settings then
        settings.minimapSettings = settings.minimapSettings or {}
        settings.minimapSettings[key] = value
    end
end

-- Set minimap hide setting
function General:SetMinimapHideSetting(key, value)
    if settings then
        settings.minimapSettings = settings.minimapSettings or {}
        settings.minimapSettings.hide = settings.minimapSettings.hide or {}
        settings.minimapSettings.hide[key] = value
    end
end

-- Get custom border setting
function General:GetCustomBorderSetting(key)
    if settings and settings.minimapSettings and settings.minimapSettings.customBorder then
        return settings.minimapSettings.customBorder[key]
    end
    return DEFAULTS.minimapSettings.customBorder[key]
end

-- Set custom border setting
function General:SetCustomBorderSetting(key, value)
    if settings then
        settings.minimapSettings = settings.minimapSettings or {}
        settings.minimapSettings.customBorder = settings.minimapSettings.customBorder or {}
        settings.minimapSettings.customBorder[key] = value
    end
end

-- Create or update custom square minimap border
function General:CreateCustomMinimapBorder()
    if not customMinimapBorder then
        customMinimapBorder = CreateFrame("Frame", "TweaksUI_MinimapBorder", Minimap, "BackdropTemplate")
        customMinimapBorder:SetFrameStrata("BACKGROUND")
        customMinimapBorder:SetFrameLevel(Minimap:GetFrameLevel() + 1)
    end
    
    local width = self:GetCustomBorderSetting("width") or 2
    local color = self:GetCustomBorderSetting("color") or { r = 0.4, g = 0.4, b = 0.4 }
    
    -- Position around minimap
    customMinimapBorder:ClearAllPoints()
    customMinimapBorder:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -width, width)
    customMinimapBorder:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", width, -width)
    
    -- Set up border backdrop
    customMinimapBorder:SetBackdrop({
        edgeFile = "Interface\\BUTTONS\\WHITE8X8",
        edgeSize = width,
    })
    customMinimapBorder:SetBackdropBorderColor(color.r, color.g, color.b, 1)
    
    return customMinimapBorder
end

-- Update custom border appearance
function General:UpdateCustomMinimapBorder()
    if not customMinimapBorder then return end
    
    local width = self:GetCustomBorderSetting("width") or 2
    local color = self:GetCustomBorderSetting("color") or { r = 0.4, g = 0.4, b = 0.4 }
    
    -- Reposition for new width
    customMinimapBorder:ClearAllPoints()
    customMinimapBorder:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -width, width)
    customMinimapBorder:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", width, -width)
    
    -- Update backdrop
    customMinimapBorder:SetBackdrop({
        edgeFile = "Interface\\BUTTONS\\WHITE8X8",
        edgeSize = width,
    })
    customMinimapBorder:SetBackdropBorderColor(color.r, color.g, color.b, 1)
end

-- Apply square minimap shape
function General:ApplyMinimapShape()
    if self:IsLeatrixManaging("squareMinimap") then return end
    
    local isSquare = self:GetMinimapSetting("squareShape")
    local isRotating = GetCVar("rotateMinimap") == "1"
    
    -- Border frames to hide with square minimap
    local borderFrames = {"MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture"}
    
    if isSquare then
        if isRotating then
            -- Square minimap is incompatible with rotation - warn user once
            if not self.rotationWarningShown then
                print("|cff00ff00TweaksUI:|r Square minimap is incompatible with 'Rotate Minimap'. Disable rotation in Edit Mode for square minimap.")
                self.rotationWarningShown = true
            end
            -- Keep circular when rotating
            Minimap:SetMaskTexture("Interface\\Minimap\\UI-Minimap-Background")
            
            -- Hide custom border since we're circular
            if customMinimapBorder then
                customMinimapBorder:Hide()
            end
            
            -- Keep Blizzard border hidden if user has that setting
            if self:GetMinimapHideSetting("border") then
                for _, frameName in ipairs(borderFrames) do
                    local frame = _G[frameName]
                    if frame then
                        pcall(function()
                            frame:Hide()
                            frame:SetAlpha(0)
                        end)
                    end
                end
            end
        else
            -- NO ROTATION: Square mask works fine
            Minimap:SetMaskTexture("Interface\\BUTTONS\\WHITE8X8")
            self.rotationWarningShown = nil  -- Reset warning flag
            
            -- Auto-hide Blizzard border when using square shape
            for _, frameName in ipairs(borderFrames) do
                local frame = _G[frameName]
                if frame then
                    pcall(function()
                        frame:Hide()
                        frame:SetAlpha(0)
                    end)
                end
            end
            
            -- Show custom border if user hasn't hidden border option
            if not self:GetMinimapHideSetting("border") then
                self:CreateCustomMinimapBorder()
                customMinimapBorder:Show()
            else
                if customMinimapBorder then
                    customMinimapBorder:Hide()
                end
            end
        end
    else
        -- CIRCULAR MODE
        Minimap:SetMaskTexture("Interface\\Minimap\\UI-Minimap-Background")
        self.rotationWarningShown = nil  -- Reset warning flag
        
        -- Hide custom border when circular
        if customMinimapBorder then
            customMinimapBorder:Hide()
        end
        
        -- Only restore Blizzard border if user hasn't manually hidden it
        if not self:GetMinimapHideSetting("border") then
            for _, frameName in ipairs(borderFrames) do
                local frame = _G[frameName]
                if frame then
                    pcall(function()
                        frame:SetAlpha(1)
                        frame:Show()
                    end)
                end
            end
        end
    end
end

-- Monitor for rotation setting changes
function General:SetupRotationMonitor()
    local rotationFrame = CreateFrame("Frame")
    rotationFrame:RegisterEvent("CVAR_UPDATE")
    rotationFrame:SetScript("OnEvent", function(self, event, cvar)
        if cvar == "rotateMinimap" then
            -- Re-apply minimap shape when rotation setting changes
            C_Timer.After(0.1, function()
                General:ApplyMinimapShape()
            end)
        end
    end)
end

-- Apply minimap scale
function General:ApplyMinimapScale()
    if self:IsLeatrixManaging("minimapScale") then return end
    
    local scale = self:GetMinimapSetting("scale") or 1.0
    
    if MinimapCluster then
        MinimapCluster:SetScale(scale)
    end
end

-- Frame references for minimap decorations (supports both old and new WoW versions)
-- NOTE: mail and tracking have special handlers in ApplyDecorationSetting
-- Frame names from MinimapCluster children: BorderTop, InstanceDifficulty, Selection, 
-- MinimapContainer, IndicatorFrame, ZoneTextButton, Tracking
local MINIMAP_DECORATION_FRAMES = {
    zoomButtons = {"MinimapZoomIn", "MinimapZoomOut"},
    border = {"MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture"},
    calendar = {"GameTimeFrame"},
    tracking = {},  -- Handled by ApplyTrackingSetting (MinimapCluster.Tracking)
    mail = {},  -- Handled by ApplyMailSetting  
    craftingOrder = {"MiniMapCraftingOrderFrame"},
    instanceDifficulty = {"MiniMapInstanceDifficulty", "GuildInstanceDifficulty"},
    clock = {"TimeManagerClockButton"},
    expansionButton = {"ExpansionLandingPageMinimapButton"},
    zoneText = {},  -- Handled by ApplyZoneTextSetting (MinimapCluster.ZoneTextButton)
    zoneTextBackground = {},  -- Handled by ApplyZoneTextBackgroundSetting (MinimapCluster.BorderTop)
}

-- Store original states for decorations
local storedDecorationStates = {}

-- Get frame by name, supporting dot notation for nested frames and Background textures
local function GetMinimapFrame(frameName)
    -- Try direct global lookup first
    local frame = _G[frameName]
    if frame then return frame end
    
    -- Try dot notation (e.g., "MinimapCluster.TrackingFrame" or "MinimapCluster.ZoneTextButton.Background")
    if frameName:find("%.") then
        local parts = {strsplit(".", frameName)}
        frame = _G[parts[1]]
        for i = 2, #parts do
            if frame then
                -- Try as a key first (for child frames/tables)
                local child = frame[parts[i]]
                if child then
                    frame = child
                else
                    -- Try GetChildren for frames
                    if frame.GetChildren then
                        local children = {frame:GetChildren()}
                        for _, c in ipairs(children) do
                            if c.GetName and c:GetName() and c:GetName():find(parts[i]) then
                                frame = c
                                child = c
                                break
                            end
                        end
                    end
                    -- Also check regions (textures, fontstrings) for "Background"
                    if not child and frame.GetRegions then
                        local regions = {frame:GetRegions()}
                        for _, r in ipairs(regions) do
                            local rname = r.GetName and r:GetName()
                            if rname and rname:find(parts[i]) then
                                frame = r
                                break
                            end
                            -- Check for "Background" texture specifically
                            if parts[i] == "Background" and r.GetObjectType and r:GetObjectType() == "Texture" then
                                local drawLayer = r.GetDrawLayer and r:GetDrawLayer()
                                if drawLayer == "BACKGROUND" then
                                    frame = r
                                    break
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    
    return frame
end

-- Hide a minimap decoration element safely (works for frames and textures)
local function HideMinimapDecoration(frameName)
    local element = GetMinimapFrame(frameName)
    if not element then return end
    
    -- Store original state if not already stored
    if storedDecorationStates[frameName] == nil then
        pcall(function()
            storedDecorationStates[frameName] = {
                shown = element.IsShown and element:IsShown() or true,
                alpha = element.GetAlpha and element:GetAlpha() or 1,
            }
        end)
    end
    
    -- Hide using both Hide() and SetAlpha(0) for best compatibility
    pcall(function()
        if element.Hide then element:Hide() end
        if element.SetAlpha then element:SetAlpha(0) end
        
        -- Hook OnShow to keep it hidden (only for frames that support it)
        if element.HookScript and not element.tweaksHideHooked then
            element:HookScript("OnShow", function(self)
                local key = General:GetDecorationKeyForFrame(frameName)
                if key and General:GetMinimapHideSetting(key) then
                    if self.Hide then self:Hide() end
                    if self.SetAlpha then self:SetAlpha(0) end
                end
            end)
            element.tweaksHideHooked = true
        end
    end)
end

-- Show a minimap decoration element
local function ShowMinimapDecoration(frameName)
    local element = GetMinimapFrame(frameName)
    if not element then return end
    
    pcall(function()
        if element.SetAlpha then element:SetAlpha(1) end
        if element.Show then element:Show() end
    end)
end

-- Get decoration key for a frame name
function General:GetDecorationKeyForFrame(frameName)
    for key, frames in pairs(MINIMAP_DECORATION_FRAMES) do
        for _, name in ipairs(frames) do
            if name == frameName then
                return key
            end
        end
    end
    return nil
end

-- Special handler for mail icon - finds and hides the mail indicator specifically
local function ApplyMailSetting(shouldHide)
    -- Try legacy mail frame references first
    local mailFrames = {
        _G["MiniMapMailFrame"],
        _G["MiniMapMailIcon"],
        _G["MiniMapMailBorder"],
    }
    
    -- Also search MinimapCluster.IndicatorFrame children for mail-related frames
    local indicatorFrame = MinimapCluster and MinimapCluster.IndicatorFrame
    if indicatorFrame and indicatorFrame.GetChildren then
        local children = {indicatorFrame:GetChildren()}
        for _, child in ipairs(children) do
            local name = child.GetName and child:GetName()
            if name and (name:find("Mail") or name:find("mail")) then
                table.insert(mailFrames, child)
            end
        end
        -- Also check for MailFrame key directly
        if indicatorFrame.MailFrame then
            table.insert(mailFrames, indicatorFrame.MailFrame)
        end
    end
    
    for _, frame in ipairs(mailFrames) do
        if frame then
            pcall(function()
                if shouldHide then
                    frame:SetAlpha(0)
                    -- Hook OnShow to keep it hidden
                    if frame.HookScript and not frame.tweaksMailHooked then
                        frame:HookScript("OnShow", function(self)
                            if General:GetMinimapHideSetting("mail") then
                                self:SetAlpha(0)
                            end
                        end)
                        frame.tweaksMailHooked = true
                    end
                else
                    frame:SetAlpha(1)
                end
            end)
        end
    end
end

-- Special handler for tracking button - finds and hides the tracking indicator specifically
local function ApplyTrackingSetting(shouldHide)
    -- Use MinimapCluster.Tracking which is the correct frame from user's WoW client
    local trackingFrame = MinimapCluster and MinimapCluster.Tracking
    
    if trackingFrame then
        pcall(function()
            if shouldHide then
                trackingFrame:SetAlpha(0)
                -- Hook OnShow to keep it hidden
                if trackingFrame.HookScript and not trackingFrame.tweaksTrackingHooked then
                    trackingFrame:HookScript("OnShow", function(self)
                        if General:GetMinimapHideSetting("tracking") then
                            self:SetAlpha(0)
                        end
                    end)
                    trackingFrame.tweaksTrackingHooked = true
                end
            else
                trackingFrame:SetAlpha(1)
            end
        end)
    end
    
    -- Also try legacy frame names
    local legacyFrames = {
        _G["MiniMapTrackingFrame"],
        _G["MiniMapTrackingButton"],
    }
    
    for _, frame in ipairs(legacyFrames) do
        if frame then
            pcall(function()
                if shouldHide then
                    frame:SetAlpha(0)
                else
                    frame:SetAlpha(1)
                end
            end)
        end
    end
end

-- Special handler for zone text button
local function ApplyZoneTextSetting(shouldHide)
    -- Use MinimapCluster.ZoneTextButton which is the correct frame
    local zoneTextFrame = MinimapCluster and MinimapCluster.ZoneTextButton
    
    if zoneTextFrame then
        pcall(function()
            if shouldHide then
                zoneTextFrame:SetAlpha(0)
                if zoneTextFrame.HookScript and not zoneTextFrame.tweaksZoneTextHooked then
                    zoneTextFrame:HookScript("OnShow", function(self)
                        if General:GetMinimapHideSetting("zoneText") then
                            self:SetAlpha(0)
                        end
                    end)
                    zoneTextFrame.tweaksZoneTextHooked = true
                end
            else
                zoneTextFrame:SetAlpha(1)
            end
        end)
    end
    
    -- Also try legacy frame name
    local legacyFrame = _G["MinimapZoneTextButton"]
    if legacyFrame then
        pcall(function()
            if shouldHide then
                legacyFrame:SetAlpha(0)
            else
                legacyFrame:SetAlpha(1)
            end
        end)
    end
end

-- Special handler for zone text background (BorderTop)
local function ApplyZoneTextBackgroundSetting(shouldHide)
    -- Use MinimapCluster.BorderTop which is the correct frame
    local borderTopFrame = MinimapCluster and MinimapCluster.BorderTop
    
    if borderTopFrame then
        pcall(function()
            if shouldHide then
                borderTopFrame:SetAlpha(0)
                if borderTopFrame.HookScript and not borderTopFrame.tweaksBorderTopHooked then
                    borderTopFrame:HookScript("OnShow", function(self)
                        if General:GetMinimapHideSetting("zoneTextBackground") then
                            self:SetAlpha(0)
                        end
                    end)
                    borderTopFrame.tweaksBorderTopHooked = true
                end
            else
                borderTopFrame:SetAlpha(1)
            end
        end)
    end
end

-- Apply a single decoration hide setting
function General:ApplyDecorationSetting(key)
    if self:IsLeatrixManaging("decorations") then return end
    
    local shouldHide = self:GetMinimapHideSetting(key)
    
    -- Special handlers for problematic frames
    if key == "mail" then
        ApplyMailSetting(shouldHide)
        return
    elseif key == "tracking" then
        ApplyTrackingSetting(shouldHide)
        return
    elseif key == "zoneText" then
        ApplyZoneTextSetting(shouldHide)
        return
    elseif key == "zoneTextBackground" then
        ApplyZoneTextBackgroundSetting(shouldHide)
        return
    elseif key == "border" then
        -- Special handling for border - always hide Blizzard border if square minimap
        local isSquare = self:GetMinimapSetting("squareShape")
        local borderFrames = {"MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture"}
        
        if isSquare then
            -- ALWAYS hide Blizzard border when square
            for _, frameName in ipairs(borderFrames) do
                HideMinimapDecoration(frameName)
            end
            -- Show/hide custom border based on setting
            if shouldHide then
                if customMinimapBorder then
                    customMinimapBorder:Hide()
                end
            else
                self:CreateCustomMinimapBorder()
                customMinimapBorder:Show()
            end
        else
            -- Circular - hide custom border, show/hide Blizzard based on setting
            if customMinimapBorder then
                customMinimapBorder:Hide()
            end
            for _, frameName in ipairs(borderFrames) do
                if shouldHide then
                    HideMinimapDecoration(frameName)
                else
                    ShowMinimapDecoration(frameName)
                end
            end
        end
        return
    end
    
    local frames = MINIMAP_DECORATION_FRAMES[key]
    if not frames then return end
    
    for _, frameName in ipairs(frames) do
        if shouldHide then
            HideMinimapDecoration(frameName)
        else
            ShowMinimapDecoration(frameName)
        end
    end
end

-- Apply all minimap settings
function General:ApplyAllMinimapSettings()
    -- Shape
    self:ApplyMinimapShape()
    
    -- Scale
    self:ApplyMinimapScale()
    
    -- Decorations (skip if Leatrix is managing)
    if not self:IsLeatrixManaging("decorations") then
        for key, _ in pairs(MINIMAP_DECORATION_FRAMES) do
            self:ApplyDecorationSetting(key)
        end
    end
    
    TweaksUI:PrintDebug("General: Minimap settings applied")
end

-- ============================================================================
-- MINIMAP BUTTON COLLECTOR
-- ============================================================================

-- Buttons to ignore (Blizzard default buttons - not addon buttons)
local IGNORE_BUTTONS = {
    ["MinimapBackdrop"] = true,
    ["MinimapBorder"] = true,
    ["MinimapBorderTop"] = true,
    ["MinimapZoomIn"] = true,
    ["MinimapZoomOut"] = true,
    ["MinimapZoneTextButton"] = true,
    ["MiniMapWorldMapButton"] = true,
    ["GameTimeFrame"] = true,
    ["TimeManagerClockButton"] = true,
    ["MiniMapMailFrame"] = true,
    ["MiniMapMailBorder"] = true,
    ["MiniMapMailIcon"] = true,
    ["MiniMapTracking"] = true,
    ["MiniMapTrackingButton"] = true,
    ["MiniMapTrackingFrame"] = true,
    ["MiniMapInstanceDifficulty"] = true,
    ["GuildInstanceDifficulty"] = true,
    ["MiniMapChallengeMode"] = true,
    ["MinimapCompassTexture"] = true,
    ["QueueStatusMinimapButton"] = true,
    ["GarrisonLandingPageMinimapButton"] = true,
    ["ExpansionLandingPageMinimapButton"] = true,
    ["MiniMapCraftingOrderFrame"] = true,
    ["TweaksUI_MinimapBorder"] = true,
    ["TweaksUI_ButtonDrawer"] = true,
}

-- Check if a frame is a valid minimap button
local function IsMinimapButton(frame)
    if not frame then return false end
    
    local name = frame:GetName()
    if not name then return false end
    
    -- Ignore known Blizzard/TweaksUI frames
    if IGNORE_BUTTONS[name] then return false end
    
    -- Must be a button or frame type
    local frameType = frame:GetObjectType()
    if frameType ~= "Button" and frameType ~= "Frame" then return false end
    
    -- Check if it's a child of minimap-related frames
    local parent = frame:GetParent()
    local isMinimapChild = parent == Minimap or parent == MinimapCluster or parent == MinimapBackdrop
    
    -- Check if name suggests it's a minimap button
    local lowerName = name:lower()
    local hasMinimapInName = lowerName:find("minimap") or 
                              lowerName:find("lib_gpi") or 
                              lowerName:find("libdbicon") or
                              lowerName:find("_minimapbutton")
    
    -- Must have some visual content (texture)
    local hasTexture = false
    if frame.GetRegions then
        local regions = {frame:GetRegions()}
        for _, region in ipairs(regions) do
            if region:GetObjectType() == "Texture" then
                hasTexture = true
                break
            end
        end
    end
    
    -- Also check for icon/normalTexture on buttons
    if not hasTexture then
        if frame.icon or (frame.GetNormalTexture and frame:GetNormalTexture()) then
            hasTexture = true
        end
    end
    
    -- It's a minimap button if it's either a child of minimap OR has minimap in name, AND has texture
    return (isMinimapChild or hasMinimapInName) and hasTexture
end

-- Find all minimap buttons
function General:FindMinimapButtons()
    local buttons = {}
    
    -- Check children of Minimap
    if Minimap and Minimap.GetChildren then
        local children = {Minimap:GetChildren()}
        for _, child in ipairs(children) do
            if IsMinimapButton(child) then
                local name = child:GetName()
                if name and not buttons[name] then
                    buttons[name] = child
                end
            end
        end
    end
    
    -- Check children of MinimapCluster
    if MinimapCluster and MinimapCluster.GetChildren then
        local children = {MinimapCluster:GetChildren()}
        for _, child in ipairs(children) do
            if IsMinimapButton(child) then
                local name = child:GetName()
                if name and not buttons[name] then
                    buttons[name] = child
                end
            end
        end
    end
    
    -- Check children of MinimapBackdrop
    if MinimapBackdrop and MinimapBackdrop.GetChildren then
        local children = {MinimapBackdrop:GetChildren()}
        for _, child in ipairs(children) do
            if IsMinimapButton(child) then
                local name = child:GetName()
                if name and not buttons[name] then
                    buttons[name] = child
                end
            end
        end
    end
    
    -- Check global LibDBIcon buttons
    for globalName, frame in pairs(_G) do
        if type(frame) == "table" and type(globalName) == "string" then
            if globalName:find("^LibDBIcon") or globalName:find("Minimap") then
                if type(frame.GetObjectType) == "function" and IsMinimapButton(frame) then
                    if not buttons[globalName] then
                        buttons[globalName] = frame
                    end
                end
            end
        end
    end
    
    return buttons
end

-- Create the button drawer frame
function General:CreateButtonDrawer()
    if buttonDrawer then return buttonDrawer end
    
    -- Get minimap size - drawer will be half width
    local minimapSize = Minimap:GetWidth() or 140
    local drawerWidth = minimapSize * 0.5
    
    buttonDrawer = CreateFrame("Frame", "TweaksUI_ButtonDrawer", Minimap, "BackdropTemplate")
    buttonDrawer:SetFrameStrata("DIALOG")
    buttonDrawer:SetFrameLevel(100)
    buttonDrawer:SetClampedToScreen(true)
    buttonDrawer:SetWidth(drawerWidth)
    
    buttonDrawer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    buttonDrawer:SetBackdropColor(0.05, 0.05, 0.05, 0.92)
    buttonDrawer:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    
    -- Create scroll frame for buttons
    local scrollFrame = CreateFrame("ScrollFrame", nil, buttonDrawer, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 4, -4)
    scrollFrame:SetPoint("BOTTOMRIGHT", -22, 4)
    
    -- Hide scroll bar when not needed, make it thinner
    local scrollBar = scrollFrame.ScrollBar
    if scrollBar then
        scrollBar:SetWidth(8)
    end
    
    -- Content frame for buttons
    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetWidth(drawerWidth - 26)
    content:SetHeight(200)  -- Will be updated by layout
    scrollFrame:SetScrollChild(content)
    buttonDrawer.content = content
    buttonDrawer.scrollFrame = scrollFrame
    
    -- Right-click to close
    buttonDrawer:EnableMouse(true)
    buttonDrawer:SetScript("OnMouseUp", function(self, btn)
        if btn == "RightButton" then
            buttonDrawer:Hide()
        end
    end)
    
    -- Also close on right-click anywhere in content
    content:EnableMouse(true)
    content:SetScript("OnMouseUp", function(self, btn)
        if btn == "RightButton" then
            buttonDrawer:Hide()
        end
    end)
    
    buttonDrawer:Hide()
    
    return buttonDrawer
end

-- Position buttons in the drawer
function General:LayoutDrawerButtons()
    if not buttonDrawer or not buttonDrawer.content then return end
    
    local content = buttonDrawer.content
    local drawerWidth = buttonDrawer:GetWidth() or 70
    local drawerHeight = buttonDrawer:GetHeight() or 140
    
    -- Calculate buttons per row based on drawer width
    local buttonSize = 28
    local padding = 3
    local availableWidth = drawerWidth - 26  -- Account for scroll bar
    local buttonsPerRow = math.floor(availableWidth / (buttonSize + padding))
    if buttonsPerRow < 1 then buttonsPerRow = 1 end
    
    local startX = 2
    local startY = -2
    
    local count = 0
    for name, button in pairs(collectedButtons) do
        if button then
            local row = math.floor(count / buttonsPerRow)
            local col = count % buttonsPerRow
            
            local x = startX + (col * (buttonSize + padding))
            local y = startY - (row * (buttonSize + padding))
            
            button:ClearAllPoints()
            button:SetPoint("TOPLEFT", content, "TOPLEFT", x, y)
            button:SetSize(buttonSize, buttonSize)
            button:SetParent(content)
            button:SetFrameLevel(content:GetFrameLevel() + 1)
            button:Show()
            
            -- Right-click on button also closes drawer
            if not button.tweaksRightClickHooked then
                button:HookScript("OnMouseUp", function(self, btn)
                    if btn == "RightButton" then
                        buttonDrawer:Hide()
                    end
                end)
                button.tweaksRightClickHooked = true
            end
            
            count = count + 1
        end
    end
    
    -- Update content height for scrolling
    local rows = math.ceil(count / buttonsPerRow)
    if rows < 1 then rows = 1 end
    local contentHeight = math.abs(startY) + (rows * (buttonSize + padding)) + padding
    content:SetHeight(math.max(contentHeight, drawerHeight - 8))
    
    if count == 0 then
        -- Show "No buttons" message
        if not buttonDrawer.emptyText then
            buttonDrawer.emptyText = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            buttonDrawer.emptyText:SetPoint("CENTER", content, "CENTER", 0, 0)
            buttonDrawer.emptyText:SetText("No addons")
            buttonDrawer.emptyText:SetTextColor(0.5, 0.5, 0.5)
        end
        buttonDrawer.emptyText:Show()
    elseif buttonDrawer.emptyText then
        buttonDrawer.emptyText:Hide()
    end
end

-- Collect buttons into drawer
function General:CollectMinimapButtons()
    if self:IsLeatrixManaging("buttonCollector") then return end
    
    local buttons = self:FindMinimapButtons()
    local newButtonsFound = false
    
    for name, button in pairs(buttons) do
        if not collectedButtons[name] then
            -- Store original position
            if not originalButtonPositions[name] then
                local point, relativeTo, relativePoint, x, y = button:GetPoint(1)
                originalButtonPositions[name] = {
                    point = point,
                    relativeTo = relativeTo,
                    relativePoint = relativePoint,
                    x = x,
                    y = y,
                    parent = button:GetParent(),
                    width = button:GetWidth(),
                    height = button:GetHeight(),
                }
            end
            
            collectedButtons[name] = button
            button:Hide()  -- Hide from minimap immediately
            newButtonsFound = true
        end
    end
    
    -- Only layout if drawer is visible and we found new buttons
    if newButtonsFound and buttonDrawer and buttonDrawer:IsShown() then
        self:LayoutDrawerButtons()
    end
end

-- Restore buttons to original positions
function General:RestoreMinimapButtons()
    for name, button in pairs(collectedButtons) do
        local original = originalButtonPositions[name]
        if original and button then
            pcall(function()
                button:ClearAllPoints()
                button:SetParent(original.parent or Minimap)
                button:SetPoint(original.point or "TOPLEFT", original.relativeTo or Minimap, original.relativePoint or "TOPLEFT", original.x or 0, original.y or 0)
                button:SetSize(original.width or 32, original.height or 32)
                button:Show()
            end)
        end
    end
    
    collectedButtons = {}
    originalButtonPositions = {}
    
    if buttonDrawer then
        buttonDrawer:Hide()
    end
end

-- Toggle drawer visibility
function General:ToggleButtonDrawer()
    if not buttonDrawer then
        self:CreateButtonDrawer()
    end
    
    if buttonDrawer:IsShown() then
        buttonDrawer:Hide()
    else
        -- Position drawer on right half of minimap
        buttonDrawer:ClearAllPoints()
        buttonDrawer:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", 0, 0)
        buttonDrawer:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", 0, 0)
        
        -- Refresh buttons
        self:CollectMinimapButtons()
        self:LayoutDrawerButtons()
        
        buttonDrawer:Show()
    end
end

-- Get button collector setting
function General:GetButtonCollectorSetting(key)
    if settings and settings.minimapSettings and settings.minimapSettings.buttonCollector then
        return settings.minimapSettings.buttonCollector[key]
    end
    return DEFAULTS.minimapSettings.buttonCollector[key]
end

-- Set button collector setting
function General:SetButtonCollectorSetting(key, value)
    if settings then
        settings.minimapSettings = settings.minimapSettings or {}
        settings.minimapSettings.buttonCollector = settings.minimapSettings.buttonCollector or {}
        settings.minimapSettings.buttonCollector[key] = value
    end
end

-- Setup minimap right-click handler
function General:SetupButtonCollector()
    if self:IsLeatrixManaging("buttonCollector") then return end
    
    -- Hook minimap right-click
    if not Minimap.tweaksRightClickHooked then
        Minimap:SetScript("OnMouseUp", function(self, button)
            if button == "RightButton" then
                if General:GetButtonCollectorSetting("enabled") and not General:IsLeatrixManaging("buttonCollector") then
                    General:ToggleButtonDrawer()
                else
                    -- Default behavior - show tracking menu
                    if MinimapCluster and MinimapCluster.Tracking and MinimapCluster.Tracking.Button then
                        MinimapCluster.Tracking.Button:Click()
                    elseif MiniMapTrackingButton then
                        MiniMapTrackingButton:Click()
                    end
                end
            end
        end)
        Minimap.tweaksRightClickHooked = true
    end
end

-- Apply button collector settings
function General:ApplyButtonCollector()
    if self:IsLeatrixManaging("buttonCollector") then 
        -- Restore buttons if Leatrix takes over
        self:RestoreMinimapButtons()
        self:StopButtonScanning()
        return 
    end
    
    local enabled = self:GetButtonCollectorSetting("enabled")
    
    if enabled then
        -- Immediately collect any existing buttons
        self:CollectMinimapButtons()
        
        -- Start aggressive scanning for new buttons during load
        self:StartButtonScanning()
    else
        self:RestoreMinimapButtons()
        self:StopButtonScanning()
    end
end

-- Scanning frame for catching buttons as they're created
local buttonScanFrame = nil
local scanEndTime = 0
local scanThrottle = 0

function General:StartButtonScanning()
    if not buttonScanFrame then
        buttonScanFrame = CreateFrame("Frame")
    end
    
    -- Scan for 3 seconds after enable
    scanEndTime = GetTime() + 3
    scanThrottle = 0
    
    buttonScanFrame:SetScript("OnUpdate", function(self, elapsed)
        if GetTime() > scanEndTime then
            General:StopButtonScanning()
            return
        end
        
        -- Throttle to every 0.05 seconds (20 times per second)
        scanThrottle = scanThrottle + elapsed
        if scanThrottle >= 0.05 then
            scanThrottle = 0
            General:CollectMinimapButtons()
        end
    end)
end

function General:StopButtonScanning()
    if buttonScanFrame then
        buttonScanFrame:SetScript("OnUpdate", nil)
    end
end

-- ============================================================================
-- INITIALIZATION
-- ============================================================================

function General:Initialize()
    TweaksUI_DB = TweaksUI_DB or {}
    TweaksUI_DB.general = TweaksUI_DB.general or {}
    settings = TweaksUI_DB.general
    
    -- Ensure visibility table exists
    settings.visibility = settings.visibility or {}
    
    -- Initialize defaults for each frame
    for frameKey, _ in pairs(VISIBILITY_FRAMES) do
        if not settings.visibility[frameKey] then
            settings.visibility[frameKey] = GetDefaultVisibilitySettings()
        else
            -- Ensure all keys exist
            local defaults = GetDefaultVisibilitySettings()
            for key, value in pairs(defaults) do
                if settings.visibility[frameKey][key] == nil then
                    settings.visibility[frameKey][key] = value
                end
            end
        end
    end
    
    -- Initialize other defaults
    for key, value in pairs(DEFAULTS) do
        if key ~= "visibility" and key ~= "minimapSettings" and settings[key] == nil then
            settings[key] = value
        end
    end
    
    -- Initialize minimapSettings with deep copy of defaults
    settings.minimapSettings = settings.minimapSettings or {}
    settings.minimapSettings.hide = settings.minimapSettings.hide or {}
    settings.minimapSettings.customBorder = settings.minimapSettings.customBorder or {}
    settings.minimapSettings.buttonCollector = settings.minimapSettings.buttonCollector or {}
    
    for key, value in pairs(DEFAULTS.minimapSettings) do
        if key == "hide" then
            for hideKey, hideValue in pairs(value) do
                if settings.minimapSettings.hide[hideKey] == nil then
                    settings.minimapSettings.hide[hideKey] = hideValue
                end
            end
        elseif key == "customBorder" then
            -- Deep copy customBorder defaults
            for borderKey, borderValue in pairs(value) do
                if settings.minimapSettings.customBorder[borderKey] == nil then
                    if type(borderValue) == "table" then
                        settings.minimapSettings.customBorder[borderKey] = {}
                        for k, v in pairs(borderValue) do
                            settings.minimapSettings.customBorder[borderKey][k] = v
                        end
                    else
                        settings.minimapSettings.customBorder[borderKey] = borderValue
                    end
                end
            end
        elseif key == "buttonCollector" then
            -- Deep copy buttonCollector defaults
            for bcKey, bcValue in pairs(value) do
                if settings.minimapSettings.buttonCollector[bcKey] == nil then
                    settings.minimapSettings.buttonCollector[bcKey] = bcValue
                end
            end
        elseif settings.minimapSettings[key] == nil then
            settings.minimapSettings[key] = value
        end
    end
    
    -- Check for Leatrix Plus conflicts
    self:CheckLeatrixConflicts()
    
    C_Timer.After(0.5, function()
        self:ApplyAllVisibility()
        self:UpdateMouseoverHitFrames()
    end)
    
    -- Apply minimap shape immediately to prevent flash on reload
    self:ApplyMinimapShape()
    self:ApplyMinimapScale()
    
    -- Apply decorations after frames are fully ready
    C_Timer.After(0.3, function()
        self:ApplyAllMinimapSettings()
    end)
    
    -- Setup button collector immediately to catch buttons before they render
    self:SetupButtonCollector()
    self:ApplyButtonCollector()
    
    self:SetupVisibilityUpdater()
    self:SetupAFKMode()
    self:SetupMerchantHandler()
    self:SetupRotationMonitor()
    self:SetupSlashCommands()
    self:CreateMinimapButton()
    
    TweaksUI:PrintDebug("General module initialized")
end

-- ============================================================================
-- SLASH COMMANDS
-- ============================================================================

function General:SetupSlashCommands()
    -- /rl - Reload UI
    SLASH_TWEAKSUI_RL1 = "/rl"
    SlashCmdList["TWEAKSUI_RL"] = function()
        ReloadUI()
    end
    
    -- /em - Open Edit Mode
    SLASH_TWEAKSUI_EM1 = "/em"
    SlashCmdList["TWEAKSUI_EM"] = function()
        if EditModeManagerFrame then
            if EditModeManagerFrame:IsShown() then
                EditModeManagerFrame:Hide()
            else
                EditModeManagerFrame:Show()
            end
        else
            print("|cff00ff00TweaksUI:|r Edit Mode not available")
        end
    end
    
    -- /cdm - Open Blizzard Cooldown Manager Settings
    SLASH_TWEAKSUI_CDM1 = "/cdm"
    SlashCmdList["TWEAKSUI_CDM"] = function()
        -- CooldownViewerSettings is Blizzard's Cooldown Settings frame
        local cooldownFrame = CooldownViewerSettings or _G["CooldownViewerSettings"]
        
        if cooldownFrame then
            if cooldownFrame:IsShown() then
                cooldownFrame:Hide()
            else
                cooldownFrame:Show()
            end
        else
            print("|cff00ff00TweaksUI:|r Cooldown Settings not available.")
        end
    end
end

-- ============================================================================
-- MINIMAP BUTTON (LibDBIcon)
-- ============================================================================

function General:CreateMinimapButton()
    -- Check if button already exists (reload safety)
    if _G["TweaksUI_MinimapButton"] then
        minimapButton = _G["TweaksUI_MinimapButton"]
        -- Re-hook the click handler on reload
        minimapButton:SetScript("OnClick", function(self, btn)
            if TweaksUI and TweaksUI.ToggleSettings then
                TweaksUI:ToggleSettings()
            end
        end)
        return
    end
    
    -- Ensure minimap settings exist
    settings.minimap = settings.minimap or {}
    local savedPos = settings.minimap.minimapPos or 225
    
    -- Create the button
    local button = CreateFrame("Button", "TweaksUI_MinimapButton", Minimap)
    button:SetSize(32, 32)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:RegisterForClicks("AnyUp")
    button:RegisterForDrag("LeftButton")
    
    -- Position function
    local function UpdatePosition(pos)
        local radian = math.rad(pos)
        local radius = (Minimap:GetWidth() / 2) + 5
        local x = math.cos(radian) * radius
        local y = math.sin(radian) * radius
        button:ClearAllPoints()
        button:SetPoint("CENTER", Minimap, "CENTER", x, y)
    end
    UpdatePosition(savedPos)
    
    -- Create textures matching other minimap buttons
    local overlay = button:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(53, 53)
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetPoint("TOPLEFT", 0, 0)
    
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetSize(20, 20)
    background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    background:SetPoint("TOPLEFT", 7, -5)
    
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetTexture("Interface\\AddOns\\!TweaksUI\\Media\\Textures\\TweaksUI_Icon.tga")
    icon:SetPoint("TOPLEFT", 7, -6)
    button.icon = icon
    
    -- No highlight texture - keeps button stable on hover
    
    -- Click handler
    button:SetScript("OnClick", function(self, btn)
        if TweaksUI and TweaksUI.ToggleSettings then
            TweaksUI:ToggleSettings()
        end
    end)
    
    -- Tooltip
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("TweaksUI", 1, 0.82, 0)
        GameTooltip:AddLine("|cffffffffClick:|r Open Settings", 1, 1, 1)
        GameTooltip:AddLine("|cffffffffDrag:|r Move Button", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    
    button:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    
    -- Dragging
    button:SetScript("OnDragStart", function(self)
        self.isDragging = true
    end)
    
    button:SetScript("OnDragStop", function(self)
        self.isDragging = false
        local mx, my = Minimap:GetCenter()
        local px, py = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        px, py = px / scale, py / scale
        local pos = math.deg(math.atan2(py - my, px - mx)) % 360
        settings.minimap.minimapPos = pos
        UpdatePosition(pos)
    end)
    
    button:SetScript("OnUpdate", function(self)
        if self.isDragging then
            local mx, my = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            px, py = px / scale, py / scale
            local pos = math.deg(math.atan2(py - my, px - mx)) % 360
            UpdatePosition(pos)
        end
    end)
    
    minimapButton = button
    
    -- Apply visibility setting
    if settings.hideMinimapButton then
        button:Hide()
    end
    
    TweaksUI:PrintDebug("General: Custom minimap button created")
end

function General:UpdateMinimapButtonPosition(button, angle)
    -- Handled internally by the button
end

function General:SetMinimapButtonVisible(visible)
    if minimapButton then
        if visible then
            minimapButton:Show()
        else
            minimapButton:Hide()
        end
    end
end

-- ============================================================================
-- HUB PANEL
-- ============================================================================

function General:CreateHub(parent)
    if generalHub then return generalHub end
    
    local hub = CreateFrame("Frame", "TweaksUI_General_Hub", parent or UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, HUB_HEIGHT + BUTTON_HEIGHT + BUTTON_SPACING)  -- Extra height for Minimap button
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    hub:Hide()
    
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("General")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        if isTestingAFK then
            General:ExitAFKMode()
        end
        hub:Hide()
        self:HideAllPanels()
    end)
    
    local yOffset = -42
    
    local generalBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    generalBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    generalBtn:SetPoint("TOP", 0, yOffset)
    generalBtn:SetText("General")
    generalBtn:SetScript("OnClick", function()
        self:TogglePanel("general")
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    local visBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    visBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    visBtn:SetPoint("TOP", 0, yOffset)
    visBtn:SetText("Visibility")
    visBtn:SetScript("OnClick", function()
        self:TogglePanel("visibility")
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    local afkBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    afkBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    afkBtn:SetPoint("TOP", 0, yOffset)
    afkBtn:SetText("AFK Mode")
    afkBtn:SetScript("OnClick", function()
        self:TogglePanel("afk")
    end)
    yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    
    local minimapBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    minimapBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    minimapBtn:SetPoint("TOP", 0, yOffset)
    minimapBtn:SetText("Minimap")
    minimapBtn:SetScript("OnClick", function()
        self:TogglePanel("minimap")
    end)
    
    generalHub = hub
    return hub
end

function General:ShowHub(parent)
    if not generalHub then
        self:CreateHub(parent)
    end
    
    if parent then
        generalHub:ClearAllPoints()
        generalHub:SetPoint("TOPLEFT", parent, "TOPRIGHT", 0, 0)
    end
    
    generalHub:Show()
end

function General:HideHub()
    if generalHub then
        if isTestingAFK then
            General:ExitAFKMode()
        end
        generalHub:Hide()
    end
    self:HideAllPanels()
end

function General:HideAllPanels()
    if generalPanel then generalPanel:Hide() end
    if visibilityPanel then
        visibilityPanel:Hide()
        self:HideVisibilityCategoryPanels()
    end
    if afkPanel then
        if isTestingAFK then
            General:ExitAFKMode()
        end
        afkPanel:Hide()
    end
    if minimapPanel then minimapPanel:Hide() end
    if currentVisibilityItemPanel then
        currentVisibilityItemPanel:Hide()
    end
end

function General:TogglePanel(panelName)
    if panelName == "general" then
        self:HideAllPanels()
        if not generalPanel then
            self:CreateGeneralPanel()
        end
        generalPanel:ClearAllPoints()
        generalPanel:SetPoint("TOPLEFT", generalHub, "TOPRIGHT", 0, 0)
        generalPanel:Show()
        
    elseif panelName == "visibility" then
        self:HideAllPanels()
        if not visibilityPanel then
            self:CreateVisibilityPanel()
        end
        visibilityPanel:ClearAllPoints()
        visibilityPanel:SetPoint("TOPLEFT", generalHub, "TOPRIGHT", 0, 0)
        visibilityPanel:Show()
        
    elseif panelName == "afk" then
        self:HideAllPanels()
        if not afkPanel then
            self:CreateAFKPanel()
        end
        afkPanel:ClearAllPoints()
        afkPanel:SetPoint("TOPLEFT", generalHub, "TOPRIGHT", 0, 0)
        afkPanel:Show()
        
    elseif panelName == "minimap" then
        self:HideAllPanels()
        if not minimapPanel then
            self:CreateMinimapPanel()
        end
        minimapPanel:ClearAllPoints()
        minimapPanel:SetPoint("TOPLEFT", generalHub, "TOPRIGHT", 0, 0)
        -- Update controls to reflect current settings before showing
        if minimapPanel.UpdateSwatchColor then
            minimapPanel:UpdateSwatchColor()
        end
        if minimapPanel.UpdateWidthDisplay then
            minimapPanel.UpdateWidthDisplay()
        end
        minimapPanel:Show()
    end
end

-- ============================================================================
-- GENERAL SETTINGS PANEL
-- ============================================================================

-- Helper to create a Leatrix warning for a specific feature set
local function CreateLeatrixQoLWarning(parent, y)
    local conflicts = General:GetLeatrixConflicts()
    if not conflicts then return y end
    
    -- Check if any QoL conflicts exist
    local hasQoLConflicts = conflicts.autoRepair or conflicts.autoSellJunk
    if not hasQoLConflicts then return y end
    
    local warning = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    warning:SetPoint("TOPLEFT", 15, y)
    warning:SetWidth(PANEL_WIDTH - 40)
    warning:SetJustifyH("LEFT")
    warning:SetText("|cffff9900⚠ Leatrix Plus|r is managing some features.\nThose options are disabled below.")
    warning:SetTextColor(1, 0.8, 0.3)
    
    return y - 45  -- More space after warning
end

function General:CreateGeneralPanel()
    if generalPanel then return generalPanel end
    
    local panel = CreateFrame("Frame", "TweaksUI_General_Settings", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, 360)  -- Slightly taller
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:Hide()
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("General Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() panel:Hide() end)
    
    local y = -50  -- More space from title
    
    -- Leatrix warning (if applicable)
    y = CreateLeatrixQoLWarning(panel, y)
    
    -- ========== Convenience Section ==========
    local convLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    convLabel:SetPoint("TOPLEFT", 15, y)
    convLabel:SetText("Convenience")
    convLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Auto Repair
    local autoRepairCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    autoRepairCb:SetPoint("TOPLEFT", 20, y)
    autoRepairCb:SetSize(24, 24)
    autoRepairCb:SetChecked(self:GetSetting("autoRepair"))
    autoRepairCb.text:SetText("Auto Repair at Merchants")
    autoRepairCb.text:SetFontObject("GameFontNormal")
    
    -- Check Leatrix conflict
    if self:IsLeatrixManaging("autoRepair") then
        autoRepairCb:Disable()
        autoRepairCb:SetAlpha(0.5)
        autoRepairCb.text:SetTextColor(0.5, 0.5, 0.5)
        autoRepairCb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Managed by Leatrix Plus", 1, 0.8, 0.3)
            GameTooltip:AddLine("Disable in Leatrix Plus to use TweaksUI's version.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        autoRepairCb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        autoRepairCb:SetScript("OnClick", function(cb)
            General:SetSetting("autoRepair", cb:GetChecked())
        end)
    end
    
    y = y - 28
    
    -- Use Guild Funds (indented, depends on Auto Repair)
    local guildFundsCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    guildFundsCb:SetPoint("TOPLEFT", 40, y)  -- Indented
    guildFundsCb:SetSize(24, 24)
    guildFundsCb:SetChecked(self:GetSetting("autoRepairGuild"))
    guildFundsCb.text:SetText("Use Guild Funds First")
    guildFundsCb.text:SetFontObject("GameFontNormal")
    
    if self:IsLeatrixManaging("autoRepair") then
        guildFundsCb:Disable()
        guildFundsCb:SetAlpha(0.5)
        guildFundsCb.text:SetTextColor(0.5, 0.5, 0.5)
    else
        guildFundsCb:SetScript("OnClick", function(cb)
            General:SetSetting("autoRepairGuild", cb:GetChecked())
        end)
    end
    
    y = y - 28
    
    -- Auto Sell Junk
    local autoSellCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    autoSellCb:SetPoint("TOPLEFT", 20, y)
    autoSellCb:SetSize(24, 24)
    autoSellCb:SetChecked(self:GetSetting("autoSellJunk"))
    autoSellCb.text:SetText("Auto Sell Junk (Grey Items)")
    autoSellCb.text:SetFontObject("GameFontNormal")
    
    if self:IsLeatrixManaging("autoSellJunk") then
        autoSellCb:Disable()
        autoSellCb:SetAlpha(0.5)
        autoSellCb.text:SetTextColor(0.5, 0.5, 0.5)
        autoSellCb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Managed by Leatrix Plus", 1, 0.8, 0.3)
            GameTooltip:AddLine("Disable in Leatrix Plus to use TweaksUI's version.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        autoSellCb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        autoSellCb:SetScript("OnClick", function(cb)
            General:SetSetting("autoSellJunk", cb:GetChecked())
        end)
    end
    
    y = y - 35
    
    -- ========== Interface Section ==========
    local interfaceLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    interfaceLabel:SetPoint("TOPLEFT", 15, y)
    interfaceLabel:SetText("Interface")
    interfaceLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Hide Minimap Button
    local minimapBtnCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    minimapBtnCb:SetPoint("TOPLEFT", 20, y)
    minimapBtnCb:SetSize(24, 24)
    minimapBtnCb:SetChecked(self:GetSetting("hideMinimapButton"))
    minimapBtnCb.text:SetText("Hide Minimap Button")
    minimapBtnCb.text:SetFontObject("GameFontNormal")
    minimapBtnCb:SetScript("OnClick", function(cb)
        General:SetSetting("hideMinimapButton", cb:GetChecked())
        General:SetMinimapButtonVisible(not cb:GetChecked())
    end)
    
    y = y - 35
    
    -- ========== Slash Commands Section ==========
    local cmdLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    cmdLabel:SetPoint("TOPLEFT", 15, y)
    cmdLabel:SetText("Slash Commands")
    cmdLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 20
    
    local cmdInfo = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    cmdInfo:SetPoint("TOPLEFT", 20, y)
    cmdInfo:SetText("|cff00ff00/rl|r - Reload UI\n|cff00ff00/em|r - Toggle Edit Mode\n|cff00ff00/cdm|r - Cooldown Manager Settings")
    cmdInfo:SetJustifyH("LEFT")
    
    generalPanel = panel
    return panel
end

-- ============================================================================
-- VISIBILITY PANEL
-- ============================================================================

function General:CreateVisibilityPanel()
    if visibilityPanel then return visibilityPanel end
    
    -- Calculate height based on number of categories
    local numCategories = #CATEGORIES
    local panelHeight = 42 + (numCategories * (BUTTON_HEIGHT + BUTTON_SPACING)) + 10
    
    local panel = CreateFrame("Frame", "TweaksUI_Visibility_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(HUB_WIDTH, panelHeight)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:Hide()
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Visibility")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
        self:HideVisibilityCategoryPanels()
    end)
    
    local yOffset = -42
    
    -- Create buttons for each category
    for _, cat in ipairs(CATEGORIES) do
        local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        btn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
        btn:SetPoint("TOP", 0, yOffset)
        btn:SetText(cat.label)
        btn:SetScript("OnClick", function()
            self:ShowVisibilityCategoryPanel(cat.key)
        end)
        yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    end
    
    visibilityPanel = panel
    return panel
end

function General:HideVisibilityCategoryPanels()
    for _, catPanel in pairs(visibilityCategoryPanels) do
        if catPanel then catPanel:Hide() end
    end
    if currentVisibilityItemPanel then
        currentVisibilityItemPanel:Hide()
    end
end

function General:ShowVisibilityCategoryPanel(categoryKey)
    self:HideVisibilityCategoryPanels()
    
    if not visibilityCategoryPanels[categoryKey] then
        self:CreateVisibilityCategoryPanel(categoryKey)
    end
    
    local catPanel = visibilityCategoryPanels[categoryKey]
    if catPanel then
        catPanel:ClearAllPoints()
        catPanel:SetPoint("TOPLEFT", visibilityPanel, "TOPRIGHT", 0, 0)
        catPanel:Show()
    end
end

function General:CreateVisibilityCategoryPanel(categoryKey)
    local categoryNames = {
        combat = "Combat",
        information = "Information",
        navigation = "Navigation",
        indicators = "Indicators",
        popups = "Popups",
    }
    
    -- Gather items for this category
    local items = {}
    for key, info in pairs(VISIBILITY_FRAMES) do
        if info.category == categoryKey then
            table.insert(items, { key = key, info = info })
        end
    end
    
    -- Sort alphabetically
    table.sort(items, function(a, b) return a.info.label < b.info.label end)
    
    local panel = CreateFrame("Frame", "TweaksUI_Visibility_" .. categoryKey, UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:Hide()
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText(categoryNames[categoryKey] or categoryKey)
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
        if currentVisibilityItemPanel then
            currentVisibilityItemPanel:Hide()
        end
    end)
    
    -- Tab container
    local tabContainer = CreateFrame("Frame", nil, panel)
    tabContainer:SetPoint("TOPLEFT", 10, -40)
    tabContainer:SetPoint("TOPRIGHT", -10, -40)
    tabContainer:SetHeight(TAB_HEIGHT)
    
    -- Content area
    local contentArea = CreateFrame("Frame", nil, panel)
    contentArea:SetPoint("TOPLEFT", 15, -70)
    contentArea:SetPoint("BOTTOMRIGHT", -15, 15)
    
    -- Create tab content frames for each item (no scroll)
    local tabContents = {}
    for _, item in ipairs(items) do
        local content = CreateFrame("Frame", nil, contentArea)
        content:SetAllPoints()
        content:Hide()
        tabContents[item.key] = content
        
        -- Populate content
        self:PopulateVisibilityItemContent(content, item.key, item.info)
    end
    
    -- Tab buttons with background (matching ActionBars style)
    local tabs = {}
    local numTabs = #items
    local tabSpacing = 4
    local totalSpacing = (numTabs - 1) * tabSpacing
    local tabWidth = (PANEL_WIDTH - 38 - totalSpacing) / numTabs
    
    local function SelectTab(index)
        for i, tab in ipairs(tabs) do
            if i == index then
                tab:SetNormalFontObject("GameFontHighlight")
                tab.bg:SetColorTexture(0.3, 0.3, 0.3, 0.8)
            else
                tab:SetNormalFontObject("GameFontNormal")
                tab.bg:SetColorTexture(0.2, 0.2, 0.2, 0.8)
            end
        end
        
        for _, item in ipairs(items) do
            tabContents[item.key]:Hide()
        end
        tabContents[items[index].key]:Show()
    end
    
    local prevTab = nil
    for i, item in ipairs(items) do
        local btn = CreateFrame("Button", nil, tabContainer)
        if prevTab then
            btn:SetPoint("TOPLEFT", prevTab, "TOPRIGHT", tabSpacing, 0)
        else
            btn:SetPoint("TOPLEFT", 0, 0)
        end
        btn:SetSize(tabWidth, TAB_HEIGHT)
        btn:SetNormalFontObject(i == 1 and "GameFontHighlight" or "GameFontNormal")
        btn:SetText(item.info.label)
        btn:GetFontString():SetPoint("CENTER")
        btn:SetScript("OnClick", function() SelectTab(i) end)
        
        -- Background texture
        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(i == 1 and 0.3 or 0.2, i == 1 and 0.3 or 0.2, i == 1 and 0.3 or 0.2, 0.8)
        btn.bg = bg
        
        -- Tooltip
        btn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(item.info.label, 1, 1, 1)
            GameTooltip:AddLine(item.info.description, 0.7, 0.7, 0.7, true)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        
        tabs[i] = btn
        prevTab = btn
    end
    
    if #items > 0 then
        SelectTab(1)
    end
    
    visibilityCategoryPanels[categoryKey] = panel
    return panel
end

function General:PopulateVisibilityItemContent(parent, frameKey, info)
    local y = 0
    
    -- Section header
    local headerLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    headerLabel:SetPoint("TOPLEFT", 5, y)
    headerLabel:SetText(info.label .. " Visibility")
    headerLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Master hide toggle
    local hideCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    hideCb:SetPoint("TOPLEFT", 10, y)
    hideCb:SetSize(24, 24)
    hideCb:SetChecked(self:GetVisibilitySetting(frameKey, "hide"))
    hideCb.text:SetText("Always Hide")
    hideCb.text:SetFontObject("GameFontNormal")
    hideCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "hide", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - 35
    
    -- Enable visibility conditions
    local enableCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    enableCb:SetPoint("TOPLEFT", 10, y)
    enableCb:SetSize(24, 24)
    enableCb:SetChecked(self:GetVisibilitySetting(frameKey, "visibilityEnabled"))
    enableCb.text:SetText("Enable Visibility Conditions")
    enableCb.text:SetFontObject("GameFontNormal")
    enableCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "visibilityEnabled", self:GetChecked())
        General:UpdateMouseoverHitFrames()
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    -- On Mouseover
    local mouseoverCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    mouseoverCb:SetPoint("TOPLEFT", 10, y)
    mouseoverCb:SetSize(24, 24)
    mouseoverCb:SetChecked(self:GetVisibilitySetting(frameKey, "onMouseover"))
    mouseoverCb.text:SetText("On Mouseover")
    mouseoverCb.text:SetFontObject("GameFontNormal")
    mouseoverCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "onMouseover", self:GetChecked())
        General:UpdateMouseoverHitFrames()
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    -- Combat conditions
    local combatCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    combatCb:SetPoint("TOPLEFT", 10, y)
    combatCb:SetSize(24, 24)
    combatCb:SetChecked(self:GetVisibilitySetting(frameKey, "inCombat"))
    combatCb.text:SetText("In Combat")
    combatCb.text:SetFontObject("GameFontNormal")
    combatCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "inCombat", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    local outCombatCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    outCombatCb:SetPoint("TOPLEFT", 10, y)
    outCombatCb:SetSize(24, 24)
    outCombatCb:SetChecked(self:GetVisibilitySetting(frameKey, "outOfCombat"))
    outCombatCb.text:SetText("Out of Combat")
    outCombatCb.text:SetFontObject("GameFontNormal")
    outCombatCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "outOfCombat", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    -- Target conditions
    local hasTargetCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    hasTargetCb:SetPoint("TOPLEFT", 10, y)
    hasTargetCb:SetSize(24, 24)
    hasTargetCb:SetChecked(self:GetVisibilitySetting(frameKey, "hasTarget"))
    hasTargetCb.text:SetText("Has Target")
    hasTargetCb.text:SetFontObject("GameFontNormal")
    hasTargetCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "hasTarget", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    local noTargetCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    noTargetCb:SetPoint("TOPLEFT", 10, y)
    noTargetCb:SetSize(24, 24)
    noTargetCb:SetChecked(self:GetVisibilitySetting(frameKey, "noTarget"))
    noTargetCb.text:SetText("No Target")
    noTargetCb.text:SetFontObject("GameFontNormal")
    noTargetCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "noTarget", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    -- Group conditions
    local soloCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    soloCb:SetPoint("TOPLEFT", 10, y)
    soloCb:SetSize(24, 24)
    soloCb:SetChecked(self:GetVisibilitySetting(frameKey, "solo"))
    soloCb.text:SetText("Solo")
    soloCb.text:SetFontObject("GameFontNormal")
    soloCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "solo", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    local partyCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    partyCb:SetPoint("TOPLEFT", 10, y)
    partyCb:SetSize(24, 24)
    partyCb:SetChecked(self:GetVisibilitySetting(frameKey, "inParty"))
    partyCb.text:SetText("In Party")
    partyCb.text:SetFontObject("GameFontNormal")
    partyCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "inParty", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    local raidCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    raidCb:SetPoint("TOPLEFT", 10, y)
    raidCb:SetSize(24, 24)
    raidCb:SetChecked(self:GetVisibilitySetting(frameKey, "inRaid"))
    raidCb.text:SetText("In Raid")
    raidCb.text:SetFontObject("GameFontNormal")
    raidCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "inRaid", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - CHECKBOX_SPACING
    
    local instanceCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    instanceCb:SetPoint("TOPLEFT", 10, y)
    instanceCb:SetSize(24, 24)
    instanceCb:SetChecked(self:GetVisibilitySetting(frameKey, "inInstance"))
    instanceCb.text:SetText("In Instance")
    instanceCb.text:SetFontObject("GameFontNormal")
    instanceCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "inInstance", self:GetChecked())
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - 35
    
    -- Fade section
    local fadeLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fadeLabel:SetPoint("TOPLEFT", 5, y)
    fadeLabel:SetText(info.label .. " Fade")
    fadeLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    local fadeCb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    fadeCb:SetPoint("TOPLEFT", 10, y)
    fadeCb:SetSize(24, 24)
    fadeCb:SetChecked(self:GetVisibilitySetting(frameKey, "fadeEnabled"))
    fadeCb.text:SetText("Enable Fade")
    fadeCb.text:SetFontObject("GameFontNormal")
    fadeCb:SetScript("OnClick", function(self)
        General:SetVisibilitySetting(frameKey, "fadeEnabled", self:GetChecked())
        if not self:GetChecked() then
            General:ResetFade(frameKey)
        end
        General:ApplyFrameVisibility(frameKey, true)
    end)
    
    y = y - 35
    
    -- Fade delay
    local delayLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    delayLabel:SetPoint("TOPLEFT", 10, y)
    delayLabel:SetText("Fade Delay (sec):")
    
    local currentDelay = self:GetVisibilitySetting(frameKey, "fadeDelay") or 3
    local delayValue = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    delayValue:SetPoint("LEFT", delayLabel, "RIGHT", 5, 0)
    delayValue:SetText(tostring(currentDelay))
    
    y = y - 22
    
    local delaySlider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    delaySlider:SetPoint("TOPLEFT", 10, y)
    delaySlider:SetSize(PANEL_WIDTH - 80, 17)
    delaySlider:SetMinMaxValues(0, 10)
    delaySlider:SetValueStep(1)
    delaySlider:SetObeyStepOnDrag(true)
    delaySlider:SetValue(currentDelay)
    delaySlider.Low:SetText("0")
    delaySlider.High:SetText("10")
    delaySlider.Text:SetText("")
    delaySlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value + 0.5)
        General:SetVisibilitySetting(frameKey, "fadeDelay", value)
        delayValue:SetText(tostring(value))
    end)
    
    y = y - 35
    
    -- Fade alpha
    local alphaLabel = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    alphaLabel:SetPoint("TOPLEFT", 10, y)
    alphaLabel:SetText("Fade Alpha:")
    
    local currentAlpha = self:GetVisibilitySetting(frameKey, "fadeAlpha") or 0.5
    local alphaValue = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    alphaValue:SetPoint("LEFT", alphaLabel, "RIGHT", 5, 0)
    alphaValue:SetText(string.format("%.1f", currentAlpha))
    
    y = y - 22
    
    local alphaSlider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    alphaSlider:SetPoint("TOPLEFT", 10, y)
    alphaSlider:SetSize(PANEL_WIDTH - 80, 17)
    alphaSlider:SetMinMaxValues(0, 1)
    alphaSlider:SetValueStep(0.1)
    alphaSlider:SetObeyStepOnDrag(true)
    alphaSlider:SetValue(currentAlpha)
    alphaSlider.Low:SetText("0")
    alphaSlider.High:SetText("1")
    alphaSlider.Text:SetText("")
    alphaSlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value * 10 + 0.5) / 10
        General:SetVisibilitySetting(frameKey, "fadeAlpha", value)
        alphaValue:SetText(string.format("%.1f", value))
    end)
end

-- ============================================================================
-- AFK MODE PANEL
-- ============================================================================

function General:CreateAFKPanel()
    if afkPanel then return afkPanel end
    
    local panel = CreateFrame("Frame", "TweaksUI_AFK_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:Hide()
    
    panel:SetScript("OnHide", function()
        if isTestingAFK then
            General:ExitAFKMode()
        end
    end)
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("AFK Mode")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() panel:Hide() end)
    
    local y = -50
    
    local enableCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    enableCb:SetPoint("TOPLEFT", 20, y)
    enableCb:SetSize(24, 24)
    enableCb:SetChecked(self:GetSetting("afkModeEnabled"))
    enableCb.text:SetText("Enable AFK Mode")
    enableCb.text:SetFontObject("GameFontNormal")
    enableCb:SetScript("OnClick", function(self)
        General:SetSetting("afkModeEnabled", self:GetChecked())
    end)
    
    y = y - 35
    
    local desc = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    desc:SetPoint("TOPLEFT", 20, y)
    desc:SetWidth(PANEL_WIDTH - 60)
    desc:SetText("|cff888888Automatically hides all UI elements when you go AFK.\nMove or press any key to restore the UI.|r")
    desc:SetJustifyH("LEFT")
    
    y = y - 50
    
    local optionsLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    optionsLabel:SetPoint("TOPLEFT", 10, y)
    optionsLabel:SetText("|cffaaaaaa— Options —|r")
    
    y = y - 25
    
    local fadeCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    fadeCb:SetPoint("TOPLEFT", 20, y)
    fadeCb:SetSize(24, 24)
    fadeCb:SetChecked(self:GetSetting("afkFadeAnimation"))
    fadeCb.text:SetText("Fade Animation")
    fadeCb.text:SetFontObject("GameFontNormal")
    fadeCb:SetScript("OnClick", function(self)
        General:SetSetting("afkFadeAnimation", self:GetChecked())
    end)
    
    y = y - 35
    
    local durationLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    durationLabel:SetPoint("TOPLEFT", 20, y)
    durationLabel:SetText("Fade Duration")
    
    local durationValue = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    durationValue:SetPoint("LEFT", durationLabel, "RIGHT", 10, 0)
    durationValue:SetText(string.format("%.1fs", self:GetSetting("afkFadeDuration")))
    
    y = y - 25
    
    local fadeSlider = CreateFrame("Slider", nil, panel, "OptionsSliderTemplate")
    fadeSlider:SetPoint("TOPLEFT", 20, y)
    fadeSlider:SetSize(PANEL_WIDTH - 80, 17)
    fadeSlider:SetMinMaxValues(0.1, 2.0)
    fadeSlider:SetValueStep(0.1)
    fadeSlider:SetObeyStepOnDrag(true)
    fadeSlider:SetValue(self:GetSetting("afkFadeDuration"))
    fadeSlider.Low:SetText("0.1s")
    fadeSlider.High:SetText("2.0s")
    fadeSlider.Text:SetText("")
    fadeSlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value * 10 + 0.5) / 10
        General:SetSetting("afkFadeDuration", value)
        durationValue:SetText(string.format("%.1fs", value))
    end)
    
    y = y - 40
    
    local spinCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    spinCb:SetPoint("TOPLEFT", 20, y)
    spinCb:SetSize(24, 24)
    spinCb:SetChecked(self:GetSetting("afkCameraSpin"))
    spinCb.text:SetText("Slowly Spin Camera")
    spinCb.text:SetFontObject("GameFontNormal")
    spinCb:SetScript("OnClick", function(self)
        General:SetSetting("afkCameraSpin", self:GetChecked())
    end)
    
    y = y - 35
    
    local spinLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    spinLabel:SetPoint("TOPLEFT", 20, y)
    spinLabel:SetText("Spin Speed")
    
    local spinValue = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    spinValue:SetPoint("LEFT", spinLabel, "RIGHT", 10, 0)
    spinValue:SetText(string.format("%.2f", self:GetSetting("afkCameraSpinSpeed") or 0.05))
    
    y = y - 25
    
    local spinSlider = CreateFrame("Slider", nil, panel, "OptionsSliderTemplate")
    spinSlider:SetPoint("TOPLEFT", 20, y)
    spinSlider:SetSize(PANEL_WIDTH - 80, 17)
    spinSlider:SetMinMaxValues(0.01, 0.2)
    spinSlider:SetValueStep(0.01)
    spinSlider:SetObeyStepOnDrag(true)
    spinSlider:SetValue(self:GetSetting("afkCameraSpinSpeed") or 0.05)
    spinSlider.Low:SetText("Slow")
    spinSlider.High:SetText("Fast")
    spinSlider.Text:SetText("")
    spinSlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value * 100 + 0.5) / 100
        General:SetSetting("afkCameraSpinSpeed", value)
        spinValue:SetText(string.format("%.2f", value))
    end)
    
    y = y - 40
    
    local nameplateCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    nameplateCb:SetPoint("TOPLEFT", 20, y)
    nameplateCb:SetSize(24, 24)
    nameplateCb:SetChecked(self:GetSetting("afkHideNameplates"))
    nameplateCb.text:SetText("Hide Nameplates")
    nameplateCb.text:SetFontObject("GameFontNormal")
    nameplateCb:SetScript("OnClick", function(self)
        General:SetSetting("afkHideNameplates", self:GetChecked())
    end)
    
    y = y - 40
    
    local keepLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    keepLabel:SetPoint("TOPLEFT", 10, y)
    keepLabel:SetText("|cffaaaaaa— Keep Visible —|r")
    
    y = y - 25
    
    local minimapCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    minimapCb:SetPoint("TOPLEFT", 20, y)
    minimapCb:SetSize(24, 24)
    minimapCb:SetChecked(self:GetSetting("afkKeepMinimap"))
    minimapCb.text:SetText("Keep Minimap")
    minimapCb.text:SetFontObject("GameFontNormal")
    minimapCb:SetScript("OnClick", function(self)
        General:SetSetting("afkKeepMinimap", self:GetChecked())
    end)
    
    y = y - CHECKBOX_SPACING
    
    local chatCb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    chatCb:SetPoint("TOPLEFT", 20, y)
    chatCb:SetSize(24, 24)
    chatCb:SetChecked(self:GetSetting("afkKeepChat"))
    chatCb.text:SetText("Keep Chat")
    chatCb.text:SetFontObject("GameFontNormal")
    chatCb:SetScript("OnClick", function(self)
        General:SetSetting("afkKeepChat", self:GetChecked())
    end)
    
    y = y - 40
    
    local testBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    testBtn:SetPoint("TOPLEFT", 20, y)
    testBtn:SetSize(150, 26)
    testBtn:SetText("Test AFK Mode")
    testBtn:SetScript("OnClick", function()
        if General:IsInAFKMode() then
            General:ExitAFKMode()
        else
            General:EnterAFKMode(true)
        end
    end)
    
    afkPanel = panel
    return panel
end

-- ============================================================================
-- MINIMAP SETTINGS PANEL
-- ============================================================================

-- Helper to create a Leatrix warning for minimap features
local function CreateLeatrixMinimapWarning(parent, y)
    local conflicts = General:GetLeatrixConflicts()
    if not conflicts then return y end
    
    -- Check if any minimap conflicts exist
    local hasMinimapConflicts = conflicts.squareMinimap or conflicts.minimapModder or 
                                 conflicts.decorations or conflicts.minimapScale or 
                                 conflicts.buttonCollector
    if not hasMinimapConflicts then return y end
    
    local warning = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    warning:SetPoint("TOPLEFT", 15, y)
    warning:SetWidth(PANEL_WIDTH - 40)
    warning:SetJustifyH("LEFT")
    warning:SetText("|cffff9900⚠ Leatrix Plus|r is managing some minimap features.\nThose options are disabled below.")
    warning:SetTextColor(1, 0.8, 0.3)
    
    return y - 45
end

function General:CreateMinimapPanel()
    if minimapPanel then return minimapPanel end
    
    local panel = CreateFrame("Frame", "TweaksUI_Minimap_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:Hide()
    
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Minimap Settings")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() panel:Hide() end)
    
    -- Create scroll frame for content
    local scrollFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10)
    
    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(PANEL_WIDTH - 50, 600)  -- Height will expand as needed
    scrollFrame:SetScrollChild(content)
    
    local y = -5
    
    -- Leatrix warning (if applicable)
    y = CreateLeatrixMinimapWarning(content, y)
    
    -- ========== Button Collector Section (at top) ==========
    local collectorLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    collectorLabel:SetPoint("TOPLEFT", 5, y)
    collectorLabel:SetText("Button Collector")
    collectorLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Enable Button Collector
    local collectorCb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
    collectorCb:SetPoint("TOPLEFT", 10, y)
    collectorCb:SetSize(24, 24)
    collectorCb:SetChecked(self:GetButtonCollectorSetting("enabled"))
    collectorCb.text:SetText("Collect Addon Buttons")
    collectorCb.text:SetFontObject("GameFontNormal")
    
    if self:IsLeatrixManaging("buttonCollector") then
        collectorCb:Disable()
        collectorCb:SetAlpha(0.5)
        collectorCb.text:SetTextColor(0.5, 0.5, 0.5)
        collectorCb:SetScript("OnEnter", function(cb)
            GameTooltip:SetOwner(cb, "ANCHOR_RIGHT")
            GameTooltip:SetText("Managed by Leatrix Plus", 1, 0.8, 0.3)
            GameTooltip:AddLine("Disable 'Hide addon buttons' in Leatrix Plus to use TweaksUI's version.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        collectorCb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        collectorCb:SetScript("OnClick", function(cb)
            General:SetButtonCollectorSetting("enabled", cb:GetChecked())
            General:ApplyButtonCollector()
        end)
    end
    
    y = y - 20
    
    -- Description text
    local collectorDesc = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    collectorDesc:SetPoint("TOPLEFT", 30, y)
    collectorDesc:SetWidth(PANEL_WIDTH - 80)
    collectorDesc:SetJustifyH("LEFT")
    collectorDesc:SetText("Right-click the minimap to open/close the button drawer.")
    collectorDesc:SetTextColor(0.6, 0.6, 0.6)
    
    y = y - 25
    
    -- ========== Shape Section ==========
    local shapeLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    shapeLabel:SetPoint("TOPLEFT", 5, y)
    shapeLabel:SetText("Shape")
    shapeLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Square Minimap
    local squareCb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
    squareCb:SetPoint("TOPLEFT", 10, y)
    squareCb:SetSize(24, 24)
    squareCb:SetChecked(self:GetMinimapSetting("squareShape"))
    squareCb.text:SetText("Square Minimap")
    squareCb.text:SetFontObject("GameFontNormal")
    
    if self:IsLeatrixManaging("squareMinimap") then
        squareCb:Disable()
        squareCb:SetAlpha(0.5)
        squareCb.text:SetTextColor(0.5, 0.5, 0.5)
        squareCb:SetScript("OnEnter", function(cb)
            GameTooltip:SetOwner(cb, "ANCHOR_RIGHT")
            GameTooltip:SetText("Managed by Leatrix Plus", 1, 0.8, 0.3)
            GameTooltip:AddLine("Disable in Leatrix Plus to use TweaksUI's version.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        squareCb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        squareCb:SetScript("OnClick", function(cb)
            General:SetMinimapSetting("squareShape", cb:GetChecked())
            General:ApplyMinimapShape()
        end)
        squareCb:SetScript("OnEnter", function(cb)
            GameTooltip:SetOwner(cb, "ANCHOR_RIGHT")
            GameTooltip:SetText("Square Minimap")
            GameTooltip:AddLine("Changes the minimap shape from circular to square.", 1, 1, 1, true)
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Note: Incompatible with 'Rotate Minimap' setting in Edit Mode.", 1, 0.5, 0.5, true)
            GameTooltip:Show()
        end)
        squareCb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    
    y = y - 35
    
    -- ========== Scale Section ==========
    local scaleLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    scaleLabel:SetPoint("TOPLEFT", 5, y)
    scaleLabel:SetText("Scale")
    scaleLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    local scaleManaged = self:IsLeatrixManaging("minimapScale")
    
    local scaleValueLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    scaleValueLabel:SetPoint("TOPLEFT", 10, y)
    scaleValueLabel:SetText("Minimap Scale:")
    
    local currentScale = self:GetMinimapSetting("scale") or 1.0
    local scaleValue = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    scaleValue:SetPoint("LEFT", scaleValueLabel, "RIGHT", 5, 0)
    scaleValue:SetText(string.format("%.1f", currentScale))
    
    y = y - 25
    
    local scaleSlider = CreateFrame("Slider", nil, content, "OptionsSliderTemplate")
    scaleSlider:SetPoint("TOPLEFT", 10, y)
    scaleSlider:SetSize(PANEL_WIDTH - 80, 17)
    scaleSlider:SetMinMaxValues(0.5, 2.0)
    scaleSlider:SetValueStep(0.1)
    scaleSlider:SetObeyStepOnDrag(true)
    scaleSlider:SetValue(currentScale)
    scaleSlider.Low:SetText("0.5")
    scaleSlider.High:SetText("2.0")
    scaleSlider.Text:SetText("")
    
    if scaleManaged then
        scaleSlider:Disable()
        scaleSlider:SetAlpha(0.5)
        scaleValueLabel:SetTextColor(0.5, 0.5, 0.5)
        scaleValue:SetTextColor(0.5, 0.5, 0.5)
    else
        scaleSlider:SetScript("OnValueChanged", function(slider, value)
            value = math.floor(value * 10 + 0.5) / 10
            General:SetMinimapSetting("scale", value)
            scaleValue:SetText(string.format("%.1f", value))
            General:ApplyMinimapScale()
        end)
    end
    
    y = y - 45
    
    -- ========== Hide Elements Section ==========
    local hideLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hideLabel:SetPoint("TOPLEFT", 5, y)
    hideLabel:SetText("Hide Elements")
    hideLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    local decorationsManaged = self:IsLeatrixManaging("decorations")
    
    -- Decoration checkboxes
    local decorationOptions = {
        { key = "zoomButtons", label = "Zoom Buttons" },
        { key = "border", label = "Border" },
        { key = "zoneText", label = "Zone Text" },
        { key = "zoneTextBackground", label = "Zone Text Background" },
        { key = "calendar", label = "Calendar Button" },
        { key = "tracking", label = "Tracking Button" },
        { key = "mail", label = "Mail Icon" },
        { key = "craftingOrder", label = "Crafting Order Icon" },
        { key = "instanceDifficulty", label = "Instance Difficulty" },
        { key = "clock", label = "Clock" },
        { key = "expansionButton", label = "Expansion Button" },
    }
    
    for _, opt in ipairs(decorationOptions) do
        local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 10, y)
        cb:SetSize(24, 24)
        cb:SetChecked(self:GetMinimapHideSetting(opt.key))
        cb.text:SetText(opt.label)
        cb.text:SetFontObject("GameFontNormal")
        
        if decorationsManaged then
            cb:Disable()
            cb:SetAlpha(0.5)
            cb.text:SetTextColor(0.5, 0.5, 0.5)
        else
            cb:SetScript("OnClick", function(checkbox)
                General:SetMinimapHideSetting(opt.key, checkbox:GetChecked())
                General:ApplyDecorationSetting(opt.key)
                -- Also update custom border if this is the border option
                if opt.key == "border" then
                    General:ApplyMinimapShape()
                end
            end)
        end
        
        y = y - 26
    end
    
    if decorationsManaged then
        local managedNote = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        managedNote:SetPoint("TOPLEFT", 10, y)
        managedNote:SetText("|cff888888Managed by Leatrix Plus|r")
        y = y - 20
    end
    
    y = y - 15
    
    -- ========== Custom Border Section (for square minimap) ==========
    local borderSectionLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    borderSectionLabel:SetPoint("TOPLEFT", 5, y)
    borderSectionLabel:SetText("Square Border Style")
    borderSectionLabel:SetTextColor(0.8, 0.8, 0.8)
    
    y = y - 25
    
    -- Border Width
    local borderWidthLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    borderWidthLabel:SetPoint("TOPLEFT", 10, y)
    borderWidthLabel:SetText("Border Width:")
    
    local borderWidthValue = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    borderWidthValue:SetPoint("LEFT", borderWidthLabel, "RIGHT", 5, 0)
    
    y = y - 22
    
    local borderWidthSlider = CreateFrame("Slider", nil, content, "OptionsSliderTemplate")
    borderWidthSlider:SetPoint("TOPLEFT", 10, y)
    borderWidthSlider:SetSize(PANEL_WIDTH - 80, 17)
    borderWidthSlider:SetMinMaxValues(0, 6)
    borderWidthSlider:SetValueStep(1)
    borderWidthSlider:SetObeyStepOnDrag(true)
    borderWidthSlider.Low:SetText("0")
    borderWidthSlider.High:SetText("6")
    borderWidthSlider.Text:SetText("")
    borderWidthSlider:SetScript("OnValueChanged", function(slider, value)
        value = math.floor(value + 0.5)
        General:SetCustomBorderSetting("width", value)
        borderWidthValue:SetText(tostring(value) .. "px")
        General:UpdateCustomMinimapBorder()
    end)
    
    -- Store references for updates
    panel.borderWidthSlider = borderWidthSlider
    panel.borderWidthValue = borderWidthValue
    
    -- Function to update width display from settings
    local function UpdateWidthDisplay()
        local width = General:GetCustomBorderSetting("width") or 2
        borderWidthSlider:SetValue(width)
        borderWidthValue:SetText(tostring(width) .. "px")
    end
    panel.UpdateWidthDisplay = UpdateWidthDisplay
    
    -- Set initial values
    UpdateWidthDisplay()
    
    y = y - 35
    
    -- Border Color
    local borderColorLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    borderColorLabel:SetPoint("TOPLEFT", 10, y)
    borderColorLabel:SetText("Border Color:")
    
    local colorSwatch = CreateFrame("Button", nil, content)
    colorSwatch:SetPoint("LEFT", borderColorLabel, "RIGHT", 10, 0)
    colorSwatch:SetSize(24, 24)
    
    -- Border first (BORDER layer - behind)
    local swatchBorder = colorSwatch:CreateTexture(nil, "BORDER")
    swatchBorder:SetPoint("TOPLEFT", -1, 1)
    swatchBorder:SetPoint("BOTTOMRIGHT", 1, -1)
    swatchBorder:SetColorTexture(0.3, 0.3, 0.3, 1)
    
    -- Color on top (OVERLAY layer - in front)
    local swatchColor = colorSwatch:CreateTexture(nil, "OVERLAY")
    swatchColor:SetAllPoints()
    
    -- Get current color from settings
    local color = self:GetCustomBorderSetting("color")
    if not color or type(color) ~= "table" then
        color = { r = 0.4, g = 0.4, b = 0.4 }
    end
    swatchColor:SetColorTexture(color.r or 0.4, color.g or 0.4, color.b or 0.4, 1)
    
    -- Store reference on panel
    panel.swatchColor = swatchColor
    
    -- Function to update swatch color from settings
    function panel:UpdateSwatchColor()
        local c = General:GetCustomBorderSetting("color")
        if not c or type(c) ~= "table" then
            c = { r = 0.4, g = 0.4, b = 0.4 }
        end
        if self.swatchColor then
            self.swatchColor:SetColorTexture(c.r or 0.4, c.g or 0.4, c.b or 0.4, 1)
        end
    end
    
    -- Update color when panel shows (combined with width update)
    panel:SetScript("OnShow", function(self)
        if self.UpdateSwatchColor then self:UpdateSwatchColor() end
        if self.UpdateWidthDisplay then self.UpdateWidthDisplay() end
    end)
    
    colorSwatch:SetScript("OnClick", function()
        local currentColor = General:GetCustomBorderSetting("color")
        if not currentColor or type(currentColor) ~= "table" then
            currentColor = { r = 0.4, g = 0.4, b = 0.4 }
        end
        local prev = { r = currentColor.r or 0.4, g = currentColor.g or 0.4, b = currentColor.b or 0.4 }
        ColorPickerFrame:SetupColorPickerAndShow({
            r = prev.r, g = prev.g, b = prev.b,
            swatchFunc = function()
                local r, g, b = ColorPickerFrame:GetColorRGB()
                General:SetCustomBorderSetting("color", { r = r, g = g, b = b })
                swatchColor:SetColorTexture(r, g, b, 1)
                General:UpdateCustomMinimapBorder()
            end,
            cancelFunc = function()
                General:SetCustomBorderSetting("color", { r = prev.r, g = prev.g, b = prev.b })
                swatchColor:SetColorTexture(prev.r, prev.g, prev.b, 1)
                General:UpdateCustomMinimapBorder()
            end,
        })
    end)
    
    colorSwatch:SetScript("OnEnter", function(btn)
        GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
        GameTooltip:SetText("Click to choose border color")
        GameTooltip:Show()
    end)
    colorSwatch:SetScript("OnLeave", function() GameTooltip:Hide() end)
    
    y = y - 30
    
    -- Update content height
    content:SetHeight(math.abs(y) + 20)
    
    minimapPanel = panel
    return panel
end

-- ============================================================================
-- LEGACY SUPPORT
-- ============================================================================

function General:ShowSettingsPanel(parentPanel)
    self:ShowHub(parentPanel)
end

function General:HideSettingsPanel()
    self:HideHub()
end

return General
