-- ============================================================================
-- TweaksUI: Nameplates Module
-- Complete CVar controls and highlights for Blizzard nameplates
-- All settings apply in real-time with info tooltips
-- ============================================================================

local ADDON_NAME, TweaksUI = ...

local Nameplates = TweaksUI.ModuleManager:NewModule(
    TweaksUI.MODULE_IDS.NAMEPLATES,
    "Nameplates",
    "CVar controls and highlights for nameplates"
)

TweaksUI.Nameplates = Nameplates

-- ============================================================================
-- LOCAL VARIABLES
-- ============================================================================

local settings = nil
local nameplatesHub = nil
local settingsPanels = {}
local currentOpenPanel = nil
local enhancedNameplates = {}
local originalCVars = {}
local infoTooltip = nil

-- ============================================================================
-- CONSTANTS (matching other TweaksUI modules)
-- ============================================================================

local HUB_WIDTH = 220
local PANEL_WIDTH = 420
local BUTTON_HEIGHT = 28
local BUTTON_SPACING = 6

-- Dark backdrop (same as Cooldowns/CastBars)
local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

-- ============================================================================
-- CVAR DEFINITIONS WITH DESCRIPTIONS
-- ============================================================================

local CVAR_INFO = {
    -- Visibility
    nameplateShowAll = {
        default = true,
        type = "bool",
        desc = "Show nameplates at all times.\n\nWhen DISABLED, only your current target's nameplate shows out of combat.\n\nMany other nameplate settings require this to be ON to work properly."
    },
    nameplateShowFriends = {
        default = false,
        type = "bool",
        desc = "Display nameplates above friendly players."
    },
    nameplateShowFriendlyNPCs = {
        default = false,
        type = "bool",
        desc = "Always show nameplates for friendly NPCs, not just when targeted."
    },
    nameplateShowEnemies = {
        default = true,
        type = "bool",
        desc = "Display nameplates above enemy players."
    },
    nameplateShowEnemyMinions = {
        default = true,
        type = "bool",
        desc = "Display nameplates for enemy minions (warlock pets, etc)."
    },
    nameplateShowEnemyGuardians = {
        default = true,
        type = "bool",
        desc = "Display nameplates for enemy guardians (totems, treants, etc)."
    },
    nameplateShowEnemyMinus = {
        default = true,
        type = "bool",
        desc = "Display nameplates for minor/trivial enemies (marked with - instead of skull)."
    },
    nameplateShowEnemyPets = {
        default = true,
        type = "bool",
        desc = "Display nameplates for enemy hunter/warlock pets."
    },
    nameplateShowEnemyTotems = {
        default = true,
        type = "bool",
        desc = "Display nameplates for enemy totems."
    },
    nameplateShowDebuffsOnFriendly = {
        default = true,
        type = "bool",
        desc = "Show debuff icons on friendly nameplates."
    },
    clampTargetNameplateToScreen = {
        default = true,
        type = "bool",
        desc = "Keep your target's nameplate visible at the edge of the screen even when the unit would be off-screen."
    },
    
    -- Stacking/Motion
    nameplateMotion = {
        default = 1,
        type = "dropdown",
        options = { {text = "Overlapping", value = 0}, {text = "Stacking", value = 1} },
        desc = "Overlapping: Nameplates stay above their units but may overlap.\n\nStacking: Nameplates spread out to avoid overlapping.\n\nNOTE: This setting cannot be changed while in combat."
    },
    nameplateMotionSpeed = {
        default = 0.025,
        type = "slider",
        min = 0.01, max = 0.1, step = 0.005,
        desc = "How fast nameplates move when stacking/spreading. Higher = faster repositioning."
    },
    nameplateOverlapH = {
        default = 0.8,
        type = "slider",
        min = 0.0, max = 2.0, step = 0.1,
        desc = "Horizontal overlap threshold. Higher values allow more horizontal overlap before spreading."
    },
    nameplateOverlapV = {
        default = 1.1,
        type = "slider",
        min = 0.0, max = 2.0, step = 0.1,
        desc = "Vertical overlap threshold. Higher values allow more vertical overlap before spreading."
    },
    
    -- Distance
    nameplateMaxDistance = {
        default = 60,
        type = "slider",
        min = 20, max = 60, step = 5,
        desc = "Maximum distance at which nameplates are visible.\n\nNOTE: Blizzard hard-caps this at 60 yards. Values above 60 will not work.",
        format = "%d"
    },
    nameplateTargetBehindMaxDistance = {
        default = 40,
        type = "slider",
        min = 10, max = 60, step = 5,
        desc = "Maximum distance for your target's nameplate when behind you.",
        format = "%d"
    },
    
    -- Scale
    nameplateGlobalScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 2.0, step = 0.05,
        desc = "Overall scale multiplier for all nameplates.\n\nNOTE: Some scale changes may require nameplates to refresh (target something new or move away and back) to see the effect."
    },
    nameplateMinScale = {
        default = 0.8,
        type = "slider",
        min = 0.5, max = 1.5, step = 0.05,
        desc = "Scale for nameplates at far distance.\n\nRequires Min Scale Distance to be different from Max Scale Distance to see the effect."
    },
    nameplateMaxScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 1.5, step = 0.05,
        desc = "Scale for nameplates at close distance.\n\nRequires Min Scale Distance to be different from Max Scale Distance to see the effect."
    },
    nameplateMinScaleDistance = {
        default = 10,
        type = "slider",
        min = 0, max = 60, step = 5,
        desc = "Distance (from max) at which nameplates reach minimum scale.\n\nExample: If Max Distance is 60 and this is 10, nameplates at 50+ yards will be at Min Scale.",
        format = "%d"
    },
    nameplateMaxScaleDistance = {
        default = 10,
        type = "slider",
        min = 0, max = 60, step = 5,
        desc = "Distance from camera at which nameplates reach maximum scale.\n\nNameplates within this distance will be at Max Scale.",
        format = "%d"
    },
    nameplateSelectedScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 2.0, step = 0.05,
        desc = "Additional scale multiplier for your current target's nameplate."
    },
    nameplateLargerScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 2.0, step = 0.05,
        desc = "Scale multiplier for 'larger' nameplates (bosses, important NPCs)."
    },
    NamePlateHorizontalScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 2.0, step = 0.05,
        desc = "Horizontal stretch factor for all nameplates."
    },
    NamePlateVerticalScale = {
        default = 1.0,
        type = "slider",
        min = 0.5, max = 2.0, step = 0.05,
        desc = "Vertical stretch factor for all nameplates."
    },
    
    -- Alpha
    nameplateMinAlpha = {
        default = 0.6,
        type = "slider",
        min = 0.0, max = 1.0, step = 0.05,
        desc = "Alpha (opacity) for nameplates at far distance.\n\nRequires Min Alpha Distance to be different from Max Alpha Distance to see the effect."
    },
    nameplateMaxAlpha = {
        default = 1.0,
        type = "slider",
        min = 0.0, max = 1.0, step = 0.05,
        desc = "Alpha (opacity) for nameplates at close distance.\n\nRequires Min Alpha Distance to be different from Max Alpha Distance to see the effect."
    },
    nameplateMinAlphaDistance = {
        default = 10,
        type = "slider",
        min = 0, max = 60, step = 5,
        desc = "Distance (from max) at which nameplates reach minimum alpha.\n\nExample: If Max Distance is 60 and this is 10, nameplates at 50+ yards will be at Min Alpha.",
        format = "%d"
    },
    nameplateMaxAlphaDistance = {
        default = 40,
        type = "slider",
        min = 0, max = 60, step = 5,
        desc = "Distance from camera at which nameplates reach maximum alpha.\n\nNameplates within this distance will be at Max Alpha.",
        format = "%d"
    },
    nameplateSelectedAlpha = {
        default = 1.0,
        type = "slider",
        min = 0.0, max = 1.0, step = 0.05,
        desc = "Alpha (opacity) for your current target's nameplate."
    },
    nameplateOccludedAlphaMult = {
        default = 0.4,
        type = "slider",
        min = 0.0, max = 1.0, step = 0.05,
        desc = "Alpha multiplier when nameplates are occluded (behind walls or other objects)."
    },
}

-- ============================================================================
-- DEFAULT SETTINGS
-- ============================================================================

local DEFAULT_SETTINGS = {
    enabled = true,
    cvars = {},
    targetHighlight = {
        enabled = true,
        style = "glow",
        color = { 1, 1, 1, 0.6 },
        thickness = 3,
    },
    focusHighlight = {
        enabled = false,
        style = "glow",
        color = { 0.5, 0, 1, 0.6 },
        thickness = 3,
    },
}

-- Populate CVar defaults
for cvar, info in pairs(CVAR_INFO) do
    DEFAULT_SETTINGS.cvars[cvar] = info.default
end

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

local function DeepCopy(orig)
    if type(orig) ~= "table" then return orig end
    local copy = {}
    for k, v in pairs(orig) do
        copy[k] = DeepCopy(v)
    end
    return copy
end

local function SaveSettings()
    TweaksUI.Database:SetModuleSettings(TweaksUI.MODULE_IDS.NAMEPLATES, settings)
end

local function DeepMerge(dest, source)
    for key, value in pairs(source) do
        if type(value) == "table" then
            if type(dest[key]) == "table" then
                DeepMerge(dest[key], value)
            else
                dest[key] = DeepCopy(value)
            end
        else
            dest[key] = value
        end
    end
end

local function EnsureSettings()
    if not settings then
        -- Start with defaults
        settings = DeepCopy(DEFAULT_SETTINGS)
        
        -- Load from database and merge saved settings
        local dbSettings = TweaksUI.Database:GetModuleSettings(TweaksUI.MODULE_IDS.NAMEPLATES)
        if dbSettings and next(dbSettings) then
            DeepMerge(settings, dbSettings)
        end
        
        -- Save back to ensure all defaults are stored
        SaveSettings()
    end
end

-- ============================================================================
-- NAMEPLATE ADDON DETECTION
-- ============================================================================

-- Check if addon is enabled and will load (not just currently loaded)
local function WillAddonLoad(addonName)
    local name = C_AddOns.GetAddOnInfo(addonName)
    if name then
        local loadable, reason = C_AddOns.IsAddOnLoadable(addonName)
        return loadable or C_AddOns.IsAddOnLoaded(addonName)
    end
    return false
end

-- Platynator detection
local function IsPlatynatorInstalled()
    return C_AddOns.DoesAddOnExist("Platynator")
end

local function IsPlatynatorEnabled()
    return WillAddonLoad("Platynator")
end

-- Plater detection
local function IsPlaterInstalled()
    return C_AddOns.DoesAddOnExist("Plater")
end

local function IsPlaterEnabled()
    return WillAddonLoad("Plater")
end

-- Check if any nameplate addon is managing things
local function IsNameplateAddonActive()
    return IsPlatynatorEnabled() or IsPlaterEnabled()
end

-- ============================================================================
-- INFO TOOLTIP SYSTEM
-- ============================================================================

local function CreateInfoTooltip()
    if infoTooltip then return end
    
    local tooltip = CreateFrame("Frame", "TweaksUI_Nameplates_InfoTooltip", UIParent, "BackdropTemplate")
    tooltip:SetSize(220, 80)
    tooltip:SetFrameStrata("TOOLTIP")
    tooltip:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    tooltip:SetBackdropColor(0.1, 0.1, 0.1, 0.95)
    tooltip:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    tooltip:Hide()
    
    local text = tooltip:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    text:SetPoint("TOPLEFT", 8, -8)
    text:SetPoint("BOTTOMRIGHT", -8, 8)
    text:SetJustifyH("LEFT")
    text:SetJustifyV("TOP")
    text:SetWordWrap(true)
    tooltip.text = text
    
    infoTooltip = tooltip
end

local function ShowInfoTooltip(anchor, desc)
    CreateInfoTooltip()
    infoTooltip.text:SetText(desc)
    local height = math.max(50, infoTooltip.text:GetStringHeight() + 16)
    infoTooltip:SetHeight(height)
    infoTooltip:ClearAllPoints()
    infoTooltip:SetPoint("LEFT", anchor, "RIGHT", 8, 0)
    infoTooltip:Show()
end

local function HideInfoTooltip()
    if infoTooltip then infoTooltip:Hide() end
end

-- ============================================================================
-- UI HELPERS (matching TweaksUI patterns)
-- ============================================================================

local function CreateHeader(parent, yOffset, text)
    yOffset = yOffset - 8
    local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    header:SetPoint("TOPLEFT", 5, yOffset)
    header:SetText(text)
    header:SetTextColor(1, 0.82, 0)
    return yOffset - 20
end

local function CreateInfoButton(parent, cvar, xOffset, yOffset)
    local info = CVAR_INFO[cvar]
    if not info or not info.desc then return end
    
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(16, 16)
    btn:SetPoint("TOPLEFT", xOffset, yOffset + 3)
    
    local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    text:SetPoint("CENTER")
    text:SetText("?")
    text:SetTextColor(0.6, 0.6, 0.6)
    btn.text = text
    
    btn:SetScript("OnEnter", function(self)
        self.text:SetTextColor(1, 0.82, 0)
        ShowInfoTooltip(self, info.desc)
    end)
    btn:SetScript("OnLeave", function(self)
        self.text:SetTextColor(0.6, 0.6, 0.6)
        HideInfoTooltip()
    end)
end

local function CreateCVarCheckbox(parent, label, yOffset, cvar, disabled)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", 10, yOffset)
    cb:SetSize(22, 22)
    cb:SetChecked(settings.cvars[cvar])
    
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    labelText:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    labelText:SetText(label)
    
    if disabled then
        cb:Disable()
        labelText:SetTextColor(0.5, 0.5, 0.5)
    else
        labelText:SetTextColor(0.9, 0.9, 0.9)
        cb:SetScript("OnClick", function(self)
            settings.cvars[cvar] = self:GetChecked()
            -- Only apply CVar if no nameplate addon is managing things
            if not IsNameplateAddonActive() then
                SetCVar(cvar, settings.cvars[cvar] and 1 or 0)
            end
            SaveSettings()
        end)
    end
    
    CreateInfoButton(parent, cvar, PANEL_WIDTH - 55, yOffset)
    
    return yOffset - 24
end

local function CreateCVarSlider(parent, label, yOffset, cvar, disabled)
    local info = CVAR_INFO[cvar]
    local formatStr = info.format or "%.2f"
    
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    labelText:SetPoint("TOPLEFT", 10, yOffset)
    labelText:SetText(label)
    
    if disabled then
        labelText:SetTextColor(0.5, 0.5, 0.5)
    else
        labelText:SetTextColor(0.9, 0.9, 0.9)
    end
    
    CreateInfoButton(parent, cvar, PANEL_WIDTH - 55, yOffset)
    
    yOffset = yOffset - 16
    
    local slider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", 10, yOffset)
    slider:SetSize(PANEL_WIDTH - 80, 17)
    slider:SetMinMaxValues(info.min, info.max)
    slider:SetValueStep(info.step)
    slider:SetObeyStepOnDrag(true)
    slider:SetValue(settings.cvars[cvar] or info.default)
    
    slider.Low:SetText(tostring(info.min))
    slider.High:SetText(tostring(info.max))
    slider.Text:SetText(string.format(formatStr, settings.cvars[cvar] or info.default))
    
    if disabled then
        slider:Disable()
        slider:SetAlpha(0.5)
    else
        slider:SetScript("OnValueChanged", function(self, value)
            value = math.floor(value / info.step + 0.5) * info.step
            settings.cvars[cvar] = value
            -- Only apply CVar if no nameplate addon is managing things
            if not IsNameplateAddonActive() then
                SetCVar(cvar, value)
            end
            self.Text:SetText(string.format(formatStr, value))
            SaveSettings()
        end)
    end
    
    return yOffset - 28
end

local function CreateCVarDropdown(parent, label, yOffset, cvar, disabled)
    local info = CVAR_INFO[cvar]
    
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    labelText:SetPoint("TOPLEFT", 10, yOffset)
    labelText:SetText(label)
    
    if disabled then
        labelText:SetTextColor(0.5, 0.5, 0.5)
    else
        labelText:SetTextColor(0.9, 0.9, 0.9)
    end
    
    CreateInfoButton(parent, cvar, PANEL_WIDTH - 55, yOffset)
    
    local dropdown = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate")
    dropdown:SetPoint("TOPLEFT", 100, yOffset + 5)
    UIDropDownMenu_SetWidth(dropdown, 130)
    
    local function GetDisplayText()
        local val = settings.cvars[cvar]
        for _, opt in ipairs(info.options) do
            if opt.value == val then return opt.text end
        end
        return "Unknown"
    end
    
    UIDropDownMenu_SetText(dropdown, GetDisplayText())
    
    if disabled then
        UIDropDownMenu_DisableDropDown(dropdown)
    else
        UIDropDownMenu_Initialize(dropdown, function()
            for _, opt in ipairs(info.options) do
                local menuInfo = UIDropDownMenu_CreateInfo()
                menuInfo.text = opt.text
                menuInfo.checked = settings.cvars[cvar] == opt.value
                menuInfo.func = function()
                    settings.cvars[cvar] = opt.value
                    -- Only apply CVar if no nameplate addon is managing things
                    if not IsNameplateAddonActive() then
                        SetCVar(cvar, opt.value)
                    end
                    UIDropDownMenu_SetText(dropdown, opt.text)
                    SaveSettings()
                end
                UIDropDownMenu_AddButton(menuInfo)
            end
        end)
    end
    
    return yOffset - 32
end

-- ============================================================================
-- CVAR MANAGEMENT
-- ============================================================================

local function ApplyCVars()
    if not settings or not settings.cvars then return end
    
    -- Skip applying CVars if a nameplate addon is active
    if IsNameplateAddonActive() then return end
    
    for cvar, value in pairs(settings.cvars) do
        if originalCVars[cvar] == nil then
            originalCVars[cvar] = GetCVar(cvar)
        end
        if type(value) == "boolean" then
            SetCVar(cvar, value and 1 or 0)
        else
            SetCVar(cvar, value)
        end
    end
end

local function RestoreCVars()
    for cvar, value in pairs(originalCVars) do
        SetCVar(cvar, value)
    end
    originalCVars = {}
end

-- ============================================================================
-- HIGHLIGHT SYSTEM
-- ============================================================================

local function CreateHighlightFrame(nameplate)
    local highlight = CreateFrame("Frame", nil, nameplate)
    highlight:SetAllPoints()
    highlight:SetFrameLevel(nameplate:GetFrameLevel() + 10)
    
    highlight.edges = {}
    for i = 1, 4 do
        highlight.edges[i] = highlight:CreateTexture(nil, "OVERLAY")
        highlight.edges[i]:SetTexture("Interface\\Buttons\\WHITE8x8")
        highlight.edges[i]:Hide()
    end
    return highlight
end

local function ApplyHighlight(highlight, frame, color, thickness, isGlow)
    local r, g, b, a = color[1], color[2], color[3], color[4] or 0.6
    local edges = highlight.edges
    
    if isGlow then
        for i = 1, 4 do edges[i]:SetBlendMode("ADD") end
    else
        for i = 1, 4 do edges[i]:SetBlendMode("BLEND") end
    end
    
    -- Top
    edges[1]:ClearAllPoints()
    edges[1]:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", -thickness, 0)
    edges[1]:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", thickness, 0)
    edges[1]:SetHeight(thickness)
    edges[1]:SetColorTexture(r, g, b, a)
    edges[1]:Show()
    
    -- Bottom
    edges[2]:ClearAllPoints()
    edges[2]:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", -thickness, 0)
    edges[2]:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", thickness, 0)
    edges[2]:SetHeight(thickness)
    edges[2]:SetColorTexture(r, g, b, a)
    edges[2]:Show()
    
    -- Left
    edges[3]:ClearAllPoints()
    edges[3]:SetPoint("TOPRIGHT", frame, "TOPLEFT", 0, 0)
    edges[3]:SetPoint("BOTTOMRIGHT", frame, "BOTTOMLEFT", 0, 0)
    edges[3]:SetWidth(thickness)
    edges[3]:SetColorTexture(r, g, b, a)
    edges[3]:Show()
    
    -- Right
    edges[4]:ClearAllPoints()
    edges[4]:SetPoint("TOPLEFT", frame, "TOPRIGHT", 0, 0)
    edges[4]:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", 0, 0)
    edges[4]:SetWidth(thickness)
    edges[4]:SetColorTexture(r, g, b, a)
    edges[4]:Show()
end

local function HideHighlight(highlight)
    if highlight and highlight.edges then
        for i = 1, 4 do highlight.edges[i]:Hide() end
    end
end

local function GetHealthBar(unitFrame)
    if unitFrame.HealthBarsContainer and unitFrame.HealthBarsContainer.healthBar then
        return unitFrame.HealthBarsContainer.healthBar
    end
    return unitFrame.healthBar
end

local function UpdateHighlights(nameplate, unit)
    local unitFrame = nameplate.UnitFrame
    if not unitFrame then return end
    
    local data = enhancedNameplates[nameplate]
    if not data then return end
    
    HideHighlight(data.highlight)
    
    local healthBar = GetHealthBar(unitFrame)
    if not healthBar then return end
    
    local isTarget = UnitIsUnit(unit, "target")
    local isFocus = UnitIsUnit(unit, "focus")
    
    if isTarget and settings.targetHighlight.enabled then
        local h = settings.targetHighlight
        ApplyHighlight(data.highlight, healthBar, h.color, h.thickness, h.style == "glow")
    elseif isFocus and settings.focusHighlight.enabled then
        local h = settings.focusHighlight
        ApplyHighlight(data.highlight, healthBar, h.color, h.thickness, h.style == "glow")
    end
end

local function RefreshAllHighlights()
    for nameplate, data in pairs(enhancedNameplates) do
        if data.unit then UpdateHighlights(nameplate, data.unit) end
    end
end

-- ============================================================================
-- NAMEPLATE MANAGEMENT
-- ============================================================================

local function EnhanceNameplate(nameplate, unit)
    if not nameplate or not nameplate.UnitFrame then return end
    
    local data = enhancedNameplates[nameplate]
    if not data then
        data = { highlight = CreateHighlightFrame(nameplate) }
        enhancedNameplates[nameplate] = data
    end
    data.unit = unit
    UpdateHighlights(nameplate, unit)
end

local function CleanupNameplate(nameplate)
    local data = enhancedNameplates[nameplate]
    if data then HideHighlight(data.highlight) end
end

-- ============================================================================
-- EVENT HANDLING
-- ============================================================================

local moduleDisabledByAddon = false

local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnEvent", function(self, event, ...)
    -- Skip all processing if module is disabled
    if moduleDisabledByAddon then return end
    
    if event == "NAME_PLATE_UNIT_ADDED" then
        local unit = ...
        local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
        if nameplate and settings and settings.enabled then
            EnhanceNameplate(nameplate, unit)
        end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        local unit = ...
        local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
        if nameplate then CleanupNameplate(nameplate) end
    elseif event == "PLAYER_TARGET_CHANGED" or event == "PLAYER_FOCUS_CHANGED" then
        RefreshAllHighlights()
    end
end)

-- Check if module is disabled due to external addon
local function IsModuleDisabledByAddon()
    return moduleDisabledByAddon
end

-- ============================================================================
-- MODULE LIFECYCLE
-- ============================================================================

-- Hook to modify our button in the main TweaksUI hub
local function ModifyMainHubButton()
    if not IsNameplateAddonActive() then return end
    
    -- Find the main hub panel
    local hubPanel = _G["TweaksUI_HubPanel"]
    if not hubPanel or not hubPanel.moduleRows then return end
    
    -- Get our row (using the module ID constant)
    local ourRow = hubPanel.moduleRows[TweaksUI.MODULE_IDS.NAMEPLATES] or hubPanel.moduleRows["Nameplates"]
    if not ourRow then return end
    
    -- Hide the checkbox so user can't toggle
    if ourRow.checkbox then
        ourRow.checkbox:Hide()
    end
    
    -- Always enable the button so they can view settings
    if ourRow.button then
        ourRow.button:Enable()
        ourRow.button:SetAlpha(1)
        
        -- Override the OnClick to always work (bypass the enabled check)
        ourRow.button:SetScript("OnClick", function()
            if TweaksUI.Settings and TweaksUI.Settings.OpenModuleSettings then
                TweaksUI.Settings:OpenModuleSettings(TweaksUI.MODULE_IDS.NAMEPLATES)
            end
        end)
    end
end

-- Hook Settings:Toggle and Settings:Show to modify our button when hub is shown
local function HookSettingsToggle()
    if not TweaksUI.Settings then return end
    
    -- Hook Toggle
    if TweaksUI.Settings.Toggle then
        local originalToggle = TweaksUI.Settings.Toggle
        TweaksUI.Settings.Toggle = function(self, ...)
            originalToggle(self, ...)
            -- After toggle, modify our button if addon is active
            if IsNameplateAddonActive() then
                C_Timer.After(0.01, ModifyMainHubButton)
            end
        end
    end
    
    -- Hook Show
    if TweaksUI.Settings.Show then
        local originalShow = TweaksUI.Settings.Show
        TweaksUI.Settings.Show = function(self, ...)
            originalShow(self, ...)
            if IsNameplateAddonActive() then
                C_Timer.After(0.01, ModifyMainHubButton)
            end
        end
    end
end

function Nameplates:OnInitialize()
    -- Always initialize settings so the hub works
    EnsureSettings()
    
    -- Check if a nameplate addon will load
    if IsNameplateAddonActive() then
        moduleDisabledByAddon = true
        
        -- Build message about which addon(s) detected
        local addons = {}
        if IsPlatynatorEnabled() then table.insert(addons, "Platynator") end
        if IsPlaterEnabled() then table.insert(addons, "Plater") end
        local addonList = table.concat(addons, " and ")
        
        -- Delay message until UI is ready
        C_Timer.After(3, function()
            TweaksUI:Print("|cffff9900Nameplates module:|r " .. addonList .. " detected.")
            TweaksUI:Print("TweaksUI Nameplates settings are disabled to avoid conflicts.")
            TweaksUI:Print("To use TweaksUI Nameplates, disable " .. addonList .. " and |cff00ff00/reload|r.")
        end)
        
        -- Hook into Settings:Toggle after a short delay to ensure it exists
        C_Timer.After(0.1, HookSettingsToggle)
    end
end

function Nameplates:OnEnable()
    EnsureSettings()
    
    -- Only apply CVars and register events if no nameplate addon is active
    if not moduleDisabledByAddon then
        ApplyCVars()
        
        eventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
        eventFrame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
        eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
        eventFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
        
        -- Process existing nameplates
        for i = 1, 40 do
            local unit = "nameplate" .. i
            if UnitExists(unit) then
                local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
                if nameplate then EnhanceNameplate(nameplate, unit) end
            end
        end
    end
end

function Nameplates:OnDisable()
    RestoreCVars()
    eventFrame:UnregisterAllEvents()
    for nameplate in pairs(enhancedNameplates) do CleanupNameplate(nameplate) end
end

function Nameplates:GetSettings() return settings end
function Nameplates:GetDefaults() return DEFAULT_SETTINGS end

-- ============================================================================
-- NAMEPLATE ADDON OPEN FUNCTIONS
-- ============================================================================

local function OpenPlatynator()
    if IsPlatynatorEnabled() then
        -- Use slash command
        if SlashCmdList and SlashCmdList["PLATYNATOR"] then
            SlashCmdList["PLATYNATOR"]("")
        else
            -- Fallback: execute the slash command directly
            local editBox = ChatFrame1EditBox
            if editBox then
                local oldText = editBox:GetText()
                editBox:SetText("/platynator")
                ChatEdit_SendText(editBox)
                editBox:SetText(oldText)
            end
        end
    end
end

local function OpenPlater()
    if IsPlaterEnabled() then
        -- Try the direct API first
        if _G.Plater and _G.Plater.OpenOptionsPanel then
            _G.Plater.OpenOptionsPanel()
        elseif SlashCmdList and SlashCmdList["PLATER"] then
            SlashCmdList["PLATER"]("")
        else
            -- Fallback: execute the slash command directly
            local editBox = ChatFrame1EditBox
            if editBox then
                local oldText = editBox:GetText()
                editBox:SetText("/plater")
                ChatEdit_SendText(editBox)
                editBox:SetText(oldText)
            end
        end
    end
end

-- ============================================================================
-- HUB CREATION (matching TweaksUI patterns)
-- ============================================================================

local platynatorButton = nil
local platerButton = nil
local hubButtons = {}

function Nameplates:ShowHub(parentPanel)
    EnsureSettings()
    
    if nameplatesHub then
        nameplatesHub:ClearAllPoints()
        nameplatesHub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
        nameplatesHub:Show()
        -- Update addon button states on re-show
        self:UpdateAddonButtons()
        return
    end
    
    local hub = CreateFrame("Frame", "TweaksUI_Nameplates_Hub", UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, 435)
    hub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    
    nameplatesHub = hub
    
    -- Title
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Nameplates")
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        self:HideAllPanels()
    end)
    
    local yOffset = -38
    
    -- Disclaimer text
    local disclaimer = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    disclaimer:SetPoint("TOP", 0, yOffset)
    disclaimer:SetWidth(HUB_WIDTH - 20)
    disclaimer:SetJustifyH("CENTER")
    disclaimer:SetText("|cffaaaaaaThese settings use Blizzard's CVar system. For advanced customization, we recommend |cff00ff00Platynator|r or |cff00ff00Plater|r.|r")
    disclaimer:SetWordWrap(true)
    hub.disclaimer = disclaimer  -- Store reference for updating
    local disclaimerHeight = disclaimer:GetStringHeight()
    yOffset = yOffset - disclaimerHeight - 10
    
    -- Separator after disclaimer
    local sep1 = hub:CreateTexture(nil, "ARTWORK")
    sep1:SetPoint("TOP", 0, yOffset)
    sep1:SetSize(HUB_WIDTH - 20, 1)
    sep1:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 10
    
    -- Section label
    local sectionLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sectionLabel:SetPoint("TOP", 0, yOffset)
    sectionLabel:SetText("|cff888888Settings Panels|r")
    yOffset = yOffset - 16
    
    -- Panel buttons
    local panels = {
        { key = "Visibility", name = "Visibility" },
        { key = "Stacking", name = "Stacking & Distance" },
        { key = "Scale", name = "Scale" },
        { key = "Alpha", name = "Alpha" },
        { key = "Highlights", name = "Highlights" },
    }
    
    hubButtons = {}
    for _, panelInfo in ipairs(panels) do
        local btn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
        btn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
        btn:SetPoint("TOP", 0, yOffset)
        btn:SetText(panelInfo.name)
        btn:SetScript("OnClick", function()
            self:TogglePanel(panelInfo.key)
        end)
        btn.panelKey = panelInfo.key
        btn.originalText = panelInfo.name
        hubButtons[panelInfo.key] = btn
        yOffset = yOffset - BUTTON_HEIGHT - BUTTON_SPACING
    end
    
    -- Separator before addon section
    yOffset = yOffset - 6
    local sep2 = hub:CreateTexture(nil, "ARTWORK")
    sep2:SetPoint("TOP", 0, yOffset)
    sep2:SetSize(HUB_WIDTH - 20, 1)
    sep2:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOffset = yOffset - 12
    
    -- Addon section label
    local addonLabel = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    addonLabel:SetPoint("TOP", 0, yOffset)
    addonLabel:SetText("|cff888888Recommended Addons|r")
    yOffset = yOffset - 18
    
    -- Platynator button
    local platBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    platBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    platBtn:SetPoint("TOP", 0, yOffset)
    platBtn:SetText("Open Platynator")
    platBtn:SetScript("OnClick", function()
        OpenPlatynator()
    end)
    platynatorButton = platBtn
    hub.platynatorButton = platBtn
    yOffset = yOffset - BUTTON_HEIGHT - 2
    
    -- Platynator status
    local platStatus = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    platStatus:SetPoint("TOP", 0, yOffset)
    platStatus:SetJustifyH("CENTER")
    hub.platynatorStatus = platStatus
    yOffset = yOffset - 14
    
    -- Plater button
    local plrBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    plrBtn:SetSize(HUB_WIDTH - 30, BUTTON_HEIGHT)
    plrBtn:SetPoint("TOP", 0, yOffset)
    plrBtn:SetText("Open Plater")
    plrBtn:SetScript("OnClick", function()
        OpenPlater()
    end)
    platerButton = plrBtn
    hub.platerButton = plrBtn
    yOffset = yOffset - BUTTON_HEIGHT - 2
    
    -- Plater status
    local plrStatus = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    plrStatus:SetPoint("TOP", 0, yOffset)
    plrStatus:SetJustifyH("CENTER")
    hub.platerStatus = plrStatus
    
    -- Update addon button states
    self:UpdateAddonButtons()
    
    hub:Show()
end

function Nameplates:UpdateAddonButtons()
    if not nameplatesHub then return end
    
    local platInstalled = IsPlatynatorInstalled()
    local platEnabled = IsPlatynatorEnabled()
    local platerInstalled = IsPlaterInstalled()
    local platerEnabled = IsPlaterEnabled()
    local anyAddonActive = platEnabled or platerEnabled
    
    -- Update Platynator button
    if platynatorButton then
        if platEnabled then
            platynatorButton:Enable()
            platynatorButton:SetText("Open Platynator")
            nameplatesHub.platynatorStatus:SetText("|cff00ff00Platynator is active|r")
        elseif platInstalled then
            platynatorButton:Enable()
            platynatorButton:SetText("Open Platynator")
            nameplatesHub.platynatorStatus:SetText("|cffffff00Installed (not loaded)|r")
        else
            platynatorButton:Disable()
            nameplatesHub.platynatorStatus:SetText("|cff888888Not installed|r")
        end
    end
    
    -- Update Plater button
    if platerButton then
        if platerEnabled then
            platerButton:Enable()
            platerButton:SetText("Open Plater")
            nameplatesHub.platerStatus:SetText("|cff00ff00Plater is active|r")
        elseif platerInstalled then
            platerButton:Enable()
            platerButton:SetText("Open Plater")
            nameplatesHub.platerStatus:SetText("|cffffff00Installed (not loaded)|r")
        else
            platerButton:Disable()
            nameplatesHub.platerStatus:SetText("|cff888888Not installed|r")
        end
    end
    
    -- Update disclaimer text based on addon state
    -- Hub buttons stay enabled so users can view (but not edit) settings
    if anyAddonActive then
        if nameplatesHub.disclaimer then
            nameplatesHub.disclaimer:SetText("|cffff6600Settings disabled:|r Platynator or Plater is active.\nSettings inside panels are view-only.\nDisable them and |cff00ff00/reload|r to edit.")
        end
    else
        if nameplatesHub.disclaimer then
            nameplatesHub.disclaimer:SetText("|cffaaaaaaThese settings use Blizzard's CVar system. For advanced customization, we recommend |cff00ff00Platynator|r or |cff00ff00Plater|r.|r")
        end
    end
end

function Nameplates:HideAllPanels()
    if nameplatesHub then nameplatesHub:Hide() end
    for _, panel in pairs(settingsPanels) do
        if panel then panel:Hide() end
    end
    currentOpenPanel = nil
    HideInfoTooltip()
end

function Nameplates:TogglePanel(panelKey)
    -- Hide other panels
    for key, panel in pairs(settingsPanels) do
        if panel and key ~= panelKey then panel:Hide() end
    end
    
    -- If this panel exists and is shown, just hide it
    if settingsPanels[panelKey] and settingsPanels[panelKey]:IsShown() then
        settingsPanels[panelKey]:Hide()
        currentOpenPanel = nil
        return
    end
    
    -- Destroy existing panel so it gets recreated with current disabled state
    if settingsPanels[panelKey] then
        settingsPanels[panelKey]:Hide()
        settingsPanels[panelKey]:SetParent(nil)
        settingsPanels[panelKey] = nil
    end
    
    -- Create fresh panel
    self:CreatePanel(panelKey)
    if settingsPanels[panelKey] then
        settingsPanels[panelKey]:Show()
        currentOpenPanel = panelKey
    end
end

-- ============================================================================
-- PANEL CREATION
-- ============================================================================

local function CreatePanelFrame(panelKey, displayName, height)
    local panel = CreateFrame("Frame", "TweaksUI_Nameplates_" .. panelKey .. "_Panel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, height)
    panel:SetPoint("TOPLEFT", nameplatesHub, "TOPRIGHT", 0, 0)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    
    settingsPanels[panelKey] = panel
    
    -- Title
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText(displayName)
    title:SetTextColor(1, 0.82, 0)
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        panel:Hide()
        currentOpenPanel = nil
    end)
    
    -- Scroll frame
    local scrollFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 10)
    
    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(PANEL_WIDTH - 50, 800)
    scrollFrame:SetScrollChild(content)
    
    panel:Hide()
    return panel, content
end

function Nameplates:CreatePanel(panelName)
    -- Check if controls should be disabled due to nameplate addon
    local disabled = IsNameplateAddonActive()
    
    if panelName == "Visibility" then
        local panel, content = CreatePanelFrame("Visibility", "Visibility", 480)
        local yOffset = -5
        
        -- Show disabled notice if addon is active
        if disabled then
            local notice = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            notice:SetPoint("TOPLEFT", 10, yOffset)
            notice:SetWidth(PANEL_WIDTH - 70)
            notice:SetJustifyH("LEFT")
            notice:SetText("|cffff6600Settings disabled:|r Platynator or Plater is managing nameplates. Disable them and /reload to use these settings.")
            notice:SetWordWrap(true)
            notice:SetTextColor(1, 0.6, 0)
            yOffset = yOffset - notice:GetStringHeight() - 10
        end
        
        yOffset = CreateHeader(content, yOffset, "General")
        yOffset = CreateCVarCheckbox(content, "Always Show Nameplates", yOffset, "nameplateShowAll", disabled)
        yOffset = CreateCVarCheckbox(content, "Clamp Target to Screen", yOffset, "clampTargetNameplateToScreen", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Friendly Units")
        yOffset = CreateCVarCheckbox(content, "Show Friendly Players", yOffset, "nameplateShowFriends", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Friendly NPCs", yOffset, "nameplateShowFriendlyNPCs", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Debuffs on Friendly", yOffset, "nameplateShowDebuffsOnFriendly", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Enemy Units")
        yOffset = CreateCVarCheckbox(content, "Show Enemy Players", yOffset, "nameplateShowEnemies", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Enemy Minions", yOffset, "nameplateShowEnemyMinions", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Enemy Guardians", yOffset, "nameplateShowEnemyGuardians", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Minor Enemies", yOffset, "nameplateShowEnemyMinus", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Enemy Pets", yOffset, "nameplateShowEnemyPets", disabled)
        yOffset = CreateCVarCheckbox(content, "Show Enemy Totems", yOffset, "nameplateShowEnemyTotems", disabled)
        
    elseif panelName == "Stacking" then
        local panel, content = CreatePanelFrame("Stacking", "Stacking & Distance", 360)
        local yOffset = -5
        
        if disabled then
            local notice = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            notice:SetPoint("TOPLEFT", 10, yOffset)
            notice:SetWidth(PANEL_WIDTH - 70)
            notice:SetJustifyH("LEFT")
            notice:SetText("|cffff6600Settings disabled:|r Platynator or Plater is managing nameplates. Disable them and /reload to use these settings.")
            notice:SetWordWrap(true)
            notice:SetTextColor(1, 0.6, 0)
            yOffset = yOffset - notice:GetStringHeight() - 10
        end
        
        yOffset = CreateHeader(content, yOffset, "Stacking Behavior")
        yOffset = CreateCVarDropdown(content, "Mode:", yOffset, "nameplateMotion", disabled)
        yOffset = CreateCVarSlider(content, "Motion Speed", yOffset, "nameplateMotionSpeed", disabled)
        yOffset = CreateCVarSlider(content, "Horizontal Overlap", yOffset, "nameplateOverlapH", disabled)
        yOffset = CreateCVarSlider(content, "Vertical Overlap", yOffset, "nameplateOverlapV", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Distance")
        yOffset = CreateCVarSlider(content, "Max Distance", yOffset, "nameplateMaxDistance", disabled)
        yOffset = CreateCVarSlider(content, "Target Behind Distance", yOffset, "nameplateTargetBehindMaxDistance", disabled)
        
    elseif panelName == "Scale" then
        local panel, content = CreatePanelFrame("Scale", "Scale", 520)
        local yOffset = -5
        
        if disabled then
            local notice = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            notice:SetPoint("TOPLEFT", 10, yOffset)
            notice:SetWidth(PANEL_WIDTH - 70)
            notice:SetJustifyH("LEFT")
            notice:SetText("|cffff6600Settings disabled:|r Platynator or Plater is managing nameplates. Disable them and /reload to use these settings.")
            notice:SetWordWrap(true)
            notice:SetTextColor(1, 0.6, 0)
            yOffset = yOffset - notice:GetStringHeight() - 10
        end
        
        yOffset = CreateHeader(content, yOffset, "Global Scale")
        yOffset = CreateCVarSlider(content, "Global Scale", yOffset, "nameplateGlobalScale", disabled)
        yOffset = CreateCVarSlider(content, "Horizontal Scale", yOffset, "NamePlateHorizontalScale", disabled)
        yOffset = CreateCVarSlider(content, "Vertical Scale", yOffset, "NamePlateVerticalScale", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Distance-Based Scale")
        yOffset = CreateCVarSlider(content, "Min Scale (far)", yOffset, "nameplateMinScale", disabled)
        yOffset = CreateCVarSlider(content, "Max Scale (close)", yOffset, "nameplateMaxScale", disabled)
        yOffset = CreateCVarSlider(content, "Min Scale Distance", yOffset, "nameplateMinScaleDistance", disabled)
        yOffset = CreateCVarSlider(content, "Max Scale Distance", yOffset, "nameplateMaxScaleDistance", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Special Scale")
        yOffset = CreateCVarSlider(content, "Target Scale", yOffset, "nameplateSelectedScale", disabled)
        yOffset = CreateCVarSlider(content, "Boss/Larger Scale", yOffset, "nameplateLargerScale", disabled)
        
    elseif panelName == "Alpha" then
        local panel, content = CreatePanelFrame("Alpha", "Alpha", 400)
        local yOffset = -5
        
        if disabled then
            local notice = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            notice:SetPoint("TOPLEFT", 10, yOffset)
            notice:SetWidth(PANEL_WIDTH - 70)
            notice:SetJustifyH("LEFT")
            notice:SetText("|cffff6600Settings disabled:|r Platynator or Plater is managing nameplates. Disable them and /reload to use these settings.")
            notice:SetWordWrap(true)
            notice:SetTextColor(1, 0.6, 0)
            yOffset = yOffset - notice:GetStringHeight() - 10
        end
        
        yOffset = CreateHeader(content, yOffset, "Distance-Based Alpha")
        yOffset = CreateCVarSlider(content, "Min Alpha (far)", yOffset, "nameplateMinAlpha", disabled)
        yOffset = CreateCVarSlider(content, "Max Alpha (close)", yOffset, "nameplateMaxAlpha", disabled)
        yOffset = CreateCVarSlider(content, "Min Alpha Distance", yOffset, "nameplateMinAlphaDistance", disabled)
        yOffset = CreateCVarSlider(content, "Max Alpha Distance", yOffset, "nameplateMaxAlphaDistance", disabled)
        
        yOffset = CreateHeader(content, yOffset - 10, "Special Alpha")
        yOffset = CreateCVarSlider(content, "Target Alpha", yOffset, "nameplateSelectedAlpha", disabled)
        yOffset = CreateCVarSlider(content, "Occluded (Behind Wall)", yOffset, "nameplateOccludedAlphaMult", disabled)
        
    elseif panelName == "Highlights" then
        local panel, content = CreatePanelFrame("Highlights", "Highlights", 420)
        local yOffset = -5
        
        if disabled then
            local notice = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            notice:SetPoint("TOPLEFT", 10, yOffset)
            notice:SetWidth(PANEL_WIDTH - 70)
            notice:SetJustifyH("LEFT")
            notice:SetText("|cffff6600Settings disabled:|r Platynator or Plater is managing nameplates. Disable them and /reload to use these settings.")
            notice:SetWordWrap(true)
            notice:SetTextColor(1, 0.6, 0)
            yOffset = yOffset - notice:GetStringHeight() - 10
        end
        
        -- Color button helper
        local function CreateColorButton(parent, color, yOff, onChange)
            local btn = CreateFrame("Button", nil, parent)
            btn:SetSize(24, 24)
            btn:SetPoint("TOPLEFT", PANEL_WIDTH - 85, yOff + 4)
            
            -- Border first (bottom layer)
            local border = btn:CreateTexture(nil, "BACKGROUND")
            border:SetAllPoints()
            border:SetColorTexture(0.3, 0.3, 0.3, 1)
            
            -- Swatch on top (inset to show border around edges)
            local swatch = btn:CreateTexture(nil, "ARTWORK")
            swatch:SetPoint("TOPLEFT", 2, -2)
            swatch:SetPoint("BOTTOMRIGHT", -2, 2)
            swatch:SetColorTexture(color[1], color[2], color[3], 1)
            btn.swatch = swatch
            
            if disabled then
                btn:Disable()
                btn:SetAlpha(0.5)
            else
                btn:SetScript("OnClick", function()
                    local r, g, b = color[1], color[2], color[3]
                    ColorPickerFrame:SetupColorPickerAndShow({
                        r = r, g = g, b = b,
                        hasOpacity = true,
                        opacity = color[4] or 0.6,
                        swatchFunc = function()
                            local nr, ng, nb = ColorPickerFrame:GetColorRGB()
                            color[1], color[2], color[3] = nr, ng, nb
                            swatch:SetColorTexture(nr, ng, nb, 1)
                            onChange()
                        end,
                        opacityFunc = function()
                            color[4] = ColorPickerFrame:GetColorAlpha()
                            onChange()
                        end,
                        cancelFunc = function(prev)
                            color[1], color[2], color[3], color[4] = prev.r, prev.g, prev.b, prev.opacity
                            swatch:SetColorTexture(prev.r, prev.g, prev.b, 1)
                            onChange()
                        end,
                    })
                end)
            end
            
            return btn
        end
        
        -- Highlight section helper
        local function CreateHighlightSection(title, hs, desc)
            yOffset = CreateHeader(content, yOffset, title)
            
            -- Description
            local descText = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            descText:SetPoint("TOPLEFT", 10, yOffset)
            descText:SetPoint("RIGHT", -20, 0)
            descText:SetJustifyH("LEFT")
            descText:SetText(desc)
            descText:SetTextColor(0.7, 0.7, 0.7)
            local descHeight = descText:GetStringHeight()
            yOffset = yOffset - descHeight - 8
            
            -- Enabled checkbox
            local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
            cb:SetPoint("TOPLEFT", 10, yOffset)
            cb:SetSize(22, 22)
            cb:SetChecked(hs.enabled)
            local lbl = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
            lbl:SetText("Enabled")
            
            if disabled then
                cb:Disable()
                lbl:SetTextColor(0.5, 0.5, 0.5)
            else
                lbl:SetTextColor(0.9, 0.9, 0.9)
                cb:SetScript("OnClick", function(self)
                    hs.enabled = self:GetChecked()
                    SaveSettings()
                    RefreshAllHighlights()
                end)
            end
            yOffset = yOffset - 26
            
            -- Style dropdown
            local styleLbl = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            styleLbl:SetPoint("TOPLEFT", 10, yOffset)
            styleLbl:SetText("Style:")
            local dropdown = CreateFrame("Frame", nil, content, "UIDropDownMenuTemplate")
            dropdown:SetPoint("TOPLEFT", 50, yOffset + 5)
            UIDropDownMenu_SetWidth(dropdown, 100)
            UIDropDownMenu_SetText(dropdown, hs.style == "glow" and "Glow" or "Border")
            
            if disabled then
                styleLbl:SetTextColor(0.5, 0.5, 0.5)
                UIDropDownMenu_DisableDropDown(dropdown)
            else
                styleLbl:SetTextColor(0.9, 0.9, 0.9)
                UIDropDownMenu_Initialize(dropdown, function()
                    for _, opt in ipairs({{text="Glow", value="glow"}, {text="Border", value="border"}}) do
                        local info = UIDropDownMenu_CreateInfo()
                        info.text = opt.text
                        info.checked = hs.style == opt.value
                        info.func = function()
                            hs.style = opt.value
                            UIDropDownMenu_SetText(dropdown, opt.text)
                            SaveSettings()
                            RefreshAllHighlights()
                        end
                        UIDropDownMenu_AddButton(info)
                    end
                end)
            end
            yOffset = yOffset - 32
            
            -- Color picker
            local colorLbl = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            colorLbl:SetPoint("TOPLEFT", 10, yOffset)
            colorLbl:SetText("Color:")
            if disabled then
                colorLbl:SetTextColor(0.5, 0.5, 0.5)
            else
                colorLbl:SetTextColor(0.9, 0.9, 0.9)
            end
            CreateColorButton(content, hs.color, yOffset, function()
                SaveSettings()
                RefreshAllHighlights()
            end)
            yOffset = yOffset - 28
            
            -- Thickness slider
            local thickLbl = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            thickLbl:SetPoint("TOPLEFT", 10, yOffset)
            thickLbl:SetText("Thickness:")
            local thickVal = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            thickVal:SetPoint("TOPRIGHT", -20, yOffset)
            thickVal:SetText(tostring(hs.thickness))
            
            if disabled then
                thickLbl:SetTextColor(0.5, 0.5, 0.5)
                thickVal:SetTextColor(0.5, 0.5, 0.5)
            else
                thickLbl:SetTextColor(0.9, 0.9, 0.9)
                thickVal:SetTextColor(0.9, 0.9, 0.9)
            end
            
            local slider = CreateFrame("Slider", nil, content, "OptionsSliderTemplate")
            slider:SetPoint("TOPLEFT", 10, yOffset - 16)
            slider:SetSize(PANEL_WIDTH - 80, 17)
            slider:SetMinMaxValues(1, 10)
            slider:SetValueStep(1)
            slider:SetObeyStepOnDrag(true)
            slider:SetValue(hs.thickness)
            slider.Low:SetText("1")
            slider.High:SetText("10")
            slider.Text:SetText("")
            
            if disabled then
                slider:Disable()
                slider:SetAlpha(0.5)
            else
                slider:SetScript("OnValueChanged", function(self, value)
                    hs.thickness = math.floor(value)
                    thickVal:SetText(tostring(hs.thickness))
                    SaveSettings()
                    RefreshAllHighlights()
                end)
            end
            yOffset = yOffset - 50
        end
        
        CreateHighlightSection("Target Highlight", settings.targetHighlight,
            "Adds a visual highlight around your current target's nameplate to make it easier to track in combat.")
        CreateHighlightSection("Focus Highlight", settings.focusHighlight,
            "Adds a visual highlight around your focus target's nameplate. Useful for tracking CC or important targets.")
    end
end
