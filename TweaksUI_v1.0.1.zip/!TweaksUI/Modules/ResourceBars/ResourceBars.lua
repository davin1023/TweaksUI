-- ============================================================================
-- TweaksUI: Resource Bars Module
-- ============================================================================

local ADDON_NAME, TweaksUI = ...

local ResourceBars = TweaksUI.ModuleManager:NewModule(
    TweaksUI.MODULE_IDS.RESOURCE_BARS,
    "Resource Bars",
    "Customizable power bars and class resources"
)

local STANDARD_TEXT_FONT = "Fonts\\FRIZQT__.TTF"
local HUB_WIDTH, HUB_HEIGHT = 160, 600
local PANEL_WIDTH, PANEL_HEIGHT = 360, 560
local BUTTON_HEIGHT, BUTTON_SPACING = 28, 6

local darkBackdrop = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
}

local SPECIAL_RESOURCES = { STAGGER = "STAGGER", SOUL_FRAGMENTS = "SOUL_FRAGMENTS" }

local PRIMARY_RESOURCES = {
    DEATHKNIGHT = Enum.PowerType.RunicPower,
    DEMONHUNTER = Enum.PowerType.Fury,
    DRUID = { default = Enum.PowerType.Mana, forms = { [1] = Enum.PowerType.Energy, [5] = Enum.PowerType.Rage, [31] = Enum.PowerType.LunarPower } },
    EVOKER = Enum.PowerType.Mana, HUNTER = Enum.PowerType.Focus, MAGE = Enum.PowerType.Mana,
    MONK = { [268] = Enum.PowerType.Energy, [269] = Enum.PowerType.Energy, [270] = Enum.PowerType.Mana },
    PALADIN = Enum.PowerType.Mana,
    PRIEST = { [256] = Enum.PowerType.Mana, [257] = Enum.PowerType.Mana, [258] = Enum.PowerType.Insanity },
    ROGUE = Enum.PowerType.Energy,
    SHAMAN = { [262] = Enum.PowerType.Maelstrom, [263] = Enum.PowerType.Mana, [264] = Enum.PowerType.Mana },
    WARLOCK = Enum.PowerType.Mana, WARRIOR = Enum.PowerType.Rage,
}

local SECONDARY_RESOURCES = {
    DEATHKNIGHT = Enum.PowerType.Runes,
    DEMONHUNTER = { default = nil, [577] = SPECIAL_RESOURCES.SOUL_FRAGMENTS, [581] = SPECIAL_RESOURCES.SOUL_FRAGMENTS },
    DRUID = { forms = { [1] = Enum.PowerType.ComboPoints } },
    EVOKER = Enum.PowerType.Essence,
    MAGE = { [62] = Enum.PowerType.ArcaneCharges },
    MONK = { [268] = SPECIAL_RESOURCES.STAGGER, [269] = Enum.PowerType.Chi },
    PALADIN = Enum.PowerType.HolyPower,
    ROGUE = Enum.PowerType.ComboPoints,
    WARLOCK = Enum.PowerType.SoulShards,
}

local RESOURCE_COLORS = {
    [Enum.PowerType.Mana] = { r = 0, g = 0, b = 1 },
    [Enum.PowerType.Rage] = { r = 1, g = 0, b = 0 },
    [Enum.PowerType.Focus] = { r = 1, g = 0.5, b = 0.25 },
    [Enum.PowerType.Energy] = { r = 1, g = 1, b = 0 },
    [Enum.PowerType.ComboPoints] = { r = 1, g = 0.96, b = 0.41 },
    [Enum.PowerType.Runes] = { r = 0.5, g = 0.5, b = 0.5 },
    [Enum.PowerType.RunicPower] = { r = 0, g = 0.82, b = 1 },
    [Enum.PowerType.SoulShards] = { r = 0.58, g = 0.51, b = 0.79 },
    [Enum.PowerType.LunarPower] = { r = 0.3, g = 0.52, b = 0.9 },
    [Enum.PowerType.HolyPower] = { r = 0.95, g = 0.9, b = 0.6 },
    [Enum.PowerType.Maelstrom] = { r = 0, g = 0.5, b = 1 },
    [Enum.PowerType.Chi] = { r = 0.71, g = 1, b = 0.92 },
    [Enum.PowerType.Insanity] = { r = 0.4, g = 0, b = 0.8 },
    [Enum.PowerType.ArcaneCharges] = { r = 0.1, g = 0.1, b = 0.98 },
    [Enum.PowerType.Fury] = { r = 0.79, g = 0.26, b = 0.99 },
    [Enum.PowerType.Essence] = { r = 0.2, g = 0.58, b = 0.5 },
    [SPECIAL_RESOURCES.STAGGER] = { r = 0.52, g = 1, b = 0.52 },
    [SPECIAL_RESOURCES.SOUL_FRAGMENTS] = { r = 0.64, g = 0.19, b = 0.79 },
}

local TEXT_FORMATS = {
    { id = "none", name = "Hidden" }, { id = "current", name = "Current" }, { id = "current_max", name = "Current / Max" },
}

local DEFAULT_SETTINGS = {
    enabled = false,
    powerBar = {
        enabled = false, width = 200, height = 16,  -- Default to disabled for new installs
        texture = "Interface\\TargetingFrame\\UI-StatusBar",
        positionX = 0, positionY = -200, anchor = "CENTER",
        showBorder = true, borderColor = { 0, 0, 0, 1 }, borderSize = 1,
        backgroundColor = { 0.1, 0.1, 0.1, 0.8 },
        useClassColor = false, useResourceColor = true, customColor = { 0, 0.8, 0, 1 },
        showText = true, textFormat = "current", textFontSize = 11, textFontOutline = "OUTLINE",
        textColor = { 1, 1, 1, 1 },
        -- Visibility (OR logic)
        visibilityEnabled = false,
        showInCombat = true, showOutOfCombat = true,
        showHasTarget = true, showNoTarget = true,
        showSolo = true, showInParty = true, showInRaid = true, showInInstance = true,
        -- Fade
        fadeEnabled = false, fadeDelay = 3.0, fadeAlpha = 0.3,
    },
    classPower = {
        enabled = false, width = 200, height = 12, spacing = 3,  -- Default to disabled for new installs
        positionX = 0, positionY = -220, anchor = "CENTER",
        showBorder = true, borderColor = { 0, 0, 0, 1 }, borderSize = 1,
        backgroundColor = { 0.15, 0.15, 0.15, 0.8 }, inactiveColor = { 0.2, 0.2, 0.2, 0.6 },
        useClassColor = false, useResourceColor = true, customColor = { 1, 0.8, 0, 1 },
        usePerPointColors = false,
        perPointColors = {
            { 0.3, 1, 0.3, 1 }, { 0.5, 1, 0.3, 1 }, { 0.7, 1, 0.2, 1 }, { 0.9, 0.9, 0.1, 1 },
            { 1, 0.6, 0, 1 }, { 1, 0.3, 0, 1 }, { 1, 0, 0, 1 },
        },
        showText = false, textFormat = "current", textFontSize = 12, textFontOutline = "OUTLINE",
        textColor = { 1, 1, 1, 1 },
        -- Visibility (OR logic)
        visibilityEnabled = false,
        showInCombat = true, showOutOfCombat = true,
        showHasTarget = true, showNoTarget = true,
        showSolo = true, showInParty = true, showInRaid = true, showInInstance = true,
        -- Fade
        fadeEnabled = false, fadeDelay = 3.0, fadeAlpha = 0.3,
    },
    runes = { showCooldownText = true, cooldownFontSize = 10, cooldownFontOutline = "OUTLINE", sortByRecharge = true },
    soulFragments = {
        enabled = false,  -- Default to disabled for new installs (Vengeance DH feature)
        style = "fel",  -- "flame", "fel", or "void"
        scale = 0.25,   -- Default to 64x64 (256 * 0.25)
        positionX = 0, positionY = -220, anchor = "CENTER",
        countFontSize = 28,
        countFontOutline = "OUTLINE",
        countColor = { 1, 1, 1, 1 },
        countOffsetY = 0,  -- Vertical offset for fine-tuning position
        showLabel = true,
        labelFontSize = 10,
        labelFontOutline = "OUTLINE",
        labelColor = { 0.7, 0.5, 0.8, 0.8 },
        -- Visibility (OR logic)
        visibilityEnabled = false,
        showInCombat = true, showOutOfCombat = true,
        showHasTarget = true, showNoTarget = true,
        showSolo = true, showInParty = true, showInRaid = true, showInInstance = true,
        -- Fade
        fadeEnabled = false, fadeDelay = 3.0, fadeAlpha = 0.3,
    },
    global = { scale = 1.0, hideBlizzardBars = true },
}

local settings, resourceBarsHub, settingsPanels, currentOpenPanel, previewWindow = nil, nil, {}, nil, nil
local powerBarFrame, classPowerFrame, classPowerSegments = nil, nil, {}
local soulFragmentFrame = nil
local secretValueDecoder, eventFrame = nil, nil
local playerClass, playerSpecIndex, playerSpecID = nil, nil, nil
local cachedMaxPrimary, cachedMaxSecondary = 100, 5
local runeUpdateTicker, soulFragmentTicker = nil, nil
local visibilityState = { power = { visible = true, lastActivity = 0 }, class = { visible = true, lastActivity = 0 }, soul = { visible = true, lastActivity = 0 } }

local function DeepCopy(orig)
    if type(orig) ~= "table" then return orig end
    local copy = {}
    for k, v in pairs(orig) do copy[k] = DeepCopy(v) end
    return copy
end

local function EnsureDefaults(tbl, defaults)
    for k, v in pairs(defaults) do
        if tbl[k] == nil then
            tbl[k] = type(v) == "table" and DeepCopy(v) or v
        elseif type(v) == "table" and type(tbl[k]) == "table" then
            EnsureDefaults(tbl[k], v)
        end
    end
end

local function GetResourceColor(powerType)
    if RESOURCE_COLORS[powerType] then
        local c = RESOURCE_COLORS[powerType]
        return c.r, c.g, c.b
    end
    local info = PowerBarColor[powerType]
    return info and info.r or 1, info and info.g or 1, info and info.b or 1
end

local function GetClassColor()
    local c = RAID_CLASS_COLORS[playerClass]
    return c and c.r or 1, c and c.g or 1, c and c.b or 1
end

local function EnsureDecoder()
    if not secretValueDecoder then
        secretValueDecoder = CreateFrame("StatusBar", nil, UIParent)
        secretValueDecoder:SetSize(100, 1)
        secretValueDecoder:SetPoint("TOPLEFT", -200, -200)
        secretValueDecoder:SetStatusBarTexture("Interface\\BUTTONS\\WHITE8X8")
        secretValueDecoder:Hide()
    end
end

local function IsValueAtLeast(secretValue, threshold)
    EnsureDecoder()
    secretValueDecoder:SetMinMaxValues(0, threshold)
    secretValueDecoder:SetValue(secretValue or 0)
    local fill = secretValueDecoder:GetStatusBarTexture()
    if fill then
        local bw, fw = secretValueDecoder:GetWidth(), fill:GetWidth()
        if bw > 0 and fw >= bw - 0.1 then return true end
    end
    return false
end

-- Soul Fragment tracking via spell count
-- Soul Cleave and Spirit Bomb show soul fragment count - but it's a secret value
-- We can only DISPLAY it via SetFormattedText, not do math on it
local SOUL_CLEAVE_SPELL_ID = 228477
local SPIRIT_BOMB_SPELL_ID = 247454
local soulFragmentSecretValue = nil

local function GetSoulFragmentSecretValue()
    -- Try C_Spell.GetSpellCastCount first (Midnight API)
    if C_Spell and C_Spell.GetSpellCastCount then
        local ok, result = pcall(C_Spell.GetSpellCastCount, SOUL_CLEAVE_SPELL_ID)
        if ok and result then
            return result
        end
        
        ok, result = pcall(C_Spell.GetSpellCastCount, SPIRIT_BOMB_SPELL_ID)
        if ok and result then
            return result
        end
    end
    
    -- Try GetSpellCount (classic API)
    if GetSpellCount then
        local ok, result = pcall(GetSpellCount, SOUL_CLEAVE_SPELL_ID)
        if ok and result then
            return result
        end
        
        ok, result = pcall(GetSpellCount, SPIRIT_BOMB_SPELL_ID)
        if ok and result then
            return result
        end
    end
    
    return nil
end

local function UpdateSoulFragmentSecretValue()
    soulFragmentSecretValue = GetSoulFragmentSecretValue()
end

local function GetPlayerInfo()
    local _, class = UnitClass("player")
    playerClass = class
    local specIndex = GetSpecialization()
    playerSpecIndex = specIndex
    if specIndex then playerSpecID = GetSpecializationInfo(specIndex) end
end

local function GetPrimaryResource()
    if not playerClass then GetPlayerInfo() end
    local data = PRIMARY_RESOURCES[playerClass]
    if not data then return nil end
    if type(data) == "table" and data.forms then
        local formID = GetShapeshiftFormID()
        return formID and data.forms[formID] or data.default or Enum.PowerType.Mana
    end
    if type(data) == "table" then
        return playerSpecID and data[playerSpecID] or data.default or Enum.PowerType.Mana
    end
    return data
end

local function GetSecondaryResource()
    if not playerClass then GetPlayerInfo() end
    local data = SECONDARY_RESOURCES[playerClass]
    if not data then return nil end
    if type(data) == "table" and data.forms then
        local formID = GetShapeshiftFormID()
        return formID and data.forms[formID] or data.default
    end
    if type(data) == "table" then
        return playerSpecID and data[playerSpecID] or data.default
    end
    return data
end

local function GetPrimaryResourceValues()
    local powerType = GetPrimaryResource()
    if not powerType then return nil, nil, nil end
    local current = UnitPower("player", powerType)
    local max = UnitPowerMax("player", powerType)
    if max then cachedMaxPrimary = max end
    if not max or max == 0 then return nil, nil, nil end
    return current, max, powerType
end

local function GetSecondaryResourceValues()
    local resourceType = GetSecondaryResource()
    if not resourceType then return nil, nil, nil end
    
    if resourceType == SPECIAL_RESOURCES.STAGGER then
        local stagger = UnitStagger("player") or 0
        local maxHealth = UnitHealthMax("player") or 1
        cachedMaxSecondary = 5
        local pct = (stagger / maxHealth) * 100
        local level = pct > 60 and 5 or pct > 40 and 4 or pct > 20 and 3 or pct > 10 and 2 or pct > 0 and 1 or 0
        return level, 5, resourceType
    end
    
    if resourceType == SPECIAL_RESOURCES.SOUL_FRAGMENTS then
        cachedMaxSecondary = 5
        -- Return special marker - actual value is secret and displayed via SetFormattedText
        UpdateSoulFragmentSecretValue()
        return "SECRET", 5, resourceType
    end
    
    if resourceType == Enum.PowerType.Runes then
        local max = UnitPowerMax("player", resourceType) or 6
        cachedMaxSecondary = max
        local ready = 0
        for i = 1, max do
            local _, _, runeReady = GetRuneCooldown(i)
            if runeReady then ready = ready + 1 end
        end
        return ready, max, resourceType
    end
    
    local current = UnitPower("player", resourceType)
    local max = UnitPowerMax("player", resourceType)
    if max then cachedMaxSecondary = max end
    if not max or max == 0 then return nil, nil, nil end
    return current, max, resourceType
end

local function IsNormalValueResource(resourceType)
    -- These resources return normal Lua numbers, not secret values
    return resourceType == SPECIAL_RESOURCES.STAGGER 
        or resourceType == SPECIAL_RESOURCES.SOUL_FRAGMENTS
        or resourceType == Enum.PowerType.Runes
end

-- Get current player state for visibility
local function GetPlayerState()
    local state = {
        inCombat = UnitAffectingCombat("player"),
        hasTarget = UnitExists("target"),
        inInstance = IsInInstance(),
        inRaid = IsInRaid(),
        inParty = IsInGroup() and not IsInRaid(),
        solo = not IsInGroup(),
    }
    return state
end

-- Check visibility conditions (OR logic)
local function CheckVisibilityConditions(cfg)
    if not cfg.visibilityEnabled then return true end
    
    local state = GetPlayerState()
    
    if state.inCombat and cfg.showInCombat then return true end
    if not state.inCombat and cfg.showOutOfCombat then return true end
    if state.hasTarget and cfg.showHasTarget then return true end
    if not state.hasTarget and cfg.showNoTarget then return true end
    if state.solo and cfg.showSolo then return true end
    if state.inParty and cfg.showInParty then return true end
    if state.inRaid and cfg.showInRaid then return true end
    if state.inInstance and cfg.showInInstance then return true end
    
    return false
end

local function ShouldShowPowerBar()
    if not settings or not settings.powerBar.enabled then return false end
    return CheckVisibilityConditions(settings.powerBar)
end

local function ShouldShowClassPower()
    if not settings or not settings.classPower.enabled then return false end
    if not GetSecondaryResource() then return false end
    return CheckVisibilityConditions(settings.classPower)
end

local function ShouldShowSoulFragments()
    if not settings or not settings.soulFragments or not settings.soulFragments.enabled then return false end
    if playerClass ~= "DEMONHUNTER" then return false end
    if GetSecondaryResource() ~= SPECIAL_RESOURCES.SOUL_FRAGMENTS then return false end
    return CheckVisibilityConditions(settings.soulFragments)
end

local function GetFadeAlpha(barType)
    local cfg
    if barType == "power" then
        cfg = settings.powerBar
    elseif barType == "class" then
        cfg = settings.classPower
    elseif barType == "soul" then
        cfg = settings.soulFragments
    else
        return 1
    end
    
    local state = visibilityState[barType]
    if not state then return 1 end
    
    if not cfg.fadeEnabled then return 1 end
    
    local now = GetTime()
    if (now - state.lastActivity) > cfg.fadeDelay then
        return cfg.fadeAlpha
    end
    return 1
end

local function MarkActivity(barType)
    visibilityState[barType].lastActivity = GetTime()
end

local function CreatePowerBar()
    if powerBarFrame then return powerBarFrame end
    local cfg = settings.powerBar
    local frame = CreateFrame("Frame", "TweaksUI_ResourceBars_PowerBar", UIParent, "BackdropTemplate")
    frame:SetSize(cfg.width, cfg.height)
    frame:SetPoint(cfg.anchor, UIParent, cfg.anchor, cfg.positionX, cfg.positionY)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(10)
    frame:SetMovable(true)
    frame:EnableMouse(false)
    frame:SetClampedToScreen(true)
    
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(cfg.backgroundColor[1], cfg.backgroundColor[2], cfg.backgroundColor[3], cfg.backgroundColor[4] or 0.8)
    frame.background = bg
    
    local sb = CreateFrame("StatusBar", nil, frame)
    sb:SetAllPoints()
    sb:SetStatusBarTexture(cfg.texture)
    sb:GetStatusBarTexture():SetDrawLayer("ARTWORK")
    sb:SetMinMaxValues(0, 100)
    sb:SetValue(100)
    frame.statusBar = sb
    
    local border = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = cfg.borderSize or 1 })
    border:SetBackdropBorderColor(cfg.borderColor[1], cfg.borderColor[2], cfg.borderColor[3], cfg.borderColor[4] or 1)
    frame.border = border
    if not cfg.showBorder then border:Hide() end
    
    local text = sb:CreateFontString(nil, "OVERLAY")
    text:SetFont(STANDARD_TEXT_FONT, cfg.textFontSize, cfg.textFontOutline)
    text:SetPoint("CENTER", 0, 0)
    text:SetTextColor(cfg.textColor[1], cfg.textColor[2], cfg.textColor[3], cfg.textColor[4] or 1)
    frame.text = text
    if not cfg.showText then text:Hide() end
    
    frame:Hide()
    powerBarFrame = frame
    
    -- Register with Edit Mode
    if TweaksUI.EditMode then
        TweaksUI.EditMode:RegisterFrame(frame, {
            name = "TweaksUI: Power Bar",
            onPositionChanged = function(f, point, x, y)
                settings.powerBar.positionX = x
                settings.powerBar.positionY = y
                settings.powerBar.anchor = point
            end,
            default = { point = cfg.anchor, x = cfg.positionX, y = cfg.positionY },
        })
    end
    
    return frame
end

local function UpdatePowerBar()
    if not powerBarFrame then CreatePowerBar() end
    if not ShouldShowPowerBar() then powerBarFrame:Hide() return end
    
    local current, max, powerType = GetPrimaryResourceValues()
    if not current or not max then powerBarFrame:Hide() return end
    
    local cfg = settings.powerBar
    powerBarFrame.statusBar:SetMinMaxValues(0, max)
    powerBarFrame.statusBar:SetValue(current)
    
    local r, g, b
    if cfg.useClassColor then r, g, b = GetClassColor()
    elseif cfg.useResourceColor then r, g, b = GetResourceColor(powerType)
    else r, g, b = cfg.customColor[1], cfg.customColor[2], cfg.customColor[3] end
    powerBarFrame.statusBar:SetStatusBarColor(r, g, b)
    
    if cfg.showText then
        if cfg.textFormat == "current" then
            powerBarFrame.text:SetFormattedText("%d", current)
        elseif cfg.textFormat == "current_max" then
            powerBarFrame.text:SetFormattedText("%d / %d", current, max)
        else
            powerBarFrame.text:SetText("")
        end
        powerBarFrame.text:Show()
    else
        powerBarFrame.text:Hide()
    end
    
    MarkActivity("power")
    powerBarFrame:SetAlpha(GetFadeAlpha("power"))
    powerBarFrame:Show()
end

local function CreateClassPowerSegment(parent, index, w, h)
    local seg = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    seg:SetSize(w, h)
    
    local bg = seg:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    seg.background = bg
    
    local fill = seg:CreateTexture(nil, "ARTWORK")
    fill:SetAllPoints()
    seg.fill = fill
    
    local border = CreateFrame("Frame", nil, seg, "BackdropTemplate")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    border:SetBackdropBorderColor(0, 0, 0, 1)
    seg.border = border
    
    local cd = seg:CreateFontString(nil, "OVERLAY")
    cd:SetFont(STANDARD_TEXT_FONT, 9, "OUTLINE")
    cd:SetPoint("CENTER")
    cd:SetTextColor(1, 1, 1, 1)
    cd:Hide()
    seg.cooldownText = cd
    
    return seg
end

local function CreateClassPowerFrame()
    if classPowerFrame then return classPowerFrame end
    local cfg = settings.classPower
    local frame = CreateFrame("Frame", "TweaksUI_ResourceBars_ClassPower", UIParent)
    frame:SetSize(cfg.width, cfg.height)
    frame:SetPoint(cfg.anchor, UIParent, cfg.anchor, cfg.positionX, cfg.positionY)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(11)
    frame:SetMovable(true)
    frame:EnableMouse(false)
    frame:SetClampedToScreen(true)
    
    local text = frame:CreateFontString(nil, "OVERLAY")
    text:SetFont(STANDARD_TEXT_FONT, cfg.textFontSize, cfg.textFontOutline)
    text:SetPoint("CENTER", 0, -cfg.height - 5)
    text:SetTextColor(cfg.textColor[1], cfg.textColor[2], cfg.textColor[3], cfg.textColor[4] or 1)
    text:Hide()
    frame.text = text
    
    frame:Hide()
    classPowerFrame = frame
    
    -- Register with Edit Mode
    if TweaksUI.EditMode then
        TweaksUI.EditMode:RegisterFrame(frame, {
            name = "TweaksUI: Class Power",
            onPositionChanged = function(f, point, x, y)
                settings.classPower.positionX = x
                settings.classPower.positionY = y
                settings.classPower.anchor = point
            end,
            default = { point = cfg.anchor, x = cfg.positionX, y = cfg.positionY },
        })
    end
    
    return frame
end

-- Separate Soul Fragment display frame (Vengeance DH only)
local function CreateSoulFragmentFrame()
    if soulFragmentFrame then return soulFragmentFrame end
    local sfCfg = settings.soulFragments
    local baseSize = 256
    local scaledSize = baseSize * sfCfg.scale
    
    local frame = CreateFrame("Frame", "TweaksUI_ResourceBars_SoulFragments", UIParent)
    frame:SetSize(scaledSize, scaledSize)
    frame:SetPoint(sfCfg.anchor, UIParent, sfCfg.anchor, sfCfg.positionX, sfCfg.positionY)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(11)
    frame:SetMovable(true)
    frame:EnableMouse(false)
    frame:SetClampedToScreen(true)
    frame:Hide()
    
    -- Background texture (the custom image)
    local texture = frame:CreateTexture(nil, "BACKGROUND")
    texture:SetAllPoints()
    texture:SetTexture("Interface\\AddOns\\!TweaksUI\\Media\\Textures\\SoulFragments_" .. sfCfg.style)
    frame.texture = texture
    
    -- Count text (centered on the image)
    local countText = frame:CreateFontString(nil, "OVERLAY")
    countText:SetFont(STANDARD_TEXT_FONT, sfCfg.countFontSize, sfCfg.countFontOutline)
    countText:SetPoint("CENTER", 0, sfCfg.countOffsetY)
    countText:SetTextColor(sfCfg.countColor[1], sfCfg.countColor[2], sfCfg.countColor[3], sfCfg.countColor[4] or 1)
    frame.countText = countText
    
    -- Label text (below the image)
    local label = frame:CreateFontString(nil, "OVERLAY")
    label:SetFont(STANDARD_TEXT_FONT, sfCfg.labelFontSize, sfCfg.labelFontOutline)
    label:SetPoint("TOP", frame, "BOTTOM", 0, -2)
    label:SetText("Soul Fragments")
    label:SetTextColor(sfCfg.labelColor[1], sfCfg.labelColor[2], sfCfg.labelColor[3], sfCfg.labelColor[4] or 1)
    if not sfCfg.showLabel then label:Hide() end
    frame.label = label
    
    soulFragmentFrame = frame
    
    -- Register with Edit Mode
    if TweaksUI.EditMode then
        TweaksUI.EditMode:RegisterFrame(frame, {
            name = "TweaksUI: Soul Fragments",
            onPositionChanged = function(f, point, x, y)
                settings.soulFragments.positionX = x
                settings.soulFragments.positionY = y
                settings.soulFragments.anchor = point
            end,
            default = { point = sfCfg.anchor, x = sfCfg.positionX, y = sfCfg.positionY },
        })
    end
    
    return frame
end

local function UpdateClassPowerSegments(maxPoints)
    if not classPowerFrame then CreateClassPowerFrame() end
    local cfg = settings.classPower
    local spacing = cfg.spacing
    local segW = (cfg.width - spacing * (maxPoints - 1)) / maxPoints
    
    for i = 1, maxPoints do
        if not classPowerSegments[i] then
            classPowerSegments[i] = CreateClassPowerSegment(classPowerFrame, i, segW, cfg.height)
        end
        local seg = classPowerSegments[i]
        seg:SetSize(segW, cfg.height)
        seg:ClearAllPoints()
        seg:SetPoint("LEFT", classPowerFrame, "LEFT", (i-1) * (segW + spacing), 0)
        
        if cfg.showBorder then
            seg.border:Show()
            seg.border:SetBackdropBorderColor(cfg.borderColor[1], cfg.borderColor[2], cfg.borderColor[3], cfg.borderColor[4] or 1)
        else
            seg.border:Hide()
        end
        
        seg.background:SetColorTexture(cfg.inactiveColor[1], cfg.inactiveColor[2], cfg.inactiveColor[3], cfg.inactiveColor[4] or 0.6)
        seg:Show()
    end
    
    for i = maxPoints + 1, #classPowerSegments do
        if classPowerSegments[i] then classPowerSegments[i]:Hide() end
    end
end

local function GetSegmentColor(index, resourceType)
    local cfg = settings.classPower
    if cfg.usePerPointColors and cfg.perPointColors[index] then
        local c = cfg.perPointColors[index]
        return c[1], c[2], c[3], c[4] or 1
    end
    if cfg.useClassColor then
        local r, g, b = GetClassColor()
        return r, g, b, 1
    end
    if cfg.useResourceColor then
        local r, g, b = GetResourceColor(resourceType)
        return r, g, b, 1
    end
    local c = cfg.customColor
    return c[1], c[2], c[3], c[4] or 1
end

local function UpdateClassPower()
    if not classPowerFrame then CreateClassPowerFrame() end
    
    local current, max, resourceType = GetSecondaryResourceValues()
    
    -- Soul fragments are handled separately
    if resourceType == SPECIAL_RESOURCES.SOUL_FRAGMENTS then
        classPowerFrame:Hide()
        return
    end
    
    if not ShouldShowClassPower() then classPowerFrame:Hide() return end
    if not resourceType then classPowerFrame:Hide() return end
    
    local safeMax = cachedMaxSecondary > 0 and cachedMaxSecondary or 5
    local cfg = settings.classPower
    
    classPowerFrame:SetSize(cfg.width, cfg.height)
    UpdateClassPowerSegments(safeMax)
    
    local isNormal = IsNormalValueResource(resourceType)
    
    for i = 1, safeMax do
        local seg = classPowerSegments[i]
        if seg then
            local isActive = isNormal and (current >= i) or IsValueAtLeast(current, i)
            local r, g, b, a = GetSegmentColor(i, resourceType)
            
            if isActive then
                seg.fill:SetColorTexture(r, g, b, a)
                seg.fill:Show()
            else
                seg.fill:Hide()
            end
        end
    end
    
    if cfg.showText then
        if isNormal then
            classPowerFrame.text:SetText(cfg.textFormat == "current" and current or (current .. "/" .. safeMax))
        else
            if cfg.textFormat == "current" then
                classPowerFrame.text:SetFormattedText("%d", current)
            else
                classPowerFrame.text:SetFormattedText("%d/%d", current, safeMax)
            end
        end
        classPowerFrame.text:Show()
    else
        classPowerFrame.text:Hide()
    end
    
    MarkActivity("class")
    classPowerFrame:SetAlpha(GetFadeAlpha("class"))
    classPowerFrame:Show()
end

local function UpdateSoulFragments()
    if playerClass ~= "DEMONHUNTER" then return end
    if GetSecondaryResource() ~= SPECIAL_RESOURCES.SOUL_FRAGMENTS then return end
    
    if not ShouldShowSoulFragments() then
        if soulFragmentFrame then soulFragmentFrame:Hide() end
        return
    end
    
    if not soulFragmentFrame then CreateSoulFragmentFrame() end
    
    -- Update the count display
    UpdateSoulFragmentSecretValue()
    local count = soulFragmentSecretValue or 0
    soulFragmentFrame.countText:SetFormattedText("%d", count)
    
    MarkActivity("soul")
    soulFragmentFrame:SetAlpha(GetFadeAlpha("soul"))
    soulFragmentFrame:Show()
end

local function UpdateRuneDisplay()
    if playerClass ~= "DEATHKNIGHT" or not classPowerFrame or not classPowerFrame:IsShown() then return end
    local cfg, runeCfg = settings.classPower, settings.runes
    local max = cachedMaxSecondary > 0 and cachedMaxSecondary or 6
    local now = GetTime()
    
    local states = {}
    for i = 1, max do
        local start, dur, ready = GetRuneCooldown(i)
        local rem = 0
        if not ready and start and dur and dur > 0 then rem = math.max(0, dur - (now - start)) end
        states[i] = { ready = ready, remaining = rem }
    end
    
    if runeCfg.sortByRecharge then
        table.sort(states, function(a, b)
            if a.ready ~= b.ready then return a.ready end
            return a.remaining < b.remaining
        end)
    end
    
    for i = 1, max do
        local seg, st = classPowerSegments[i], states[i]
        if seg and st then
            local r, g, b, a = GetSegmentColor(i, Enum.PowerType.Runes)
            if st.ready then
                seg.fill:SetColorTexture(r, g, b, a)
                seg.fill:Show()
                seg.cooldownText:Hide()
            else
                seg.fill:SetColorTexture(r*0.4, g*0.4, b*0.4, a*0.6)
                seg.fill:Show()
                if runeCfg.showCooldownText then
                    seg.cooldownText:SetText(string.format("%.1f", st.remaining))
                    seg.cooldownText:SetFont(STANDARD_TEXT_FONT, runeCfg.cooldownFontSize, runeCfg.cooldownFontOutline)
                    seg.cooldownText:Show()
                else
                    seg.cooldownText:Hide()
                end
            end
        end
    end
end

local function StartRuneUpdateTicker()
    if runeUpdateTicker or playerClass ~= "DEATHKNIGHT" then return end
    runeUpdateTicker = C_Timer.NewTicker(0.1, function()
        if settings and settings.enabled and settings.classPower.enabled then UpdateRuneDisplay()
        else if runeUpdateTicker then runeUpdateTicker:Cancel() runeUpdateTicker = nil end end
    end)
end

local function StopRuneUpdateTicker()
    if runeUpdateTicker then runeUpdateTicker:Cancel() runeUpdateTicker = nil end
end

local function StartSoulFragmentTicker()
    if soulFragmentTicker or playerClass ~= "DEMONHUNTER" then return end
    if GetSecondaryResource() ~= SPECIAL_RESOURCES.SOUL_FRAGMENTS then return end
    soulFragmentTicker = C_Timer.NewTicker(0.1, function()
        if settings and settings.enabled and settings.soulFragments.enabled then 
            UpdateSoulFragments()
        else 
            if soulFragmentTicker then soulFragmentTicker:Cancel() soulFragmentTicker = nil end 
        end
    end)
end

local function StopSoulFragmentTicker()
    if soulFragmentTicker then soulFragmentTicker:Cancel() soulFragmentTicker = nil end
end

local blizzardFramesHidden = false

local function HideBlizzardResourceFrames()
    if not settings.global.hideBlizzardBars or blizzardFramesHidden or InCombatLockdown() then return end
    if PlayerFrame and PlayerFrame.PlayerFrameContent and PlayerFrame.PlayerFrameContent.PlayerFrameContentMain then
        local m = PlayerFrame.PlayerFrameContent.PlayerFrameContentMain
        if m.ClassPowerBar then m.ClassPowerBar:SetAlpha(0) end
        if m.ComboPointsFrame then m.ComboPointsFrame:SetAlpha(0) end
        if m.RuneFrame then m.RuneFrame:SetAlpha(0) end
    end
    if PaladinPowerBarFrame then PaladinPowerBarFrame:SetAlpha(0) end
    if WarlockPowerFrame then WarlockPowerFrame:SetAlpha(0) end
    if MonkHarmonyBarFrame then MonkHarmonyBarFrame:SetAlpha(0) end
    if MonkStaggerBar then MonkStaggerBar:SetAlpha(0) end
    if MageArcaneChargesFrame then MageArcaneChargesFrame:SetAlpha(0) end
    if EssencePlayerFrame then EssencePlayerFrame:SetAlpha(0) end
    if RuneFrame then RuneFrame:SetAlpha(0) end
    blizzardFramesHidden = true
end

local function ShowBlizzardResourceFrames()
    if not blizzardFramesHidden or InCombatLockdown() then return end
    if PlayerFrame and PlayerFrame.PlayerFrameContent and PlayerFrame.PlayerFrameContent.PlayerFrameContentMain then
        local m = PlayerFrame.PlayerFrameContent.PlayerFrameContentMain
        if m.ClassPowerBar then m.ClassPowerBar:SetAlpha(1) end
        if m.ComboPointsFrame then m.ComboPointsFrame:SetAlpha(1) end
        if m.RuneFrame then m.RuneFrame:SetAlpha(1) end
    end
    if PaladinPowerBarFrame then PaladinPowerBarFrame:SetAlpha(1) end
    if WarlockPowerFrame then WarlockPowerFrame:SetAlpha(1) end
    if MonkHarmonyBarFrame then MonkHarmonyBarFrame:SetAlpha(1) end
    if MonkStaggerBar then MonkStaggerBar:SetAlpha(1) end
    if MageArcaneChargesFrame then MageArcaneChargesFrame:SetAlpha(1) end
    if EssencePlayerFrame then EssencePlayerFrame:SetAlpha(1) end
    if RuneFrame then RuneFrame:SetAlpha(1) end
    blizzardFramesHidden = false
end

local function RefreshPowerBarLayout()
    if not powerBarFrame then return end
    local cfg = settings.powerBar
    powerBarFrame:SetSize(cfg.width * settings.global.scale, cfg.height * settings.global.scale)
    powerBarFrame:ClearAllPoints()
    powerBarFrame:SetPoint(cfg.anchor, UIParent, cfg.anchor, cfg.positionX, cfg.positionY)
    powerBarFrame.statusBar:SetStatusBarTexture(cfg.texture)
    powerBarFrame.background:SetColorTexture(cfg.backgroundColor[1], cfg.backgroundColor[2], cfg.backgroundColor[3], cfg.backgroundColor[4] or 0.8)
    if cfg.showBorder then
        powerBarFrame.border:Show()
        powerBarFrame.border:SetBackdropBorderColor(cfg.borderColor[1], cfg.borderColor[2], cfg.borderColor[3], cfg.borderColor[4] or 1)
    else
        powerBarFrame.border:Hide()
    end
    powerBarFrame.text:SetFont(STANDARD_TEXT_FONT, cfg.textFontSize, cfg.textFontOutline)
    powerBarFrame.text:SetTextColor(cfg.textColor[1], cfg.textColor[2], cfg.textColor[3], cfg.textColor[4] or 1)
    if cfg.showText then powerBarFrame.text:Show() else powerBarFrame.text:Hide() end
end

local function RefreshClassPowerLayout()
    if not classPowerFrame then return end
    local cfg = settings.classPower
    classPowerFrame:SetSize(cfg.width * settings.global.scale, cfg.height * settings.global.scale)
    classPowerFrame:ClearAllPoints()
    classPowerFrame:SetPoint(cfg.anchor, UIParent, cfg.anchor, cfg.positionX, cfg.positionY)
    classPowerFrame.text:SetFont(STANDARD_TEXT_FONT, cfg.textFontSize, cfg.textFontOutline)
    classPowerFrame.text:SetTextColor(cfg.textColor[1], cfg.textColor[2], cfg.textColor[3], cfg.textColor[4] or 1)
    if cachedMaxSecondary > 0 then UpdateClassPowerSegments(cachedMaxSecondary) end
end

local function RefreshSoulFragmentDisplay()
    if not soulFragmentFrame then return end
    local sfCfg = settings.soulFragments
    local baseSize = 256
    local scaledSize = baseSize * sfCfg.scale
    
    -- Update size and position
    soulFragmentFrame:SetSize(scaledSize, scaledSize)
    soulFragmentFrame:ClearAllPoints()
    soulFragmentFrame:SetPoint(sfCfg.anchor, UIParent, sfCfg.anchor, sfCfg.positionX, sfCfg.positionY)
    
    -- Update texture (with fallback)
    local texturePath = "Interface\\AddOns\\!TweaksUI\\Media\\Textures\\SoulFragments_" .. sfCfg.style
    soulFragmentFrame.texture:SetTexture(texturePath)
    
    -- If texture failed to load, use a fallback
    if not soulFragmentFrame.texture:GetTexture() then
        soulFragmentFrame.texture:SetTexture("Interface\\Icons\\Spell_Shadow_SoulLeech_3")
        soulFragmentFrame.texture:SetTexCoord(0, 1, 0, 1)
    end
    
    -- Update count text
    soulFragmentFrame.countText:SetFont(STANDARD_TEXT_FONT, sfCfg.countFontSize, sfCfg.countFontOutline)
    soulFragmentFrame.countText:ClearAllPoints()
    soulFragmentFrame.countText:SetPoint("CENTER", 0, sfCfg.countOffsetY)
    soulFragmentFrame.countText:SetTextColor(sfCfg.countColor[1], sfCfg.countColor[2], sfCfg.countColor[3], sfCfg.countColor[4] or 1)
    
    -- Update label
    soulFragmentFrame.label:SetFont(STANDARD_TEXT_FONT, sfCfg.labelFontSize, sfCfg.labelFontOutline)
    soulFragmentFrame.label:SetTextColor(sfCfg.labelColor[1], sfCfg.labelColor[2], sfCfg.labelColor[3], sfCfg.labelColor[4] or 1)
    if sfCfg.showLabel then
        soulFragmentFrame.label:Show()
    else
        soulFragmentFrame.label:Hide()
    end
end

local function RefreshAllBars()
    RefreshPowerBarLayout()
    RefreshClassPowerLayout()
    RefreshSoulFragmentDisplay()
    UpdatePowerBar()
    UpdateClassPower()
    UpdateSoulFragments()
    if previewWindow and previewWindow:IsShown() then ResourceBars:UpdatePreview() end
end

local function OnEvent(self, event, ...)
    if event == "PLAYER_ENTERING_WORLD" then
        GetPlayerInfo()
        GetPrimaryResourceValues()
        GetSecondaryResourceValues()
        C_Timer.After(0.5, function()
            if settings and settings.enabled then
                HideBlizzardResourceFrames()
                RefreshAllBars()
                if playerClass == "DEATHKNIGHT" then StartRuneUpdateTicker() end
                if playerClass == "DEMONHUNTER" then StartSoulFragmentTicker() end
            end
        end)
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        GetPlayerInfo()
        GetPrimaryResourceValues()
        GetSecondaryResourceValues()
        RefreshAllBars()
        StopRuneUpdateTicker()
        StopSoulFragmentTicker()
        if playerClass == "DEATHKNIGHT" then StartRuneUpdateTicker() end
        if playerClass == "DEMONHUNTER" then StartSoulFragmentTicker() end
    elseif event == "UPDATE_SHAPESHIFT_FORM" then
        GetSecondaryResourceValues()
        RefreshAllBars()
    elseif event == "UNIT_POWER_UPDATE" or event == "UNIT_POWER_FREQUENT" then
        if ... == "player" then
            UpdatePowerBar()
            -- DK uses rune ticker, DH uses soul fragment ticker
            if playerClass ~= "DEATHKNIGHT" and playerClass ~= "DEMONHUNTER" then 
                UpdateClassPower() 
            end
        end
    elseif event == "UNIT_MAXPOWER" then
        if ... == "player" then
            GetPrimaryResourceValues()
            GetSecondaryResourceValues()
            RefreshAllBars()
        end
    elseif event == "PLAYER_TARGET_CHANGED" or event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED" then
        UpdatePowerBar()
        UpdateClassPower()
    elseif event == "RUNE_POWER_UPDATE" then
        if playerClass == "DEATHKNIGHT" then UpdateClassPower() end
    elseif event == "GROUP_ROSTER_UPDATE" then
        UpdatePowerBar()
        UpdateClassPower()
    end
end

local function RegisterEvents()
    if not eventFrame then
        eventFrame = CreateFrame("Frame")
        eventFrame:SetScript("OnEvent", OnEvent)
    end
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    eventFrame:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
    eventFrame:RegisterEvent("UNIT_POWER_UPDATE")
    eventFrame:RegisterEvent("UNIT_POWER_FREQUENT")
    eventFrame:RegisterEvent("UNIT_MAXPOWER")
    eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("RUNE_POWER_UPDATE")
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
end

local function UnregisterEvents()
    if eventFrame then eventFrame:UnregisterAllEvents() end
end

-- Preview Window
function ResourceBars:CreatePreviewWindow()
    if previewWindow then previewWindow:Show() self:UpdatePreview() return end
    local w = CreateFrame("Frame", "TweaksUI_ResourceBars_Preview", UIParent, "BackdropTemplate")
    w:SetSize(400, 300)
    w:SetPoint("CENTER", 250, 100)
    w:SetBackdrop(darkBackdrop)
    w:SetBackdropColor(0.1, 0.1, 0.1, 0.95)
    w:SetBackdropBorderColor(0.5, 0.5, 0.5, 1)
    w:SetFrameStrata("DIALOG")
    w:SetMovable(true)
    w:EnableMouse(true)
    w:SetClampedToScreen(true)
    w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", w.StartMoving)
    w:SetScript("OnDragStop", w.StopMovingOrSizing)
    
    local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Resource Bars Preview")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, w, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function() w:Hide() if resourceBarsHub and resourceBarsHub.previewBtn then resourceBarsHub.previewBtn:SetText("Show Preview") end end)
    
    local classInfo = w:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    classInfo:SetPoint("TOP", title, "BOTTOM", 0, -8)
    classInfo:SetTextColor(0.8, 0.8, 0.8)
    w.classInfo = classInfo
    
    local container = CreateFrame("Frame", nil, w)
    container:SetPoint("TOPLEFT", 20, -60)
    container:SetPoint("BOTTOMRIGHT", -20, 40)
    
    local pp = CreateFrame("Frame", nil, container, "BackdropTemplate")
    pp:SetSize(200, 16)
    pp:SetPoint("TOP", 0, -20)
    local ppBg = pp:CreateTexture(nil, "BACKGROUND")
    ppBg:SetAllPoints()
    ppBg:SetColorTexture(0.1, 0.1, 0.1, 0.8)
    local ppBar = CreateFrame("StatusBar", nil, pp)
    ppBar:SetAllPoints()
    ppBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    ppBar:SetMinMaxValues(0, 100)
    ppBar:SetValue(75)
    pp.statusBar = ppBar
    local ppBorder = CreateFrame("Frame", nil, pp, "BackdropTemplate")
    ppBorder:SetPoint("TOPLEFT", -1, 1)
    ppBorder:SetPoint("BOTTOMRIGHT", 1, -1)
    ppBorder:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    ppBorder:SetBackdropBorderColor(0, 0, 0, 1)
    pp.border = ppBorder
    local ppText = ppBar:CreateFontString(nil, "OVERLAY")
    ppText:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    ppText:SetPoint("CENTER")
    ppText:SetText("75 / 100")
    pp.text = ppText
    w.powerPreview = pp
    
    local cp = CreateFrame("Frame", nil, container)
    cp:SetSize(200, 12)
    cp:SetPoint("TOP", pp, "BOTTOM", 0, -40)
    w.classPreview = cp
    w.classSegments = {}
    local cpLabel = container:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cpLabel:SetPoint("BOTTOM", cp, "TOP", 0, 4)
    cpLabel:SetText("Class Power")
    cpLabel:SetTextColor(0.7, 0.7, 0.7)
    w.classLabel = cpLabel
    
    previewWindow = w
    self:UpdatePreview()
    w:Show()
end

function ResourceBars:UpdatePreview()
    if not previewWindow then return end
    local _, cn = UnitClass("player")
    local si = GetSpecialization()
    local sn = si and select(2, GetSpecializationInfo(si)) or "No Spec"
    previewWindow.classInfo:SetText(cn .. " - " .. sn)
    
    local cfg = settings.powerBar
    local pt = GetPrimaryResource()
    previewWindow.powerPreview:SetSize(cfg.width, cfg.height)
    local r, g, b
    if cfg.useClassColor then r, g, b = GetClassColor()
    elseif cfg.useResourceColor and pt then r, g, b = GetResourceColor(pt)
    else r, g, b = cfg.customColor[1], cfg.customColor[2], cfg.customColor[3] end
    previewWindow.powerPreview.statusBar:SetStatusBarColor(r, g, b)
    if cfg.showBorder then previewWindow.powerPreview.border:Show() else previewWindow.powerPreview.border:Hide() end
    previewWindow.powerPreview.text:SetFont(STANDARD_TEXT_FONT, cfg.textFontSize, cfg.textFontOutline)
    if cfg.showText then previewWindow.powerPreview.text:Show() else previewWindow.powerPreview.text:Hide() end
    
    local ccfg = settings.classPower
    local rt = GetSecondaryResource()
    local max = cachedMaxSecondary > 0 and cachedMaxSecondary or 5
    local spacing = ccfg.spacing
    local segW = (ccfg.width - spacing * (max - 1)) / max
    
    for i = 1, 7 do
        if not previewWindow.classSegments[i] then
            local seg = CreateFrame("Frame", nil, previewWindow.classPreview, "BackdropTemplate")
            local fill = seg:CreateTexture(nil, "ARTWORK")
            fill:SetAllPoints()
            seg.fill = fill
            local border = CreateFrame("Frame", nil, seg, "BackdropTemplate")
            border:SetPoint("TOPLEFT", -1, 1)
            border:SetPoint("BOTTOMRIGHT", 1, -1)
            border:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
            border:SetBackdropBorderColor(0, 0, 0, 1)
            seg.border = border
            previewWindow.classSegments[i] = seg
        end
        local seg = previewWindow.classSegments[i]
        if i <= max then
            seg:SetSize(segW, ccfg.height)
            seg:ClearAllPoints()
            seg:SetPoint("LEFT", previewWindow.classPreview, "LEFT", (i-1) * (segW + spacing), 0)
            local active = math.min(3, max)
            if i <= active then
                local sr, sg, sb
                if ccfg.usePerPointColors and ccfg.perPointColors[i] then sr, sg, sb = ccfg.perPointColors[i][1], ccfg.perPointColors[i][2], ccfg.perPointColors[i][3]
                elseif ccfg.useClassColor then sr, sg, sb = GetClassColor()
                elseif ccfg.useResourceColor and rt then sr, sg, sb = GetResourceColor(rt)
                else sr, sg, sb = ccfg.customColor[1], ccfg.customColor[2], ccfg.customColor[3] end
                seg.fill:SetColorTexture(sr, sg, sb, 1)
            else
                seg.fill:SetColorTexture(ccfg.inactiveColor[1], ccfg.inactiveColor[2], ccfg.inactiveColor[3], ccfg.inactiveColor[4] or 0.6)
            end
            if ccfg.showBorder then seg.border:Show() else seg.border:Hide() end
            seg:Show()
        else
            seg:Hide()
        end
    end
    previewWindow.classPreview:SetSize(ccfg.width, ccfg.height)
    
    local rn = "Class Power"
    if rt == Enum.PowerType.ComboPoints then rn = "Combo Points"
    elseif rt == Enum.PowerType.HolyPower then rn = "Holy Power"
    elseif rt == Enum.PowerType.SoulShards then rn = "Soul Shards"
    elseif rt == Enum.PowerType.ArcaneCharges then rn = "Arcane Charges"
    elseif rt == Enum.PowerType.Chi then rn = "Chi"
    elseif rt == Enum.PowerType.Essence then rn = "Essence"
    elseif rt == Enum.PowerType.Runes then rn = "Runes"
    elseif rt == SPECIAL_RESOURCES.STAGGER then rn = "Stagger"
    elseif rt == SPECIAL_RESOURCES.SOUL_FRAGMENTS then rn = "Soul Fragments"
    elseif rt == nil then rn = "None" end
    
    if rt then
        previewWindow.classLabel:SetText(rn .. " (" .. max .. " max)")
        previewWindow.classPreview:Show()
    else
        previewWindow.classLabel:SetText("No Secondary Resource")
        previewWindow.classPreview:Hide()
    end
end

function ResourceBars:TogglePreviewWindow()
    if previewWindow and previewWindow:IsShown() then
        previewWindow:Hide()
        if resourceBarsHub and resourceBarsHub.previewBtn then resourceBarsHub.previewBtn:SetText("Show Preview") end
    else
        self:CreatePreviewWindow()
        if resourceBarsHub and resourceBarsHub.previewBtn then resourceBarsHub.previewBtn:SetText("Hide Preview") end
    end
end

-- Settings UI Hub
function ResourceBars:ShowHub(parentPanel)
    if resourceBarsHub then
        resourceBarsHub:ClearAllPoints()
        resourceBarsHub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
        resourceBarsHub:Show()
        return
    end
    
    local hub = CreateFrame("Frame", "TweaksUI_ResourceBars_Hub", UIParent, "BackdropTemplate")
    hub:SetSize(HUB_WIDTH, HUB_HEIGHT)
    hub:SetPoint("TOPLEFT", parentPanel, "TOPRIGHT", 0, 0)
    hub:SetBackdrop(darkBackdrop)
    hub:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    hub:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    hub:SetFrameStrata("DIALOG")
    hub:SetMovable(true)
    hub:EnableMouse(true)
    hub:SetClampedToScreen(true)
    resourceBarsHub = hub
    
    local title = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Resource Bars")
    title:SetTextColor(1, 0.82, 0)
    
    local closeBtn = CreateFrame("Button", nil, hub, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -3, -3)
    closeBtn:SetScript("OnClick", function() self:HideAllPanels() end)
    
    hub:SetScript("OnHide", function()
        for _, p in pairs(settingsPanels) do if p and p.Hide then p:Hide() end end
        currentOpenPanel = nil
    end)
    
    hub:RegisterForDrag("LeftButton")
    hub:SetScript("OnDragStart", hub.StartMoving)
    hub:SetScript("OnDragStop", hub.StopMovingOrSizing)
    
    local yOff = -42
    local bw = HUB_WIDTH - 20
    
    local sl = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sl:SetPoint("TOP", 0, yOff)
    sl:SetText("|cff888888Settings|r")
    yOff = yOff - 16
    
    local buttons = { 
        {id="general",name="General"}, 
        {id="powerbar",name="Power Bar"}, 
        {id="classpower",name="Class Power"}, 
        {id="visibility",name="Visibility"} 
    }
    
    -- Add Soul Fragments button for Demon Hunters
    if playerClass == "DEMONHUNTER" then
        table.insert(buttons, {id="soulfragments",name="Soul Fragments"})
    end
    
    for _, cat in ipairs(buttons) do
        local btn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
        btn:SetSize(bw, BUTTON_HEIGHT)
        btn:SetPoint("TOP", 0, yOff)
        btn:SetText(cat.name)
        btn:SetScript("OnClick", function() self:TogglePanel(cat.id) end)
        yOff = yOff - BUTTON_HEIGHT - BUTTON_SPACING
    end
    
    yOff = yOff - 8
    local sep = hub:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOP", 0, yOff)
    sep:SetSize(bw, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    yOff = yOff - 12
    
    local tl = hub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    tl:SetPoint("TOP", 0, yOff)
    tl:SetText("|cff888888Tools|r")
    yOff = yOff - 20
    
    local pvBtn = CreateFrame("Button", nil, hub, "UIPanelButtonTemplate")
    pvBtn:SetSize(bw, BUTTON_HEIGHT)
    pvBtn:SetPoint("TOP", 0, yOff)
    pvBtn:SetText("Show Preview")
    pvBtn:SetScript("OnClick", function() self:TogglePreviewWindow() end)
    hub.previewBtn = pvBtn
    
    hub:Show()
end

function ResourceBars:HideAllPanels()
    if resourceBarsHub then resourceBarsHub:Hide() end
    for _, p in pairs(settingsPanels) do if p and p.Hide then p:Hide() end end
    currentOpenPanel = nil
    if previewWindow then previewWindow:Hide() end
    if resourceBarsHub and resourceBarsHub.previewBtn then resourceBarsHub.previewBtn:SetText("Show Preview") end
end

local function CreateSettingsPanel(panelId, panelTitle, createContent)
    local panel = CreateFrame("Frame", "TweaksUI_ResourceBars_" .. panelId, UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    panel:SetBackdrop(darkBackdrop)
    panel:SetBackdropColor(0.08, 0.08, 0.08, 0.95)
    panel:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
    panel:SetFrameStrata("DIALOG")
    panel:EnableMouse(true)
    panel:Hide()
    
    local t = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOP", 0, -12)
    t:SetText(panelTitle)
    t:SetTextColor(1, 0.82, 0)
    
    local cb = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    cb:SetPoint("TOPRIGHT", -3, -3)
    cb:SetScript("OnClick", function() panel:Hide() end)
    
    local sf = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, -40)
    sf:SetPoint("BOTTOMRIGHT", -30, 12)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetSize(PANEL_WIDTH - 50, 800)
    sf:SetScrollChild(sc)
    panel.scrollChild = sc
    
    if createContent then createContent(sc) end
    settingsPanels[panelId] = panel
    return panel
end

function ResourceBars:TogglePanel(panelId)
    if currentOpenPanel and currentOpenPanel ~= panelId and settingsPanels[currentOpenPanel] then
        settingsPanels[currentOpenPanel]:Hide()
    end
    if not settingsPanels[panelId] then self:CreatePanel(panelId) end
    local panel = settingsPanels[panelId]
    if not panel then return end
    if panel:IsShown() then
        panel:Hide()
        currentOpenPanel = nil
    else
        panel:ClearAllPoints()
        panel:SetPoint("TOPLEFT", resourceBarsHub, "TOPRIGHT", 0, 0)
        panel:Show()
        currentOpenPanel = panelId
    end
end

local function CreateCheckbox(parent, x, y, label, getFunc, setFunc)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    cb:SetSize(24, 24)
    cb:SetChecked(getFunc())
    local txt = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    txt:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    txt:SetText(label)
    cb:SetScript("OnClick", function(self) setFunc(self:GetChecked()) RefreshAllBars() end)
    return y - 26
end

local function CreateSlider(parent, x, y, label, min, max, step, getFunc, setFunc)
    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    lbl:SetPoint("TOPLEFT", x, y)
    lbl:SetText(label .. ": " .. getFunc())
    local sl = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    sl:SetPoint("TOPLEFT", x, y - 18)
    sl:SetSize(200, 17)
    sl:SetMinMaxValues(min, max)
    sl:SetValueStep(step)
    sl:SetObeyStepOnDrag(true)
    sl.Low:SetText(min)
    sl.High:SetText(max)
    local init = true
    sl:SetScript("OnValueChanged", function(self, v)
        if init then return end
        v = math.floor(v / step + 0.5) * step
        lbl:SetText(label .. ": " .. v)
        setFunc(v)
        RefreshAllBars()
    end)
    sl:SetValue(getFunc())
    init = false
    return y - 50
end

local function CreateColorPicker(parent, x, y, label, color)
    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    lbl:SetPoint("TOPLEFT", x + 28, y)
    lbl:SetText(label)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetPoint("TOPLEFT", x, y - 4)
    btn:SetSize(22, 22)
    btn:SetBackdrop({ bgFile = "Interface\\BUTTONS\\WHITE8X8", edgeFile = "Interface\\BUTTONS\\WHITE8X8", edgeSize = 1 })
    btn:SetBackdropColor(color[1], color[2], color[3], color[4] or 1)
    btn:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    btn:SetScript("OnClick", function()
        local r, g, b, a = color[1], color[2], color[3], color[4] or 1
        ColorPickerFrame:SetColorRGB(r, g, b)
        ColorPickerFrame.hasOpacity = true
        ColorPickerFrame.opacity = 1 - a
        ColorPickerFrame.func = function()
            local nr, ng, nb = ColorPickerFrame:GetColorRGB()
            local na = 1 - ColorPickerFrame.opacity
            color[1], color[2], color[3], color[4] = nr, ng, nb, na
            btn:SetBackdropColor(nr, ng, nb, na)
            RefreshAllBars()
        end
        ColorPickerFrame.opacityFunc = ColorPickerFrame.func
        ColorPickerFrame.cancelFunc = function() btn:SetBackdropColor(r, g, b, a) color[1], color[2], color[3], color[4] = r, g, b, a end
        ColorPickerFrame:Show()
    end)
    return y - 28
end

local function CreateDropdown(parent, x, y, label, options, getFunc, setFunc)
    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    lbl:SetPoint("TOPLEFT", x, y)
    lbl:SetText(label)
    local dd = CreateFrame("Frame", "TweaksUI_RB_DD_" .. label:gsub(" ", ""), parent, "UIDropDownMenuTemplate")
    dd:SetPoint("TOPLEFT", x - 16, y - 18)
    UIDropDownMenu_SetWidth(dd, 150)
    local curVal = getFunc()
    local curText = curVal
    for _, o in ipairs(options) do if o.id == curVal then curText = o.name break end end
    UIDropDownMenu_SetText(dd, curText)
    UIDropDownMenu_Initialize(dd, function(self, level)
        for _, o in ipairs(options) do
            local info = UIDropDownMenu_CreateInfo()
            info.text, info.value, info.checked = o.name, o.id, (getFunc() == o.id)
            info.func = function() setFunc(o.id) UIDropDownMenu_SetText(dd, o.name) RefreshAllBars() end
            UIDropDownMenu_AddButton(info)
        end
    end)
    return y - 50
end

local function CreateHeader(parent, x, y, text)
    local h = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    h:SetPoint("TOPLEFT", x, y)
    h:SetText("|cffffcc00" .. text .. "|r")
    return y - 20
end

local function CreateSeparator(parent, y)
    local sep = parent:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT", 0, y)
    sep:SetSize(PANEL_WIDTH - 60, 1)
    sep:SetColorTexture(0.4, 0.4, 0.4, 0.6)
    return y - 15
end

function ResourceBars:CreatePanel(panelId)
    if panelId == "general" then
        CreateSettingsPanel("general", "General Settings", function(p)
            local y = -10
            y = CreateSlider(p, 10, y, "Global Scale", 0.5, 2, 0.05,
                function() return settings.global.scale end,
                function(v) settings.global.scale = v end)
            y = CreateCheckbox(p, 10, y, "Hide Blizzard Resource Bars",
                function() return settings.global.hideBlizzardBars end,
                function(c) settings.global.hideBlizzardBars = c if c then HideBlizzardResourceFrames() else ShowBlizzardResourceFrames() end end)
            y = CreateSeparator(p, y - 10)
            local info = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            info:SetPoint("TOPLEFT", 10, y)
            info:SetWidth(PANEL_WIDTH - 70)
            info:SetJustifyH("LEFT")
            info:SetText("|cff888888Use Blizzard's Edit Mode (ESC > Edit Mode) to reposition the resource bars.|r")
            y = y - 40
            local rb = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            rb:SetPoint("TOPLEFT", 10, y)
            rb:SetSize(140, 26)
            rb:SetText("Reset Positions")
            rb:SetScript("OnClick", function()
                settings.powerBar.positionX, settings.powerBar.positionY, settings.powerBar.anchor = 0, -200, "CENTER"
                settings.classPower.positionX, settings.classPower.positionY, settings.classPower.anchor = 0, -220, "CENTER"
                RefreshAllBars()
                TweaksUI:Print("Positions reset")
            end)
        end)
    elseif panelId == "powerbar" then
        CreateSettingsPanel("powerbar", "Power Bar", function(p)
            local y, cfg = -10, settings.powerBar
            
            y = CreateCheckbox(p, 10, y, "Enable Power Bar",
                function() return cfg.enabled end, function(c) cfg.enabled = c end)
            
            y = CreateHeader(p, 10, y - 10, "Size")
            y = CreateSlider(p, 10, y, "Width", 50, 400, 5, function() return cfg.width end, function(v) cfg.width = v end)
            y = CreateSlider(p, 10, y, "Height", 4, 40, 1, function() return cfg.height end, function(v) cfg.height = v end)
            
            y = CreateHeader(p, 10, y - 10, "Appearance")
            y = CreateCheckbox(p, 10, y, "Show Border", function() return cfg.showBorder end, function(c) cfg.showBorder = c end)
            y = CreateColorPicker(p, 10, y, "Background", cfg.backgroundColor)
            y = CreateColorPicker(p, 10, y, "Border Color", cfg.borderColor)
            
            y = CreateHeader(p, 10, y - 10, "Bar Color")
            y = CreateCheckbox(p, 10, y, "Use Class Color", function() return cfg.useClassColor end,
                function(c) cfg.useClassColor = c if c then cfg.useResourceColor = false end end)
            y = CreateCheckbox(p, 10, y, "Use Resource Color", function() return cfg.useResourceColor end,
                function(c) cfg.useResourceColor = c if c then cfg.useClassColor = false end end)
            y = CreateColorPicker(p, 10, y, "Custom Color", cfg.customColor)
            
            y = CreateHeader(p, 10, y - 10, "Text")
            y = CreateCheckbox(p, 10, y, "Show Text", function() return cfg.showText end, function(c) cfg.showText = c end)
            y = CreateDropdown(p, 10, y, "Text Format", TEXT_FORMATS, function() return cfg.textFormat end, function(v) cfg.textFormat = v end)
            y = CreateSlider(p, 10, y, "Font Size", 8, 24, 1, function() return cfg.textFontSize end, function(v) cfg.textFontSize = v end)
            y = CreateColorPicker(p, 10, y, "Text Color", cfg.textColor)
            
            y = CreateHeader(p, 10, y - 10, "Visibility (OR logic)")
            y = CreateCheckbox(p, 10, y, "Enable Visibility Conditions",
                function() return cfg.visibilityEnabled end, function(c) cfg.visibilityEnabled = c end)
            y = CreateCheckbox(p, 10, y, "In Combat", function() return cfg.showInCombat end, function(c) cfg.showInCombat = c end)
            y = CreateCheckbox(p, 10, y, "Out of Combat", function() return cfg.showOutOfCombat end, function(c) cfg.showOutOfCombat = c end)
            y = CreateCheckbox(p, 10, y, "Has Target", function() return cfg.showHasTarget end, function(c) cfg.showHasTarget = c end)
            y = CreateCheckbox(p, 10, y, "No Target", function() return cfg.showNoTarget end, function(c) cfg.showNoTarget = c end)
            y = CreateCheckbox(p, 10, y, "Solo", function() return cfg.showSolo end, function(c) cfg.showSolo = c end)
            y = CreateCheckbox(p, 10, y, "In Party", function() return cfg.showInParty end, function(c) cfg.showInParty = c end)
            y = CreateCheckbox(p, 10, y, "In Raid", function() return cfg.showInRaid end, function(c) cfg.showInRaid = c end)
            y = CreateCheckbox(p, 10, y, "In Instance", function() return cfg.showInInstance end, function(c) cfg.showInInstance = c end)
            
            y = CreateHeader(p, 10, y - 10, "Fade")
            y = CreateCheckbox(p, 10, y, "Enable Fade", function() return cfg.fadeEnabled end, function(c) cfg.fadeEnabled = c end)
            y = CreateSlider(p, 10, y, "Fade Delay (sec)", 0, 10, 0.5, function() return cfg.fadeDelay end, function(v) cfg.fadeDelay = v end)
            y = CreateSlider(p, 10, y, "Fade Alpha", 0, 1, 0.05, function() return cfg.fadeAlpha end, function(v) cfg.fadeAlpha = v end)
        end)
    elseif panelId == "classpower" then
        CreateSettingsPanel("classpower", "Class Power", function(p)
            local y, cfg = -10, settings.classPower
            
            y = CreateCheckbox(p, 10, y, "Enable Class Power",
                function() return cfg.enabled end, function(c) cfg.enabled = c end)
            
            y = CreateHeader(p, 10, y - 10, "Size")
            y = CreateSlider(p, 10, y, "Width", 50, 400, 5, function() return cfg.width end, function(v) cfg.width = v end)
            y = CreateSlider(p, 10, y, "Height", 4, 30, 1, function() return cfg.height end, function(v) cfg.height = v end)
            y = CreateSlider(p, 10, y, "Spacing", 0, 10, 1, function() return cfg.spacing end, function(v) cfg.spacing = v end)
            
            y = CreateHeader(p, 10, y - 10, "Appearance")
            y = CreateCheckbox(p, 10, y, "Show Border", function() return cfg.showBorder end, function(c) cfg.showBorder = c end)
            y = CreateColorPicker(p, 10, y, "Inactive Color", cfg.inactiveColor)
            y = CreateColorPicker(p, 10, y, "Border Color", cfg.borderColor)
            
            y = CreateHeader(p, 10, y - 10, "Segment Color")
            y = CreateCheckbox(p, 10, y, "Use Class Color", function() return cfg.useClassColor end,
                function(c) cfg.useClassColor = c if c then cfg.useResourceColor = false cfg.usePerPointColors = false end end)
            y = CreateCheckbox(p, 10, y, "Use Resource Color", function() return cfg.useResourceColor end,
                function(c) cfg.useResourceColor = c if c then cfg.useClassColor = false cfg.usePerPointColors = false end end)
            y = CreateCheckbox(p, 10, y, "Per-Point Gradient", function() return cfg.usePerPointColors end,
                function(c) cfg.usePerPointColors = c if c then cfg.useClassColor = false cfg.useResourceColor = false end end)
            y = CreateColorPicker(p, 10, y, "Custom Color", cfg.customColor)
            
            if cfg.usePerPointColors or true then -- Always show for reference
                y = CreateHeader(p, 10, y - 10, "Per-Point Colors")
                for i = 1, 7 do
                    y = CreateColorPicker(p, 10, y, "Point " .. i, cfg.perPointColors[i])
                end
            end
            
            y = CreateHeader(p, 10, y - 10, "Text")
            y = CreateCheckbox(p, 10, y, "Show Text", function() return cfg.showText end, function(c) cfg.showText = c end)
            y = CreateSlider(p, 10, y, "Font Size", 8, 24, 1, function() return cfg.textFontSize end, function(v) cfg.textFontSize = v end)
            
            if playerClass == "DEATHKNIGHT" then
                y = CreateHeader(p, 10, y - 10, "Runes")
                y = CreateCheckbox(p, 10, y, "Show Cooldown Text",
                    function() return settings.runes.showCooldownText end, function(c) settings.runes.showCooldownText = c end)
                y = CreateCheckbox(p, 10, y, "Sort by Recharge",
                    function() return settings.runes.sortByRecharge end, function(c) settings.runes.sortByRecharge = c end)
                y = CreateSlider(p, 10, y, "Cooldown Font Size", 6, 16, 1,
                    function() return settings.runes.cooldownFontSize end, function(v) settings.runes.cooldownFontSize = v end)
            end
            
            y = CreateHeader(p, 10, y - 10, "Visibility (OR logic)")
            y = CreateCheckbox(p, 10, y, "Enable Visibility Conditions",
                function() return cfg.visibilityEnabled end, function(c) cfg.visibilityEnabled = c end)
            y = CreateCheckbox(p, 10, y, "In Combat", function() return cfg.showInCombat end, function(c) cfg.showInCombat = c end)
            y = CreateCheckbox(p, 10, y, "Out of Combat", function() return cfg.showOutOfCombat end, function(c) cfg.showOutOfCombat = c end)
            y = CreateCheckbox(p, 10, y, "Has Target", function() return cfg.showHasTarget end, function(c) cfg.showHasTarget = c end)
            y = CreateCheckbox(p, 10, y, "No Target", function() return cfg.showNoTarget end, function(c) cfg.showNoTarget = c end)
            y = CreateCheckbox(p, 10, y, "Solo", function() return cfg.showSolo end, function(c) cfg.showSolo = c end)
            y = CreateCheckbox(p, 10, y, "In Party", function() return cfg.showInParty end, function(c) cfg.showInParty = c end)
            y = CreateCheckbox(p, 10, y, "In Raid", function() return cfg.showInRaid end, function(c) cfg.showInRaid = c end)
            y = CreateCheckbox(p, 10, y, "In Instance", function() return cfg.showInInstance end, function(c) cfg.showInInstance = c end)
            
            y = CreateHeader(p, 10, y - 10, "Fade")
            y = CreateCheckbox(p, 10, y, "Enable Fade", function() return cfg.fadeEnabled end, function(c) cfg.fadeEnabled = c end)
            y = CreateSlider(p, 10, y, "Fade Delay (sec)", 0, 10, 0.5, function() return cfg.fadeDelay end, function(v) cfg.fadeDelay = v end)
            y = CreateSlider(p, 10, y, "Fade Alpha", 0, 1, 0.05, function() return cfg.fadeAlpha end, function(v) cfg.fadeAlpha = v end)
        end)
    elseif panelId == "visibility" then
        CreateSettingsPanel("visibility", "Visibility Settings", function(p)
            local y = -10
            
            y = CreateHeader(p, 10, y, "Power Bar")
            y = CreateCheckbox(p, 10, y, "Enable Visibility Conditions",
                function() return settings.powerBar.visibilityEnabled end,
                function(c) settings.powerBar.visibilityEnabled = c end)
            y = CreateCheckbox(p, 10, y, "In Combat", function() return settings.powerBar.showInCombat end, function(c) settings.powerBar.showInCombat = c end)
            y = CreateCheckbox(p, 10, y, "Out of Combat", function() return settings.powerBar.showOutOfCombat end, function(c) settings.powerBar.showOutOfCombat = c end)
            y = CreateCheckbox(p, 10, y, "Has Target", function() return settings.powerBar.showHasTarget end, function(c) settings.powerBar.showHasTarget = c end)
            y = CreateCheckbox(p, 10, y, "No Target", function() return settings.powerBar.showNoTarget end, function(c) settings.powerBar.showNoTarget = c end)
            y = CreateCheckbox(p, 10, y, "Solo", function() return settings.powerBar.showSolo end, function(c) settings.powerBar.showSolo = c end)
            y = CreateCheckbox(p, 10, y, "In Party", function() return settings.powerBar.showInParty end, function(c) settings.powerBar.showInParty = c end)
            y = CreateCheckbox(p, 10, y, "In Raid", function() return settings.powerBar.showInRaid end, function(c) settings.powerBar.showInRaid = c end)
            y = CreateCheckbox(p, 10, y, "In Instance", function() return settings.powerBar.showInInstance end, function(c) settings.powerBar.showInInstance = c end)
            
            y = CreateHeader(p, 10, y - 10, "Power Bar Fade")
            y = CreateCheckbox(p, 10, y, "Enable Fade", function() return settings.powerBar.fadeEnabled end, function(c) settings.powerBar.fadeEnabled = c end)
            y = CreateSlider(p, 10, y, "Fade Delay (sec)", 0, 10, 0.5, function() return settings.powerBar.fadeDelay end, function(v) settings.powerBar.fadeDelay = v end)
            y = CreateSlider(p, 10, y, "Fade Alpha", 0, 1, 0.05, function() return settings.powerBar.fadeAlpha end, function(v) settings.powerBar.fadeAlpha = v end)
            
            y = CreateSeparator(p, y - 10)
            
            y = CreateHeader(p, 10, y - 5, "Class Power")
            y = CreateCheckbox(p, 10, y, "Enable Visibility Conditions",
                function() return settings.classPower.visibilityEnabled end,
                function(c) settings.classPower.visibilityEnabled = c end)
            y = CreateCheckbox(p, 10, y, "In Combat", function() return settings.classPower.showInCombat end, function(c) settings.classPower.showInCombat = c end)
            y = CreateCheckbox(p, 10, y, "Out of Combat", function() return settings.classPower.showOutOfCombat end, function(c) settings.classPower.showOutOfCombat = c end)
            y = CreateCheckbox(p, 10, y, "Has Target", function() return settings.classPower.showHasTarget end, function(c) settings.classPower.showHasTarget = c end)
            y = CreateCheckbox(p, 10, y, "No Target", function() return settings.classPower.showNoTarget end, function(c) settings.classPower.showNoTarget = c end)
            y = CreateCheckbox(p, 10, y, "Solo", function() return settings.classPower.showSolo end, function(c) settings.classPower.showSolo = c end)
            y = CreateCheckbox(p, 10, y, "In Party", function() return settings.classPower.showInParty end, function(c) settings.classPower.showInParty = c end)
            y = CreateCheckbox(p, 10, y, "In Raid", function() return settings.classPower.showInRaid end, function(c) settings.classPower.showInRaid = c end)
            y = CreateCheckbox(p, 10, y, "In Instance", function() return settings.classPower.showInInstance end, function(c) settings.classPower.showInInstance = c end)
            
            y = CreateHeader(p, 10, y - 10, "Class Power Fade")
            y = CreateCheckbox(p, 10, y, "Enable Fade", function() return settings.classPower.fadeEnabled end, function(c) settings.classPower.fadeEnabled = c end)
            y = CreateSlider(p, 10, y, "Fade Delay (sec)", 0, 10, 0.5, function() return settings.classPower.fadeDelay end, function(v) settings.classPower.fadeDelay = v end)
            y = CreateSlider(p, 10, y, "Fade Alpha", 0, 1, 0.05, function() return settings.classPower.fadeAlpha end, function(v) settings.classPower.fadeAlpha = v end)
            
            -- Soul Fragments visibility (Demon Hunter only)
            if playerClass == "DEMONHUNTER" then
                y = CreateSeparator(p, y - 10)
                
                y = CreateHeader(p, 10, y - 5, "Soul Fragments")
                y = CreateCheckbox(p, 10, y, "Enable Visibility Conditions",
                    function() return settings.soulFragments.visibilityEnabled end,
                    function(c) settings.soulFragments.visibilityEnabled = c end)
                y = CreateCheckbox(p, 10, y, "In Combat", function() return settings.soulFragments.showInCombat end, function(c) settings.soulFragments.showInCombat = c end)
                y = CreateCheckbox(p, 10, y, "Out of Combat", function() return settings.soulFragments.showOutOfCombat end, function(c) settings.soulFragments.showOutOfCombat = c end)
                y = CreateCheckbox(p, 10, y, "Has Target", function() return settings.soulFragments.showHasTarget end, function(c) settings.soulFragments.showHasTarget = c end)
                y = CreateCheckbox(p, 10, y, "No Target", function() return settings.soulFragments.showNoTarget end, function(c) settings.soulFragments.showNoTarget = c end)
                y = CreateCheckbox(p, 10, y, "Solo", function() return settings.soulFragments.showSolo end, function(c) settings.soulFragments.showSolo = c end)
                y = CreateCheckbox(p, 10, y, "In Party", function() return settings.soulFragments.showInParty end, function(c) settings.soulFragments.showInParty = c end)
                y = CreateCheckbox(p, 10, y, "In Raid", function() return settings.soulFragments.showInRaid end, function(c) settings.soulFragments.showInRaid = c end)
                y = CreateCheckbox(p, 10, y, "In Instance", function() return settings.soulFragments.showInInstance end, function(c) settings.soulFragments.showInInstance = c end)
                
                y = CreateHeader(p, 10, y - 10, "Soul Fragments Fade")
                y = CreateCheckbox(p, 10, y, "Enable Fade", function() return settings.soulFragments.fadeEnabled end, function(c) settings.soulFragments.fadeEnabled = c end)
                y = CreateSlider(p, 10, y, "Fade Delay (sec)", 0, 10, 0.5, function() return settings.soulFragments.fadeDelay end, function(v) settings.soulFragments.fadeDelay = v end)
                y = CreateSlider(p, 10, y, "Fade Alpha", 0, 1, 0.05, function() return settings.soulFragments.fadeAlpha end, function(v) settings.soulFragments.fadeAlpha = v end)
            end
        end)
    elseif panelId == "soulfragments" then
        CreateSettingsPanel("soulfragments", "Soul Fragments", function(p)
            local y = -10
            local cfg = settings.soulFragments
            
            y = CreateCheckbox(p, 10, y, "Enable Soul Fragments Display", 
                function() return cfg.enabled end, 
                function(c) 
                    cfg.enabled = c 
                    if c then 
                        if not soulFragmentFrame then CreateSoulFragmentFrame() end
                        StartSoulFragmentTicker()
                    else 
                        StopSoulFragmentTicker()
                        if soulFragmentFrame then soulFragmentFrame:Hide() end
                    end
                end)
            
            y = CreateSeparator(p, y - 5)
            
            y = CreateHeader(p, 10, y - 5, "Display Style")
            
            local styleOptions = { { value = "flame", label = "Flame" }, { value = "fel", label = "Fel" }, { value = "void", label = "Void" } }
            y = CreateDropdown(p, 10, y, "Style", styleOptions, 
                function() return cfg.style end, 
                function(v) cfg.style = v RefreshSoulFragmentDisplay() end)
            
            y = CreateSlider(p, 10, y, "Scale", 0.1, 1.0, 0.05, 
                function() return cfg.scale end, 
                function(v) cfg.scale = v RefreshSoulFragmentDisplay() end)
            
            y = CreateHeader(p, 10, y - 10, "Count Text")
            y = CreateSlider(p, 10, y, "Font Size", 12, 48, 1, 
                function() return cfg.countFontSize end, 
                function(v) cfg.countFontSize = v RefreshSoulFragmentDisplay() end)
            
            local outlineOptions = { { value = "NONE", label = "None" }, { value = "OUTLINE", label = "Outline" }, { value = "THICKOUTLINE", label = "Thick Outline" } }
            y = CreateDropdown(p, 10, y, "Font Outline", outlineOptions, 
                function() return cfg.countFontOutline end, 
                function(v) cfg.countFontOutline = v RefreshSoulFragmentDisplay() end)
            
            y = CreateColorPicker(p, 10, y, "Count Color", cfg.countColor)
            
            y = CreateSlider(p, 10, y, "Vertical Offset", -50, 50, 1, 
                function() return cfg.countOffsetY end, 
                function(v) cfg.countOffsetY = v RefreshSoulFragmentDisplay() end)
            
            y = CreateHeader(p, 10, y - 10, "Label")
            y = CreateCheckbox(p, 10, y, "Show Label", 
                function() return cfg.showLabel end, 
                function(c) cfg.showLabel = c RefreshSoulFragmentDisplay() end)
            
            y = CreateSlider(p, 10, y, "Label Font Size", 8, 24, 1, 
                function() return cfg.labelFontSize end, 
                function(v) cfg.labelFontSize = v RefreshSoulFragmentDisplay() end)
            
            y = CreateDropdown(p, 10, y, "Label Font Outline", outlineOptions, 
                function() return cfg.labelFontOutline end, 
                function(v) cfg.labelFontOutline = v RefreshSoulFragmentDisplay() end)
            
            y = CreateColorPicker(p, 10, y, "Label Color", cfg.labelColor)
            
            y = CreateSeparator(p, y - 10)
            
            local info = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            info:SetPoint("TOPLEFT", 10, y - 5)
            info:SetWidth(PANEL_WIDTH - 70)
            info:SetJustifyH("LEFT")
            info:SetText("|cff888888Place custom textures in:\n!TweaksUI/Media/Textures/\nNamed: SoulFragments_flame.tga\nSoulFragments_fel.tga\nSoulFragments_void.tga\n\nUse Edit Mode to position the display.|r")
        end)
    end
end

-- Module Lifecycle
function ResourceBars:OnInitialize()
    local db = TweaksUI.Database:GetModuleSettings(self.id)
    if not db then
        db = DeepCopy(DEFAULT_SETTINGS)
        TweaksUI.Database:SaveModuleSettings(self.id, db)
    end
    EnsureDefaults(db, DEFAULT_SETTINGS)
    settings = db
    GetPlayerInfo()
end

function ResourceBars:OnEnable()
    if not settings then return end
    settings.enabled = true
    CreatePowerBar()
    CreateClassPowerFrame()
    if playerClass == "DEMONHUNTER" then CreateSoulFragmentFrame() end
    RegisterEvents()
    C_Timer.After(0.1, HideBlizzardResourceFrames)
    if playerClass == "DEATHKNIGHT" then StartRuneUpdateTicker() end
    if playerClass == "DEMONHUNTER" then StartSoulFragmentTicker() end
    C_Timer.After(0.2, RefreshAllBars)
    TweaksUI:Print("Resource Bars |cff00ff00enabled|r")
end

function ResourceBars:OnDisable()
    if not settings then return end
    settings.enabled = false
    UnregisterEvents()
    StopRuneUpdateTicker()
    StopSoulFragmentTicker()
    if powerBarFrame then powerBarFrame:Hide() end
    if classPowerFrame then classPowerFrame:Hide() end
    if soulFragmentFrame then soulFragmentFrame:Hide() end
    ShowBlizzardResourceFrames()
    TweaksUI:Print("Resource Bars |cffff0000disabled|r")
end

function ResourceBars:GetSettings() return settings end
function ResourceBars:SaveSettings() if settings then TweaksUI.Database:SaveModuleSettings(self.id, settings) end end
function ResourceBars:RefreshAll() RefreshAllBars() end

TweaksUI.ResourceBars = ResourceBars
